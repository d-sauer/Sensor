--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: c_users; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE c_users (
    id bigint NOT NULL,
    email character varying(100) NOT NULL,
    user_name character varying(100) NOT NULL,
    password character varying(50),
    first_name character varying(50),
    last_name character varying(50),
    phone_land character varying(20),
    phone_mobile character varying(20),
    city character varying(50),
    post_number character varying(10),
    street character varying(100),
    active integer DEFAULT 0
);


ALTER TABLE public.c_users OWNER TO dsauer;

--
-- Name: c_users_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE c_users_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.c_users_seq OWNER TO dsauer;

--
-- Name: c_users_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('c_users_seq', 20, true);


--
-- Name: play_evolutions; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE play_evolutions (
    id integer NOT NULL,
    hash character varying(255) NOT NULL,
    applied_at timestamp without time zone NOT NULL,
    apply_script text,
    revert_script text,
    state character varying(255),
    last_problem text
);


ALTER TABLE public.play_evolutions OWNER TO dsauer;

--
-- Name: s_data_customs; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_customs (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    data_type character varying(9),
    cool double precision,
    CONSTRAINT ck_s_data_customs_data_type CHECK (((data_type)::text = ANY ((ARRAY['issRecept'::character varying, 'arcInt'::character varying])::text[])))
);


ALTER TABLE public.s_data_customs OWNER TO dsauer;

--
-- Name: s_data_customs_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_customs_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_customs_seq OWNER TO dsauer;

--
-- Name: s_data_customs_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_customs_seq', 1, false);


--
-- Name: s_data_degree_days; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_degree_days (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    heat double precision,
    cool double precision
);


ALTER TABLE public.s_data_degree_days OWNER TO dsauer;

--
-- Name: s_data_degree_days_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_degree_days_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_degree_days_seq OWNER TO dsauer;

--
-- Name: s_data_degree_days_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_degree_days_seq', 2120, true);


--
-- Name: s_data_densitys; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_densitys (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    density double precision
);


ALTER TABLE public.s_data_densitys OWNER TO dsauer;

--
-- Name: s_data_densitys_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_densitys_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_densitys_seq OWNER TO dsauer;

--
-- Name: s_data_densitys_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_densitys_seq', 2120, true);


--
-- Name: s_data_emc; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_emc (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    emc double precision
);


ALTER TABLE public.s_data_emc OWNER TO dsauer;

--
-- Name: s_data_emc_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_emc_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_emc_seq OWNER TO dsauer;

--
-- Name: s_data_emc_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_emc_seq', 2120, true);


--
-- Name: s_data_humiditys; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_humiditys (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    humidity double precision,
    absolute_humidity double precision,
    relative_humidity double precision,
    specific_humidity double precision
);


ALTER TABLE public.s_data_humiditys OWNER TO dsauer;

--
-- Name: s_data_humiditys_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_humiditys_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_humiditys_seq OWNER TO dsauer;

--
-- Name: s_data_humiditys_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_humiditys_seq', 6540, true);


--
-- Name: s_data_moistures; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_moistures (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    moisture double precision
);


ALTER TABLE public.s_data_moistures OWNER TO dsauer;

--
-- Name: s_data_moistures_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_moistures_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_moistures_seq OWNER TO dsauer;

--
-- Name: s_data_moistures_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_moistures_seq', 4420, true);


--
-- Name: s_data_pressures; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_pressures (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    pressure_pascal double precision,
    pressure_bar double precision
);


ALTER TABLE public.s_data_pressures OWNER TO dsauer;

--
-- Name: s_data_pressures_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_pressures_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_pressures_seq OWNER TO dsauer;

--
-- Name: s_data_pressures_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_pressures_seq', 2120, true);


--
-- Name: s_data_rains; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_rains (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    rain double precision,
    raint_rate double precision
);


ALTER TABLE public.s_data_rains OWNER TO dsauer;

--
-- Name: s_data_rains_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_rains_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_rains_seq OWNER TO dsauer;

--
-- Name: s_data_rains_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_rains_seq', 2120, true);


--
-- Name: s_data_temperatures; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_temperatures (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    temperature double precision,
    heat double precision,
    heatindex double precision,
    thwindex double precision
);


ALTER TABLE public.s_data_temperatures OWNER TO dsauer;

--
-- Name: s_data_temperatures_high_low; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_temperatures_high_low (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    heat_high double precision,
    heat_low double precision,
    temperature_high double precision,
    temperature_low double precision
);


ALTER TABLE public.s_data_temperatures_high_low OWNER TO dsauer;

--
-- Name: s_data_temperatures_high_low_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_temperatures_high_low_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_temperatures_high_low_seq OWNER TO dsauer;

--
-- Name: s_data_temperatures_high_low_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_temperatures_high_low_seq', 2340, true);


--
-- Name: s_data_temperatures_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_temperatures_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_temperatures_seq OWNER TO dsauer;

--
-- Name: s_data_temperatures_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_temperatures_seq', 8600, true);


--
-- Name: s_data_wetness; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_wetness (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    wetness double precision,
    dry double precision,
    dew_point double precision,
    precipitation double precision
);


ALTER TABLE public.s_data_wetness OWNER TO dsauer;

--
-- Name: s_data_wetness_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_wetness_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_wetness_seq OWNER TO dsauer;

--
-- Name: s_data_wetness_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_wetness_seq', 6540, true);


--
-- Name: s_data_winds; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_winds (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    wind_speed double precision,
    wind_run double precision,
    direction character varying(255),
    direction_degree integer,
    wind_chill double precision,
    wind_sample double precision,
    wind_tx double precision
);


ALTER TABLE public.s_data_winds OWNER TO dsauer;

--
-- Name: s_data_winds_high_low; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_data_winds_high_low (
    id bigint NOT NULL,
    sensor_id bigint,
    sensor_data_id bigint,
    date_time timestamp without time zone NOT NULL,
    high_speed double precision,
    high_speed_direction character varying(255),
    high_speed_direction_degree integer,
    low_speed double precision,
    low_speed_direction character varying(255),
    low_speed_direction_degree integer
);


ALTER TABLE public.s_data_winds_high_low OWNER TO dsauer;

--
-- Name: s_data_winds_high_low_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_winds_high_low_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_winds_high_low_seq OWNER TO dsauer;

--
-- Name: s_data_winds_high_low_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_winds_high_low_seq', 2340, true);


--
-- Name: s_data_winds_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_data_winds_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_data_winds_seq OWNER TO dsauer;

--
-- Name: s_data_winds_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_data_winds_seq', 2340, true);


--
-- Name: s_sensor_group_properties; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_sensor_group_properties (
    id bigint NOT NULL,
    group_id bigint,
    property character varying(70) NOT NULL,
    value character varying(400),
    user_label character varying(255),
    user_description character varying(500),
    db_table character varying(255),
    db_column character varying(255),
    updated timestamp without time zone NOT NULL
);


ALTER TABLE public.s_sensor_group_properties OWNER TO dsauer;

--
-- Name: s_sensor_group_properties_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_sensor_group_properties_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_sensor_group_properties_seq OWNER TO dsauer;

--
-- Name: s_sensor_group_properties_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_sensor_group_properties_seq', 40, true);


--
-- Name: s_sensor_groups; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_sensor_groups (
    id bigint NOT NULL,
    user_id bigint,
    name character varying(100) NOT NULL,
    description character varying(400),
    active boolean,
    visible boolean,
    sensor_group_class character varying(300)
);


ALTER TABLE public.s_sensor_groups OWNER TO dsauer;

--
-- Name: s_sensor_groups_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_sensor_groups_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_sensor_groups_seq OWNER TO dsauer;

--
-- Name: s_sensor_groups_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_sensor_groups_seq', 200, true);


--
-- Name: s_sensor_properties; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_sensor_properties (
    id bigint NOT NULL,
    sensor_id bigint,
    property character varying(70) NOT NULL,
    value character varying(400),
    user_label character varying(255),
    user_description character varying(500),
    db_table character varying(255),
    db_column character varying(255),
    updated timestamp without time zone NOT NULL
);


ALTER TABLE public.s_sensor_properties OWNER TO dsauer;

--
-- Name: s_sensor_properties_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_sensor_properties_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_sensor_properties_seq OWNER TO dsauer;

--
-- Name: s_sensor_properties_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_sensor_properties_seq', 280, true);


--
-- Name: s_sensor_raw_data; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_sensor_raw_data (
    id bigint NOT NULL,
    group_id bigint,
    when_created timestamp without time zone NOT NULL,
    date_time timestamp without time zone NOT NULL,
    data text
);


ALTER TABLE public.s_sensor_raw_data OWNER TO dsauer;

--
-- Name: s_sensor_raw_data_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_sensor_raw_data_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_sensor_raw_data_seq OWNER TO dsauer;

--
-- Name: s_sensor_raw_data_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_sensor_raw_data_seq', 2340, true);


--
-- Name: s_sensors; Type: TABLE; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE TABLE s_sensors (
    id bigint NOT NULL,
    group_id bigint,
    user_id bigint,
    name character varying(100) NOT NULL,
    description character varying(400),
    last_update timestamp without time zone,
    active boolean,
    visible boolean,
    sensor_class character varying(300)
);


ALTER TABLE public.s_sensors OWNER TO dsauer;

--
-- Name: s_sensors_seq; Type: SEQUENCE; Schema: public; Owner: dsauer
--

CREATE SEQUENCE s_sensors_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.s_sensors_seq OWNER TO dsauer;

--
-- Name: s_sensors_seq; Type: SEQUENCE SET; Schema: public; Owner: dsauer
--

SELECT pg_catalog.setval('s_sensors_seq', 280, true);


--
-- Data for Name: c_users; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY c_users (id, email, user_name, password, first_name, last_name, phone_land, phone_mobile, city, post_number, street, active) FROM stdin;
1	davor@sauer	davor@sauer	anita5	Davor	Sauer		09189	Varaždin	42000	Zagrebačka 74/1	-1
\.


--
-- Data for Name: play_evolutions; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY play_evolutions (id, hash, applied_at, apply_script, revert_script, state, last_problem) FROM stdin;
1	900236923131764c9be1a99b39a9a94a6be89cef	2012-11-28 00:00:00	create table c_users (\nid                        bigint not null,\nemail                     varchar(100) not null,\nuser_name                 varchar(100) not null,\npassword                  varchar(50),\nfirst_name                varchar(50),\nlast_name                 varchar(50),\nphone_land                varchar(20),\nphone_mobile              varchar(20),\ncity                      varchar(50),\npost_number               varchar(10),\nstreet                    varchar(100),\nactive                    integer default 0,\nconstraint uq_c_users_email unique (email),\nconstraint uq_c_users_user_name unique (user_name),\nconstraint pk_c_users primary key (id))\n;\n\ncreate table s_sensors (\nid                        bigint not null,\ngroup_id                  bigint,\nuser_id                   bigint,\nname                      varchar(100) not null,\ndescription               varchar(400),\nlast_update               timestamp,\nactive                    boolean,\nvisible                   boolean,\nsensor_class              varchar(300),\nconstraint pk_s_sensors primary key (id))\n;\n\ncreate table s_sensor_raw_data (\nid                        bigint not null,\ngroup_id                  bigint,\nwhen_created              timestamp not null,\ndate_time                 timestamp not null,\ndata                      text,\nconstraint pk_s_sensor_raw_data primary key (id))\n;\n\ncreate table s_data_customs (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\ndata_type                 varchar(9),\ncool                      float,\nconstraint ck_s_data_customs_data_type check (data_type in ('issRecept','arcInt')),\nconstraint pk_s_data_customs primary key (id))\n;\n\ncreate table s_data_degree_days (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\nheat                      float,\ncool                      float,\nconstraint pk_s_data_degree_days primary key (id))\n;\n\ncreate table s_data_densitys (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\ndensity                   float,\nconstraint pk_s_data_densitys primary key (id))\n;\n\ncreate table s_data_emc (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\nemc                       float,\nconstraint pk_s_data_emc primary key (id))\n;\n\ncreate table s_data_humiditys (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\nhumidity                  float,\nabsolute_humidity         float,\nrelative_humidity         float,\nspecific_humidity         float,\nconstraint pk_s_data_humiditys primary key (id))\n;\n\ncreate table s_data_moistures (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\nmoisture                  float,\nconstraint pk_s_data_moistures primary key (id))\n;\n\ncreate table s_data_pressures (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\npressure_pascal           float,\npressure_bar              float,\nconstraint pk_s_data_pressures primary key (id))\n;\n\ncreate table s_data_rains (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\nrain                      float,\nraint_rate                float,\nconstraint pk_s_data_rains primary key (id))\n;\n\ncreate table s_data_temperatures (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\ntemperature               float,\nheat                      float,\nheatIndex                 float,\nthwIndex                  float,\nconstraint pk_s_data_temperatures primary key (id))\n;\n\ncreate table s_data_temperatures_high_low (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\nheat_high                 float,\nheat_low                  float,\ntemperature_high          float,\ntemperature_low           float,\nconstraint pk_s_data_temperatures_high_low primary key (id))\n;\n\ncreate table s_data_wetness (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\nwetness                   float,\ndry                       float,\ndew_point                 float,\nprecipitation             float,\nconstraint pk_s_data_wetness primary key (id))\n;\n\ncreate table s_data_winds (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\nwind_speed                float,\nwind_run                  float,\ndirection                 varchar(255),\ndirection_degree          integer,\nwind_chill                float,\nwind_sample               float,\nwind_tx                   float,\nconstraint pk_s_data_winds primary key (id))\n;\n\ncreate table s_data_winds_high_low (\nid                        bigint not null,\nsensor_id                 bigint,\nsensor_data_id            bigint,\ndate_time                 timestamp not null,\nhigh_speed                float,\nhigh_speed_direction      varchar(255),\nhigh_speed_direction_degree integer,\nlow_speed                 float,\nlow_speed_direction       varchar(255),\nlow_speed_direction_degree integer,\nconstraint pk_s_data_winds_high_low primary key (id))\n;\n\ncreate table s_sensor_groups (\nid                        bigint not null,\nuser_id                   bigint,\nname                      varchar(100) not null,\ndescription               varchar(400),\nactive                    boolean,\nvisible                   boolean,\nsensor_group_class        varchar(300),\nconstraint pk_s_sensor_groups primary key (id))\n;\n\ncreate table s_sensor_group_properties (\nid                        bigint not null,\ngroup_id                  bigint,\nproperty                  varchar(70) not null,\nvalue                     varchar(400),\nuser_label                varchar(255),\nuser_description          varchar(500),\ndb_table                  varchar(255),\ndb_column                 varchar(255),\nupdated                   timestamp not null,\nconstraint pk_s_sensor_group_properties primary key (id))\n;\n\ncreate table s_sensor_properties (\nid                        bigint not null,\nsensor_id                 bigint,\nproperty                  varchar(70) not null,\nvalue                     varchar(400),\nuser_label                varchar(255),\nuser_description          varchar(500),\ndb_table                  varchar(255),\ndb_column                 varchar(255),\nupdated                   timestamp not null,\nconstraint pk_s_sensor_properties primary key (id))\n;\n\ncreate sequence c_users_seq;\n\ncreate sequence s_sensors_seq;\n\ncreate sequence s_sensor_raw_data_seq;\n\ncreate sequence s_data_customs_seq;\n\ncreate sequence s_data_degree_days_seq;\n\ncreate sequence s_data_densitys_seq;\n\ncreate sequence s_data_emc_seq;\n\ncreate sequence s_data_humiditys_seq;\n\ncreate sequence s_data_moistures_seq;\n\ncreate sequence s_data_pressures_seq;\n\ncreate sequence s_data_rains_seq;\n\ncreate sequence s_data_temperatures_seq;\n\ncreate sequence s_data_temperatures_high_low_seq;\n\ncreate sequence s_data_wetness_seq;\n\ncreate sequence s_data_winds_seq;\n\ncreate sequence s_data_winds_high_low_seq;\n\ncreate sequence s_sensor_groups_seq;\n\ncreate sequence s_sensor_group_properties_seq;\n\ncreate sequence s_sensor_properties_seq;\n\nalter table s_sensors add constraint fk_s_sensors_group_1 foreign key (group_id) references s_sensor_groups (id);\ncreate index ix_s_sensors_group_1 on s_sensors (group_id);\nalter table s_sensors add constraint fk_s_sensors_user_2 foreign key (user_id) references c_users (id);\ncreate index ix_s_sensors_user_2 on s_sensors (user_id);\nalter table s_sensor_raw_data add constraint fk_s_sensor_raw_data_group_3 foreign key (group_id) references s_sensor_groups (id);\ncreate index ix_s_sensor_raw_data_group_3 on s_sensor_raw_data (group_id);\nalter table s_data_customs add constraint fk_s_data_customs_sensor_4 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_customs_sensor_4 on s_data_customs (sensor_id);\nalter table s_data_customs add constraint fk_s_data_customs_sensorData_5 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_customs_sensorData_5 on s_data_customs (sensor_data_id);\nalter table s_data_degree_days add constraint fk_s_data_degree_days_sensor_6 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_degree_days_sensor_6 on s_data_degree_days (sensor_id);\nalter table s_data_degree_days add constraint fk_s_data_degree_days_sensorDa_7 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_degree_days_sensorDa_7 on s_data_degree_days (sensor_data_id);\nalter table s_data_densitys add constraint fk_s_data_densitys_sensor_8 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_densitys_sensor_8 on s_data_densitys (sensor_id);\nalter table s_data_densitys add constraint fk_s_data_densitys_sensorData_9 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_densitys_sensorData_9 on s_data_densitys (sensor_data_id);\nalter table s_data_emc add constraint fk_s_data_emc_sensor_10 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_emc_sensor_10 on s_data_emc (sensor_id);\nalter table s_data_emc add constraint fk_s_data_emc_sensorData_11 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_emc_sensorData_11 on s_data_emc (sensor_data_id);\nalter table s_data_humiditys add constraint fk_s_data_humiditys_sensor_12 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_humiditys_sensor_12 on s_data_humiditys (sensor_id);\nalter table s_data_humiditys add constraint fk_s_data_humiditys_sensorDat_13 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_humiditys_sensorDat_13 on s_data_humiditys (sensor_data_id);\nalter table s_data_moistures add constraint fk_s_data_moistures_sensor_14 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_moistures_sensor_14 on s_data_moistures (sensor_id);\nalter table s_data_moistures add constraint fk_s_data_moistures_sensorDat_15 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_moistures_sensorDat_15 on s_data_moistures (sensor_data_id);\nalter table s_data_pressures add constraint fk_s_data_pressures_sensor_16 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_pressures_sensor_16 on s_data_pressures (sensor_id);\nalter table s_data_pressures add constraint fk_s_data_pressures_sensorDat_17 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_pressures_sensorDat_17 on s_data_pressures (sensor_data_id);\nalter table s_data_rains add constraint fk_s_data_rains_sensor_18 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_rains_sensor_18 on s_data_rains (sensor_id);\nalter table s_data_rains add constraint fk_s_data_rains_sensorData_19 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_rains_sensorData_19 on s_data_rains (sensor_data_id);\nalter table s_data_temperatures add constraint fk_s_data_temperatures_sensor_20 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_temperatures_sensor_20 on s_data_temperatures (sensor_id);\nalter table s_data_temperatures add constraint fk_s_data_temperatures_sensor_21 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_temperatures_sensor_21 on s_data_temperatures (sensor_data_id);\nalter table s_data_temperatures_high_low add constraint fk_s_data_temperatures_high_l_22 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_temperatures_high_l_22 on s_data_temperatures_high_low (sensor_id);\nalter table s_data_temperatures_high_low add constraint fk_s_data_temperatures_high_l_23 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_temperatures_high_l_23 on s_data_temperatures_high_low (sensor_data_id);\nalter table s_data_wetness add constraint fk_s_data_wetness_sensor_24 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_wetness_sensor_24 on s_data_wetness (sensor_id);\nalter table s_data_wetness add constraint fk_s_data_wetness_sensorData_25 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_wetness_sensorData_25 on s_data_wetness (sensor_data_id);\nalter table s_data_winds add constraint fk_s_data_winds_sensor_26 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_winds_sensor_26 on s_data_winds (sensor_id);\nalter table s_data_winds add constraint fk_s_data_winds_sensorData_27 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_winds_sensorData_27 on s_data_winds (sensor_data_id);\nalter table s_data_winds_high_low add constraint fk_s_data_winds_high_low_sens_28 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_data_winds_high_low_sens_28 on s_data_winds_high_low (sensor_id);\nalter table s_data_winds_high_low add constraint fk_s_data_winds_high_low_sens_29 foreign key (sensor_data_id) references s_sensor_raw_data (id);\ncreate index ix_s_data_winds_high_low_sens_29 on s_data_winds_high_low (sensor_data_id);\nalter table s_sensor_groups add constraint fk_s_sensor_groups_user_30 foreign key (user_id) references c_users (id);\ncreate index ix_s_sensor_groups_user_30 on s_sensor_groups (user_id);\nalter table s_sensor_group_properties add constraint fk_s_sensor_group_properties__31 foreign key (group_id) references s_sensor_groups (id);\ncreate index ix_s_sensor_group_properties__31 on s_sensor_group_properties (group_id);\nalter table s_sensor_properties add constraint fk_s_sensor_properties_sensor_32 foreign key (sensor_id) references s_sensors (id);\ncreate index ix_s_sensor_properties_sensor_32 on s_sensor_properties (sensor_id);	drop table if exists c_users cascade;\n\ndrop table if exists s_sensors cascade;\n\ndrop table if exists s_sensor_raw_data cascade;\n\ndrop table if exists s_data_customs cascade;\n\ndrop table if exists s_data_degree_days cascade;\n\ndrop table if exists s_data_densitys cascade;\n\ndrop table if exists s_data_emc cascade;\n\ndrop table if exists s_data_humiditys cascade;\n\ndrop table if exists s_data_moistures cascade;\n\ndrop table if exists s_data_pressures cascade;\n\ndrop table if exists s_data_rains cascade;\n\ndrop table if exists s_data_temperatures cascade;\n\ndrop table if exists s_data_temperatures_high_low cascade;\n\ndrop table if exists s_data_wetness cascade;\n\ndrop table if exists s_data_winds cascade;\n\ndrop table if exists s_data_winds_high_low cascade;\n\ndrop table if exists s_sensor_groups cascade;\n\ndrop table if exists s_sensor_group_properties cascade;\n\ndrop table if exists s_sensor_properties cascade;\n\ndrop sequence if exists c_users_seq;\n\ndrop sequence if exists s_sensors_seq;\n\ndrop sequence if exists s_sensor_raw_data_seq;\n\ndrop sequence if exists s_data_customs_seq;\n\ndrop sequence if exists s_data_degree_days_seq;\n\ndrop sequence if exists s_data_densitys_seq;\n\ndrop sequence if exists s_data_emc_seq;\n\ndrop sequence if exists s_data_humiditys_seq;\n\ndrop sequence if exists s_data_moistures_seq;\n\ndrop sequence if exists s_data_pressures_seq;\n\ndrop sequence if exists s_data_rains_seq;\n\ndrop sequence if exists s_data_temperatures_seq;\n\ndrop sequence if exists s_data_temperatures_high_low_seq;\n\ndrop sequence if exists s_data_wetness_seq;\n\ndrop sequence if exists s_data_winds_seq;\n\ndrop sequence if exists s_data_winds_high_low_seq;\n\ndrop sequence if exists s_sensor_groups_seq;\n\ndrop sequence if exists s_sensor_group_properties_seq;\n\ndrop sequence if exists s_sensor_properties_seq;	applied	
\.


--
-- Data for Name: s_data_customs; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_customs (id, sensor_id, sensor_data_id, date_time, data_type, cool) FROM stdin;
\.


--
-- Data for Name: s_data_degree_days; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_degree_days (id, sensor_id, sensor_data_id, date_time, heat, cool) FROM stdin;
1581	249	1801	2012-11-22 00:30:00	0.20399999999999999	0
1582	249	1802	2012-11-22 01:00:00	0.20399999999999999	0
1583	249	1803	2012-11-22 01:30:00	0.20399999999999999	0
1584	249	1804	2012-11-22 02:00:00	0.20599999999999999	0
1585	249	1805	2012-11-22 02:30:00	0.20599999999999999	0
1586	249	1806	2012-11-22 03:00:00	0.20699999999999999	0
1587	249	1807	2012-11-22 03:30:00	0.20599999999999999	0
1588	249	1808	2012-11-22 04:00:00	0.20799999999999999	0
1589	249	1809	2012-11-22 04:30:00	0.20799999999999999	0
1590	249	1810	2012-11-22 05:00:00	0.20899999999999999	0
1591	249	1811	2012-11-22 05:30:00	0.20799999999999999	0
1592	249	1812	2012-11-22 06:00:00	0.20899999999999999	0
1593	249	1813	2012-11-22 06:30:00	0.20799999999999999	0
1594	249	1814	2012-11-22 07:00:00	0.20799999999999999	0
1595	249	1815	2012-11-22 07:30:00	0.20599999999999999	0
1596	249	1816	2012-11-22 08:00:00	0.20300000000000001	0
1597	249	1817	2012-11-22 08:30:00	0.19700000000000001	0
1598	249	1818	2012-11-22 09:00:00	0.191	0
1599	249	1819	2012-11-22 09:30:00	0.188	0
1600	249	1820	2012-11-22 10:00:00	0.183	0
1601	249	1821	2012-11-22 10:30:00	0.18099999999999999	0
1602	249	1822	2012-11-22 11:00:00	0.17899999999999999	0
1603	249	1823	2012-11-22 11:30:00	0.17399999999999999	0
1604	249	1824	2012-11-22 12:00:00	0.17199999999999999	0
1605	249	1825	2012-11-22 12:30:00	0.16900000000000001	0
1606	249	1826	2012-11-22 13:00:00	0.16700000000000001	0
1607	249	1827	2012-11-22 13:30:00	0.16900000000000001	0
1608	249	1828	2012-11-22 14:00:00	0.17000000000000001	0
1609	249	1829	2012-11-22 14:30:00	0.17000000000000001	0
1610	249	1830	2012-11-22 15:00:00	0.17000000000000001	0
1611	249	1831	2012-11-22 15:30:00	0.17199999999999999	0
1612	249	1832	2012-11-22 16:00:00	0.17499999999999999	0
1613	249	1833	2012-11-22 16:30:00	0.17699999999999999	0
1614	249	1834	2012-11-22 17:00:00	0.17899999999999999	0
1615	249	1835	2012-11-22 17:30:00	0.183	0
1616	249	1836	2012-11-22 18:00:00	0.186	0
1617	249	1837	2012-11-22 18:30:00	0.188	0
1618	249	1838	2012-11-22 19:00:00	0.189	0
1619	249	1839	2012-11-22 19:30:00	0.19	0
1620	249	1840	2012-11-22 20:00:00	0.192	0
1621	249	1841	2012-11-22 20:30:00	0.19400000000000001	0
1622	249	1842	2012-11-22 21:00:00	0.19600000000000001	0
1623	249	1843	2012-11-22 21:30:00	0.19700000000000001	0
1624	249	1844	2012-11-22 22:00:00	0.19800000000000001	0
1625	249	1845	2012-11-22 22:30:00	0.19800000000000001	0
1626	249	1846	2012-11-22 23:00:00	0.19900000000000001	0
1627	249	1847	2012-11-22 23:30:00	0.20100000000000001	0
1628	249	1848	2012-11-23 00:00:00	0.20300000000000001	0
1629	249	1849	2012-11-23 00:30:00	0.20399999999999999	0
1630	249	1850	2012-11-23 01:00:00	0.20599999999999999	0
1631	249	1851	2012-11-23 01:30:00	0.20799999999999999	0
1632	249	1852	2012-11-23 02:00:00	0.20899999999999999	0
1633	249	1853	2012-11-23 02:30:00	0.21099999999999999	0
1634	249	1854	2012-11-23 03:00:00	0.21099999999999999	0
1635	249	1855	2012-11-23 03:30:00	0.21199999999999999	0
1636	249	1856	2012-11-23 04:00:00	0.21199999999999999	0
1637	249	1857	2012-11-23 04:30:00	0.21299999999999999	0
1638	249	1858	2012-11-23 05:00:00	0.214	0
1639	249	1859	2012-11-23 05:30:00	0.214	0
1640	249	1860	2012-11-23 06:00:00	0.214	0
1641	249	1861	2012-11-23 06:30:00	0.215	0
1642	249	1862	2012-11-23 07:00:00	0.215	0
1643	249	1863	2012-11-23 07:30:00	0.215	0
1644	249	1864	2012-11-23 08:00:00	0.214	0
1645	249	1865	2012-11-23 08:30:00	0.21099999999999999	0
1646	249	1866	2012-11-23 09:00:00	0.20799999999999999	0
1647	249	1867	2012-11-23 09:30:00	0.20499999999999999	0
1648	249	1868	2012-11-23 10:00:00	0.20100000000000001	0
1649	249	1869	2012-11-23 10:30:00	0.20300000000000001	0
1650	249	1870	2012-11-23 11:00:00	0.20000000000000001	0
1651	249	1871	2012-11-23 11:30:00	0.19800000000000001	0
1652	249	1872	2012-11-23 12:00:00	0.192	0
1653	249	1873	2012-11-23 12:30:00	0.185	0
1654	249	1874	2012-11-23 13:00:00	0.17699999999999999	0
1655	249	1875	2012-11-23 13:30:00	0.17199999999999999	0
1656	249	1876	2012-11-23 14:00:00	0.17000000000000001	0
1657	249	1877	2012-11-23 14:30:00	0.17100000000000001	0
1658	249	1878	2012-11-23 15:00:00	0.17399999999999999	0
1659	249	1879	2012-11-23 15:30:00	0.17799999999999999	0
1660	249	1880	2012-11-23 16:00:00	0.183	0
1661	249	1881	2012-11-23 16:30:00	0.186	0
1662	249	1882	2012-11-23 17:00:00	0.188	0
1663	249	1883	2012-11-23 17:30:00	0.19	0
1664	249	1884	2012-11-23 18:00:00	0.192	0
1665	249	1885	2012-11-23 18:30:00	0.193	0
1666	249	1886	2012-11-23 19:00:00	0.193	0
1667	249	1887	2012-11-23 19:30:00	0.19400000000000001	0
1668	249	1888	2012-11-23 20:00:00	0.19400000000000001	0
1669	249	1889	2012-11-23 20:30:00	0.19600000000000001	0
1670	249	1890	2012-11-23 21:00:00	0.19800000000000001	0
1671	249	1891	2012-11-23 21:30:00	0.19800000000000001	0
1672	249	1892	2012-11-23 22:00:00	0.19900000000000001	0
1673	249	1893	2012-11-23 22:30:00	0.19900000000000001	0
1674	249	1894	2012-11-23 23:00:00	0.20399999999999999	0
1675	249	1895	2012-11-23 23:30:00	0.20799999999999999	0
1676	249	1896	2012-11-24 00:00:00	0.214	0
1677	249	1897	2012-11-24 00:30:00	0.219	0
1678	249	1898	2012-11-24 01:00:00	0.218	0
1679	249	1899	2012-11-24 01:30:00	0.216	0
1680	249	1900	2012-11-24 02:00:00	0.221	0
1681	249	1901	2012-11-24 02:30:00	0.22700000000000001	0
1682	249	1902	2012-11-24 03:00:00	0.23499999999999999	0
1683	249	1903	2012-11-24 03:30:00	0.24299999999999999	0
1684	249	1904	2012-11-24 04:00:00	0.25600000000000001	0
1685	249	1905	2012-11-24 04:30:00	0.25800000000000001	0
1686	249	1906	2012-11-24 05:00:00	0.255	0
1687	249	1907	2012-11-24 05:30:00	0.252	0
1688	249	1908	2012-11-24 06:00:00	0.253	0
1689	249	1909	2012-11-24 06:30:00	0.253	0
1690	249	1910	2012-11-24 07:00:00	0.255	0
1691	249	1911	2012-11-24 07:30:00	0.249	0
1692	249	1912	2012-11-24 08:00:00	0.23699999999999999	0
1693	249	1913	2012-11-24 08:30:00	0.22500000000000001	0
1694	249	1914	2012-11-24 09:00:00	0.216	0
1695	249	1915	2012-11-24 09:30:00	0.191	0
1696	249	1916	2012-11-24 10:00:00	0.17499999999999999	0
1697	249	1917	2012-11-24 10:30:00	0.16300000000000001	0
1698	249	1918	2012-11-24 11:00:00	0.14099999999999999	0
1699	249	1919	2012-11-24 11:30:00	0.14199999999999999	0
1700	249	1920	2012-11-24 12:00:00	0.13700000000000001	0
1701	249	1921	2012-11-24 12:30:00	0.128	0
1702	249	1922	2012-11-24 13:00:00	0.127	0
1703	249	1923	2012-11-24 13:30:00	0.125	0
1704	249	1924	2012-11-24 14:00:00	0.125	0
1705	249	1925	2012-11-24 14:30:00	0.123	0
1706	249	1926	2012-11-24 15:00:00	0.11600000000000001	0
1707	249	1927	2012-11-24 15:30:00	0.13900000000000001	0
1708	249	1928	2012-11-24 16:00:00	0.157	0
1709	249	1929	2012-11-24 16:30:00	0.17899999999999999	0
1710	249	1930	2012-11-24 17:00:00	0.19600000000000001	0
1711	249	1931	2012-11-24 17:30:00	0.20799999999999999	0
1712	249	1932	2012-11-24 18:00:00	0.23100000000000001	0
1713	249	1933	2012-11-24 18:30:00	0.248	0
1714	249	1934	2012-11-24 19:00:00	0.26300000000000001	0
1715	249	1935	2012-11-24 19:30:00	0.28399999999999997	0
1716	249	1936	2012-11-24 20:00:00	0.29099999999999998	0
1717	249	1937	2012-11-24 20:30:00	0.29499999999999998	0
1718	249	1938	2012-11-24 21:00:00	0.29699999999999999	0
1719	249	1939	2012-11-24 21:30:00	0.30599999999999999	0
1720	249	1940	2012-11-24 22:00:00	0.30599999999999999	0
1721	249	1941	2012-11-24 22:30:00	0.31	0
1722	249	1942	2012-11-24 23:00:00	0.32400000000000001	0
1723	249	1943	2012-11-24 23:30:00	0.33400000000000002	0
1724	249	1944	2012-11-25 00:00:00	0.33400000000000002	0
1725	249	1945	2012-11-25 00:30:00	0.34300000000000003	0
1726	249	1946	2012-11-25 01:00:00	0.34499999999999997	0
1727	249	1947	2012-11-25 01:30:00	0.34300000000000003	0
1728	249	1948	2012-11-25 02:00:00	0.33200000000000002	0
1729	249	1949	2012-11-25 02:30:00	0.32300000000000001	0
1730	249	1950	2012-11-25 03:00:00	0.31900000000000001	0
1731	249	1951	2012-11-25 03:30:00	0.31900000000000001	0
1732	249	1952	2012-11-25 04:00:00	0.315	0
1733	249	1953	2012-11-25 04:30:00	0.31	0
1734	249	1954	2012-11-25 05:00:00	0.311	0
1735	249	1955	2012-11-25 05:30:00	0.308	0
1736	249	1956	2012-11-25 06:00:00	0.309	0
1737	249	1957	2012-11-25 06:30:00	0.31	0
1738	249	1958	2012-11-25 07:00:00	0.315	0
1739	249	1959	2012-11-25 07:30:00	0.315	0
1740	249	1960	2012-11-25 08:00:00	0.314	0
1741	249	1961	2012-11-25 08:30:00	0.313	0
1742	249	1962	2012-11-25 09:00:00	0.29899999999999999	0
1743	249	1963	2012-11-25 09:30:00	0.29099999999999998	0
1744	249	1964	2012-11-25 10:00:00	0.27500000000000002	0
1745	249	1965	2012-11-25 10:30:00	0.25800000000000001	0
1746	249	1966	2012-11-25 11:00:00	0.24099999999999999	0
1747	249	1967	2012-11-25 11:30:00	0.222	0
1748	249	1968	2012-11-25 12:00:00	0.21099999999999999	0
1749	249	1969	2012-11-25 12:30:00	0.186	0
1750	249	1970	2012-11-25 13:00:00	0.17199999999999999	0
1751	249	1971	2012-11-25 13:30:00	0.16400000000000001	0
1752	249	1972	2012-11-25 14:00:00	0.16900000000000001	0
1753	249	1973	2012-11-25 14:30:00	0.17699999999999999	0
1754	249	1974	2012-11-25 15:00:00	0.19600000000000001	0
1755	249	1975	2012-11-25 15:30:00	0.20799999999999999	0
1756	249	1976	2012-11-25 16:00:00	0.21199999999999999	0
1757	249	1977	2012-11-25 16:30:00	0.215	0
1758	249	1978	2012-11-25 17:00:00	0.215	0
1759	249	1979	2012-11-25 17:30:00	0.215	0
1760	249	1980	2012-11-25 18:00:00	0.214	0
1761	249	1981	2012-11-25 18:30:00	0.216	0
1762	249	1982	2012-11-25 19:00:00	0.22	0
1763	249	1983	2012-11-25 19:30:00	0.22	0
1764	249	1984	2012-11-25 20:00:00	0.219	0
1765	249	1985	2012-11-25 20:30:00	0.22	0
1766	249	1986	2012-11-25 21:00:00	0.221	0
1767	249	1987	2012-11-25 21:30:00	0.223	0
1768	249	1988	2012-11-25 22:00:00	0.22700000000000001	0
1769	249	1989	2012-11-25 22:30:00	0.23000000000000001	0
1770	249	1990	2012-11-25 23:00:00	0.23400000000000001	0
1771	249	1991	2012-11-25 23:30:00	0.23400000000000001	0
1772	249	1992	2012-11-26 00:00:00	0.23699999999999999	0
1773	249	1993	2012-11-26 00:30:00	0.24399999999999999	0
1774	249	1994	2012-11-26 01:00:00	0.24399999999999999	0
1775	249	1995	2012-11-26 01:30:00	0.24399999999999999	0
1776	249	1996	2012-11-26 02:00:00	0.245	0
1777	249	1997	2012-11-26 02:30:00	0.247	0
1778	249	1998	2012-11-26 03:00:00	0.249	0
1779	249	1999	2012-11-26 03:30:00	0.25	0
1780	249	2000	2012-11-26 04:00:00	0.253	0
1781	249	2001	2012-11-26 04:30:00	0.251	0
1782	249	2002	2012-11-26 05:00:00	0.25	0
1783	249	2003	2012-11-26 05:30:00	0.249	0
1784	249	2004	2012-11-26 06:00:00	0.248	0
1785	249	2005	2012-11-26 06:30:00	0.245	0
1786	249	2006	2012-11-26 07:00:00	0.24299999999999999	0
1787	249	2007	2012-11-26 07:30:00	0.24099999999999999	0
1788	249	2008	2012-11-26 08:00:00	0.23499999999999999	0
1789	249	2009	2012-11-26 08:30:00	0.22600000000000001	0
1790	249	2010	2012-11-26 09:00:00	0.20799999999999999	0
1791	249	2011	2012-11-26 09:30:00	0.17199999999999999	0
1792	249	2012	2012-11-26 10:00:00	0.13500000000000001	0
1793	249	2013	2012-11-26 10:30:00	0.125	0
1794	249	2014	2012-11-26 11:00:00	0.11799999999999999	0
1795	249	2015	2012-11-26 11:30:00	0.11	0
1803	249	2023	2012-11-26 15:30:00	0.057000000000000002	0
1806	249	2026	2012-11-26 17:00:00	0.075999999999999998	0
1808	249	2028	2012-11-26 18:00:00	0.084000000000000005	0
1809	249	2029	2012-11-26 18:30:00	0.096000000000000002	0
1823	249	2043	2012-11-27 01:30:00	0.13200000000000001	0
1832	249	2052	2012-11-27 06:00:00	0.161	0
1838	249	2058	2012-11-27 09:00:00	0.10000000000000001	0
1796	249	2016	2012-11-26 12:00:00	0.108	0
1797	249	2017	2012-11-26 12:30:00	0.10000000000000001	0
1801	249	2021	2012-11-26 14:30:00	0.042999999999999997	0
1807	249	2027	2012-11-26 17:30:00	0.075999999999999998	0
1820	249	2040	2012-11-27 00:00:00	0.13800000000000001	0
1839	249	2059	2012-11-27 09:30:00	0.105	0
1798	249	2018	2012-11-26 13:00:00	0.095000000000000001	0
1818	249	2038	2012-11-26 23:00:00	0.11899999999999999	0
1799	249	2019	2012-11-26 13:30:00	0.074999999999999997	0
1802	249	2022	2012-11-26 15:00:00	0.044999999999999998	0
1811	249	2031	2012-11-26 19:30:00	0.113	0
1816	249	2036	2012-11-26 22:00:00	0.13300000000000001	0
1821	249	2041	2012-11-27 00:30:00	0.13200000000000001	0
1835	249	2055	2012-11-27 07:30:00	0.14199999999999999	0
1841	249	2061	2012-11-27 10:30:00	0.057000000000000002	0
1844	249	2064	2012-11-27 12:00:00	0.039	0
1845	249	2065	2012-11-27 12:30:00	0.031	0
1846	249	2066	2012-11-27 13:00:00	0.035999999999999997	0
1800	249	2020	2012-11-26 14:00:00	0.053999999999999999	0
1804	249	2024	2012-11-26 16:00:00	0.080000000000000002	0
1812	249	2032	2012-11-26 20:00:00	0.11899999999999999	0
1826	249	2046	2012-11-27 03:00:00	0.11799999999999999	0
1843	249	2063	2012-11-27 11:30:00	0.047	0
1805	249	2025	2012-11-26 16:30:00	0.078	0
1815	249	2035	2012-11-26 21:30:00	0.13900000000000001	0
1819	249	2039	2012-11-26 23:30:00	0.128	0
1824	249	2044	2012-11-27 02:00:00	0.11899999999999999	0
1825	249	2045	2012-11-27 02:30:00	0.122	0
1828	249	2048	2012-11-27 04:00:00	0.124	0
1810	249	2030	2012-11-26 19:00:00	0.105	0
1829	249	2049	2012-11-27 04:30:00	0.127	0
1833	249	2053	2012-11-27 06:30:00	0.16800000000000001	0
1847	249	2067	2012-11-27 13:30:00	0.031	0
1813	249	2033	2012-11-26 20:30:00	0.13800000000000001	0
1814	249	2034	2012-11-26 21:00:00	0.14199999999999999	0
1837	249	2057	2012-11-27 08:30:00	0.115	0
1840	249	2060	2012-11-27 10:00:00	0.078	0
1817	249	2037	2012-11-26 22:30:00	0.11799999999999999	0
1822	249	2042	2012-11-27 01:00:00	0.13500000000000001	0
1827	249	2047	2012-11-27 03:30:00	0.124	0
1830	249	2050	2012-11-27 05:00:00	0.13500000000000001	0
1831	249	2051	2012-11-27 05:30:00	0.152	0
1834	249	2054	2012-11-27 07:00:00	0.14599999999999999	0
1836	249	2056	2012-11-27 08:00:00	0.13500000000000001	0
1842	249	2062	2012-11-27 11:00:00	0.058000000000000003	0
1848	249	2068	2012-11-27 14:00:00	0.035000000000000003	0
1849	249	2069	2012-11-27 14:30:00	0.035000000000000003	0
1850	249	2070	2012-11-27 15:00:00	0.049000000000000002	0
1851	249	2071	2012-11-27 15:30:00	0.056000000000000001	0
1852	249	2072	2012-11-27 16:00:00	0.065000000000000002	0
1853	249	2073	2012-11-27 16:30:00	0.084000000000000005	0
1854	249	2074	2012-11-27 17:00:00	0.084000000000000005	0
1855	249	2075	2012-11-27 17:30:00	0.104	0
1856	249	2076	2012-11-27 18:00:00	0.097000000000000003	0
1857	249	2077	2012-11-27 18:30:00	0.097000000000000003	0
1858	249	2078	2012-11-27 19:00:00	0.123	0
1859	249	2079	2012-11-27 19:30:00	0.13200000000000001	0
1860	249	2080	2012-11-27 20:00:00	0.14000000000000001	0
1861	249	2081	2012-11-27 20:30:00	0.156	0
1862	249	2082	2012-11-27 21:00:00	0.14599999999999999	0
1863	249	2083	2012-11-27 21:30:00	0.156	0
1864	249	2084	2012-11-27 22:00:00	0.16700000000000001	0
1865	249	2085	2012-11-27 22:30:00	0.16400000000000001	0
1866	249	2086	2012-11-27 23:00:00	0.155	0
1867	249	2087	2012-11-27 23:30:00	0.154	0
1868	249	2088	2012-11-28 00:00:00	0.16200000000000001	0
1869	249	2089	2012-11-28 00:30:00	0.184	0
1870	249	2090	2012-11-28 01:00:00	0.19600000000000001	0
1871	249	2091	2012-11-28 01:30:00	0.19900000000000001	0
1872	249	2092	2012-11-28 02:00:00	0.19800000000000001	0
1873	249	2093	2012-11-28 02:30:00	0.19700000000000001	0
1874	249	2094	2012-11-28 03:00:00	0.19700000000000001	0
1875	249	2095	2012-11-28 03:30:00	0.192	0
1876	249	2096	2012-11-28 04:00:00	0.191	0
1877	249	2097	2012-11-28 04:30:00	0.191	0
1878	249	2098	2012-11-28 05:00:00	0.186	0
1879	249	2099	2012-11-28 05:30:00	0.192	0
1880	249	2100	2012-11-28 06:00:00	0.20499999999999999	0
1881	249	2101	2012-11-28 06:30:00	0.20599999999999999	0
1882	249	2102	2012-11-28 07:00:00	0.20899999999999999	0
1883	249	2103	2012-11-28 07:30:00	0.222	0
1884	249	2104	2012-11-28 08:00:00	0.214	0
1885	249	2105	2012-11-28 08:30:00	0.19	0
1886	249	2106	2012-11-28 09:00:00	0.17199999999999999	0
1887	249	2107	2012-11-28 09:30:00	0.16700000000000001	0
1888	249	2108	2012-11-28 10:00:00	0.126	0
1889	249	2109	2012-11-28 10:30:00	0.097000000000000003	0
1890	249	2110	2012-11-28 11:00:00	0.084000000000000005	0
1891	249	2111	2012-11-28 11:30:00	0.051999999999999998	0
1892	249	2112	2012-11-28 12:00:00	0.056000000000000001	0
1893	249	2113	2012-11-28 12:30:00	0.056000000000000001	0
1894	249	2114	2012-11-28 13:00:00	0.053999999999999999	0
1895	249	2115	2012-11-28 13:30:00	0.057000000000000002	0
1896	249	2116	2012-11-28 14:00:00	0.074999999999999997	0
1897	249	2117	2012-11-28 14:30:00	0.074999999999999997	0
1898	249	2118	2012-11-28 15:00:00	0.087999999999999995	0
1899	249	2119	2012-11-28 15:30:00	0.10199999999999999	0
1900	249	2120	2012-11-28 16:00:00	0.126	0
1901	249	2121	2012-11-28 16:30:00	0.13200000000000001	0
1902	249	2122	2012-11-28 17:00:00	0.14499999999999999	0
1903	249	2123	2012-11-28 17:30:00	0.14899999999999999	0
1904	249	2124	2012-11-28 18:00:00	0.14999999999999999	0
1905	249	2125	2012-11-28 18:30:00	0.14799999999999999	0
1906	249	2126	2012-11-28 19:00:00	0.14699999999999999	0
1907	249	2127	2012-11-28 19:30:00	0.153	0
1908	249	2128	2012-11-28 20:00:00	0.154	0
1909	249	2129	2012-11-28 20:30:00	0.154	0
1910	249	2130	2012-11-28 21:00:00	0.14899999999999999	0
1911	249	2131	2012-11-28 21:30:00	0.155	0
1912	249	2132	2012-11-28 22:00:00	0.159	0
1913	249	2133	2012-11-28 22:30:00	0.128	0
1914	249	2134	2012-11-28 23:00:00	0.13800000000000001	0
1915	249	2135	2012-11-28 23:30:00	0.14599999999999999	0
1916	249	2136	2012-11-29 00:00:00	0.154	0
1917	249	2137	2012-11-29 00:30:00	0.14799999999999999	0
1918	249	2138	2012-11-29 01:00:00	0.152	0
1919	249	2139	2012-11-29 01:30:00	0.16200000000000001	0
1920	249	2140	2012-11-29 02:00:00	0.17399999999999999	0
1921	249	2141	2012-11-29 02:30:00	0.184	0
1922	249	2142	2012-11-29 03:00:00	0.193	0
1923	249	2143	2012-11-29 03:30:00	0.20100000000000001	0
1924	249	2144	2012-11-29 04:00:00	0.23000000000000001	0
1925	249	2145	2012-11-29 04:30:00	0.24199999999999999	0
1926	249	2146	2012-11-29 05:00:00	0.26600000000000001	0
1927	249	2147	2012-11-29 05:30:00	0.26000000000000001	0
1928	249	2148	2012-11-29 06:00:00	0.27200000000000002	0
1929	249	2149	2012-11-29 06:30:00	0.27100000000000002	0
1930	249	2150	2012-11-29 07:00:00	0.27100000000000002	0
1931	249	2151	2012-11-29 07:30:00	0.25700000000000001	0
1932	249	2152	2012-11-29 08:00:00	0.22600000000000001	0
1933	249	2153	2012-11-29 08:30:00	0.17699999999999999	0
1934	249	2154	2012-11-29 09:00:00	0.157	0
1935	249	2155	2012-11-29 09:30:00	0.13300000000000001	0
1936	249	2156	2012-11-29 10:00:00	0.122	0
1937	249	2157	2012-11-29 10:30:00	0.11	0
1938	249	2158	2012-11-29 11:00:00	0.104	0
1939	249	2159	2012-11-29 11:30:00	0.086999999999999994	0
1940	249	2160	2012-11-29 12:00:00	0.089999999999999997	0
1941	249	2161	2012-11-29 12:30:00	0.075999999999999998	0
1942	249	2162	2012-11-29 13:00:00	0.087999999999999995	0
1943	249	2163	2012-11-29 13:30:00	0.073999999999999996	0
1944	249	2164	2012-11-29 14:00:00	0.086999999999999994	0
1945	249	2165	2012-11-29 14:30:00	0.094	0
1946	249	2166	2012-11-29 15:00:00	0.11700000000000001	0
1947	249	2167	2012-11-29 15:30:00	0.16800000000000001	0
1948	249	2168	2012-11-29 16:00:00	0.17499999999999999	0
1949	249	2169	2012-11-29 16:30:00	0.17799999999999999	0
1954	249	2174	2012-11-29 19:00:00	0.20499999999999999	0
1950	249	2170	2012-11-29 17:00:00	0.183	0
1952	249	2172	2012-11-29 18:00:00	0.191	0
1951	249	2171	2012-11-29 17:30:00	0.189	0
1953	249	2173	2012-11-29 18:30:00	0.19600000000000001	0
1955	249	2175	2012-11-29 19:30:00	0.20799999999999999	0
1956	249	2176	2012-11-29 20:00:00	0.21099999999999999	0
1957	249	2177	2012-11-29 20:30:00	0.20699999999999999	0
1958	249	2178	2012-11-29 21:00:00	0.20399999999999999	0
1959	249	2179	2012-11-29 21:30:00	0.20300000000000001	0
1960	249	2180	2012-11-29 22:00:00	0.20499999999999999	0
1961	249	2181	2012-11-29 22:30:00	0.20499999999999999	0
1962	249	2182	2012-11-29 23:00:00	0.20100000000000001	0
1963	249	2183	2012-11-29 23:30:00	0.23499999999999999	0
1964	249	2184	2012-11-30 00:00:00	0.255	0
1965	249	2185	2012-11-30 00:30:00	0.26600000000000001	0
1966	249	2186	2012-11-30 01:00:00	0.27400000000000002	0
1967	249	2187	2012-11-30 01:30:00	0.28000000000000003	0
1968	249	2188	2012-11-30 02:00:00	0.29399999999999998	0
1969	249	2189	2012-11-30 02:30:00	0.29999999999999999	0
1970	249	2190	2012-11-30 03:00:00	0.30299999999999999	0
1971	249	2191	2012-11-30 03:30:00	0.30399999999999999	0
1972	249	2192	2012-11-30 04:00:00	0.309	0
1973	249	2193	2012-11-30 04:30:00	0.313	0
1974	249	2194	2012-11-30 05:00:00	0.314	0
1975	249	2195	2012-11-30 05:30:00	0.315	0
1976	249	2196	2012-11-30 06:00:00	0.318	0
2001	249	2221	2012-11-30 06:30:00	0.32300000000000001	0
2002	249	2222	2012-11-30 07:00:00	0.32400000000000001	0
2021	249	2241	2012-11-30 07:30:00	0.32300000000000001	0
2022	249	2242	2012-11-30 08:00:00	0.32100000000000001	0
2023	249	2243	2012-11-30 08:30:00	0.317	0
2024	249	2244	2012-11-30 09:00:00	0.31	0
2025	249	2245	2012-11-30 09:30:00	0.29899999999999999	0
2026	249	2246	2012-11-30 10:00:00	0.29599999999999999	0
2027	249	2247	2012-11-30 10:30:00	0.28699999999999998	0
2028	249	2248	2012-11-30 11:00:00	0.28100000000000003	0
2029	249	2249	2012-11-30 11:30:00	0.27700000000000002	0
2030	249	2250	2012-11-30 12:00:00	0.27300000000000002	0
2031	249	2251	2012-11-30 12:30:00	0.26900000000000002	0
2032	249	2252	2012-11-30 13:00:00	0.26500000000000001	0
2033	249	2253	2012-11-30 13:30:00	0.26300000000000001	0
2034	249	2254	2012-11-30 14:00:00	0.26000000000000001	0
2035	249	2255	2012-11-30 14:30:00	0.26300000000000001	0
2036	249	2256	2012-11-30 15:00:00	0.26400000000000001	0
2037	249	2257	2012-11-30 15:30:00	0.26900000000000002	0
2038	249	2258	2012-11-30 16:00:00	0.27200000000000002	0
2039	249	2259	2012-11-30 16:30:00	0.27900000000000003	0
2040	249	2260	2012-11-30 17:00:00	0.28599999999999998	0
2041	249	2261	2012-11-30 17:30:00	0.28899999999999998	0
2042	249	2262	2012-11-30 18:00:00	0.29499999999999998	0
2043	249	2263	2012-11-30 18:30:00	0.29699999999999999	0
2044	249	2264	2012-11-30 19:00:00	0.29899999999999999	0
2061	249	2281	2012-11-30 19:30:00	0.30199999999999999	0
2062	249	2282	2012-11-30 20:00:00	0.29699999999999999	0
2081	249	2301	2012-11-30 20:30:00	0.28599999999999998	0
2082	249	2302	2012-11-30 21:00:00	0.28799999999999998	0
2083	249	2303	2012-11-30 21:30:00	0.28899999999999998	0
2084	249	2304	2012-11-30 22:00:00	0.29199999999999998	0
2101	249	2321	2012-11-30 22:30:00	0.29199999999999998	0
2102	249	2322	2012-11-30 23:00:00	0.29199999999999998	0
\.


--
-- Data for Name: s_data_densitys; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_densitys (id, sensor_id, sensor_data_id, date_time, density) FROM stdin;
1581	258	1801	2012-11-22 00:30:00	1.2096
1582	258	1802	2012-11-22 01:00:00	1.2101999999999999
1583	258	1803	2012-11-22 01:30:00	1.2104999999999999
1584	258	1804	2012-11-22 02:00:00	1.2110000000000001
1585	258	1805	2012-11-22 02:30:00	1.2111000000000001
1586	258	1806	2012-11-22 03:00:00	1.2116
1587	258	1807	2012-11-22 03:30:00	1.2116
1588	258	1808	2012-11-22 04:00:00	1.212
1589	258	1809	2012-11-22 04:30:00	1.2121999999999999
1590	258	1810	2012-11-22 05:00:00	1.2125999999999999
1591	258	1811	2012-11-22 05:30:00	1.2130000000000001
1592	258	1812	2012-11-22 06:00:00	1.2139
1593	258	1813	2012-11-22 06:30:00	1.2139
1594	258	1814	2012-11-22 07:00:00	1.2143999999999999
1595	258	1815	2012-11-22 07:30:00	1.2151000000000001
1596	258	1816	2012-11-22 08:00:00	1.2154
1597	258	1817	2012-11-22 08:30:00	1.2157
1598	258	1818	2012-11-22 09:00:00	1.2164999999999999
1599	258	1819	2012-11-22 09:30:00	1.2168000000000001
1600	258	1820	2012-11-22 10:00:00	1.2176
1601	258	1821	2012-11-22 10:30:00	1.2177
1602	258	1822	2012-11-22 11:00:00	1.2177
1603	258	1823	2012-11-22 11:30:00	1.2165999999999999
1604	258	1824	2012-11-22 12:00:00	1.2126999999999999
1605	258	1825	2012-11-22 12:30:00	1.2099
1606	258	1826	2012-11-22 13:00:00	1.2069000000000001
1607	258	1827	2012-11-22 13:30:00	1.2053
1608	258	1828	2012-11-22 14:00:00	1.2059
1609	258	1829	2012-11-22 14:30:00	1.2053
1610	258	1830	2012-11-22 15:00:00	1.2054
1611	258	1831	2012-11-22 15:30:00	1.2052
1612	258	1832	2012-11-22 16:00:00	1.2049000000000001
1613	258	1833	2012-11-22 16:30:00	1.2050000000000001
1614	258	1834	2012-11-22 17:00:00	1.2045999999999999
1615	258	1835	2012-11-22 17:30:00	1.2034
1616	258	1836	2012-11-22 18:00:00	1.2021999999999999
1617	258	1837	2012-11-22 18:30:00	1.2012
1618	258	1838	2012-11-22 19:00:00	1.2011000000000001
1619	258	1839	2012-11-22 19:30:00	1.2015
1620	258	1840	2012-11-22 20:00:00	1.2016
1621	258	1841	2012-11-22 20:30:00	1.2014
1622	258	1842	2012-11-22 21:00:00	1.2008000000000001
1623	258	1843	2012-11-22 21:30:00	1.2005999999999999
1624	258	1844	2012-11-22 22:00:00	1.2001999999999999
1625	258	1845	2012-11-22 22:30:00	1.2004999999999999
1626	258	1846	2012-11-22 23:00:00	1.2004999999999999
1627	258	1847	2012-11-22 23:30:00	1.2009000000000001
1628	258	1848	2012-11-23 00:00:00	1.2014
1629	258	1849	2012-11-23 00:30:00	1.2017
1630	258	1850	2012-11-23 01:00:00	1.2020999999999999
1631	258	1851	2012-11-23 01:30:00	1.2025999999999999
1632	258	1852	2012-11-23 02:00:00	1.2027000000000001
1633	258	1853	2012-11-23 02:30:00	1.2030000000000001
1634	258	1854	2012-11-23 03:00:00	1.2030000000000001
1635	258	1855	2012-11-23 03:30:00	1.2033
1636	258	1856	2012-11-23 04:00:00	1.2037
1637	258	1857	2012-11-23 04:30:00	1.2038
1638	258	1858	2012-11-23 05:00:00	1.2039
1639	258	1859	2012-11-23 05:30:00	1.2043999999999999
1640	258	1860	2012-11-23 06:00:00	1.2049000000000001
1641	258	1861	2012-11-23 06:30:00	1.2051000000000001
1642	258	1862	2012-11-23 07:00:00	1.2055
1643	258	1863	2012-11-23 07:30:00	1.2062999999999999
1644	258	1864	2012-11-23 08:00:00	1.2068000000000001
1645	258	1865	2012-11-23 08:30:00	1.2068000000000001
1646	258	1866	2012-11-23 09:00:00	1.2072000000000001
1647	258	1867	2012-11-23 09:30:00	1.2073
1648	258	1868	2012-11-23 10:00:00	1.2078
1649	258	1869	2012-11-23 10:30:00	1.2081
1650	258	1870	2012-11-23 11:00:00	1.2058
1651	258	1871	2012-11-23 11:30:00	1.2021999999999999
1652	258	1872	2012-11-23 12:00:00	1.1999
1653	258	1873	2012-11-23 12:30:00	1.1987000000000001
1654	258	1874	2012-11-23 13:00:00	1.1980999999999999
1655	258	1875	2012-11-23 13:30:00	1.1979
1656	258	1876	2012-11-23 14:00:00	1.1975
1657	258	1877	2012-11-23 14:30:00	1.1973
1658	258	1878	2012-11-23 15:00:00	1.1976
1659	258	1879	2012-11-23 15:30:00	1.1978
1660	258	1880	2012-11-23 16:00:00	1.1978
1661	258	1881	2012-11-23 16:30:00	1.1974
1662	258	1882	2012-11-23 17:00:00	1.1964999999999999
1663	258	1883	2012-11-23 17:30:00	1.1960999999999999
1664	258	1884	2012-11-23 18:00:00	1.1956
1665	258	1885	2012-11-23 18:30:00	1.1950000000000001
1666	258	1886	2012-11-23 19:00:00	1.1944999999999999
1667	258	1887	2012-11-23 19:30:00	1.1944999999999999
1668	258	1888	2012-11-23 20:00:00	1.1940999999999999
1669	258	1889	2012-11-23 20:30:00	1.1938
1670	258	1890	2012-11-23 21:00:00	1.194
1671	258	1891	2012-11-23 21:30:00	1.1944999999999999
1672	258	1892	2012-11-23 22:00:00	1.1950000000000001
1673	258	1893	2012-11-23 22:30:00	1.1954
1674	258	1894	2012-11-23 23:00:00	1.1960999999999999
1675	258	1895	2012-11-23 23:30:00	1.1967000000000001
1676	258	1896	2012-11-24 00:00:00	1.1962999999999999
1677	258	1897	2012-11-24 00:30:00	1.1966000000000001
1678	258	1898	2012-11-24 01:00:00	1.1967000000000001
1679	258	1899	2012-11-24 01:30:00	1.1977
1680	258	1900	2012-11-24 02:00:00	1.1981999999999999
1681	258	1901	2012-11-24 02:30:00	1.198
1682	258	1902	2012-11-24 03:00:00	1.1980999999999999
1683	258	1903	2012-11-24 03:30:00	1.1981999999999999
1684	258	1904	2012-11-24 04:00:00	1.1987000000000001
1685	258	1905	2012-11-24 04:30:00	1.1992
1686	258	1906	2012-11-24 05:00:00	1.1997
1687	258	1907	2012-11-24 05:30:00	1.1999
1688	258	1908	2012-11-24 06:00:00	1.2000999999999999
1689	258	1909	2012-11-24 06:30:00	1.2005999999999999
1690	258	1910	2012-11-24 07:00:00	1.2015
1691	258	1911	2012-11-24 07:30:00	1.2022999999999999
1692	258	1912	2012-11-24 08:00:00	1.2027000000000001
1693	258	1913	2012-11-24 08:30:00	1.2035
1694	258	1914	2012-11-24 09:00:00	1.2033
1695	258	1915	2012-11-24 09:30:00	1.2040999999999999
1696	258	1916	2012-11-24 10:00:00	1.204
1697	258	1917	2012-11-24 10:30:00	1.2042999999999999
1698	258	1918	2012-11-24 11:00:00	1.2037
1699	258	1919	2012-11-24 11:30:00	1.2025999999999999
1700	258	1920	2012-11-24 12:00:00	1.202
1701	258	1921	2012-11-24 12:30:00	1.2015
1702	258	1922	2012-11-24 13:00:00	1.2010000000000001
1703	258	1923	2012-11-24 13:30:00	1.2004999999999999
1704	258	1924	2012-11-24 14:00:00	1.2002999999999999
1705	258	1925	2012-11-24 14:30:00	1.1998
1706	258	1926	2012-11-24 15:00:00	1.1998
1707	258	1927	2012-11-24 15:30:00	1.2000999999999999
1708	258	1928	2012-11-24 16:00:00	1.2004999999999999
1709	258	1929	2012-11-24 16:30:00	1.1999
1710	258	1930	2012-11-24 17:00:00	1.2002999999999999
1711	258	1931	2012-11-24 17:30:00	1.2011000000000001
1712	258	1932	2012-11-24 18:00:00	1.2010000000000001
1713	258	1933	2012-11-24 18:30:00	1.2014
1714	258	1934	2012-11-24 19:00:00	1.202
1715	258	1935	2012-11-24 19:30:00	1.2023999999999999
1716	258	1936	2012-11-24 20:00:00	1.2021999999999999
1717	258	1937	2012-11-24 20:30:00	1.2028000000000001
1718	258	1938	2012-11-24 21:00:00	1.2033
1719	258	1939	2012-11-24 21:30:00	1.2038
1720	258	1940	2012-11-24 22:00:00	1.2037
1721	258	1941	2012-11-24 22:30:00	1.2036
1722	258	1942	2012-11-24 23:00:00	1.2045999999999999
1723	258	1943	2012-11-24 23:30:00	1.2049000000000001
1724	258	1944	2012-11-25 00:00:00	1.2049000000000001
1725	258	1945	2012-11-25 00:30:00	1.2053
1726	258	1946	2012-11-25 01:00:00	1.2057
1727	258	1947	2012-11-25 01:30:00	1.2056
1728	258	1948	2012-11-25 02:00:00	1.2062999999999999
1729	258	1949	2012-11-25 02:30:00	1.2065999999999999
1730	258	1950	2012-11-25 03:00:00	1.2069000000000001
1731	258	1951	2012-11-25 03:30:00	1.2068000000000001
1732	258	1952	2012-11-25 04:00:00	1.2069000000000001
1733	258	1953	2012-11-25 04:30:00	1.2074
1734	258	1954	2012-11-25 05:00:00	1.2075
1735	258	1955	2012-11-25 05:30:00	1.2078
1736	258	1956	2012-11-25 06:00:00	1.2081999999999999
1737	258	1957	2012-11-25 06:30:00	1.2087000000000001
1738	258	1958	2012-11-25 07:00:00	1.2090000000000001
1739	258	1959	2012-11-25 07:30:00	1.2098
1740	258	1960	2012-11-25 08:00:00	1.2103999999999999
1741	258	1961	2012-11-25 08:30:00	1.2108000000000001
1742	258	1962	2012-11-25 09:00:00	1.2114
1743	258	1963	2012-11-25 09:30:00	1.212
1744	258	1964	2012-11-25 10:00:00	1.2118
1745	258	1965	2012-11-25 10:30:00	1.21
1746	258	1966	2012-11-25 11:00:00	1.208
1747	258	1967	2012-11-25 11:30:00	1.2069000000000001
1748	258	1968	2012-11-25 12:00:00	1.2057
1749	258	1969	2012-11-25 12:30:00	1.2051000000000001
1750	258	1970	2012-11-25 13:00:00	1.2040999999999999
1751	258	1971	2012-11-25 13:30:00	1.2043999999999999
1752	258	1972	2012-11-25 14:00:00	1.2043999999999999
1753	258	1973	2012-11-25 14:30:00	1.2042999999999999
1754	258	1974	2012-11-25 15:00:00	1.2035
1755	258	1975	2012-11-25 15:30:00	1.2032
1756	258	1976	2012-11-25 16:00:00	1.2022999999999999
1757	258	1977	2012-11-25 16:30:00	1.2019
1758	258	1978	2012-11-25 17:00:00	1.2017
1759	258	1979	2012-11-25 17:30:00	1.2016
1760	258	1980	2012-11-25 18:00:00	1.2012
1761	258	1981	2012-11-25 18:30:00	1.2004999999999999
1762	258	1982	2012-11-25 19:00:00	1.2004999999999999
1763	258	1983	2012-11-25 19:30:00	1.2001999999999999
1764	258	1984	2012-11-25 20:00:00	1.1996
1765	258	1985	2012-11-25 20:30:00	1.1996
1766	258	1986	2012-11-25 21:00:00	1.1995
1767	258	1987	2012-11-25 21:30:00	1.1993
1768	258	1988	2012-11-25 22:00:00	1.1998
1769	258	1989	2012-11-25 22:30:00	1.2003999999999999
1770	258	1990	2012-11-25 23:00:00	1.2003999999999999
1771	258	1991	2012-11-25 23:30:00	1.2008000000000001
1772	258	1992	2012-11-26 00:00:00	1.2013
1773	258	1993	2012-11-26 00:30:00	1.2015
1774	258	1994	2012-11-26 01:00:00	1.2017
1775	258	1995	2012-11-26 01:30:00	1.2020999999999999
1776	258	1996	2012-11-26 02:00:00	1.2028000000000001
1777	258	1997	2012-11-26 02:30:00	1.2027000000000001
1778	258	1998	2012-11-26 03:00:00	1.2024999999999999
1779	258	1999	2012-11-26 03:30:00	1.2030000000000001
1780	258	2000	2012-11-26 04:00:00	1.2027000000000001
1781	258	2001	2012-11-26 04:30:00	1.2030000000000001
1782	258	2002	2012-11-26 05:00:00	1.2036
1783	258	2003	2012-11-26 05:30:00	1.204
1784	258	2004	2012-11-26 06:00:00	1.2037
1785	258	2005	2012-11-26 06:30:00	1.204
1786	258	2006	2012-11-26 07:00:00	1.2039
1787	258	2007	2012-11-26 07:30:00	1.2044999999999999
1788	258	2008	2012-11-26 08:00:00	1.2045999999999999
1789	258	2009	2012-11-26 08:30:00	1.2045999999999999
1790	258	2010	2012-11-26 09:00:00	1.2048000000000001
1791	258	2011	2012-11-26 09:30:00	1.2053
1792	258	2012	2012-11-26 10:00:00	1.2049000000000001
1793	258	2013	2012-11-26 10:30:00	1.204
1794	258	2014	2012-11-26 11:00:00	1.2028000000000001
1795	258	2015	2012-11-26 11:30:00	1.2018
1796	258	2016	2012-11-26 12:00:00	1.2009000000000001
1797	258	2017	2012-11-26 12:30:00	1.1998
1798	258	2018	2012-11-26 13:00:00	1.1989000000000001
1799	258	2019	2012-11-26 13:30:00	1.1982999999999999
1800	258	2020	2012-11-26 14:00:00	1.1974
1801	258	2021	2012-11-26 14:30:00	1.1969000000000001
1802	258	2022	2012-11-26 15:00:00	1.196
1803	258	2023	2012-11-26 15:30:00	1.1958
1804	258	2024	2012-11-26 16:00:00	1.1954
1805	258	2025	2012-11-26 16:30:00	1.1952
1806	258	2026	2012-11-26 17:00:00	1.1943999999999999
1807	258	2027	2012-11-26 17:30:00	1.1938
1808	258	2028	2012-11-26 18:00:00	1.1938
1809	258	2029	2012-11-26 18:30:00	1.1932
1810	258	2030	2012-11-26 19:00:00	1.1938
1811	258	2031	2012-11-26 19:30:00	1.1936
1812	258	2032	2012-11-26 20:00:00	1.1939
1813	258	2033	2012-11-26 20:30:00	1.1938
1814	258	2034	2012-11-26 21:00:00	1.1939
1815	258	2035	2012-11-26 21:30:00	1.1939
1816	258	2036	2012-11-26 22:00:00	1.1942999999999999
1817	258	2037	2012-11-26 22:30:00	1.1941999999999999
1818	258	2038	2012-11-26 23:00:00	1.1947000000000001
1819	258	2039	2012-11-26 23:30:00	1.1948000000000001
1820	258	2040	2012-11-27 00:00:00	1.1948000000000001
1821	258	2041	2012-11-27 00:30:00	1.1943999999999999
1825	258	2045	2012-11-27 02:30:00	1.194
1836	258	2056	2012-11-27 08:00:00	1.1951000000000001
1844	258	2064	2012-11-27 12:00:00	1.1957
1822	258	2042	2012-11-27 01:00:00	1.194
1831	258	2051	2012-11-27 05:30:00	1.1940999999999999
1823	258	2043	2012-11-27 01:30:00	1.1934
1824	258	2044	2012-11-27 02:00:00	1.1937
1834	258	2054	2012-11-27 07:00:00	1.1950000000000001
1838	258	2058	2012-11-27 09:00:00	1.1958
1845	258	2065	2012-11-27 12:30:00	1.1949000000000001
1826	258	2046	2012-11-27 03:00:00	1.1933
1837	258	2057	2012-11-27 08:30:00	1.1955
1840	258	2060	2012-11-27 10:00:00	1.1964999999999999
1842	258	2062	2012-11-27 11:00:00	1.1962999999999999
1827	258	2047	2012-11-27 03:30:00	1.194
1830	258	2050	2012-11-27 05:00:00	1.1941999999999999
1843	258	2063	2012-11-27 11:30:00	1.1958
1846	258	2066	2012-11-27 13:00:00	1.194
1828	258	2048	2012-11-27 04:00:00	1.1938
1832	258	2052	2012-11-27 06:00:00	1.1944999999999999
1841	258	2061	2012-11-27 10:30:00	1.1967000000000001
1829	258	2049	2012-11-27 04:30:00	1.1939
1833	258	2053	2012-11-27 06:30:00	1.1942999999999999
1835	258	2055	2012-11-27 07:30:00	1.1949000000000001
1839	258	2059	2012-11-27 09:30:00	1.196
1847	258	2067	2012-11-27 13:30:00	1.1940999999999999
1848	258	2068	2012-11-27 14:00:00	1.1937
1849	258	2069	2012-11-27 14:30:00	1.1934
1850	258	2070	2012-11-27 15:00:00	1.1935
1851	258	2071	2012-11-27 15:30:00	1.1933
1852	258	2072	2012-11-27 16:00:00	1.1933
1853	258	2073	2012-11-27 16:30:00	1.1935
1854	258	2074	2012-11-27 17:00:00	1.1940999999999999
1855	258	2075	2012-11-27 17:30:00	1.194
1856	258	2076	2012-11-27 18:00:00	1.1935
1857	258	2077	2012-11-27 18:30:00	1.1934
1858	258	2078	2012-11-27 19:00:00	1.1934
1859	258	2079	2012-11-27 19:30:00	1.1932
1860	258	2080	2012-11-27 20:00:00	1.1927000000000001
1861	258	2081	2012-11-27 20:30:00	1.1927000000000001
1862	258	2082	2012-11-27 21:00:00	1.1923999999999999
1863	258	2083	2012-11-27 21:30:00	1.1921999999999999
1864	258	2084	2012-11-27 22:00:00	1.1920999999999999
1865	258	2085	2012-11-27 22:30:00	1.1919
1866	258	2086	2012-11-27 23:00:00	1.1918
1867	258	2087	2012-11-27 23:30:00	1.1918
1868	258	2088	2012-11-28 00:00:00	1.1916
1869	258	2089	2012-11-28 00:30:00	1.1911
1870	258	2090	2012-11-28 01:00:00	1.1908000000000001
1871	258	2091	2012-11-28 01:30:00	1.1911
1872	258	2092	2012-11-28 02:00:00	1.1913
1873	258	2093	2012-11-28 02:30:00	1.1911
1874	258	2094	2012-11-28 03:00:00	1.1904999999999999
1875	258	2095	2012-11-28 03:30:00	1.1902999999999999
1876	258	2096	2012-11-28 04:00:00	1.1899
1877	258	2097	2012-11-28 04:30:00	1.1899
1878	258	2098	2012-11-28 05:00:00	1.1897
1879	258	2099	2012-11-28 05:30:00	1.1893
1880	258	2100	2012-11-28 06:00:00	1.1890000000000001
1881	258	2101	2012-11-28 06:30:00	1.1892
1882	258	2102	2012-11-28 07:00:00	1.1895
1883	258	2103	2012-11-28 07:30:00	1.1895
1884	258	2104	2012-11-28 08:00:00	1.1891
1885	258	2105	2012-11-28 08:30:00	1.1893
1886	258	2106	2012-11-28 09:00:00	1.1892
1887	258	2107	2012-11-28 09:30:00	1.1892
1888	258	2108	2012-11-28 10:00:00	1.1889000000000001
1889	258	2109	2012-11-28 10:30:00	1.1884999999999999
1890	258	2110	2012-11-28 11:00:00	1.1874
1891	258	2111	2012-11-28 11:30:00	1.1861999999999999
1892	258	2112	2012-11-28 12:00:00	1.1846000000000001
1893	258	2113	2012-11-28 12:30:00	1.1830000000000001
1894	258	2114	2012-11-28 13:00:00	1.1818
1895	258	2115	2012-11-28 13:30:00	1.1805000000000001
1896	258	2116	2012-11-28 14:00:00	1.1792
1897	258	2117	2012-11-28 14:30:00	1.1779999999999999
1898	258	2118	2012-11-28 15:00:00	1.1768000000000001
1899	258	2119	2012-11-28 15:30:00	1.1759999999999999
1900	258	2120	2012-11-28 16:00:00	1.1738999999999999
1901	258	2121	2012-11-28 16:30:00	1.1729000000000001
1902	258	2122	2012-11-28 17:00:00	1.1718
1903	258	2123	2012-11-28 17:30:00	1.1699999999999999
1904	258	2124	2012-11-28 18:00:00	1.1691
1905	258	2125	2012-11-28 18:30:00	1.1678999999999999
1906	258	2126	2012-11-28 19:00:00	1.167
1907	258	2127	2012-11-28 19:30:00	1.1660999999999999
1908	258	2128	2012-11-28 20:00:00	1.1664000000000001
1909	258	2129	2012-11-28 20:30:00	1.1658999999999999
1910	258	2130	2012-11-28 21:00:00	1.1660999999999999
1911	258	2131	2012-11-28 21:30:00	1.1671
1912	258	2132	2012-11-28 22:00:00	1.1686000000000001
1913	258	2133	2012-11-28 22:30:00	1.1693
1914	258	2134	2012-11-28 23:00:00	1.1667000000000001
1915	258	2135	2012-11-28 23:30:00	1.1671
1916	258	2136	2012-11-29 00:00:00	1.167
1917	258	2137	2012-11-29 00:30:00	1.1674
1918	258	2138	2012-11-29 01:00:00	1.1671
1919	258	2139	2012-11-29 01:30:00	1.167
1920	258	2140	2012-11-29 02:00:00	1.1674
1921	258	2141	2012-11-29 02:30:00	1.1654
1922	258	2142	2012-11-29 03:00:00	1.1666000000000001
1923	258	2143	2012-11-29 03:30:00	1.1675
1924	258	2144	2012-11-29 04:00:00	1.1671
1925	258	2145	2012-11-29 04:30:00	1.1675
1926	258	2146	2012-11-29 05:00:00	1.1681999999999999
1927	258	2147	2012-11-29 05:30:00	1.1687000000000001
1928	258	2148	2012-11-29 06:00:00	1.1695
1929	258	2149	2012-11-29 06:30:00	1.1692
1930	258	2150	2012-11-29 07:00:00	1.1696
1931	258	2151	2012-11-29 07:30:00	1.1692
1932	258	2152	2012-11-29 08:00:00	1.1708000000000001
1933	258	2153	2012-11-29 08:30:00	1.1716
1934	258	2154	2012-11-29 09:00:00	1.1717
1935	258	2155	2012-11-29 09:30:00	1.1716
1936	258	2156	2012-11-29 10:00:00	1.1724000000000001
1937	258	2157	2012-11-29 10:30:00	1.173
1938	258	2158	2012-11-29 11:00:00	1.173
1939	258	2159	2012-11-29 11:30:00	1.1725000000000001
1940	258	2160	2012-11-29 12:00:00	1.1719999999999999
1941	258	2161	2012-11-29 12:30:00	1.1715
1942	258	2162	2012-11-29 13:00:00	1.1718
1943	258	2163	2012-11-29 13:30:00	1.1718999999999999
1944	258	2164	2012-11-29 14:00:00	1.1718
1945	258	2165	2012-11-29 14:30:00	1.1726000000000001
1946	258	2166	2012-11-29 15:00:00	1.1731
1947	258	2167	2012-11-29 15:30:00	1.1738999999999999
1948	258	2168	2012-11-29 16:00:00	1.1734
1949	258	2169	2012-11-29 16:30:00	1.1725000000000001
1950	258	2170	2012-11-29 17:00:00	1.1718999999999999
1951	258	2171	2012-11-29 17:30:00	1.1712
1952	258	2172	2012-11-29 18:00:00	1.1711
1953	258	2173	2012-11-29 18:30:00	1.1707000000000001
1954	258	2174	2012-11-29 19:00:00	1.1704000000000001
1955	258	2175	2012-11-29 19:30:00	1.1704000000000001
1956	258	2176	2012-11-29 20:00:00	1.1706000000000001
1957	258	2177	2012-11-29 20:30:00	1.1706000000000001
1958	258	2178	2012-11-29 21:00:00	1.1705000000000001
1959	258	2179	2012-11-29 21:30:00	1.1698
1960	258	2180	2012-11-29 22:00:00	1.1698999999999999
1961	258	2181	2012-11-29 22:30:00	1.1698
1962	258	2182	2012-11-29 23:00:00	1.1700999999999999
1963	258	2183	2012-11-29 23:30:00	1.1705000000000001
1964	258	2184	2012-11-30 00:00:00	1.1726000000000001
1965	258	2185	2012-11-30 00:30:00	1.1739999999999999
1966	258	2186	2012-11-30 01:00:00	1.1755
1967	258	2187	2012-11-30 01:30:00	1.1769000000000001
1968	258	2188	2012-11-30 02:00:00	1.1775
1969	258	2189	2012-11-30 02:30:00	1.1785000000000001
1970	258	2190	2012-11-30 03:00:00	1.1793
1971	258	2191	2012-11-30 03:30:00	1.1799999999999999
1972	258	2192	2012-11-30 04:00:00	1.1809000000000001
1973	258	2193	2012-11-30 04:30:00	1.1822999999999999
1974	258	2194	2012-11-30 05:00:00	1.1834
1975	258	2195	2012-11-30 05:30:00	1.1841999999999999
1976	258	2196	2012-11-30 06:00:00	1.1850000000000001
2001	258	2221	2012-11-30 06:30:00	1.1859
2002	258	2222	2012-11-30 07:00:00	1.1867000000000001
2021	258	2241	2012-11-30 07:30:00	1.1877
2022	258	2242	2012-11-30 08:00:00	1.1879999999999999
2023	258	2243	2012-11-30 08:30:00	1.1874
2024	258	2244	2012-11-30 09:00:00	1.1874
2025	258	2245	2012-11-30 09:30:00	1.1869000000000001
2026	258	2246	2012-11-30 10:00:00	1.1869000000000001
2027	258	2247	2012-11-30 10:30:00	1.1871
2028	258	2248	2012-11-30 11:00:00	1.1865000000000001
2029	258	2249	2012-11-30 11:30:00	1.1868000000000001
2030	258	2250	2012-11-30 12:00:00	1.1876
2031	258	2251	2012-11-30 12:30:00	1.1872
2032	258	2252	2012-11-30 13:00:00	1.1872
2033	258	2253	2012-11-30 13:30:00	1.1878
2034	258	2254	2012-11-30 14:00:00	1.1888000000000001
2035	258	2255	2012-11-30 14:30:00	1.1892
2036	258	2256	2012-11-30 15:00:00	1.1896
2037	258	2257	2012-11-30 15:30:00	1.1899999999999999
2038	258	2258	2012-11-30 16:00:00	1.1900999999999999
2039	258	2259	2012-11-30 16:30:00	1.1901999999999999
2040	258	2260	2012-11-30 17:00:00	1.1895
2041	258	2261	2012-11-30 17:30:00	1.1894
2042	258	2262	2012-11-30 18:00:00	1.1898
2043	258	2263	2012-11-30 18:30:00	1.1897
2044	258	2264	2012-11-30 19:00:00	1.1900999999999999
2061	258	2281	2012-11-30 19:30:00	1.1906000000000001
2062	258	2282	2012-11-30 20:00:00	1.1910000000000001
2081	258	2301	2012-11-30 20:30:00	1.1919
2082	258	2302	2012-11-30 21:00:00	1.1921999999999999
2083	258	2303	2012-11-30 21:30:00	1.1933
2084	258	2304	2012-11-30 22:00:00	1.1939
2101	258	2321	2012-11-30 22:30:00	1.1943999999999999
2102	258	2322	2012-11-30 23:00:00	1.1957
\.


--
-- Data for Name: s_data_emc; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_emc (id, sensor_id, sensor_data_id, date_time, emc) FROM stdin;
1581	251	1801	2012-11-22 00:30:00	9.3399999999999999
1582	251	1802	2012-11-22 01:00:00	9.3399999999999999
1583	251	1803	2012-11-22 01:30:00	9.3399999999999999
1584	251	1804	2012-11-22 02:00:00	9.3399999999999999
1585	251	1805	2012-11-22 02:30:00	9.3399999999999999
1586	251	1806	2012-11-22 03:00:00	9.3499999999999996
1587	251	1807	2012-11-22 03:30:00	9.3499999999999996
1588	251	1808	2012-11-22 04:00:00	9.3499999999999996
1589	251	1809	2012-11-22 04:30:00	9.3499999999999996
1590	251	1810	2012-11-22 05:00:00	9.3499999999999996
1591	251	1811	2012-11-22 05:30:00	9.3499999999999996
1592	251	1812	2012-11-22 06:00:00	9.3599999999999994
1593	251	1813	2012-11-22 06:30:00	9.3599999999999994
1594	251	1814	2012-11-22 07:00:00	9.3599999999999994
1595	251	1815	2012-11-22 07:30:00	9.3599999999999994
1596	251	1816	2012-11-22 08:00:00	9.3599999999999994
1597	251	1817	2012-11-22 08:30:00	9.3599999999999994
1598	251	1818	2012-11-22 09:00:00	9.3599999999999994
1599	251	1819	2012-11-22 09:30:00	9.3599999999999994
1600	251	1820	2012-11-22 10:00:00	9.3699999999999992
1601	251	1821	2012-11-22 10:30:00	9.3699999999999992
1602	251	1822	2012-11-22 11:00:00	9.3699999999999992
1603	251	1823	2012-11-22 11:30:00	9.75
1604	251	1824	2012-11-22 12:00:00	10.449999999999999
1605	251	1825	2012-11-22 12:30:00	10.75
1606	251	1826	2012-11-22 13:00:00	11.050000000000001
1607	251	1827	2012-11-22 13:30:00	11.050000000000001
1608	251	1828	2012-11-22 14:00:00	10.609999999999999
1609	251	1829	2012-11-22 14:30:00	10.6
1610	251	1830	2012-11-22 15:00:00	10.4
1611	251	1831	2012-11-22 15:30:00	10.199999999999999
1612	251	1832	2012-11-22 16:00:00	10.19
1613	251	1833	2012-11-22 16:30:00	10.029999999999999
1614	251	1834	2012-11-22 17:00:00	10.02
1615	251	1835	2012-11-22 17:30:00	10.18
1616	251	1836	2012-11-22 18:00:00	10.17
1617	251	1837	2012-11-22 18:30:00	10.17
1618	251	1838	2012-11-22 19:00:00	9.9700000000000006
1619	251	1839	2012-11-22 19:30:00	9.9800000000000004
1620	251	1840	2012-11-22 20:00:00	9.9800000000000004
1621	251	1841	2012-11-22 20:30:00	9.8599999999999994
1622	251	1842	2012-11-22 21:00:00	9.8599999999999994
1623	251	1843	2012-11-22 21:30:00	9.8599999999999994
1624	251	1844	2012-11-22 22:00:00	9.8599999999999994
1625	251	1845	2012-11-22 22:30:00	9.6600000000000001
1626	251	1846	2012-11-22 23:00:00	9.6600000000000001
1627	251	1847	2012-11-22 23:30:00	9.6600000000000001
1628	251	1848	2012-11-23 00:00:00	9.6699999999999999
1629	251	1849	2012-11-23 00:30:00	9.6699999999999999
1630	251	1850	2012-11-23 01:00:00	9.4700000000000006
1631	251	1851	2012-11-23 01:30:00	9.4800000000000004
1632	251	1852	2012-11-23 02:00:00	9.4800000000000004
1633	251	1853	2012-11-23 02:30:00	9.4800000000000004
1634	251	1854	2012-11-23 03:00:00	9.4800000000000004
1635	251	1855	2012-11-23 03:30:00	9.4900000000000002
1636	251	1856	2012-11-23 04:00:00	9.4900000000000002
1637	251	1857	2012-11-23 04:30:00	9.4900000000000002
1638	251	1858	2012-11-23 05:00:00	9.2899999999999991
1639	251	1859	2012-11-23 05:30:00	9.3000000000000007
1640	251	1860	2012-11-23 06:00:00	9.3000000000000007
1641	251	1861	2012-11-23 06:30:00	9.3000000000000007
1642	251	1862	2012-11-23 07:00:00	9.3000000000000007
1643	251	1863	2012-11-23 07:30:00	9.3100000000000005
1644	251	1864	2012-11-23 08:00:00	9.3100000000000005
1645	251	1865	2012-11-23 08:30:00	9.3100000000000005
1646	251	1866	2012-11-23 09:00:00	9.3100000000000005
1647	251	1867	2012-11-23 09:30:00	9.3100000000000005
1648	251	1868	2012-11-23 10:00:00	9.3200000000000003
1649	251	1869	2012-11-23 10:30:00	9.3200000000000003
1650	251	1870	2012-11-23 11:00:00	10.07
1651	251	1871	2012-11-23 11:30:00	10.59
1652	251	1872	2012-11-23 12:00:00	10.75
1653	251	1873	2012-11-23 12:30:00	10.369999999999999
1654	251	1874	2012-11-23 13:00:00	10.17
1655	251	1875	2012-11-23 13:30:00	9.9700000000000006
1656	251	1876	2012-11-23 14:00:00	9.8599999999999994
1657	251	1877	2012-11-23 14:30:00	9.8599999999999994
1658	251	1878	2012-11-23 15:00:00	9.9700000000000006
1659	251	1879	2012-11-23 15:30:00	9.9700000000000006
1660	251	1880	2012-11-23 16:00:00	9.9700000000000006
1661	251	1881	2012-11-23 16:30:00	9.9600000000000009
1662	251	1882	2012-11-23 17:00:00	9.9499999999999993
1663	251	1883	2012-11-23 17:30:00	9.9399999999999995
1664	251	1884	2012-11-23 18:00:00	9.9399999999999995
1665	251	1885	2012-11-23 18:30:00	9.9299999999999997
1666	251	1886	2012-11-23 19:00:00	9.9299999999999997
1667	251	1887	2012-11-23 19:30:00	9.9299999999999997
1668	251	1888	2012-11-23 20:00:00	9.9199999999999999
1669	251	1889	2012-11-23 20:30:00	9.9199999999999999
1670	251	1890	2012-11-23 21:00:00	9.9199999999999999
1671	251	1891	2012-11-23 21:30:00	9.9199999999999999
1672	251	1892	2012-11-23 22:00:00	9.9299999999999997
1673	251	1893	2012-11-23 22:30:00	9.9299999999999997
1674	251	1894	2012-11-23 23:00:00	9.9299999999999997
1675	251	1895	2012-11-23 23:30:00	9.9399999999999995
1676	251	1896	2012-11-24 00:00:00	9.9399999999999995
1677	251	1897	2012-11-24 00:30:00	9.9399999999999995
1678	251	1898	2012-11-24 01:00:00	9.9399999999999995
1679	251	1899	2012-11-24 01:30:00	9.8300000000000001
1680	251	1900	2012-11-24 02:00:00	9.8399999999999999
1681	251	1901	2012-11-24 02:30:00	9.8399999999999999
1682	251	1902	2012-11-24 03:00:00	9.6500000000000004
1683	251	1903	2012-11-24 03:30:00	9.6500000000000004
1684	251	1904	2012-11-24 04:00:00	9.6500000000000004
1685	251	1905	2012-11-24 04:30:00	9.4499999999999993
1686	251	1906	2012-11-24 05:00:00	9.4600000000000009
1687	251	1907	2012-11-24 05:30:00	9.4600000000000009
1688	251	1908	2012-11-24 06:00:00	9.4600000000000009
1689	251	1909	2012-11-24 06:30:00	9.4600000000000009
1690	251	1910	2012-11-24 07:00:00	9.2699999999999996
1691	251	1911	2012-11-24 07:30:00	9.2699999999999996
1692	251	1912	2012-11-24 08:00:00	9.2699999999999996
1693	251	1913	2012-11-24 08:30:00	9.2799999999999994
1694	251	1914	2012-11-24 09:00:00	9.2799999999999994
1695	251	1915	2012-11-24 09:30:00	9.2799999999999994
1696	251	1916	2012-11-24 10:00:00	9.4800000000000004
1697	251	1917	2012-11-24 10:30:00	9.2799999999999994
1698	251	1918	2012-11-24 11:00:00	9.4800000000000004
1699	251	1919	2012-11-24 11:30:00	9.4800000000000004
1700	251	1920	2012-11-24 12:00:00	9.4700000000000006
1701	251	1921	2012-11-24 12:30:00	9.4700000000000006
1702	251	1922	2012-11-24 13:00:00	9.4700000000000006
1703	251	1923	2012-11-24 13:30:00	9.4700000000000006
1704	251	1924	2012-11-24 14:00:00	9.4700000000000006
1705	251	1925	2012-11-24 14:30:00	9.4600000000000009
1706	251	1926	2012-11-24 15:00:00	9.2599999999999998
1707	251	1927	2012-11-24 15:30:00	9.0600000000000005
1708	251	1928	2012-11-24 16:00:00	9.2699999999999996
1709	251	1929	2012-11-24 16:30:00	9.2599999999999998
1710	251	1930	2012-11-24 17:00:00	9.2699999999999996
1711	251	1931	2012-11-24 17:30:00	9.2699999999999996
1712	251	1932	2012-11-24 18:00:00	9.2699999999999996
1713	251	1933	2012-11-24 18:30:00	9.2699999999999996
1714	251	1934	2012-11-24 19:00:00	9.2799999999999994
1715	251	1935	2012-11-24 19:30:00	9.2799999999999994
1716	251	1936	2012-11-24 20:00:00	9.2799999999999994
1717	251	1937	2012-11-24 20:30:00	9.0800000000000001
1718	251	1938	2012-11-24 21:00:00	9.0899999999999999
1719	251	1939	2012-11-24 21:30:00	9.0899999999999999
1720	251	1940	2012-11-24 22:00:00	9.0899999999999999
1721	251	1941	2012-11-24 22:30:00	9.0899999999999999
1722	251	1942	2012-11-24 23:00:00	9.0999999999999996
1723	251	1943	2012-11-24 23:30:00	8.9000000000000004
1724	251	1944	2012-11-25 00:00:00	8.9000000000000004
1725	251	1945	2012-11-25 00:30:00	8.9100000000000001
1726	251	1946	2012-11-25 01:00:00	8.9100000000000001
1727	251	1947	2012-11-25 01:30:00	8.9100000000000001
1728	251	1948	2012-11-25 02:00:00	8.9199999999999999
1729	251	1949	2012-11-25 02:30:00	8.8200000000000003
1730	251	1950	2012-11-25 03:00:00	8.8200000000000003
1731	251	1951	2012-11-25 03:30:00	8.8300000000000001
1732	251	1952	2012-11-25 04:00:00	8.8300000000000001
1733	251	1953	2012-11-25 04:30:00	8.8300000000000001
1734	251	1954	2012-11-25 05:00:00	8.8300000000000001
1735	251	1955	2012-11-25 05:30:00	8.8399999999999999
1736	251	1956	2012-11-25 06:00:00	8.8399999999999999
1737	251	1957	2012-11-25 06:30:00	8.8399999999999999
1738	251	1958	2012-11-25 07:00:00	8.8399999999999999
1739	251	1959	2012-11-25 07:30:00	8.8499999999999996
1740	251	1960	2012-11-25 08:00:00	8.8499999999999996
1741	251	1961	2012-11-25 08:30:00	8.8499999999999996
1742	251	1962	2012-11-25 09:00:00	8.8599999999999994
1743	251	1963	2012-11-25 09:30:00	8.8599999999999994
1744	251	1964	2012-11-25 10:00:00	8.8599999999999994
1745	251	1965	2012-11-25 10:30:00	8.9499999999999993
1746	251	1966	2012-11-25 11:00:00	8.9399999999999995
1747	251	1967	2012-11-25 11:30:00	8.9299999999999997
1748	251	1968	2012-11-25 12:00:00	8.9299999999999997
1749	251	1969	2012-11-25 12:30:00	8.9199999999999999
1750	251	1970	2012-11-25 13:00:00	9.1199999999999992
1751	251	1971	2012-11-25 13:30:00	9.1199999999999992
1752	251	1972	2012-11-25 14:00:00	9.1199999999999992
1753	251	1973	2012-11-25 14:30:00	9.1199999999999992
1754	251	1974	2012-11-25 15:00:00	9.1199999999999992
1755	251	1975	2012-11-25 15:30:00	9.1099999999999994
1756	251	1976	2012-11-25 16:00:00	9.1099999999999994
1757	251	1977	2012-11-25 16:30:00	9.0999999999999996
1758	251	1978	2012-11-25 17:00:00	9.0999999999999996
1759	251	1979	2012-11-25 17:30:00	9.0999999999999996
1760	251	1980	2012-11-25 18:00:00	9.0999999999999996
1761	251	1981	2012-11-25 18:30:00	9.0899999999999999
1762	251	1982	2012-11-25 19:00:00	9.0899999999999999
1763	251	1983	2012-11-25 19:30:00	9.0899999999999999
1764	251	1984	2012-11-25 20:00:00	9.0800000000000001
1765	251	1985	2012-11-25 20:30:00	9.0800000000000001
1766	251	1986	2012-11-25 21:00:00	9.0800000000000001
1767	251	1987	2012-11-25 21:30:00	9.0800000000000001
1768	251	1988	2012-11-25 22:00:00	9.0899999999999999
1769	251	1989	2012-11-25 22:30:00	9.0899999999999999
1770	251	1990	2012-11-25 23:00:00	9.0899999999999999
1771	251	1991	2012-11-25 23:30:00	9.0899999999999999
1772	251	1992	2012-11-26 00:00:00	9.0999999999999996
1773	251	1993	2012-11-26 00:30:00	9.0999999999999996
1774	251	1994	2012-11-26 01:00:00	9.0999999999999996
1775	251	1995	2012-11-26 01:30:00	9.1099999999999994
1776	251	1996	2012-11-26 02:00:00	8.9100000000000001
1777	251	1997	2012-11-26 02:30:00	8.9100000000000001
1778	251	1998	2012-11-26 03:00:00	8.9100000000000001
1779	251	1999	2012-11-26 03:30:00	8.9199999999999999
1780	251	2000	2012-11-26 04:00:00	8.9199999999999999
1781	251	2001	2012-11-26 04:30:00	8.9199999999999999
1782	251	2002	2012-11-26 05:00:00	8.9199999999999999
1783	251	2003	2012-11-26 05:30:00	8.9299999999999997
1784	251	2004	2012-11-26 06:00:00	8.9299999999999997
1785	251	2005	2012-11-26 06:30:00	8.9299999999999997
1786	251	2006	2012-11-26 07:00:00	8.9299999999999997
1787	251	2007	2012-11-26 07:30:00	8.9299999999999997
1788	251	2008	2012-11-26 08:00:00	8.9299999999999997
1789	251	2009	2012-11-26 08:30:00	8.9299999999999997
1790	251	2010	2012-11-26 09:00:00	8.9399999999999995
1791	251	2011	2012-11-26 09:30:00	8.9399999999999995
1792	251	2012	2012-11-26 10:00:00	9.1400000000000006
1793	251	2013	2012-11-26 10:30:00	9.1400000000000006
1794	251	2014	2012-11-26 11:00:00	9.1300000000000008
1795	251	2015	2012-11-26 11:30:00	9.1300000000000008
1796	251	2016	2012-11-26 12:00:00	9.1300000000000008
1797	251	2017	2012-11-26 12:30:00	9.1199999999999992
1798	251	2018	2012-11-26 13:00:00	9.1199999999999992
1799	251	2019	2012-11-26 13:30:00	9.1199999999999992
1800	251	2020	2012-11-26 14:00:00	9.1099999999999994
1801	251	2021	2012-11-26 14:30:00	9.1099999999999994
1802	251	2022	2012-11-26 15:00:00	9.1099999999999994
1803	251	2023	2012-11-26 15:30:00	9.1099999999999994
1804	251	2024	2012-11-26 16:00:00	9.3100000000000005
1805	251	2025	2012-11-26 16:30:00	9.3100000000000005
1806	251	2026	2012-11-26 17:00:00	9.3000000000000007
1807	251	2027	2012-11-26 17:30:00	9.3000000000000007
1808	251	2028	2012-11-26 18:00:00	9.3000000000000007
1809	251	2029	2012-11-26 18:30:00	9.2899999999999991
1810	251	2030	2012-11-26 19:00:00	9.3000000000000007
1811	251	2031	2012-11-26 19:30:00	9.3000000000000007
1812	251	2032	2012-11-26 20:00:00	9.3000000000000007
1813	251	2033	2012-11-26 20:30:00	9.3000000000000007
1814	251	2034	2012-11-26 21:00:00	9.3000000000000007
1815	251	2035	2012-11-26 21:30:00	9.3000000000000007
1816	251	2036	2012-11-26 22:00:00	9.1099999999999994
1817	251	2037	2012-11-26 22:30:00	9.1099999999999994
1818	251	2038	2012-11-26 23:00:00	9.1099999999999994
1819	251	2039	2012-11-26 23:30:00	9.1099999999999994
1820	251	2040	2012-11-27 00:00:00	9.1099999999999994
1821	251	2041	2012-11-27 00:30:00	9.1099999999999994
1837	251	2057	2012-11-27 08:30:00	8.9299999999999997
1844	251	2064	2012-11-27 12:00:00	9.1400000000000006
1845	251	2065	2012-11-27 12:30:00	9.1400000000000006
1822	251	2042	2012-11-27 01:00:00	9.1099999999999994
1842	251	2062	2012-11-27 11:00:00	8.9399999999999995
1823	251	2043	2012-11-27 01:30:00	9.1099999999999994
1824	251	2044	2012-11-27 02:00:00	9.1199999999999992
1827	251	2047	2012-11-27 03:30:00	8.9199999999999999
1834	251	2054	2012-11-27 07:00:00	8.9299999999999997
1839	251	2059	2012-11-27 09:30:00	8.9299999999999997
1840	251	2060	2012-11-27 10:00:00	8.9399999999999995
1825	251	2045	2012-11-27 02:30:00	8.9199999999999999
1828	251	2048	2012-11-27 04:00:00	8.9199999999999999
1846	251	2066	2012-11-27 13:00:00	9.1300000000000008
1826	251	2046	2012-11-27 03:00:00	8.9199999999999999
1847	251	2067	2012-11-27 13:30:00	8.9299999999999997
1829	251	2049	2012-11-27 04:30:00	8.9199999999999999
1830	251	2050	2012-11-27 05:00:00	8.9299999999999997
1836	251	2056	2012-11-27 08:00:00	8.9299999999999997
1831	251	2051	2012-11-27 05:30:00	8.9299999999999997
1833	251	2053	2012-11-27 06:30:00	8.9299999999999997
1835	251	2055	2012-11-27 07:30:00	8.9299999999999997
1841	251	2061	2012-11-27 10:30:00	8.9399999999999995
1832	251	2052	2012-11-27 06:00:00	8.9299999999999997
1838	251	2058	2012-11-27 09:00:00	8.9299999999999997
1843	251	2063	2012-11-27 11:30:00	8.9399999999999995
1848	251	2068	2012-11-27 14:00:00	8.9299999999999997
1849	251	2069	2012-11-27 14:30:00	8.9299999999999997
1850	251	2070	2012-11-27 15:00:00	8.9299999999999997
1851	251	2071	2012-11-27 15:30:00	8.9299999999999997
1852	251	2072	2012-11-27 16:00:00	8.9299999999999997
1853	251	2073	2012-11-27 16:30:00	8.8300000000000001
1854	251	2074	2012-11-27 17:00:00	8.8399999999999999
1855	251	2075	2012-11-27 17:30:00	8.8399999999999999
1856	251	2076	2012-11-27 18:00:00	8.8399999999999999
1857	251	2077	2012-11-27 18:30:00	8.6500000000000004
1858	251	2078	2012-11-27 19:00:00	8.8399999999999999
1859	251	2079	2012-11-27 19:30:00	8.8399999999999999
1860	251	2080	2012-11-27 20:00:00	8.9399999999999995
1861	251	2081	2012-11-27 20:30:00	8.9399999999999995
1862	251	2082	2012-11-27 21:00:00	8.9399999999999995
1863	251	2083	2012-11-27 21:30:00	8.9399999999999995
1864	251	2084	2012-11-27 22:00:00	8.9399999999999995
1865	251	2085	2012-11-27 22:30:00	8.9399999999999995
1866	251	2086	2012-11-27 23:00:00	8.9399999999999995
1867	251	2087	2012-11-27 23:30:00	8.9399999999999995
1868	251	2088	2012-11-28 00:00:00	8.9399999999999995
1869	251	2089	2012-11-28 00:30:00	9.1400000000000006
1870	251	2090	2012-11-28 01:00:00	9.1400000000000006
1871	251	2091	2012-11-28 01:30:00	9.1400000000000006
1872	251	2092	2012-11-28 02:00:00	9.1400000000000006
1873	251	2093	2012-11-28 02:30:00	9.1400000000000006
1874	251	2094	2012-11-28 03:00:00	9.1400000000000006
1875	251	2095	2012-11-28 03:30:00	9.1400000000000006
1876	251	2096	2012-11-28 04:00:00	9.1400000000000006
1877	251	2097	2012-11-28 04:30:00	9.1400000000000006
1878	251	2098	2012-11-28 05:00:00	9.1400000000000006
1879	251	2099	2012-11-28 05:30:00	9.1400000000000006
1880	251	2100	2012-11-28 06:00:00	9.1400000000000006
1881	251	2101	2012-11-28 06:30:00	9.1400000000000006
1882	251	2102	2012-11-28 07:00:00	9.1500000000000004
1883	251	2103	2012-11-28 07:30:00	9.1500000000000004
1884	251	2104	2012-11-28 08:00:00	9.1500000000000004
1885	251	2105	2012-11-28 08:30:00	9.1500000000000004
1886	251	2106	2012-11-28 09:00:00	9.1500000000000004
1887	251	2107	2012-11-28 09:30:00	9.1500000000000004
1888	251	2108	2012-11-28 10:00:00	9.1500000000000004
1889	251	2109	2012-11-28 10:30:00	9.1500000000000004
1890	251	2110	2012-11-28 11:00:00	9.3499999999999996
1891	251	2111	2012-11-28 11:30:00	9.3499999999999996
1892	251	2112	2012-11-28 12:00:00	9.3399999999999999
1893	251	2113	2012-11-28 12:30:00	9.3300000000000001
1894	251	2114	2012-11-28 13:00:00	9.5299999999999994
1895	251	2115	2012-11-28 13:30:00	9.5299999999999994
1896	251	2116	2012-11-28 14:00:00	9.5199999999999996
1897	251	2117	2012-11-28 14:30:00	9.5099999999999998
1898	251	2118	2012-11-28 15:00:00	9.5099999999999998
1899	251	2119	2012-11-28 15:30:00	9.5
1900	251	2120	2012-11-28 16:00:00	9.4900000000000002
1901	251	2121	2012-11-28 16:30:00	9.4900000000000002
1902	251	2122	2012-11-28 17:00:00	9.4800000000000004
1903	251	2123	2012-11-28 17:30:00	9.4700000000000006
1904	251	2124	2012-11-28 18:00:00	9.4700000000000006
1905	251	2125	2012-11-28 18:30:00	9.2699999999999996
1906	251	2126	2012-11-28 19:00:00	9.2699999999999996
1907	251	2127	2012-11-28 19:30:00	9.2699999999999996
1908	251	2128	2012-11-28 20:00:00	9.2699999999999996
1909	251	2129	2012-11-28 20:30:00	9.2699999999999996
1910	251	2130	2012-11-28 21:00:00	9.2699999999999996
1911	251	2131	2012-11-28 21:30:00	9.2799999999999994
1912	251	2132	2012-11-28 22:00:00	9.2799999999999994
1913	251	2133	2012-11-28 22:30:00	9.2799999999999994
1914	251	2134	2012-11-28 23:00:00	9.4800000000000004
1915	251	2135	2012-11-28 23:30:00	9.4800000000000004
1916	251	2136	2012-11-29 00:00:00	9.4800000000000004
1917	251	2137	2012-11-29 00:30:00	9.4900000000000002
1918	251	2138	2012-11-29 01:00:00	9.4900000000000002
1919	251	2139	2012-11-29 01:30:00	9.4900000000000002
1920	251	2140	2012-11-29 02:00:00	9.2899999999999991
1921	251	2141	2012-11-29 02:30:00	9.0800000000000001
1922	251	2142	2012-11-29 03:00:00	9.2899999999999991
1923	251	2143	2012-11-29 03:30:00	9.2899999999999991
1924	251	2144	2012-11-29 04:00:00	9.2899999999999991
1925	251	2145	2012-11-29 04:30:00	9.3000000000000007
1926	251	2146	2012-11-29 05:00:00	9.0999999999999996
1927	251	2147	2012-11-29 05:30:00	9.0999999999999996
1928	251	2148	2012-11-29 06:00:00	9.1099999999999994
1929	251	2149	2012-11-29 06:30:00	9.1099999999999994
1930	251	2150	2012-11-29 07:00:00	9.1099999999999994
1931	251	2151	2012-11-29 07:30:00	8.9000000000000004
1932	251	2152	2012-11-29 08:00:00	8.9100000000000001
1933	251	2153	2012-11-29 08:30:00	8.9199999999999999
1934	251	2154	2012-11-29 09:00:00	9.1199999999999992
1935	251	2155	2012-11-29 09:30:00	9.1199999999999992
1936	251	2156	2012-11-29 10:00:00	8.9199999999999999
1937	251	2157	2012-11-29 10:30:00	8.9299999999999997
1938	251	2158	2012-11-29 11:00:00	8.9299999999999997
1939	251	2159	2012-11-29 11:30:00	9.1300000000000008
1940	251	2160	2012-11-29 12:00:00	9.1300000000000008
1941	251	2161	2012-11-29 12:30:00	9.3300000000000001
1942	251	2162	2012-11-29 13:00:00	9.3300000000000001
1943	251	2163	2012-11-29 13:30:00	9.3300000000000001
1944	251	2164	2012-11-29 14:00:00	9.3300000000000001
1945	251	2165	2012-11-29 14:30:00	9.3300000000000001
1946	251	2166	2012-11-29 15:00:00	9.3300000000000001
1947	251	2167	2012-11-29 15:30:00	9.3300000000000001
1948	251	2168	2012-11-29 16:00:00	9.3300000000000001
1949	251	2169	2012-11-29 16:30:00	9.5199999999999996
1950	251	2170	2012-11-29 17:00:00	9.5199999999999996
1951	251	2171	2012-11-29 17:30:00	9.5099999999999998
1952	251	2172	2012-11-29 18:00:00	9.5099999999999998
1953	251	2173	2012-11-29 18:30:00	9.5099999999999998
1954	251	2174	2012-11-29 19:00:00	9.5
1955	251	2175	2012-11-29 19:30:00	9.3000000000000007
1956	251	2176	2012-11-29 20:00:00	9.3000000000000007
1957	251	2177	2012-11-29 20:30:00	9.3000000000000007
1958	251	2178	2012-11-29 21:00:00	9.3000000000000007
1959	251	2179	2012-11-29 21:30:00	9.2899999999999991
1960	251	2180	2012-11-29 22:00:00	9.2899999999999991
1961	251	2181	2012-11-29 22:30:00	9.2899999999999991
1962	251	2182	2012-11-29 23:00:00	9.2899999999999991
1963	251	2183	2012-11-29 23:30:00	9.2899999999999991
1964	251	2184	2012-11-30 00:00:00	9.0899999999999999
1965	251	2185	2012-11-30 00:30:00	9.0899999999999999
1966	251	2186	2012-11-30 01:00:00	8.9000000000000004
1967	251	2187	2012-11-30 01:30:00	8.8000000000000007
1968	251	2188	2012-11-30 02:00:00	8.8100000000000005
1969	251	2189	2012-11-30 02:30:00	8.6500000000000004
1970	251	2190	2012-11-30 03:00:00	8.5099999999999998
1971	251	2191	2012-11-30 03:30:00	8.5199999999999996
1972	251	2192	2012-11-30 04:00:00	8.5199999999999996
1973	251	2193	2012-11-30 04:30:00	8.3499999999999996
1974	251	2194	2012-11-30 05:00:00	8.3499999999999996
1975	251	2195	2012-11-30 05:30:00	8.3499999999999996
1976	251	2196	2012-11-30 06:00:00	8.3499999999999996
2001	251	2221	2012-11-30 06:30:00	8.25
2002	251	2222	2012-11-30 07:00:00	8.25
2021	251	2241	2012-11-30 07:30:00	8.3499999999999996
2022	251	2242	2012-11-30 08:00:00	8.3499999999999996
2023	251	2243	2012-11-30 08:30:00	8.5399999999999991
2024	251	2244	2012-11-30 09:00:00	8.5299999999999994
2025	251	2245	2012-11-30 09:30:00	8.5299999999999994
2026	251	2246	2012-11-30 10:00:00	8.6500000000000004
2027	251	2247	2012-11-30 10:30:00	8.6500000000000004
2028	251	2248	2012-11-30 11:00:00	8.6500000000000004
2029	251	2249	2012-11-30 11:30:00	8.5199999999999996
2030	251	2250	2012-11-30 12:00:00	8.5199999999999996
2031	251	2251	2012-11-30 12:30:00	8.5199999999999996
2032	251	2252	2012-11-30 13:00:00	8.5199999999999996
2033	251	2253	2012-11-30 13:30:00	8.5199999999999996
2034	251	2254	2012-11-30 14:00:00	8.5299999999999994
2035	251	2255	2012-11-30 14:30:00	8.5299999999999994
2036	251	2256	2012-11-30 15:00:00	8.5299999999999994
2037	251	2257	2012-11-30 15:30:00	8.5299999999999994
2038	251	2258	2012-11-30 16:00:00	8.5299999999999994
2039	251	2259	2012-11-30 16:30:00	8.5199999999999996
2040	251	2260	2012-11-30 17:00:00	8.5199999999999996
2041	251	2261	2012-11-30 17:30:00	8.5199999999999996
2042	251	2262	2012-11-30 18:00:00	8.5199999999999996
2043	251	2263	2012-11-30 18:30:00	8.5099999999999998
2044	251	2264	2012-11-30 19:00:00	8.5099999999999998
2061	251	2281	2012-11-30 19:30:00	8.5099999999999998
2062	251	2282	2012-11-30 20:00:00	8.5099999999999998
2081	251	2301	2012-11-30 20:30:00	8.5199999999999996
2082	251	2302	2012-11-30 21:00:00	8.5199999999999996
2083	251	2303	2012-11-30 21:30:00	8.5199999999999996
2084	251	2304	2012-11-30 22:00:00	8.5199999999999996
2101	251	2321	2012-11-30 22:30:00	8.5299999999999994
2102	251	2322	2012-11-30 23:00:00	8.3499999999999996
\.


--
-- Data for Name: s_data_humiditys; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_humiditys (id, sensor_id, sensor_data_id, date_time, humidity, absolute_humidity, relative_humidity, specific_humidity) FROM stdin;
5141	254	1801	2012-11-22 00:30:00	50	\N	\N	\N
5142	255	1801	2012-11-22 00:30:00	80	\N	\N	\N
5143	242	1801	2012-11-22 00:30:00	96	\N	\N	\N
5144	254	1802	2012-11-22 01:00:00	50	\N	\N	\N
5145	255	1802	2012-11-22 01:00:00	80	\N	\N	\N
5146	242	1802	2012-11-22 01:00:00	96	\N	\N	\N
5147	254	1803	2012-11-22 01:30:00	50	\N	\N	\N
5148	255	1803	2012-11-22 01:30:00	80	\N	\N	\N
5149	242	1803	2012-11-22 01:30:00	96	\N	\N	\N
5150	254	1804	2012-11-22 02:00:00	50	\N	\N	\N
5151	255	1804	2012-11-22 02:00:00	80	\N	\N	\N
5152	242	1804	2012-11-22 02:00:00	96	\N	\N	\N
5153	254	1805	2012-11-22 02:30:00	50	\N	\N	\N
5154	255	1805	2012-11-22 02:30:00	80	\N	\N	\N
5155	242	1805	2012-11-22 02:30:00	96	\N	\N	\N
5156	254	1806	2012-11-22 03:00:00	50	\N	\N	\N
5157	255	1806	2012-11-22 03:00:00	80	\N	\N	\N
5158	242	1806	2012-11-22 03:00:00	96	\N	\N	\N
5159	254	1807	2012-11-22 03:30:00	50	\N	\N	\N
5160	255	1807	2012-11-22 03:30:00	80	\N	\N	\N
5161	242	1807	2012-11-22 03:30:00	96	\N	\N	\N
5162	254	1808	2012-11-22 04:00:00	50	\N	\N	\N
5163	255	1808	2012-11-22 04:00:00	80	\N	\N	\N
5164	242	1808	2012-11-22 04:00:00	96	\N	\N	\N
5165	254	1809	2012-11-22 04:30:00	50	\N	\N	\N
5166	255	1809	2012-11-22 04:30:00	80	\N	\N	\N
5167	242	1809	2012-11-22 04:30:00	97	\N	\N	\N
5168	254	1810	2012-11-22 05:00:00	50	\N	\N	\N
5169	255	1810	2012-11-22 05:00:00	80	\N	\N	\N
5170	242	1810	2012-11-22 05:00:00	97	\N	\N	\N
5171	254	1811	2012-11-22 05:30:00	50	\N	\N	\N
5172	255	1811	2012-11-22 05:30:00	80	\N	\N	\N
5173	242	1811	2012-11-22 05:30:00	97	\N	\N	\N
5174	254	1812	2012-11-22 06:00:00	50	\N	\N	\N
5175	255	1812	2012-11-22 06:00:00	80	\N	\N	\N
5176	242	1812	2012-11-22 06:00:00	97	\N	\N	\N
5177	254	1813	2012-11-22 06:30:00	50	\N	\N	\N
5178	255	1813	2012-11-22 06:30:00	80	\N	\N	\N
5179	242	1813	2012-11-22 06:30:00	97	\N	\N	\N
5180	254	1814	2012-11-22 07:00:00	50	\N	\N	\N
5181	255	1814	2012-11-22 07:00:00	80	\N	\N	\N
5182	242	1814	2012-11-22 07:00:00	97	\N	\N	\N
5183	254	1815	2012-11-22 07:30:00	50	\N	\N	\N
5184	255	1815	2012-11-22 07:30:00	80	\N	\N	\N
5185	242	1815	2012-11-22 07:30:00	97	\N	\N	\N
5186	254	1816	2012-11-22 08:00:00	50	\N	\N	\N
5187	255	1816	2012-11-22 08:00:00	80	\N	\N	\N
5188	242	1816	2012-11-22 08:00:00	97	\N	\N	\N
5189	254	1817	2012-11-22 08:30:00	50	\N	\N	\N
5190	255	1817	2012-11-22 08:30:00	80	\N	\N	\N
5191	242	1817	2012-11-22 08:30:00	96	\N	\N	\N
5192	254	1818	2012-11-22 09:00:00	50	\N	\N	\N
5193	255	1818	2012-11-22 09:00:00	80	\N	\N	\N
5194	242	1818	2012-11-22 09:00:00	95	\N	\N	\N
5195	254	1819	2012-11-22 09:30:00	50	\N	\N	\N
5196	255	1819	2012-11-22 09:30:00	80	\N	\N	\N
5197	242	1819	2012-11-22 09:30:00	93	\N	\N	\N
5198	254	1820	2012-11-22 10:00:00	50	\N	\N	\N
5199	255	1820	2012-11-22 10:00:00	80	\N	\N	\N
5200	242	1820	2012-11-22 10:00:00	93	\N	\N	\N
5201	254	1821	2012-11-22 10:30:00	50	\N	\N	\N
5202	255	1821	2012-11-22 10:30:00	80	\N	\N	\N
5203	242	1821	2012-11-22 10:30:00	93	\N	\N	\N
5204	254	1822	2012-11-22 11:00:00	50	\N	\N	\N
5205	255	1822	2012-11-22 11:00:00	81	\N	\N	\N
5206	242	1822	2012-11-22 11:00:00	92	\N	\N	\N
5207	254	1823	2012-11-22 11:30:00	52	\N	\N	\N
5208	255	1823	2012-11-22 11:30:00	81	\N	\N	\N
5209	242	1823	2012-11-22 11:30:00	91	\N	\N	\N
5210	254	1824	2012-11-22 12:00:00	56	\N	\N	\N
5211	255	1824	2012-11-22 12:00:00	81	\N	\N	\N
5212	242	1824	2012-11-22 12:00:00	91	\N	\N	\N
5213	254	1825	2012-11-22 12:30:00	58	\N	\N	\N
5214	255	1825	2012-11-22 12:30:00	80	\N	\N	\N
5215	242	1825	2012-11-22 12:30:00	90	\N	\N	\N
5216	254	1826	2012-11-22 13:00:00	60	\N	\N	\N
5217	255	1826	2012-11-22 13:00:00	80	\N	\N	\N
5218	242	1826	2012-11-22 13:00:00	90	\N	\N	\N
5219	254	1827	2012-11-22 13:30:00	60	\N	\N	\N
5220	255	1827	2012-11-22 13:30:00	79	\N	\N	\N
5221	242	1827	2012-11-22 13:30:00	91	\N	\N	\N
5222	254	1828	2012-11-22 14:00:00	57	\N	\N	\N
5223	255	1828	2012-11-22 14:00:00	79	\N	\N	\N
5224	242	1828	2012-11-22 14:00:00	91	\N	\N	\N
5225	254	1829	2012-11-22 14:30:00	57	\N	\N	\N
5226	255	1829	2012-11-22 14:30:00	79	\N	\N	\N
5227	242	1829	2012-11-22 14:30:00	91	\N	\N	\N
5228	254	1830	2012-11-22 15:00:00	56	\N	\N	\N
5229	255	1830	2012-11-22 15:00:00	80	\N	\N	\N
5230	242	1830	2012-11-22 15:00:00	91	\N	\N	\N
5231	254	1831	2012-11-22 15:30:00	55	\N	\N	\N
5232	255	1831	2012-11-22 15:30:00	80	\N	\N	\N
5233	242	1831	2012-11-22 15:30:00	91	\N	\N	\N
5234	254	1832	2012-11-22 16:00:00	55	\N	\N	\N
5235	255	1832	2012-11-22 16:00:00	80	\N	\N	\N
5236	242	1832	2012-11-22 16:00:00	92	\N	\N	\N
5237	254	1833	2012-11-22 16:30:00	54	\N	\N	\N
5238	255	1833	2012-11-22 16:30:00	80	\N	\N	\N
5239	242	1833	2012-11-22 16:30:00	92	\N	\N	\N
5240	254	1834	2012-11-22 17:00:00	54	\N	\N	\N
5241	255	1834	2012-11-22 17:00:00	80	\N	\N	\N
5242	242	1834	2012-11-22 17:00:00	93	\N	\N	\N
5243	254	1835	2012-11-22 17:30:00	55	\N	\N	\N
5244	255	1835	2012-11-22 17:30:00	80	\N	\N	\N
5245	242	1835	2012-11-22 17:30:00	93	\N	\N	\N
5246	254	1836	2012-11-22 18:00:00	55	\N	\N	\N
5247	255	1836	2012-11-22 18:00:00	79	\N	\N	\N
5248	242	1836	2012-11-22 18:00:00	94	\N	\N	\N
5249	254	1837	2012-11-22 18:30:00	55	\N	\N	\N
5250	255	1837	2012-11-22 18:30:00	79	\N	\N	\N
5251	242	1837	2012-11-22 18:30:00	94	\N	\N	\N
5252	254	1838	2012-11-22 19:00:00	54	\N	\N	\N
5253	255	1838	2012-11-22 19:00:00	79	\N	\N	\N
5254	242	1838	2012-11-22 19:00:00	94	\N	\N	\N
5255	254	1839	2012-11-22 19:30:00	54	\N	\N	\N
5256	255	1839	2012-11-22 19:30:00	79	\N	\N	\N
5257	242	1839	2012-11-22 19:30:00	94	\N	\N	\N
5258	254	1840	2012-11-22 20:00:00	54	\N	\N	\N
5259	255	1840	2012-11-22 20:00:00	79	\N	\N	\N
5260	242	1840	2012-11-22 20:00:00	95	\N	\N	\N
5261	254	1841	2012-11-22 20:30:00	53	\N	\N	\N
5262	255	1841	2012-11-22 20:30:00	79	\N	\N	\N
5263	242	1841	2012-11-22 20:30:00	95	\N	\N	\N
5264	254	1842	2012-11-22 21:00:00	53	\N	\N	\N
5265	255	1842	2012-11-22 21:00:00	79	\N	\N	\N
5266	242	1842	2012-11-22 21:00:00	95	\N	\N	\N
5267	254	1843	2012-11-22 21:30:00	53	\N	\N	\N
5268	255	1843	2012-11-22 21:30:00	79	\N	\N	\N
5269	242	1843	2012-11-22 21:30:00	95	\N	\N	\N
5270	254	1844	2012-11-22 22:00:00	53	\N	\N	\N
5271	255	1844	2012-11-22 22:00:00	79	\N	\N	\N
5272	242	1844	2012-11-22 22:00:00	96	\N	\N	\N
5273	254	1845	2012-11-22 22:30:00	52	\N	\N	\N
5274	255	1845	2012-11-22 22:30:00	78	\N	\N	\N
5275	242	1845	2012-11-22 22:30:00	96	\N	\N	\N
5276	254	1846	2012-11-22 23:00:00	52	\N	\N	\N
5277	255	1846	2012-11-22 23:00:00	79	\N	\N	\N
5278	242	1846	2012-11-22 23:00:00	96	\N	\N	\N
5279	254	1847	2012-11-22 23:30:00	52	\N	\N	\N
5280	255	1847	2012-11-22 23:30:00	79	\N	\N	\N
5281	242	1847	2012-11-22 23:30:00	95	\N	\N	\N
5282	254	1848	2012-11-23 00:00:00	52	\N	\N	\N
5283	255	1848	2012-11-23 00:00:00	78	\N	\N	\N
5284	242	1848	2012-11-23 00:00:00	95	\N	\N	\N
5285	254	1849	2012-11-23 00:30:00	52	\N	\N	\N
5286	255	1849	2012-11-23 00:30:00	78	\N	\N	\N
5287	242	1849	2012-11-23 00:30:00	95	\N	\N	\N
5288	254	1850	2012-11-23 01:00:00	51	\N	\N	\N
5289	255	1850	2012-11-23 01:00:00	78	\N	\N	\N
5290	242	1850	2012-11-23 01:00:00	95	\N	\N	\N
5291	254	1851	2012-11-23 01:30:00	51	\N	\N	\N
5292	255	1851	2012-11-23 01:30:00	78	\N	\N	\N
5293	242	1851	2012-11-23 01:30:00	95	\N	\N	\N
5294	254	1852	2012-11-23 02:00:00	51	\N	\N	\N
5295	255	1852	2012-11-23 02:00:00	79	\N	\N	\N
5296	242	1852	2012-11-23 02:00:00	96	\N	\N	\N
5297	254	1853	2012-11-23 02:30:00	51	\N	\N	\N
5298	255	1853	2012-11-23 02:30:00	79	\N	\N	\N
5299	242	1853	2012-11-23 02:30:00	96	\N	\N	\N
5300	254	1854	2012-11-23 03:00:00	51	\N	\N	\N
5301	255	1854	2012-11-23 03:00:00	79	\N	\N	\N
5302	242	1854	2012-11-23 03:00:00	96	\N	\N	\N
5303	254	1855	2012-11-23 03:30:00	51	\N	\N	\N
5304	255	1855	2012-11-23 03:30:00	78	\N	\N	\N
5305	242	1855	2012-11-23 03:30:00	96	\N	\N	\N
5306	254	1856	2012-11-23 04:00:00	51	\N	\N	\N
5307	255	1856	2012-11-23 04:00:00	78	\N	\N	\N
5308	242	1856	2012-11-23 04:00:00	96	\N	\N	\N
5309	254	1857	2012-11-23 04:30:00	51	\N	\N	\N
5310	255	1857	2012-11-23 04:30:00	78	\N	\N	\N
5311	242	1857	2012-11-23 04:30:00	96	\N	\N	\N
5312	254	1858	2012-11-23 05:00:00	50	\N	\N	\N
5313	255	1858	2012-11-23 05:00:00	78	\N	\N	\N
5314	242	1858	2012-11-23 05:00:00	96	\N	\N	\N
5315	254	1859	2012-11-23 05:30:00	50	\N	\N	\N
5316	255	1859	2012-11-23 05:30:00	79	\N	\N	\N
5317	242	1859	2012-11-23 05:30:00	96	\N	\N	\N
5318	254	1860	2012-11-23 06:00:00	50	\N	\N	\N
5319	255	1860	2012-11-23 06:00:00	78	\N	\N	\N
5320	242	1860	2012-11-23 06:00:00	96	\N	\N	\N
5321	254	1861	2012-11-23 06:30:00	50	\N	\N	\N
5322	255	1861	2012-11-23 06:30:00	79	\N	\N	\N
5323	242	1861	2012-11-23 06:30:00	96	\N	\N	\N
5324	254	1862	2012-11-23 07:00:00	50	\N	\N	\N
5325	255	1862	2012-11-23 07:00:00	79	\N	\N	\N
5326	242	1862	2012-11-23 07:00:00	97	\N	\N	\N
5327	254	1863	2012-11-23 07:30:00	50	\N	\N	\N
5328	255	1863	2012-11-23 07:30:00	79	\N	\N	\N
5329	242	1863	2012-11-23 07:30:00	97	\N	\N	\N
5330	254	1864	2012-11-23 08:00:00	50	\N	\N	\N
5331	255	1864	2012-11-23 08:00:00	79	\N	\N	\N
5332	242	1864	2012-11-23 08:00:00	97	\N	\N	\N
5333	254	1865	2012-11-23 08:30:00	50	\N	\N	\N
5334	255	1865	2012-11-23 08:30:00	79	\N	\N	\N
5335	242	1865	2012-11-23 08:30:00	97	\N	\N	\N
5336	254	1866	2012-11-23 09:00:00	50	\N	\N	\N
5337	255	1866	2012-11-23 09:00:00	79	\N	\N	\N
5338	242	1866	2012-11-23 09:00:00	97	\N	\N	\N
5339	254	1867	2012-11-23 09:30:00	50	\N	\N	\N
5340	255	1867	2012-11-23 09:30:00	79	\N	\N	\N
5341	242	1867	2012-11-23 09:30:00	98	\N	\N	\N
5342	254	1868	2012-11-23 10:00:00	50	\N	\N	\N
5343	255	1868	2012-11-23 10:00:00	79	\N	\N	\N
5344	242	1868	2012-11-23 10:00:00	98	\N	\N	\N
5345	254	1869	2012-11-23 10:30:00	50	\N	\N	\N
5346	255	1869	2012-11-23 10:30:00	80	\N	\N	\N
5347	242	1869	2012-11-23 10:30:00	98	\N	\N	\N
5348	254	1870	2012-11-23 11:00:00	54	\N	\N	\N
5349	255	1870	2012-11-23 11:00:00	80	\N	\N	\N
5350	242	1870	2012-11-23 11:00:00	98	\N	\N	\N
5351	254	1871	2012-11-23 11:30:00	57	\N	\N	\N
5352	255	1871	2012-11-23 11:30:00	79	\N	\N	\N
5353	242	1871	2012-11-23 11:30:00	98	\N	\N	\N
5354	254	1872	2012-11-23 12:00:00	58	\N	\N	\N
5355	255	1872	2012-11-23 12:00:00	79	\N	\N	\N
5356	242	1872	2012-11-23 12:00:00	98	\N	\N	\N
5357	254	1873	2012-11-23 12:30:00	56	\N	\N	\N
5358	255	1873	2012-11-23 12:30:00	79	\N	\N	\N
5359	242	1873	2012-11-23 12:30:00	97	\N	\N	\N
5360	254	1874	2012-11-23 13:00:00	55	\N	\N	\N
5361	255	1874	2012-11-23 13:00:00	79	\N	\N	\N
5362	242	1874	2012-11-23 13:00:00	96	\N	\N	\N
5363	254	1875	2012-11-23 13:30:00	54	\N	\N	\N
5364	255	1875	2012-11-23 13:30:00	79	\N	\N	\N
5365	242	1875	2012-11-23 13:30:00	94	\N	\N	\N
5366	254	1876	2012-11-23 14:00:00	53	\N	\N	\N
5367	255	1876	2012-11-23 14:00:00	79	\N	\N	\N
5368	242	1876	2012-11-23 14:00:00	94	\N	\N	\N
5369	254	1877	2012-11-23 14:30:00	53	\N	\N	\N
5370	255	1877	2012-11-23 14:30:00	79	\N	\N	\N
5371	242	1877	2012-11-23 14:30:00	94	\N	\N	\N
5372	254	1878	2012-11-23 15:00:00	54	\N	\N	\N
5373	255	1878	2012-11-23 15:00:00	79	\N	\N	\N
5374	242	1878	2012-11-23 15:00:00	93	\N	\N	\N
5375	254	1879	2012-11-23 15:30:00	54	\N	\N	\N
5376	255	1879	2012-11-23 15:30:00	79	\N	\N	\N
5377	242	1879	2012-11-23 15:30:00	94	\N	\N	\N
5378	254	1880	2012-11-23 16:00:00	54	\N	\N	\N
5379	255	1880	2012-11-23 16:00:00	78	\N	\N	\N
5380	242	1880	2012-11-23 16:00:00	94	\N	\N	\N
5381	254	1881	2012-11-23 16:30:00	54	\N	\N	\N
5388	255	1883	2012-11-23 17:30:00	78	\N	\N	\N
5393	254	1885	2012-11-23 18:30:00	54	\N	\N	\N
5399	254	1887	2012-11-23 19:30:00	54	\N	\N	\N
5405	254	1889	2012-11-23 20:30:00	54	\N	\N	\N
5425	242	1895	2012-11-23 23:30:00	97	\N	\N	\N
5451	255	1904	2012-11-24 04:00:00	76	\N	\N	\N
5457	255	1906	2012-11-24 05:00:00	75	\N	\N	\N
5469	255	1910	2012-11-24 07:00:00	75	\N	\N	\N
5475	255	1912	2012-11-24 08:00:00	75	\N	\N	\N
5481	255	1914	2012-11-24 09:00:00	75	\N	\N	\N
5487	255	1916	2012-11-24 10:00:00	77	\N	\N	\N
5492	254	1918	2012-11-24 11:00:00	51	\N	\N	\N
5494	242	1918	2012-11-24 11:00:00	89	\N	\N	\N
5498	254	1920	2012-11-24 12:00:00	51	\N	\N	\N
5505	255	1922	2012-11-24 13:00:00	77	\N	\N	\N
5510	254	1924	2012-11-24 14:00:00	51	\N	\N	\N
5516	254	1926	2012-11-24 15:00:00	50	\N	\N	\N
5523	255	1928	2012-11-24 16:00:00	76	\N	\N	\N
5534	254	1932	2012-11-24 18:00:00	50	\N	\N	\N
5540	254	1934	2012-11-24 19:00:00	50	\N	\N	\N
5546	254	1936	2012-11-24 20:00:00	50	\N	\N	\N
5560	242	1940	2012-11-24 22:00:00	97	\N	\N	\N
5564	254	1942	2012-11-24 23:00:00	49	\N	\N	\N
5596	242	1952	2012-11-25 04:00:00	98	\N	\N	\N
5602	242	1954	2012-11-25 05:00:00	98	\N	\N	\N
5608	242	1956	2012-11-25 06:00:00	98	\N	\N	\N
5626	242	1962	2012-11-25 09:00:00	98	\N	\N	\N
5640	255	1967	2012-11-25 11:30:00	73	\N	\N	\N
5646	255	1969	2012-11-25 12:30:00	74	\N	\N	\N
5650	242	1970	2012-11-25 13:00:00	93	\N	\N	\N
5652	255	1971	2012-11-25 13:30:00	75	\N	\N	\N
5675	254	1979	2012-11-25 17:30:00	49	\N	\N	\N
5682	255	1981	2012-11-25 18:30:00	76	\N	\N	\N
5694	255	1985	2012-11-25 20:30:00	75	\N	\N	\N
5729	254	1997	2012-11-26 02:30:00	48	\N	\N	\N
5731	242	1997	2012-11-26 02:30:00	98	\N	\N	\N
5737	242	1999	2012-11-26 03:30:00	98	\N	\N	\N
5741	254	2001	2012-11-26 04:30:00	48	\N	\N	\N
5748	255	2003	2012-11-26 05:30:00	74	\N	\N	\N
5753	254	2005	2012-11-26 06:30:00	48	\N	\N	\N
5759	254	2007	2012-11-26 07:30:00	48	\N	\N	\N
5765	254	2009	2012-11-26 08:30:00	48	\N	\N	\N
5785	242	2015	2012-11-26 11:30:00	78	\N	\N	\N
5801	254	2021	2012-11-26 14:30:00	49	\N	\N	\N
5811	255	2024	2012-11-26 16:00:00	77	\N	\N	\N
5818	242	2026	2012-11-26 17:00:00	72	\N	\N	\N
5825	254	2029	2012-11-26 18:30:00	50	\N	\N	\N
5828	254	2030	2012-11-26 19:00:00	50	\N	\N	\N
5833	242	2031	2012-11-26 19:30:00	75	\N	\N	\N
5838	255	2033	2012-11-26 20:30:00	77	\N	\N	\N
5841	255	2034	2012-11-26 21:00:00	77	\N	\N	\N
5879	254	2047	2012-11-27 03:30:00	48	\N	\N	\N
5884	242	2048	2012-11-27 04:00:00	77	\N	\N	\N
5896	242	2052	2012-11-27 06:00:00	80	\N	\N	\N
5906	254	2056	2012-11-27 08:00:00	48	\N	\N	\N
5909	254	2057	2012-11-27 08:30:00	48	\N	\N	\N
5915	254	2059	2012-11-27 09:30:00	48	\N	\N	\N
5919	255	2060	2012-11-27 10:00:00	76	\N	\N	\N
5382	255	1881	2012-11-23 16:30:00	78	\N	\N	\N
5394	255	1885	2012-11-23 18:30:00	78	\N	\N	\N
5429	254	1897	2012-11-24 00:30:00	54	\N	\N	\N
5431	242	1897	2012-11-24 00:30:00	97	\N	\N	\N
5437	242	1899	2012-11-24 01:30:00	98	\N	\N	\N
5441	254	1901	2012-11-24 02:30:00	53	\N	\N	\N
5448	255	1903	2012-11-24 03:30:00	76	\N	\N	\N
5453	254	1905	2012-11-24 04:30:00	51	\N	\N	\N
5459	254	1907	2012-11-24 05:30:00	51	\N	\N	\N
5465	254	1909	2012-11-24 06:30:00	51	\N	\N	\N
5485	242	1915	2012-11-24 09:30:00	98	\N	\N	\N
5511	255	1924	2012-11-24 14:00:00	76	\N	\N	\N
5517	255	1926	2012-11-24 15:00:00	76	\N	\N	\N
5529	255	1930	2012-11-24 17:00:00	76	\N	\N	\N
5535	255	1932	2012-11-24 18:00:00	76	\N	\N	\N
5541	255	1934	2012-11-24 19:00:00	75	\N	\N	\N
5547	255	1936	2012-11-24 20:00:00	72	\N	\N	\N
5552	254	1938	2012-11-24 21:00:00	49	\N	\N	\N
5554	242	1938	2012-11-24 21:00:00	96	\N	\N	\N
5558	254	1940	2012-11-24 22:00:00	49	\N	\N	\N
5565	255	1942	2012-11-24 23:00:00	67	\N	\N	\N
5570	254	1944	2012-11-25 00:00:00	48	\N	\N	\N
5576	254	1946	2012-11-25 01:00:00	48	\N	\N	\N
5583	255	1948	2012-11-25 02:00:00	66	\N	\N	\N
5594	254	1952	2012-11-25 04:00:00	47	\N	\N	\N
5600	254	1954	2012-11-25 05:00:00	47	\N	\N	\N
5606	254	1956	2012-11-25 06:00:00	47	\N	\N	\N
5620	242	1960	2012-11-25 08:00:00	98	\N	\N	\N
5624	254	1962	2012-11-25 09:00:00	47	\N	\N	\N
5656	242	1972	2012-11-25 14:00:00	92	\N	\N	\N
5662	242	1974	2012-11-25 15:00:00	94	\N	\N	\N
5668	242	1976	2012-11-25 16:00:00	97	\N	\N	\N
5686	242	1982	2012-11-25 19:00:00	98	\N	\N	\N
5700	255	1987	2012-11-25 21:30:00	76	\N	\N	\N
5706	255	1989	2012-11-25 22:30:00	75	\N	\N	\N
5710	242	1990	2012-11-25 23:00:00	98	\N	\N	\N
5712	255	1991	2012-11-25 23:30:00	75	\N	\N	\N
5735	254	1999	2012-11-26 03:30:00	48	\N	\N	\N
5742	255	2001	2012-11-26 04:30:00	74	\N	\N	\N
5754	255	2005	2012-11-26 06:30:00	74	\N	\N	\N
5789	254	2017	2012-11-26 12:30:00	49	\N	\N	\N
5793	255	2018	2012-11-26 13:00:00	77	\N	\N	\N
5797	242	2019	2012-11-26 13:30:00	75	\N	\N	\N
5831	254	2031	2012-11-26 19:30:00	50	\N	\N	\N
5835	255	2032	2012-11-26 20:00:00	77	\N	\N	\N
5849	254	2037	2012-11-26 22:30:00	49	\N	\N	\N
5852	254	2038	2012-11-26 23:00:00	49	\N	\N	\N
5860	242	2040	2012-11-27 00:00:00	79	\N	\N	\N
5867	254	2043	2012-11-27 01:30:00	49	\N	\N	\N
5870	254	2044	2012-11-27 02:00:00	49	\N	\N	\N
5878	242	2046	2012-11-27 03:00:00	72	\N	\N	\N
5890	242	2050	2012-11-27 05:00:00	77	\N	\N	\N
5905	242	2055	2012-11-27 07:30:00	76	\N	\N	\N
5908	242	2056	2012-11-27 08:00:00	75	\N	\N	\N
5911	242	2057	2012-11-27 08:30:00	70	\N	\N	\N
5917	242	2059	2012-11-27 09:30:00	68	\N	\N	\N
5924	254	2062	2012-11-27 11:00:00	48	\N	\N	\N
5929	242	2063	2012-11-27 11:30:00	61	\N	\N	\N
5936	254	2066	2012-11-27 13:00:00	49	\N	\N	\N
5383	242	1881	2012-11-23 16:30:00	95	\N	\N	\N
5387	254	1883	2012-11-23 17:30:00	54	\N	\N	\N
5389	242	1883	2012-11-23 17:30:00	96	\N	\N	\N
5433	255	1898	2012-11-24 01:00:00	78	\N	\N	\N
5439	255	1900	2012-11-24 02:00:00	78	\N	\N	\N
5452	242	1904	2012-11-24 04:00:00	97	\N	\N	\N
5458	242	1906	2012-11-24 05:00:00	98	\N	\N	\N
5462	254	1908	2012-11-24 06:00:00	51	\N	\N	\N
5464	242	1908	2012-11-24 06:00:00	98	\N	\N	\N
5471	254	1911	2012-11-24 07:30:00	50	\N	\N	\N
5478	255	1913	2012-11-24 08:30:00	75	\N	\N	\N
5484	255	1915	2012-11-24 09:30:00	76	\N	\N	\N
5490	255	1917	2012-11-24 10:30:00	77	\N	\N	\N
5496	255	1919	2012-11-24 11:30:00	78	\N	\N	\N
5515	242	1925	2012-11-24 14:30:00	74	\N	\N	\N
5521	242	1927	2012-11-24 15:30:00	86	\N	\N	\N
5527	242	1929	2012-11-24 16:30:00	91	\N	\N	\N
5528	254	1930	2012-11-24 17:00:00	50	\N	\N	\N
5533	242	1931	2012-11-24 17:30:00	94	\N	\N	\N
5537	254	1933	2012-11-24 18:30:00	50	\N	\N	\N
5539	242	1933	2012-11-24 18:30:00	95	\N	\N	\N
5543	254	1935	2012-11-24 19:30:00	50	\N	\N	\N
5563	242	1941	2012-11-24 22:30:00	97	\N	\N	\N
5567	254	1943	2012-11-24 23:30:00	48	\N	\N	\N
5569	242	1943	2012-11-24 23:30:00	97	\N	\N	\N
5613	255	1958	2012-11-25 07:00:00	68	\N	\N	\N
5619	255	1960	2012-11-25 08:00:00	68	\N	\N	\N
5632	242	1964	2012-11-25 10:00:00	98	\N	\N	\N
5638	242	1966	2012-11-25 11:00:00	98	\N	\N	\N
5642	254	1968	2012-11-25 12:00:00	48	\N	\N	\N
5644	242	1968	2012-11-25 12:00:00	98	\N	\N	\N
5651	254	1971	2012-11-25 13:30:00	49	\N	\N	\N
5658	255	1973	2012-11-25 14:30:00	76	\N	\N	\N
5664	255	1975	2012-11-25 15:30:00	76	\N	\N	\N
5670	255	1977	2012-11-25 16:30:00	75	\N	\N	\N
5676	255	1979	2012-11-25 17:30:00	76	\N	\N	\N
5695	242	1985	2012-11-25 20:30:00	98	\N	\N	\N
5701	242	1987	2012-11-25 21:30:00	98	\N	\N	\N
5707	242	1989	2012-11-25 22:30:00	98	\N	\N	\N
5708	254	1990	2012-11-25 23:00:00	49	\N	\N	\N
5713	242	1991	2012-11-25 23:30:00	98	\N	\N	\N
5717	254	1993	2012-11-26 00:30:00	49	\N	\N	\N
5719	242	1993	2012-11-26 00:30:00	98	\N	\N	\N
5723	254	1995	2012-11-26 01:30:00	49	\N	\N	\N
5743	242	2001	2012-11-26 04:30:00	98	\N	\N	\N
5747	254	2003	2012-11-26 05:30:00	48	\N	\N	\N
5749	242	2003	2012-11-26 05:30:00	98	\N	\N	\N
5800	242	2020	2012-11-26 14:00:00	71	\N	\N	\N
5805	255	2022	2012-11-26 15:00:00	77	\N	\N	\N
5813	254	2025	2012-11-26 16:30:00	50	\N	\N	\N
5832	255	2031	2012-11-26 19:30:00	77	\N	\N	\N
5836	242	2032	2012-11-26 20:00:00	76	\N	\N	\N
5847	255	2036	2012-11-26 22:00:00	77	\N	\N	\N
5857	242	2039	2012-11-26 23:30:00	77	\N	\N	\N
5862	255	2041	2012-11-27 00:30:00	77	\N	\N	\N
5866	242	2042	2012-11-27 01:00:00	78	\N	\N	\N
5872	242	2044	2012-11-27 02:00:00	73	\N	\N	\N
5883	255	2048	2012-11-27 04:00:00	77	\N	\N	\N
5887	242	2049	2012-11-27 04:30:00	77	\N	\N	\N
5897	254	2053	2012-11-27 06:30:00	48	\N	\N	\N
5900	254	2054	2012-11-27 07:00:00	48	\N	\N	\N
5904	255	2055	2012-11-27 07:30:00	76	\N	\N	\N
5916	255	2059	2012-11-27 09:30:00	77	\N	\N	\N
5922	255	2061	2012-11-27 10:30:00	76	\N	\N	\N
5927	254	2063	2012-11-27 11:30:00	48	\N	\N	\N
5937	255	2066	2012-11-27 13:00:00	76	\N	\N	\N
5384	254	1882	2012-11-23 17:00:00	54	\N	\N	\N
5416	242	1892	2012-11-23 22:00:00	97	\N	\N	\N
5422	242	1894	2012-11-23 23:00:00	97	\N	\N	\N
5428	242	1896	2012-11-24 00:00:00	97	\N	\N	\N
5446	242	1902	2012-11-24 03:00:00	97	\N	\N	\N
5460	255	1907	2012-11-24 05:30:00	76	\N	\N	\N
5466	255	1909	2012-11-24 06:30:00	75	\N	\N	\N
5470	242	1910	2012-11-24 07:00:00	98	\N	\N	\N
5472	255	1911	2012-11-24 07:30:00	75	\N	\N	\N
5495	254	1919	2012-11-24 11:30:00	51	\N	\N	\N
5502	255	1921	2012-11-24 12:30:00	78	\N	\N	\N
5514	255	1925	2012-11-24 14:30:00	76	\N	\N	\N
5549	254	1937	2012-11-24 20:30:00	49	\N	\N	\N
5551	242	1937	2012-11-24 20:30:00	96	\N	\N	\N
5557	242	1939	2012-11-24 21:30:00	96	\N	\N	\N
5561	254	1941	2012-11-24 22:30:00	49	\N	\N	\N
5568	255	1943	2012-11-24 23:30:00	67	\N	\N	\N
5573	254	1945	2012-11-25 00:30:00	48	\N	\N	\N
5579	254	1947	2012-11-25 01:30:00	48	\N	\N	\N
5585	254	1949	2012-11-25 02:30:00	47	\N	\N	\N
5605	242	1955	2012-11-25 05:30:00	98	\N	\N	\N
5631	255	1964	2012-11-25 10:00:00	71	\N	\N	\N
5637	255	1966	2012-11-25 11:00:00	72	\N	\N	\N
5649	255	1970	2012-11-25 13:00:00	75	\N	\N	\N
5655	255	1972	2012-11-25 14:00:00	76	\N	\N	\N
5661	255	1974	2012-11-25 15:00:00	76	\N	\N	\N
5667	255	1976	2012-11-25 16:00:00	75	\N	\N	\N
5672	254	1978	2012-11-25 17:00:00	49	\N	\N	\N
5674	242	1978	2012-11-25 17:00:00	97	\N	\N	\N
5678	254	1980	2012-11-25 18:00:00	49	\N	\N	\N
5685	255	1982	2012-11-25 19:00:00	76	\N	\N	\N
5690	254	1984	2012-11-25 20:00:00	49	\N	\N	\N
5696	254	1986	2012-11-25 21:00:00	49	\N	\N	\N
5703	255	1988	2012-11-25 22:00:00	76	\N	\N	\N
5714	254	1992	2012-11-26 00:00:00	49	\N	\N	\N
5720	254	1994	2012-11-26 01:00:00	49	\N	\N	\N
5726	254	1996	2012-11-26 02:00:00	48	\N	\N	\N
5740	242	2000	2012-11-26 04:00:00	98	\N	\N	\N
5744	254	2002	2012-11-26 05:00:00	48	\N	\N	\N
5776	242	2012	2012-11-26 10:00:00	84	\N	\N	\N
5782	242	2014	2012-11-26 11:00:00	79	\N	\N	\N
5788	242	2016	2012-11-26 12:00:00	78	\N	\N	\N
5792	254	2018	2012-11-26 13:00:00	49	\N	\N	\N
5796	255	2019	2012-11-26 13:30:00	77	\N	\N	\N
5804	254	2022	2012-11-26 15:00:00	49	\N	\N	\N
5808	255	2023	2012-11-26 15:30:00	77	\N	\N	\N
5812	242	2024	2012-11-26 16:00:00	72	\N	\N	\N
5817	255	2026	2012-11-26 17:00:00	78	\N	\N	\N
5823	255	2028	2012-11-26 18:00:00	77	\N	\N	\N
5826	255	2029	2012-11-26 18:30:00	77	\N	\N	\N
5830	242	2030	2012-11-26 19:00:00	74	\N	\N	\N
5843	254	2035	2012-11-26 21:30:00	50	\N	\N	\N
5848	242	2036	2012-11-26 22:00:00	78	\N	\N	\N
5858	254	2040	2012-11-27 00:00:00	49	\N	\N	\N
5863	242	2041	2012-11-27 00:30:00	77	\N	\N	\N
5868	255	2043	2012-11-27 01:30:00	77	\N	\N	\N
5875	242	2045	2012-11-27 02:30:00	73	\N	\N	\N
5882	254	2048	2012-11-27 04:00:00	48	\N	\N	\N
5885	254	2049	2012-11-27 04:30:00	48	\N	\N	\N
5891	254	2051	2012-11-27 05:30:00	48	\N	\N	\N
5895	255	2052	2012-11-27 06:00:00	77	\N	\N	\N
5899	242	2053	2012-11-27 06:30:00	80	\N	\N	\N
5913	255	2058	2012-11-27 09:00:00	77	\N	\N	\N
5923	242	2061	2012-11-27 10:30:00	63	\N	\N	\N
5930	254	2064	2012-11-27 12:00:00	49	\N	\N	\N
5935	242	2065	2012-11-27 12:30:00	61	\N	\N	\N
5385	255	1882	2012-11-23 17:00:00	78	\N	\N	\N
5390	254	1884	2012-11-23 18:00:00	54	\N	\N	\N
5396	254	1886	2012-11-23 19:00:00	54	\N	\N	\N
5403	255	1888	2012-11-23 20:00:00	77	\N	\N	\N
5414	254	1892	2012-11-23 22:00:00	54	\N	\N	\N
5420	254	1894	2012-11-23 23:00:00	54	\N	\N	\N
5426	254	1896	2012-11-24 00:00:00	54	\N	\N	\N
5440	242	1900	2012-11-24 02:00:00	98	\N	\N	\N
5444	254	1902	2012-11-24 03:00:00	52	\N	\N	\N
5476	242	1912	2012-11-24 08:00:00	98	\N	\N	\N
5482	242	1914	2012-11-24 09:00:00	98	\N	\N	\N
5488	242	1916	2012-11-24 10:00:00	98	\N	\N	\N
5506	242	1922	2012-11-24 13:00:00	77	\N	\N	\N
5520	255	1927	2012-11-24 15:30:00	76	\N	\N	\N
5526	255	1929	2012-11-24 16:30:00	76	\N	\N	\N
5530	242	1930	2012-11-24 17:00:00	93	\N	\N	\N
5532	255	1931	2012-11-24 17:30:00	76	\N	\N	\N
5555	254	1939	2012-11-24 21:30:00	49	\N	\N	\N
5562	255	1941	2012-11-24 22:30:00	69	\N	\N	\N
5574	255	1945	2012-11-25 00:30:00	66	\N	\N	\N
5609	254	1957	2012-11-25 06:30:00	47	\N	\N	\N
5611	242	1957	2012-11-25 06:30:00	98	\N	\N	\N
5617	242	1959	2012-11-25 07:30:00	98	\N	\N	\N
5621	254	1961	2012-11-25 08:30:00	47	\N	\N	\N
5628	255	1963	2012-11-25 09:30:00	70	\N	\N	\N
5633	254	1965	2012-11-25 10:30:00	48	\N	\N	\N
5639	254	1967	2012-11-25 11:30:00	48	\N	\N	\N
5645	254	1969	2012-11-25 12:30:00	48	\N	\N	\N
5665	242	1975	2012-11-25 15:30:00	95	\N	\N	\N
5691	255	1984	2012-11-25 20:00:00	75	\N	\N	\N
5697	255	1986	2012-11-25 21:00:00	76	\N	\N	\N
5709	255	1990	2012-11-25 23:00:00	75	\N	\N	\N
5715	255	1992	2012-11-26 00:00:00	76	\N	\N	\N
5721	255	1994	2012-11-26 01:00:00	75	\N	\N	\N
5727	255	1996	2012-11-26 02:00:00	75	\N	\N	\N
5732	254	1998	2012-11-26 03:00:00	48	\N	\N	\N
5734	242	1998	2012-11-26 03:00:00	98	\N	\N	\N
5738	254	2000	2012-11-26 04:00:00	48	\N	\N	\N
5745	255	2002	2012-11-26 05:00:00	74	\N	\N	\N
5750	254	2004	2012-11-26 06:00:00	48	\N	\N	\N
5756	254	2006	2012-11-26 07:00:00	48	\N	\N	\N
5763	255	2008	2012-11-26 08:00:00	75	\N	\N	\N
5774	254	2012	2012-11-26 10:00:00	49	\N	\N	\N
5780	254	2014	2012-11-26 11:00:00	49	\N	\N	\N
5786	254	2016	2012-11-26 12:00:00	49	\N	\N	\N
5799	255	2020	2012-11-26 14:00:00	77	\N	\N	\N
5815	242	2025	2012-11-26 16:30:00	72	\N	\N	\N
5827	242	2029	2012-11-26 18:30:00	73	\N	\N	\N
5834	254	2032	2012-11-26 20:00:00	50	\N	\N	\N
5839	242	2033	2012-11-26 20:30:00	79	\N	\N	\N
5846	254	2036	2012-11-26 22:00:00	49	\N	\N	\N
5865	255	2042	2012-11-27 01:00:00	77	\N	\N	\N
5873	254	2045	2012-11-27 02:30:00	48	\N	\N	\N
5881	242	2047	2012-11-27 03:30:00	76	\N	\N	\N
5894	254	2052	2012-11-27 06:00:00	48	\N	\N	\N
5914	242	2058	2012-11-27 09:00:00	68	\N	\N	\N
5918	254	2060	2012-11-27 10:00:00	48	\N	\N	\N
5932	242	2064	2012-11-27 12:00:00	60	\N	\N	\N
5940	255	2067	2012-11-27 13:30:00	76	\N	\N	\N
5386	242	1882	2012-11-23 17:00:00	95	\N	\N	\N
5400	255	1887	2012-11-23 19:30:00	77	\N	\N	\N
5406	255	1889	2012-11-23 20:30:00	77	\N	\N	\N
5410	242	1890	2012-11-23 21:00:00	97	\N	\N	\N
5412	255	1891	2012-11-23 21:30:00	77	\N	\N	\N
5435	254	1899	2012-11-24 01:30:00	53	\N	\N	\N
5442	255	1901	2012-11-24 02:30:00	77	\N	\N	\N
5454	255	1905	2012-11-24 04:30:00	75	\N	\N	\N
5489	254	1917	2012-11-24 10:30:00	50	\N	\N	\N
5491	242	1917	2012-11-24 10:30:00	93	\N	\N	\N
5497	242	1919	2012-11-24 11:30:00	87	\N	\N	\N
5501	254	1921	2012-11-24 12:30:00	51	\N	\N	\N
5508	255	1923	2012-11-24 13:30:00	77	\N	\N	\N
5513	254	1925	2012-11-24 14:30:00	51	\N	\N	\N
5519	254	1927	2012-11-24 15:30:00	49	\N	\N	\N
5525	254	1929	2012-11-24 16:30:00	50	\N	\N	\N
5545	242	1935	2012-11-24 19:30:00	95	\N	\N	\N
5571	255	1944	2012-11-25 00:00:00	67	\N	\N	\N
5577	255	1946	2012-11-25 01:00:00	66	\N	\N	\N
5589	255	1950	2012-11-25 03:00:00	67	\N	\N	\N
5595	255	1952	2012-11-25 04:00:00	67	\N	\N	\N
5601	255	1954	2012-11-25 05:00:00	68	\N	\N	\N
5607	255	1956	2012-11-25 06:00:00	68	\N	\N	\N
5612	254	1958	2012-11-25 07:00:00	47	\N	\N	\N
5614	242	1958	2012-11-25 07:00:00	98	\N	\N	\N
5618	254	1960	2012-11-25 08:00:00	47	\N	\N	\N
5625	255	1962	2012-11-25 09:00:00	69	\N	\N	\N
5630	254	1964	2012-11-25 10:00:00	47	\N	\N	\N
5636	254	1966	2012-11-25 11:00:00	48	\N	\N	\N
5643	255	1968	2012-11-25 12:00:00	73	\N	\N	\N
5654	254	1972	2012-11-25 14:00:00	49	\N	\N	\N
5660	254	1974	2012-11-25 15:00:00	49	\N	\N	\N
5666	254	1976	2012-11-25 16:00:00	49	\N	\N	\N
5680	242	1980	2012-11-25 18:00:00	98	\N	\N	\N
5684	254	1982	2012-11-25 19:00:00	49	\N	\N	\N
5716	242	1992	2012-11-26 00:00:00	98	\N	\N	\N
5722	242	1994	2012-11-26 01:00:00	98	\N	\N	\N
5728	242	1996	2012-11-26 02:00:00	98	\N	\N	\N
5746	242	2002	2012-11-26 05:00:00	98	\N	\N	\N
5760	255	2007	2012-11-26 07:30:00	75	\N	\N	\N
5766	255	2009	2012-11-26 08:30:00	75	\N	\N	\N
5770	242	2010	2012-11-26 09:00:00	98	\N	\N	\N
5772	255	2011	2012-11-26 09:30:00	77	\N	\N	\N
5791	242	2017	2012-11-26 12:30:00	77	\N	\N	\N
5795	254	2019	2012-11-26 13:30:00	49	\N	\N	\N
5809	242	2023	2012-11-26 15:30:00	69	\N	\N	\N
5822	254	2028	2012-11-26 18:00:00	50	\N	\N	\N
5829	255	2030	2012-11-26 19:00:00	77	\N	\N	\N
5842	242	2034	2012-11-26 21:00:00	80	\N	\N	\N
5850	255	2037	2012-11-26 22:30:00	77	\N	\N	\N
5855	254	2039	2012-11-26 23:30:00	49	\N	\N	\N
5869	242	2043	2012-11-27 01:30:00	77	\N	\N	\N
5880	255	2047	2012-11-27 03:30:00	77	\N	\N	\N
5888	254	2050	2012-11-27 05:00:00	48	\N	\N	\N
5892	255	2051	2012-11-27 05:30:00	77	\N	\N	\N
5901	255	2054	2012-11-27 07:00:00	76	\N	\N	\N
5907	255	2056	2012-11-27 08:00:00	76	\N	\N	\N
5921	254	2061	2012-11-27 10:30:00	48	\N	\N	\N
5925	255	2062	2012-11-27 11:00:00	75	\N	\N	\N
5931	255	2064	2012-11-27 12:00:00	76	\N	\N	\N
5939	254	2067	2012-11-27 13:30:00	48	\N	\N	\N
5391	255	1884	2012-11-23 18:00:00	78	\N	\N	\N
5397	255	1886	2012-11-23 19:00:00	77	\N	\N	\N
5409	255	1890	2012-11-23 21:00:00	77	\N	\N	\N
5415	255	1892	2012-11-23 22:00:00	78	\N	\N	\N
5421	255	1894	2012-11-23 23:00:00	78	\N	\N	\N
5427	255	1896	2012-11-24 00:00:00	78	\N	\N	\N
5432	254	1898	2012-11-24 01:00:00	54	\N	\N	\N
5434	242	1898	2012-11-24 01:00:00	98	\N	\N	\N
5438	254	1900	2012-11-24 02:00:00	53	\N	\N	\N
5445	255	1902	2012-11-24 03:00:00	77	\N	\N	\N
5450	254	1904	2012-11-24 04:00:00	52	\N	\N	\N
5456	254	1906	2012-11-24 05:00:00	51	\N	\N	\N
5463	255	1908	2012-11-24 06:00:00	75	\N	\N	\N
5474	254	1912	2012-11-24 08:00:00	50	\N	\N	\N
5480	254	1914	2012-11-24 09:00:00	50	\N	\N	\N
5486	254	1916	2012-11-24 10:00:00	51	\N	\N	\N
5500	242	1920	2012-11-24 12:00:00	84	\N	\N	\N
5504	254	1922	2012-11-24 13:00:00	51	\N	\N	\N
5536	242	1932	2012-11-24 18:00:00	94	\N	\N	\N
5542	242	1934	2012-11-24 19:00:00	95	\N	\N	\N
5548	242	1936	2012-11-24 20:00:00	95	\N	\N	\N
5566	242	1942	2012-11-24 23:00:00	97	\N	\N	\N
5580	255	1947	2012-11-25 01:30:00	65	\N	\N	\N
5586	255	1949	2012-11-25 02:30:00	66	\N	\N	\N
5590	242	1950	2012-11-25 03:00:00	98	\N	\N	\N
5592	255	1951	2012-11-25 03:30:00	66	\N	\N	\N
5615	254	1959	2012-11-25 07:30:00	47	\N	\N	\N
5622	255	1961	2012-11-25 08:30:00	68	\N	\N	\N
5634	255	1965	2012-11-25 10:30:00	71	\N	\N	\N
5669	254	1977	2012-11-25 16:30:00	49	\N	\N	\N
5671	242	1977	2012-11-25 16:30:00	97	\N	\N	\N
5677	242	1979	2012-11-25 17:30:00	97	\N	\N	\N
5681	254	1981	2012-11-25 18:30:00	49	\N	\N	\N
5688	255	1983	2012-11-25 19:30:00	76	\N	\N	\N
5693	254	1985	2012-11-25 20:30:00	49	\N	\N	\N
5699	254	1987	2012-11-25 21:30:00	49	\N	\N	\N
5705	254	1989	2012-11-25 22:30:00	49	\N	\N	\N
5725	242	1995	2012-11-26 01:30:00	98	\N	\N	\N
5751	255	2004	2012-11-26 06:00:00	74	\N	\N	\N
5757	255	2006	2012-11-26 07:00:00	74	\N	\N	\N
5769	255	2010	2012-11-26 09:00:00	76	\N	\N	\N
5775	255	2012	2012-11-26 10:00:00	77	\N	\N	\N
5781	255	2014	2012-11-26 11:00:00	77	\N	\N	\N
5787	255	2016	2012-11-26 12:00:00	77	\N	\N	\N
5798	254	2020	2012-11-26 14:00:00	49	\N	\N	\N
5803	242	2021	2012-11-26 14:30:00	70	\N	\N	\N
5810	254	2024	2012-11-26 16:00:00	50	\N	\N	\N
5814	255	2025	2012-11-26 16:30:00	78	\N	\N	\N
5819	254	2027	2012-11-26 17:30:00	50	\N	\N	\N
5824	242	2028	2012-11-26 18:00:00	72	\N	\N	\N
5844	255	2035	2012-11-26 21:30:00	77	\N	\N	\N
5853	255	2038	2012-11-26 23:00:00	77	\N	\N	\N
5856	255	2039	2012-11-26 23:30:00	77	\N	\N	\N
5874	255	2045	2012-11-27 02:30:00	77	\N	\N	\N
5889	255	2050	2012-11-27 05:00:00	77	\N	\N	\N
5938	242	2066	2012-11-27 13:00:00	61	\N	\N	\N
5392	242	1884	2012-11-23 18:00:00	96	\N	\N	\N
5398	242	1886	2012-11-23 19:00:00	97	\N	\N	\N
5402	254	1888	2012-11-23 20:00:00	54	\N	\N	\N
5404	242	1888	2012-11-23 20:00:00	97	\N	\N	\N
5411	254	1891	2012-11-23 21:30:00	54	\N	\N	\N
5418	255	1893	2012-11-23 22:30:00	78	\N	\N	\N
5424	255	1895	2012-11-23 23:30:00	78	\N	\N	\N
5430	255	1897	2012-11-24 00:30:00	78	\N	\N	\N
5436	255	1899	2012-11-24 01:30:00	78	\N	\N	\N
5455	242	1905	2012-11-24 04:30:00	97	\N	\N	\N
5461	242	1907	2012-11-24 05:30:00	98	\N	\N	\N
5467	242	1909	2012-11-24 06:30:00	98	\N	\N	\N
5468	254	1910	2012-11-24 07:00:00	50	\N	\N	\N
5473	242	1911	2012-11-24 07:30:00	98	\N	\N	\N
5477	254	1913	2012-11-24 08:30:00	50	\N	\N	\N
5479	242	1913	2012-11-24 08:30:00	98	\N	\N	\N
5483	254	1915	2012-11-24 09:30:00	50	\N	\N	\N
5503	242	1921	2012-11-24 12:30:00	83	\N	\N	\N
5507	254	1923	2012-11-24 13:30:00	51	\N	\N	\N
5509	242	1923	2012-11-24 13:30:00	76	\N	\N	\N
5553	255	1938	2012-11-24 21:00:00	70	\N	\N	\N
5559	255	1940	2012-11-24 22:00:00	69	\N	\N	\N
5572	242	1944	2012-11-25 00:00:00	97	\N	\N	\N
5578	242	1946	2012-11-25 01:00:00	97	\N	\N	\N
5582	254	1948	2012-11-25 02:00:00	48	\N	\N	\N
5584	242	1948	2012-11-25 02:00:00	97	\N	\N	\N
5591	254	1951	2012-11-25 03:30:00	47	\N	\N	\N
5598	255	1953	2012-11-25 04:30:00	67	\N	\N	\N
5604	255	1955	2012-11-25 05:30:00	68	\N	\N	\N
5610	255	1957	2012-11-25 06:30:00	68	\N	\N	\N
5616	255	1959	2012-11-25 07:30:00	68	\N	\N	\N
5635	242	1965	2012-11-25 10:30:00	98	\N	\N	\N
5641	242	1967	2012-11-25 11:30:00	98	\N	\N	\N
5647	242	1969	2012-11-25 12:30:00	96	\N	\N	\N
5648	254	1970	2012-11-25 13:00:00	49	\N	\N	\N
5653	242	1971	2012-11-25 13:30:00	91	\N	\N	\N
5657	254	1973	2012-11-25 14:30:00	49	\N	\N	\N
5659	242	1973	2012-11-25 14:30:00	92	\N	\N	\N
5663	254	1975	2012-11-25 15:30:00	49	\N	\N	\N
5683	242	1981	2012-11-25 18:30:00	98	\N	\N	\N
5687	254	1983	2012-11-25 19:30:00	49	\N	\N	\N
5689	242	1983	2012-11-25 19:30:00	98	\N	\N	\N
5733	255	1998	2012-11-26 03:00:00	75	\N	\N	\N
5739	255	2000	2012-11-26 04:00:00	74	\N	\N	\N
5752	242	2004	2012-11-26 06:00:00	98	\N	\N	\N
5758	242	2006	2012-11-26 07:00:00	98	\N	\N	\N
5762	254	2008	2012-11-26 08:00:00	48	\N	\N	\N
5764	242	2008	2012-11-26 08:00:00	98	\N	\N	\N
5771	254	2011	2012-11-26 09:30:00	48	\N	\N	\N
5778	255	2013	2012-11-26 10:30:00	77	\N	\N	\N
5784	255	2015	2012-11-26 11:30:00	77	\N	\N	\N
5794	242	2018	2012-11-26 13:00:00	78	\N	\N	\N
5802	255	2021	2012-11-26 14:30:00	77	\N	\N	\N
5807	254	2023	2012-11-26 15:30:00	49	\N	\N	\N
5821	242	2027	2012-11-26 17:30:00	71	\N	\N	\N
5840	254	2034	2012-11-26 21:00:00	50	\N	\N	\N
5854	242	2038	2012-11-26 23:00:00	75	\N	\N	\N
5861	254	2041	2012-11-27 00:30:00	49	\N	\N	\N
5877	255	2046	2012-11-27 03:00:00	77	\N	\N	\N
5886	255	2049	2012-11-27 04:30:00	77	\N	\N	\N
5893	242	2051	2012-11-27 05:30:00	79	\N	\N	\N
5898	255	2053	2012-11-27 06:30:00	76	\N	\N	\N
5903	254	2055	2012-11-27 07:30:00	48	\N	\N	\N
5910	255	2057	2012-11-27 08:30:00	77	\N	\N	\N
5928	255	2063	2012-11-27 11:30:00	75	\N	\N	\N
5934	255	2065	2012-11-27 12:30:00	76	\N	\N	\N
5395	242	1885	2012-11-23 18:30:00	96	\N	\N	\N
5401	242	1887	2012-11-23 19:30:00	97	\N	\N	\N
5407	242	1889	2012-11-23 20:30:00	97	\N	\N	\N
5408	254	1890	2012-11-23 21:00:00	54	\N	\N	\N
5413	242	1891	2012-11-23 21:30:00	97	\N	\N	\N
5417	254	1893	2012-11-23 22:30:00	54	\N	\N	\N
5419	242	1893	2012-11-23 22:30:00	97	\N	\N	\N
5423	254	1895	2012-11-23 23:30:00	54	\N	\N	\N
5443	242	1901	2012-11-24 02:30:00	97	\N	\N	\N
5447	254	1903	2012-11-24 03:30:00	52	\N	\N	\N
5449	242	1903	2012-11-24 03:30:00	97	\N	\N	\N
5493	255	1918	2012-11-24 11:00:00	78	\N	\N	\N
5499	255	1920	2012-11-24 12:00:00	77	\N	\N	\N
5512	242	1924	2012-11-24 14:00:00	76	\N	\N	\N
5518	242	1926	2012-11-24 15:00:00	73	\N	\N	\N
5522	254	1928	2012-11-24 16:00:00	50	\N	\N	\N
5524	242	1928	2012-11-24 16:00:00	89	\N	\N	\N
5531	254	1931	2012-11-24 17:30:00	50	\N	\N	\N
5538	255	1933	2012-11-24 18:30:00	75	\N	\N	\N
5544	255	1935	2012-11-24 19:30:00	73	\N	\N	\N
5550	255	1937	2012-11-24 20:30:00	71	\N	\N	\N
5556	255	1939	2012-11-24 21:30:00	70	\N	\N	\N
5575	242	1945	2012-11-25 00:30:00	97	\N	\N	\N
5581	242	1947	2012-11-25 01:30:00	97	\N	\N	\N
5587	242	1949	2012-11-25 02:30:00	98	\N	\N	\N
5588	254	1950	2012-11-25 03:00:00	47	\N	\N	\N
5593	242	1951	2012-11-25 03:30:00	97	\N	\N	\N
5597	254	1953	2012-11-25 04:30:00	47	\N	\N	\N
5599	242	1953	2012-11-25 04:30:00	98	\N	\N	\N
5603	254	1955	2012-11-25 05:30:00	47	\N	\N	\N
5623	242	1961	2012-11-25 08:30:00	98	\N	\N	\N
5627	254	1963	2012-11-25 09:30:00	47	\N	\N	\N
5629	242	1963	2012-11-25 09:30:00	98	\N	\N	\N
5673	255	1978	2012-11-25 17:00:00	75	\N	\N	\N
5679	255	1980	2012-11-25 18:00:00	76	\N	\N	\N
5692	242	1984	2012-11-25 20:00:00	98	\N	\N	\N
5698	242	1986	2012-11-25 21:00:00	98	\N	\N	\N
5702	254	1988	2012-11-25 22:00:00	49	\N	\N	\N
5704	242	1988	2012-11-25 22:00:00	98	\N	\N	\N
5711	254	1991	2012-11-25 23:30:00	49	\N	\N	\N
5718	255	1993	2012-11-26 00:30:00	75	\N	\N	\N
5724	255	1995	2012-11-26 01:30:00	75	\N	\N	\N
5730	255	1997	2012-11-26 02:30:00	75	\N	\N	\N
5736	255	1999	2012-11-26 03:30:00	75	\N	\N	\N
5755	242	2005	2012-11-26 06:30:00	98	\N	\N	\N
5761	242	2007	2012-11-26 07:30:00	98	\N	\N	\N
5767	242	2009	2012-11-26 08:30:00	98	\N	\N	\N
5768	254	2010	2012-11-26 09:00:00	48	\N	\N	\N
5773	242	2011	2012-11-26 09:30:00	98	\N	\N	\N
5777	254	2013	2012-11-26 10:30:00	49	\N	\N	\N
5779	242	2013	2012-11-26 10:30:00	82	\N	\N	\N
5783	254	2015	2012-11-26 11:30:00	49	\N	\N	\N
5790	255	2017	2012-11-26 12:30:00	77	\N	\N	\N
5806	242	2022	2012-11-26 15:00:00	68	\N	\N	\N
5816	254	2026	2012-11-26 17:00:00	50	\N	\N	\N
5820	255	2027	2012-11-26 17:30:00	77	\N	\N	\N
5837	254	2033	2012-11-26 20:30:00	50	\N	\N	\N
5845	242	2035	2012-11-26 21:30:00	79	\N	\N	\N
5851	242	2037	2012-11-26 22:30:00	75	\N	\N	\N
5859	255	2040	2012-11-27 00:00:00	77	\N	\N	\N
5864	254	2042	2012-11-27 01:00:00	49	\N	\N	\N
5871	255	2044	2012-11-27 02:00:00	77	\N	\N	\N
5876	254	2046	2012-11-27 03:00:00	48	\N	\N	\N
5902	242	2054	2012-11-27 07:00:00	77	\N	\N	\N
5912	254	2058	2012-11-27 09:00:00	48	\N	\N	\N
5920	242	2060	2012-11-27 10:00:00	67	\N	\N	\N
5926	242	2062	2012-11-27 11:00:00	65	\N	\N	\N
5933	254	2065	2012-11-27 12:30:00	49	\N	\N	\N
5941	242	2067	2012-11-27 13:30:00	59	\N	\N	\N
5942	254	2068	2012-11-27 14:00:00	48	\N	\N	\N
5943	255	2068	2012-11-27 14:00:00	76	\N	\N	\N
5944	242	2068	2012-11-27 14:00:00	58	\N	\N	\N
5945	254	2069	2012-11-27 14:30:00	48	\N	\N	\N
5946	255	2069	2012-11-27 14:30:00	76	\N	\N	\N
5947	242	2069	2012-11-27 14:30:00	57	\N	\N	\N
5948	254	2070	2012-11-27 15:00:00	48	\N	\N	\N
5949	255	2070	2012-11-27 15:00:00	76	\N	\N	\N
5950	242	2070	2012-11-27 15:00:00	59	\N	\N	\N
5951	254	2071	2012-11-27 15:30:00	48	\N	\N	\N
5952	255	2071	2012-11-27 15:30:00	76	\N	\N	\N
5953	242	2071	2012-11-27 15:30:00	61	\N	\N	\N
5954	254	2072	2012-11-27 16:00:00	48	\N	\N	\N
5955	255	2072	2012-11-27 16:00:00	76	\N	\N	\N
5956	242	2072	2012-11-27 16:00:00	63	\N	\N	\N
5957	254	2073	2012-11-27 16:30:00	47	\N	\N	\N
5958	255	2073	2012-11-27 16:30:00	76	\N	\N	\N
5959	242	2073	2012-11-27 16:30:00	66	\N	\N	\N
5960	254	2074	2012-11-27 17:00:00	47	\N	\N	\N
5961	255	2074	2012-11-27 17:00:00	76	\N	\N	\N
5962	242	2074	2012-11-27 17:00:00	65	\N	\N	\N
5963	254	2075	2012-11-27 17:30:00	47	\N	\N	\N
5964	255	2075	2012-11-27 17:30:00	76	\N	\N	\N
5965	242	2075	2012-11-27 17:30:00	69	\N	\N	\N
5966	254	2076	2012-11-27 18:00:00	47	\N	\N	\N
5967	255	2076	2012-11-27 18:00:00	75	\N	\N	\N
5968	242	2076	2012-11-27 18:00:00	65	\N	\N	\N
5969	254	2077	2012-11-27 18:30:00	46	\N	\N	\N
5970	255	2077	2012-11-27 18:30:00	73	\N	\N	\N
5971	242	2077	2012-11-27 18:30:00	64	\N	\N	\N
5972	254	2078	2012-11-27 19:00:00	47	\N	\N	\N
5973	255	2078	2012-11-27 19:00:00	74	\N	\N	\N
5974	242	2078	2012-11-27 19:00:00	71	\N	\N	\N
5975	254	2079	2012-11-27 19:30:00	47	\N	\N	\N
5976	255	2079	2012-11-27 19:30:00	75	\N	\N	\N
5977	242	2079	2012-11-27 19:30:00	73	\N	\N	\N
5978	254	2080	2012-11-27 20:00:00	48	\N	\N	\N
5979	255	2080	2012-11-27 20:00:00	75	\N	\N	\N
5980	242	2080	2012-11-27 20:00:00	75	\N	\N	\N
5981	254	2081	2012-11-27 20:30:00	48	\N	\N	\N
5982	255	2081	2012-11-27 20:30:00	75	\N	\N	\N
5983	242	2081	2012-11-27 20:30:00	80	\N	\N	\N
5984	254	2082	2012-11-27 21:00:00	48	\N	\N	\N
5985	255	2082	2012-11-27 21:00:00	76	\N	\N	\N
5986	242	2082	2012-11-27 21:00:00	78	\N	\N	\N
5987	254	2083	2012-11-27 21:30:00	48	\N	\N	\N
5988	255	2083	2012-11-27 21:30:00	75	\N	\N	\N
5989	242	2083	2012-11-27 21:30:00	80	\N	\N	\N
5990	254	2084	2012-11-27 22:00:00	48	\N	\N	\N
5991	255	2084	2012-11-27 22:00:00	75	\N	\N	\N
5992	242	2084	2012-11-27 22:00:00	82	\N	\N	\N
5993	254	2085	2012-11-27 22:30:00	48	\N	\N	\N
5998	242	2086	2012-11-27 23:00:00	80	\N	\N	\N
6010	242	2090	2012-11-28 01:00:00	88	\N	\N	\N
6012	255	2091	2012-11-28 01:30:00	76	\N	\N	\N
6015	255	2092	2012-11-28 02:00:00	76	\N	\N	\N
6019	242	2093	2012-11-28 02:30:00	90	\N	\N	\N
6025	242	2095	2012-11-28 03:30:00	90	\N	\N	\N
6037	242	2099	2012-11-28 05:30:00	88	\N	\N	\N
6044	254	2102	2012-11-28 07:00:00	49	\N	\N	\N
6049	242	2103	2012-11-28 07:30:00	93	\N	\N	\N
6067	242	2109	2012-11-28 10:30:00	76	\N	\N	\N
6074	254	2112	2012-11-28 12:00:00	50	\N	\N	\N
6079	242	2113	2012-11-28 12:30:00	72	\N	\N	\N
6093	255	2118	2012-11-28 15:00:00	77	\N	\N	\N
6096	255	2119	2012-11-28 15:30:00	76	\N	\N	\N
6102	255	2121	2012-11-28 16:30:00	77	\N	\N	\N
6106	242	2122	2012-11-28 17:00:00	91	\N	\N	\N
6111	255	2124	2012-11-28 18:00:00	78	\N	\N	\N
6119	254	2127	2012-11-28 19:30:00	50	\N	\N	\N
6123	255	2128	2012-11-28 20:00:00	77	\N	\N	\N
6127	242	2129	2012-11-28 20:30:00	90	\N	\N	\N
6138	255	2133	2012-11-28 22:30:00	79	\N	\N	\N
6142	242	2134	2012-11-28 23:00:00	94	\N	\N	\N
6143	254	2135	2012-11-28 23:30:00	51	\N	\N	\N
6150	255	2137	2012-11-29 00:30:00	79	\N	\N	\N
6187	242	2149	2012-11-29 06:30:00	97	\N	\N	\N
6195	255	2152	2012-11-29 08:00:00	73	\N	\N	\N
6203	254	2155	2012-11-29 09:30:00	49	\N	\N	\N
6210	255	2157	2012-11-29 10:30:00	76	\N	\N	\N
6228	255	2163	2012-11-29 13:30:00	77	\N	\N	\N
6239	254	2167	2012-11-29 15:30:00	50	\N	\N	\N
6259	242	2173	2012-11-29 18:30:00	95	\N	\N	\N
5994	255	2085	2012-11-27 22:30:00	75	\N	\N	\N
6004	242	2088	2012-11-28 00:00:00	82	\N	\N	\N
6011	254	2091	2012-11-28 01:30:00	49	\N	\N	\N
6021	255	2094	2012-11-28 03:00:00	76	\N	\N	\N
6052	242	2104	2012-11-28 08:00:00	94	\N	\N	\N
6057	255	2106	2012-11-28 09:00:00	76	\N	\N	\N
6065	254	2109	2012-11-28 10:30:00	49	\N	\N	\N
6068	254	2110	2012-11-28 11:00:00	50	\N	\N	\N
6073	242	2111	2012-11-28 11:30:00	72	\N	\N	\N
6078	255	2113	2012-11-28 12:30:00	78	\N	\N	\N
6081	255	2114	2012-11-28 13:00:00	78	\N	\N	\N
6085	242	2115	2012-11-28 13:30:00	68	\N	\N	\N
6095	254	2119	2012-11-28 15:30:00	51	\N	\N	\N
6109	242	2123	2012-11-28 17:30:00	92	\N	\N	\N
6114	255	2125	2012-11-28 18:30:00	78	\N	\N	\N
6124	242	2128	2012-11-28 20:00:00	90	\N	\N	\N
6135	255	2132	2012-11-28 22:00:00	78	\N	\N	\N
6154	242	2138	2012-11-29 01:00:00	94	\N	\N	\N
6166	242	2142	2012-11-29 03:00:00	95	\N	\N	\N
6173	254	2145	2012-11-29 04:30:00	50	\N	\N	\N
6178	242	2146	2012-11-29 05:00:00	96	\N	\N	\N
6183	255	2148	2012-11-29 06:00:00	73	\N	\N	\N
6186	255	2149	2012-11-29 06:30:00	72	\N	\N	\N
6192	255	2151	2012-11-29 07:30:00	72	\N	\N	\N
6206	254	2156	2012-11-29 10:00:00	48	\N	\N	\N
6223	242	2161	2012-11-29 12:30:00	67	\N	\N	\N
6230	254	2164	2012-11-29 14:00:00	50	\N	\N	\N
6235	242	2165	2012-11-29 14:30:00	71	\N	\N	\N
6248	254	2170	2012-11-29 17:00:00	51	\N	\N	\N
6253	242	2171	2012-11-29 17:30:00	95	\N	\N	\N
6261	255	2174	2012-11-29 19:00:00	77	\N	\N	\N
6267	255	2176	2012-11-29 20:00:00	76	\N	\N	\N
5995	242	2085	2012-11-27 22:30:00	82	\N	\N	\N
6006	255	2089	2012-11-28 00:30:00	76	\N	\N	\N
6009	255	2090	2012-11-28 01:00:00	76	\N	\N	\N
6014	254	2092	2012-11-28 02:00:00	49	\N	\N	\N
6017	254	2093	2012-11-28 02:30:00	49	\N	\N	\N
6022	242	2094	2012-11-28 03:00:00	90	\N	\N	\N
6026	254	2096	2012-11-28 04:00:00	49	\N	\N	\N
6034	242	2098	2012-11-28 05:00:00	87	\N	\N	\N
6048	255	2103	2012-11-28 07:30:00	75	\N	\N	\N
6054	255	2105	2012-11-28 08:30:00	76	\N	\N	\N
6071	254	2111	2012-11-28 11:30:00	50	\N	\N	\N
6075	255	2112	2012-11-28 12:00:00	78	\N	\N	\N
6087	255	2116	2012-11-28 14:00:00	77	\N	\N	\N
6091	242	2117	2012-11-28 14:30:00	72	\N	\N	\N
6107	254	2123	2012-11-28 17:30:00	51	\N	\N	\N
6132	255	2131	2012-11-28 21:30:00	78	\N	\N	\N
6137	254	2133	2012-11-28 22:30:00	50	\N	\N	\N
6141	255	2134	2012-11-28 23:00:00	79	\N	\N	\N
6159	255	2140	2012-11-29 02:00:00	78	\N	\N	\N
6180	255	2147	2012-11-29 05:30:00	74	\N	\N	\N
6194	254	2152	2012-11-29 08:00:00	48	\N	\N	\N
6198	255	2153	2012-11-29 08:30:00	74	\N	\N	\N
6207	255	2156	2012-11-29 10:00:00	76	\N	\N	\N
6221	254	2161	2012-11-29 12:30:00	50	\N	\N	\N
6225	255	2162	2012-11-29 13:00:00	77	\N	\N	\N
6231	255	2164	2012-11-29 14:00:00	77	\N	\N	\N
6242	254	2168	2012-11-29 16:00:00	50	\N	\N	\N
6246	255	2169	2012-11-29 16:30:00	77	\N	\N	\N
6256	242	2172	2012-11-29 18:00:00	96	\N	\N	\N
6266	254	2176	2012-11-29 20:00:00	50	\N	\N	\N
5996	254	2086	2012-11-27 23:00:00	48	\N	\N	\N
6002	254	2088	2012-11-28 00:00:00	48	\N	\N	\N
6005	254	2089	2012-11-28 00:30:00	49	\N	\N	\N
6024	255	2095	2012-11-28 03:30:00	76	\N	\N	\N
6036	255	2099	2012-11-28 05:30:00	75	\N	\N	\N
6040	242	2100	2012-11-28 06:00:00	90	\N	\N	\N
6045	255	2102	2012-11-28 07:00:00	76	\N	\N	\N
6060	255	2107	2012-11-28 09:30:00	76	\N	\N	\N
6082	242	2114	2012-11-28 13:00:00	72	\N	\N	\N
6094	242	2118	2012-11-28 15:00:00	75	\N	\N	\N
6104	254	2122	2012-11-28 17:00:00	51	\N	\N	\N
6108	255	2123	2012-11-28 17:30:00	77	\N	\N	\N
6112	242	2124	2012-11-28 18:00:00	92	\N	\N	\N
6120	255	2127	2012-11-28 19:30:00	77	\N	\N	\N
6131	254	2131	2012-11-28 21:30:00	50	\N	\N	\N
6147	255	2136	2012-11-29 00:00:00	79	\N	\N	\N
6172	242	2144	2012-11-29 04:00:00	94	\N	\N	\N
6177	255	2146	2012-11-29 05:00:00	75	\N	\N	\N
6185	254	2149	2012-11-29 06:30:00	49	\N	\N	\N
6188	254	2150	2012-11-29 07:00:00	49	\N	\N	\N
6196	242	2152	2012-11-29 08:00:00	96	\N	\N	\N
6219	255	2160	2012-11-29 12:00:00	76	\N	\N	\N
6234	255	2165	2012-11-29 14:30:00	77	\N	\N	\N
6251	254	2171	2012-11-29 17:30:00	51	\N	\N	\N
6262	242	2174	2012-11-29 19:00:00	96	\N	\N	\N
5997	255	2086	2012-11-27 23:00:00	76	\N	\N	\N
6016	242	2092	2012-11-28 02:00:00	91	\N	\N	\N
6020	254	2094	2012-11-28 03:00:00	49	\N	\N	\N
6028	242	2096	2012-11-28 04:00:00	89	\N	\N	\N
6035	254	2099	2012-11-28 05:30:00	49	\N	\N	\N
6038	254	2100	2012-11-28 06:00:00	49	\N	\N	\N
6053	254	2105	2012-11-28 08:30:00	49	\N	\N	\N
6058	242	2106	2012-11-28 09:00:00	87	\N	\N	\N
6063	255	2108	2012-11-28 10:00:00	77	\N	\N	\N
6066	255	2109	2012-11-28 10:30:00	77	\N	\N	\N
6070	242	2110	2012-11-28 11:00:00	74	\N	\N	\N
6072	255	2111	2012-11-28 11:30:00	78	\N	\N	\N
6080	254	2114	2012-11-28 13:00:00	51	\N	\N	\N
6090	255	2117	2012-11-28 14:30:00	77	\N	\N	\N
6100	242	2120	2012-11-28 16:00:00	85	\N	\N	\N
6105	255	2122	2012-11-28 17:00:00	77	\N	\N	\N
6115	242	2125	2012-11-28 18:30:00	91	\N	\N	\N
6126	255	2129	2012-11-28 20:30:00	77	\N	\N	\N
6129	255	2130	2012-11-28 21:00:00	77	\N	\N	\N
6134	254	2132	2012-11-28 22:00:00	50	\N	\N	\N
6139	242	2133	2012-11-28 22:30:00	92	\N	\N	\N
6146	254	2136	2012-11-29 00:00:00	51	\N	\N	\N
6149	254	2137	2012-11-29 00:30:00	51	\N	\N	\N
6152	254	2138	2012-11-29 01:00:00	51	\N	\N	\N
6160	242	2140	2012-11-29 02:00:00	94	\N	\N	\N
6167	254	2143	2012-11-29 03:30:00	50	\N	\N	\N
6174	255	2145	2012-11-29 04:30:00	76	\N	\N	\N
6202	242	2154	2012-11-29 09:00:00	89	\N	\N	\N
6209	254	2157	2012-11-29 10:30:00	48	\N	\N	\N
6213	255	2158	2012-11-29 11:00:00	76	\N	\N	\N
6217	242	2159	2012-11-29 11:30:00	75	\N	\N	\N
6222	255	2161	2012-11-29 12:30:00	76	\N	\N	\N
6227	254	2163	2012-11-29 13:30:00	50	\N	\N	\N
6237	255	2166	2012-11-29 15:00:00	77	\N	\N	\N
6250	242	2170	2012-11-29 17:00:00	95	\N	\N	\N
6257	254	2173	2012-11-29 18:30:00	51	\N	\N	\N
6260	254	2174	2012-11-29 19:00:00	51	\N	\N	\N
6264	255	2175	2012-11-29 19:30:00	76	\N	\N	\N
5999	254	2087	2012-11-27 23:30:00	48	\N	\N	\N
6003	255	2088	2012-11-28 00:00:00	76	\N	\N	\N
6007	242	2089	2012-11-28 00:30:00	86	\N	\N	\N
6027	255	2096	2012-11-28 04:00:00	76	\N	\N	\N
6031	242	2097	2012-11-28 04:30:00	89	\N	\N	\N
6041	254	2101	2012-11-28 06:30:00	49	\N	\N	\N
6051	255	2104	2012-11-28 08:00:00	75	\N	\N	\N
6062	254	2108	2012-11-28 10:00:00	49	\N	\N	\N
6069	255	2110	2012-11-28 11:00:00	77	\N	\N	\N
6076	242	2112	2012-11-28 12:00:00	72	\N	\N	\N
6084	255	2115	2012-11-28 13:30:00	77	\N	\N	\N
6098	254	2120	2012-11-28 16:00:00	51	\N	\N	\N
6103	242	2121	2012-11-28 16:30:00	86	\N	\N	\N
6118	242	2126	2012-11-28 19:00:00	90	\N	\N	\N
6128	254	2130	2012-11-28 21:00:00	50	\N	\N	\N
6157	242	2139	2012-11-29 01:30:00	94	\N	\N	\N
6162	255	2141	2012-11-29 02:30:00	78	\N	\N	\N
6168	255	2143	2012-11-29 03:30:00	77	\N	\N	\N
6170	254	2144	2012-11-29 04:00:00	50	\N	\N	\N
6175	242	2145	2012-11-29 04:30:00	95	\N	\N	\N
6179	254	2147	2012-11-29 05:30:00	49	\N	\N	\N
6184	242	2148	2012-11-29 06:00:00	96	\N	\N	\N
6190	242	2150	2012-11-29 07:00:00	96	\N	\N	\N
6218	254	2160	2012-11-29 12:00:00	49	\N	\N	\N
6232	242	2164	2012-11-29 14:00:00	70	\N	\N	\N
6240	255	2167	2012-11-29 15:30:00	77	\N	\N	\N
6254	254	2172	2012-11-29 18:00:00	51	\N	\N	\N
6258	255	2173	2012-11-29 18:30:00	77	\N	\N	\N
6263	254	2175	2012-11-29 19:30:00	50	\N	\N	\N
6000	255	2087	2012-11-27 23:30:00	76	\N	\N	\N
6029	254	2097	2012-11-28 04:30:00	49	\N	\N	\N
6033	255	2098	2012-11-28 05:00:00	75	\N	\N	\N
6042	255	2101	2012-11-28 06:30:00	76	\N	\N	\N
6047	254	2103	2012-11-28 07:30:00	49	\N	\N	\N
6064	242	2108	2012-11-28 10:00:00	80	\N	\N	\N
6083	254	2115	2012-11-28 13:30:00	51	\N	\N	\N
6088	242	2116	2012-11-28 14:00:00	72	\N	\N	\N
6101	254	2121	2012-11-28 16:30:00	51	\N	\N	\N
6110	254	2124	2012-11-28 18:00:00	51	\N	\N	\N
6121	242	2127	2012-11-28 19:30:00	90	\N	\N	\N
6130	242	2130	2012-11-28 21:00:00	89	\N	\N	\N
6136	242	2132	2012-11-28 22:00:00	93	\N	\N	\N
6140	254	2134	2012-11-28 23:00:00	51	\N	\N	\N
6145	242	2135	2012-11-28 23:30:00	94	\N	\N	\N
6148	242	2136	2012-11-29 00:00:00	95	\N	\N	\N
6151	242	2137	2012-11-29 00:30:00	94	\N	\N	\N
6155	254	2139	2012-11-29 01:30:00	51	\N	\N	\N
6158	254	2140	2012-11-29 02:00:00	50	\N	\N	\N
6164	254	2142	2012-11-29 03:00:00	50	\N	\N	\N
6169	242	2143	2012-11-29 03:30:00	96	\N	\N	\N
6176	254	2146	2012-11-29 05:00:00	49	\N	\N	\N
6181	242	2147	2012-11-29 05:30:00	96	\N	\N	\N
6193	242	2151	2012-11-29 07:30:00	97	\N	\N	\N
6199	242	2153	2012-11-29 08:30:00	91	\N	\N	\N
6204	255	2155	2012-11-29 09:30:00	75	\N	\N	\N
6212	254	2158	2012-11-29 11:00:00	48	\N	\N	\N
6216	255	2159	2012-11-29 11:30:00	76	\N	\N	\N
6244	242	2168	2012-11-29 16:00:00	93	\N	\N	\N
6268	242	2176	2012-11-29 20:00:00	96	\N	\N	\N
6001	242	2087	2012-11-27 23:30:00	80	\N	\N	\N
6008	254	2090	2012-11-28 01:00:00	49	\N	\N	\N
6023	254	2095	2012-11-28 03:30:00	49	\N	\N	\N
6030	255	2097	2012-11-28 04:30:00	75	\N	\N	\N
6046	242	2102	2012-11-28 07:00:00	91	\N	\N	\N
6056	254	2106	2012-11-28 09:00:00	49	\N	\N	\N
6061	242	2107	2012-11-28 09:30:00	87	\N	\N	\N
6086	254	2116	2012-11-28 14:00:00	51	\N	\N	\N
6089	254	2117	2012-11-28 14:30:00	51	\N	\N	\N
6092	254	2118	2012-11-28 15:00:00	51	\N	\N	\N
6099	255	2120	2012-11-28 16:00:00	77	\N	\N	\N
6113	254	2125	2012-11-28 18:30:00	50	\N	\N	\N
6117	255	2126	2012-11-28 19:00:00	77	\N	\N	\N
6161	254	2141	2012-11-29 02:30:00	49	\N	\N	\N
6165	255	2142	2012-11-29 03:00:00	78	\N	\N	\N
6171	255	2144	2012-11-29 04:00:00	77	\N	\N	\N
6182	254	2148	2012-11-29 06:00:00	49	\N	\N	\N
6189	255	2150	2012-11-29 07:00:00	72	\N	\N	\N
6191	254	2151	2012-11-29 07:30:00	48	\N	\N	\N
6200	254	2154	2012-11-29 09:00:00	49	\N	\N	\N
6205	242	2155	2012-11-29 09:30:00	83	\N	\N	\N
6208	242	2156	2012-11-29 10:00:00	81	\N	\N	\N
6211	242	2157	2012-11-29 10:30:00	76	\N	\N	\N
6215	254	2159	2012-11-29 11:30:00	49	\N	\N	\N
6220	242	2160	2012-11-29 12:00:00	73	\N	\N	\N
6226	242	2162	2012-11-29 13:00:00	72	\N	\N	\N
6233	254	2165	2012-11-29 14:30:00	50	\N	\N	\N
6238	242	2166	2012-11-29 15:00:00	80	\N	\N	\N
6243	255	2168	2012-11-29 16:00:00	78	\N	\N	\N
6247	242	2169	2012-11-29 16:30:00	94	\N	\N	\N
6249	255	2170	2012-11-29 17:00:00	77	\N	\N	\N
6252	255	2171	2012-11-29 17:30:00	77	\N	\N	\N
6013	242	2091	2012-11-28 01:30:00	89	\N	\N	\N
6018	255	2093	2012-11-28 02:30:00	76	\N	\N	\N
6032	254	2098	2012-11-28 05:00:00	49	\N	\N	\N
6039	255	2100	2012-11-28 06:00:00	75	\N	\N	\N
6043	242	2101	2012-11-28 06:30:00	91	\N	\N	\N
6050	254	2104	2012-11-28 08:00:00	49	\N	\N	\N
6055	242	2105	2012-11-28 08:30:00	91	\N	\N	\N
6059	254	2107	2012-11-28 09:30:00	49	\N	\N	\N
6077	254	2113	2012-11-28 12:30:00	50	\N	\N	\N
6097	242	2119	2012-11-28 15:30:00	79	\N	\N	\N
6116	254	2126	2012-11-28 19:00:00	50	\N	\N	\N
6122	254	2128	2012-11-28 20:00:00	50	\N	\N	\N
6125	254	2129	2012-11-28 20:30:00	50	\N	\N	\N
6133	242	2131	2012-11-28 21:30:00	91	\N	\N	\N
6144	255	2135	2012-11-28 23:30:00	79	\N	\N	\N
6153	255	2138	2012-11-29 01:00:00	79	\N	\N	\N
6156	255	2139	2012-11-29 01:30:00	79	\N	\N	\N
6163	242	2141	2012-11-29 02:30:00	95	\N	\N	\N
6197	254	2153	2012-11-29 08:30:00	48	\N	\N	\N
6201	255	2154	2012-11-29 09:00:00	75	\N	\N	\N
6214	242	2158	2012-11-29 11:00:00	76	\N	\N	\N
6224	254	2162	2012-11-29 13:00:00	50	\N	\N	\N
6229	242	2163	2012-11-29 13:30:00	67	\N	\N	\N
6236	254	2166	2012-11-29 15:00:00	50	\N	\N	\N
6241	242	2167	2012-11-29 15:30:00	91	\N	\N	\N
6245	254	2169	2012-11-29 16:30:00	51	\N	\N	\N
6255	255	2172	2012-11-29 18:00:00	77	\N	\N	\N
6265	242	2175	2012-11-29 19:30:00	96	\N	\N	\N
6269	254	2177	2012-11-29 20:30:00	50	\N	\N	\N
6270	255	2177	2012-11-29 20:30:00	76	\N	\N	\N
6271	242	2177	2012-11-29 20:30:00	97	\N	\N	\N
6272	254	2178	2012-11-29 21:00:00	50	\N	\N	\N
6273	255	2178	2012-11-29 21:00:00	76	\N	\N	\N
6274	242	2178	2012-11-29 21:00:00	96	\N	\N	\N
6275	254	2179	2012-11-29 21:30:00	50	\N	\N	\N
6276	255	2179	2012-11-29 21:30:00	76	\N	\N	\N
6277	242	2179	2012-11-29 21:30:00	96	\N	\N	\N
6278	254	2180	2012-11-29 22:00:00	50	\N	\N	\N
6279	255	2180	2012-11-29 22:00:00	76	\N	\N	\N
6280	242	2180	2012-11-29 22:00:00	96	\N	\N	\N
6281	254	2181	2012-11-29 22:30:00	50	\N	\N	\N
6282	255	2181	2012-11-29 22:30:00	75	\N	\N	\N
6283	242	2181	2012-11-29 22:30:00	96	\N	\N	\N
6284	254	2182	2012-11-29 23:00:00	50	\N	\N	\N
6285	255	2182	2012-11-29 23:00:00	75	\N	\N	\N
6286	242	2182	2012-11-29 23:00:00	96	\N	\N	\N
6287	254	2183	2012-11-29 23:30:00	50	\N	\N	\N
6288	255	2183	2012-11-29 23:30:00	74	\N	\N	\N
6289	242	2183	2012-11-29 23:30:00	95	\N	\N	\N
6290	254	2184	2012-11-30 00:00:00	49	\N	\N	\N
6291	255	2184	2012-11-30 00:00:00	73	\N	\N	\N
6292	242	2184	2012-11-30 00:00:00	94	\N	\N	\N
6293	254	2185	2012-11-30 00:30:00	49	\N	\N	\N
6294	255	2185	2012-11-30 00:30:00	70	\N	\N	\N
6295	242	2185	2012-11-30 00:30:00	94	\N	\N	\N
6296	254	2186	2012-11-30 01:00:00	48	\N	\N	\N
6297	255	2186	2012-11-30 01:00:00	68	\N	\N	\N
6298	242	2186	2012-11-30 01:00:00	94	\N	\N	\N
6299	254	2187	2012-11-30 01:30:00	47	\N	\N	\N
6300	255	2187	2012-11-30 01:30:00	68	\N	\N	\N
6301	242	2187	2012-11-30 01:30:00	95	\N	\N	\N
6302	254	2188	2012-11-30 02:00:00	47	\N	\N	\N
6303	255	2188	2012-11-30 02:00:00	66	\N	\N	\N
6304	242	2188	2012-11-30 02:00:00	92	\N	\N	\N
6305	254	2189	2012-11-30 02:30:00	46	\N	\N	\N
6306	255	2189	2012-11-30 02:30:00	64	\N	\N	\N
6307	242	2189	2012-11-30 02:30:00	93	\N	\N	\N
6308	254	2190	2012-11-30 03:00:00	45	\N	\N	\N
6309	255	2190	2012-11-30 03:00:00	64	\N	\N	\N
6310	242	2190	2012-11-30 03:00:00	93	\N	\N	\N
6311	254	2191	2012-11-30 03:30:00	45	\N	\N	\N
6312	255	2191	2012-11-30 03:30:00	64	\N	\N	\N
6313	242	2191	2012-11-30 03:30:00	95	\N	\N	\N
6314	254	2192	2012-11-30 04:00:00	45	\N	\N	\N
6315	255	2192	2012-11-30 04:00:00	64	\N	\N	\N
6316	242	2192	2012-11-30 04:00:00	94	\N	\N	\N
6317	254	2193	2012-11-30 04:30:00	44	\N	\N	\N
6318	255	2193	2012-11-30 04:30:00	63	\N	\N	\N
6319	242	2193	2012-11-30 04:30:00	93	\N	\N	\N
6320	254	2194	2012-11-30 05:00:00	44	\N	\N	\N
6321	255	2194	2012-11-30 05:00:00	63	\N	\N	\N
6322	242	2194	2012-11-30 05:00:00	94	\N	\N	\N
6323	254	2195	2012-11-30 05:30:00	44	\N	\N	\N
6324	255	2195	2012-11-30 05:30:00	63	\N	\N	\N
6325	242	2195	2012-11-30 05:30:00	93	\N	\N	\N
6326	254	2196	2012-11-30 06:00:00	44	\N	\N	\N
6327	255	2196	2012-11-30 06:00:00	62	\N	\N	\N
6328	242	2196	2012-11-30 06:00:00	94	\N	\N	\N
6341	254	2221	2012-11-30 06:30:00	43	\N	\N	\N
6342	255	2221	2012-11-30 06:30:00	62	\N	\N	\N
6343	242	2221	2012-11-30 06:30:00	94	\N	\N	\N
6344	254	2222	2012-11-30 07:00:00	43	\N	\N	\N
6345	255	2222	2012-11-30 07:00:00	63	\N	\N	\N
6346	242	2222	2012-11-30 07:00:00	94	\N	\N	\N
6361	254	2241	2012-11-30 07:30:00	44	\N	\N	\N
6362	255	2241	2012-11-30 07:30:00	64	\N	\N	\N
6363	242	2241	2012-11-30 07:30:00	95	\N	\N	\N
6364	254	2242	2012-11-30 08:00:00	44	\N	\N	\N
6365	255	2242	2012-11-30 08:00:00	66	\N	\N	\N
6366	242	2242	2012-11-30 08:00:00	95	\N	\N	\N
6367	254	2243	2012-11-30 08:30:00	45	\N	\N	\N
6368	255	2243	2012-11-30 08:30:00	65	\N	\N	\N
6369	242	2243	2012-11-30 08:30:00	95	\N	\N	\N
6370	254	2244	2012-11-30 09:00:00	45	\N	\N	\N
6371	255	2244	2012-11-30 09:00:00	68	\N	\N	\N
6372	242	2244	2012-11-30 09:00:00	96	\N	\N	\N
6373	254	2245	2012-11-30 09:30:00	45	\N	\N	\N
6374	255	2245	2012-11-30 09:30:00	69	\N	\N	\N
6375	242	2245	2012-11-30 09:30:00	96	\N	\N	\N
6376	254	2246	2012-11-30 10:00:00	46	\N	\N	\N
6377	255	2246	2012-11-30 10:00:00	69	\N	\N	\N
6378	242	2246	2012-11-30 10:00:00	93	\N	\N	\N
6379	254	2247	2012-11-30 10:30:00	46	\N	\N	\N
6380	255	2247	2012-11-30 10:30:00	69	\N	\N	\N
6381	242	2247	2012-11-30 10:30:00	92	\N	\N	\N
6382	254	2248	2012-11-30 11:00:00	46	\N	\N	\N
6383	255	2248	2012-11-30 11:00:00	69	\N	\N	\N
6384	242	2248	2012-11-30 11:00:00	92	\N	\N	\N
6385	254	2249	2012-11-30 11:30:00	45	\N	\N	\N
6386	255	2249	2012-11-30 11:30:00	69	\N	\N	\N
6387	242	2249	2012-11-30 11:30:00	90	\N	\N	\N
6388	254	2250	2012-11-30 12:00:00	45	\N	\N	\N
6389	255	2250	2012-11-30 12:00:00	69	\N	\N	\N
6390	242	2250	2012-11-30 12:00:00	90	\N	\N	\N
6391	254	2251	2012-11-30 12:30:00	45	\N	\N	\N
6392	255	2251	2012-11-30 12:30:00	69	\N	\N	\N
6393	242	2251	2012-11-30 12:30:00	89	\N	\N	\N
6394	254	2252	2012-11-30 13:00:00	45	\N	\N	\N
6395	255	2252	2012-11-30 13:00:00	69	\N	\N	\N
6396	242	2252	2012-11-30 13:00:00	86	\N	\N	\N
6397	254	2253	2012-11-30 13:30:00	45	\N	\N	\N
6398	255	2253	2012-11-30 13:30:00	68	\N	\N	\N
6399	242	2253	2012-11-30 13:30:00	82	\N	\N	\N
6400	254	2254	2012-11-30 14:00:00	45	\N	\N	\N
6401	255	2254	2012-11-30 14:00:00	68	\N	\N	\N
6402	242	2254	2012-11-30 14:00:00	82	\N	\N	\N
6403	254	2255	2012-11-30 14:30:00	45	\N	\N	\N
6404	255	2255	2012-11-30 14:30:00	67	\N	\N	\N
6405	242	2255	2012-11-30 14:30:00	81	\N	\N	\N
6406	254	2256	2012-11-30 15:00:00	45	\N	\N	\N
6407	255	2256	2012-11-30 15:00:00	67	\N	\N	\N
6408	242	2256	2012-11-30 15:00:00	82	\N	\N	\N
6409	254	2257	2012-11-30 15:30:00	45	\N	\N	\N
6410	255	2257	2012-11-30 15:30:00	67	\N	\N	\N
6411	242	2257	2012-11-30 15:30:00	83	\N	\N	\N
6412	254	2258	2012-11-30 16:00:00	45	\N	\N	\N
6413	255	2258	2012-11-30 16:00:00	66	\N	\N	\N
6414	242	2258	2012-11-30 16:00:00	83	\N	\N	\N
6415	254	2259	2012-11-30 16:30:00	45	\N	\N	\N
6416	255	2259	2012-11-30 16:30:00	65	\N	\N	\N
6417	242	2259	2012-11-30 16:30:00	86	\N	\N	\N
6418	254	2260	2012-11-30 17:00:00	45	\N	\N	\N
6419	255	2260	2012-11-30 17:00:00	65	\N	\N	\N
6420	242	2260	2012-11-30 17:00:00	87	\N	\N	\N
6421	254	2261	2012-11-30 17:30:00	45	\N	\N	\N
6422	255	2261	2012-11-30 17:30:00	65	\N	\N	\N
6423	242	2261	2012-11-30 17:30:00	89	\N	\N	\N
6424	254	2262	2012-11-30 18:00:00	45	\N	\N	\N
6425	255	2262	2012-11-30 18:00:00	65	\N	\N	\N
6426	242	2262	2012-11-30 18:00:00	90	\N	\N	\N
6427	254	2263	2012-11-30 18:30:00	45	\N	\N	\N
6428	255	2263	2012-11-30 18:30:00	66	\N	\N	\N
6429	242	2263	2012-11-30 18:30:00	90	\N	\N	\N
6430	254	2264	2012-11-30 19:00:00	45	\N	\N	\N
6431	255	2264	2012-11-30 19:00:00	66	\N	\N	\N
6432	242	2264	2012-11-30 19:00:00	92	\N	\N	\N
6461	254	2281	2012-11-30 19:30:00	45	\N	\N	\N
6462	255	2281	2012-11-30 19:30:00	66	\N	\N	\N
6463	242	2281	2012-11-30 19:30:00	93	\N	\N	\N
6464	254	2282	2012-11-30 20:00:00	45	\N	\N	\N
6465	255	2282	2012-11-30 20:00:00	67	\N	\N	\N
6466	242	2282	2012-11-30 20:00:00	90	\N	\N	\N
6481	254	2301	2012-11-30 20:30:00	45	\N	\N	\N
6482	255	2301	2012-11-30 20:30:00	67	\N	\N	\N
6483	242	2301	2012-11-30 20:30:00	86	\N	\N	\N
6484	254	2302	2012-11-30 21:00:00	45	\N	\N	\N
6485	255	2302	2012-11-30 21:00:00	67	\N	\N	\N
6486	242	2302	2012-11-30 21:00:00	86	\N	\N	\N
6487	254	2303	2012-11-30 21:30:00	45	\N	\N	\N
6488	255	2303	2012-11-30 21:30:00	67	\N	\N	\N
6489	242	2303	2012-11-30 21:30:00	90	\N	\N	\N
6490	254	2304	2012-11-30 22:00:00	45	\N	\N	\N
6491	255	2304	2012-11-30 22:00:00	67	\N	\N	\N
6492	242	2304	2012-11-30 22:00:00	89	\N	\N	\N
6521	254	2321	2012-11-30 22:30:00	45	\N	\N	\N
6522	255	2321	2012-11-30 22:30:00	67	\N	\N	\N
6523	242	2321	2012-11-30 22:30:00	88	\N	\N	\N
6524	254	2322	2012-11-30 23:00:00	44	\N	\N	\N
6525	255	2322	2012-11-30 23:00:00	67	\N	\N	\N
6526	242	2322	2012-11-30 23:00:00	86	\N	\N	\N
\.


--
-- Data for Name: s_data_moistures; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_moistures (id, sensor_id, sensor_data_id, date_time, moisture) FROM stdin;
3461	244	1801	2012-11-22 00:30:00	11
3462	245	1801	2012-11-22 00:30:00	8
3463	244	1802	2012-11-22 01:00:00	11
3464	245	1802	2012-11-22 01:00:00	8
3465	244	1803	2012-11-22 01:30:00	11
3466	245	1803	2012-11-22 01:30:00	8
3467	244	1804	2012-11-22 02:00:00	11
3468	245	1804	2012-11-22 02:00:00	8
3469	244	1805	2012-11-22 02:30:00	11
3470	245	1805	2012-11-22 02:30:00	8
3471	244	1806	2012-11-22 03:00:00	11
3472	245	1806	2012-11-22 03:00:00	8
3473	244	1807	2012-11-22 03:30:00	11
3474	245	1807	2012-11-22 03:30:00	8
3475	244	1808	2012-11-22 04:00:00	11
3476	245	1808	2012-11-22 04:00:00	8
3477	244	1809	2012-11-22 04:30:00	12
3478	245	1809	2012-11-22 04:30:00	8
3479	244	1810	2012-11-22 05:00:00	12
3480	245	1810	2012-11-22 05:00:00	8
3481	244	1811	2012-11-22 05:30:00	12
3482	245	1811	2012-11-22 05:30:00	8
3483	244	1812	2012-11-22 06:00:00	12
3484	245	1812	2012-11-22 06:00:00	8
3485	244	1813	2012-11-22 06:30:00	12
3486	245	1813	2012-11-22 06:30:00	8
3487	244	1814	2012-11-22 07:00:00	12
3488	245	1814	2012-11-22 07:00:00	8
3489	244	1815	2012-11-22 07:30:00	12
3490	245	1815	2012-11-22 07:30:00	8
3491	244	1816	2012-11-22 08:00:00	12
3492	245	1816	2012-11-22 08:00:00	8
3493	244	1817	2012-11-22 08:30:00	12
3494	245	1817	2012-11-22 08:30:00	8
3495	244	1818	2012-11-22 09:00:00	12
3496	245	1818	2012-11-22 09:00:00	8
3497	244	1819	2012-11-22 09:30:00	12
3498	245	1819	2012-11-22 09:30:00	8
3499	244	1820	2012-11-22 10:00:00	12
3500	245	1820	2012-11-22 10:00:00	8
3501	244	1821	2012-11-22 10:30:00	12
3502	245	1821	2012-11-22 10:30:00	8
3503	244	1822	2012-11-22 11:00:00	12
3504	245	1822	2012-11-22 11:00:00	8
3505	244	1823	2012-11-22 11:30:00	12
3506	245	1823	2012-11-22 11:30:00	8
3507	244	1824	2012-11-22 12:00:00	12
3508	245	1824	2012-11-22 12:00:00	8
3509	244	1825	2012-11-22 12:30:00	12
3510	245	1825	2012-11-22 12:30:00	8
3511	244	1826	2012-11-22 13:00:00	11
3512	245	1826	2012-11-22 13:00:00	8
3513	244	1827	2012-11-22 13:30:00	11
3514	245	1827	2012-11-22 13:30:00	8
3515	244	1828	2012-11-22 14:00:00	11
3516	245	1828	2012-11-22 14:00:00	8
3517	244	1829	2012-11-22 14:30:00	11
3518	245	1829	2012-11-22 14:30:00	8
3519	244	1830	2012-11-22 15:00:00	11
3520	245	1830	2012-11-22 15:00:00	8
3521	244	1831	2012-11-22 15:30:00	11
3522	245	1831	2012-11-22 15:30:00	8
3523	244	1832	2012-11-22 16:00:00	11
3524	245	1832	2012-11-22 16:00:00	8
3525	244	1833	2012-11-22 16:30:00	11
3526	245	1833	2012-11-22 16:30:00	8
3527	244	1834	2012-11-22 17:00:00	11
3528	245	1834	2012-11-22 17:00:00	8
3529	244	1835	2012-11-22 17:30:00	11
3530	245	1835	2012-11-22 17:30:00	8
3531	244	1836	2012-11-22 18:00:00	11
3532	245	1836	2012-11-22 18:00:00	8
3533	244	1837	2012-11-22 18:30:00	11
3534	245	1837	2012-11-22 18:30:00	8
3535	244	1838	2012-11-22 19:00:00	12
3536	245	1838	2012-11-22 19:00:00	8
3537	244	1839	2012-11-22 19:30:00	12
3538	245	1839	2012-11-22 19:30:00	8
3539	244	1840	2012-11-22 20:00:00	12
3540	245	1840	2012-11-22 20:00:00	8
3541	244	1841	2012-11-22 20:30:00	12
3542	245	1841	2012-11-22 20:30:00	8
3543	244	1842	2012-11-22 21:00:00	12
3544	245	1842	2012-11-22 21:00:00	8
3545	244	1843	2012-11-22 21:30:00	12
3546	245	1843	2012-11-22 21:30:00	8
3547	244	1844	2012-11-22 22:00:00	12
3548	245	1844	2012-11-22 22:00:00	8
3549	244	1845	2012-11-22 22:30:00	12
3550	245	1845	2012-11-22 22:30:00	8
3551	244	1846	2012-11-22 23:00:00	12
3552	245	1846	2012-11-22 23:00:00	8
3553	244	1847	2012-11-22 23:30:00	12
3554	245	1847	2012-11-22 23:30:00	8
3555	244	1848	2012-11-23 00:00:00	12
3556	245	1848	2012-11-23 00:00:00	8
3557	244	1849	2012-11-23 00:30:00	12
3558	245	1849	2012-11-23 00:30:00	8
3559	244	1850	2012-11-23 01:00:00	12
3560	245	1850	2012-11-23 01:00:00	8
3561	244	1851	2012-11-23 01:30:00	12
3562	245	1851	2012-11-23 01:30:00	8
3563	244	1852	2012-11-23 02:00:00	12
3564	245	1852	2012-11-23 02:00:00	8
3565	244	1853	2012-11-23 02:30:00	12
3566	245	1853	2012-11-23 02:30:00	8
3567	244	1854	2012-11-23 03:00:00	12
3568	245	1854	2012-11-23 03:00:00	8
3569	244	1855	2012-11-23 03:30:00	12
3570	245	1855	2012-11-23 03:30:00	8
3571	244	1856	2012-11-23 04:00:00	12
3572	245	1856	2012-11-23 04:00:00	8
3573	244	1857	2012-11-23 04:30:00	12
3574	245	1857	2012-11-23 04:30:00	8
3575	244	1858	2012-11-23 05:00:00	12
3576	245	1858	2012-11-23 05:00:00	8
3577	244	1859	2012-11-23 05:30:00	12
3578	245	1859	2012-11-23 05:30:00	8
3579	244	1860	2012-11-23 06:00:00	12
3580	245	1860	2012-11-23 06:00:00	8
3581	244	1861	2012-11-23 06:30:00	12
3582	245	1861	2012-11-23 06:30:00	8
3583	244	1862	2012-11-23 07:00:00	12
3584	245	1862	2012-11-23 07:00:00	8
3585	244	1863	2012-11-23 07:30:00	12
3586	245	1863	2012-11-23 07:30:00	8
3587	244	1864	2012-11-23 08:00:00	12
3588	245	1864	2012-11-23 08:00:00	8
3589	244	1865	2012-11-23 08:30:00	12
3590	245	1865	2012-11-23 08:30:00	8
3591	244	1866	2012-11-23 09:00:00	12
3592	245	1866	2012-11-23 09:00:00	8
3593	244	1867	2012-11-23 09:30:00	12
3594	245	1867	2012-11-23 09:30:00	8
3595	244	1868	2012-11-23 10:00:00	12
3596	245	1868	2012-11-23 10:00:00	8
3597	244	1869	2012-11-23 10:30:00	12
3598	245	1869	2012-11-23 10:30:00	8
3599	244	1870	2012-11-23 11:00:00	12
3600	245	1870	2012-11-23 11:00:00	8
3601	244	1871	2012-11-23 11:30:00	12
3602	245	1871	2012-11-23 11:30:00	8
3603	244	1872	2012-11-23 12:00:00	12
3604	245	1872	2012-11-23 12:00:00	8
3605	244	1873	2012-11-23 12:30:00	12
3606	245	1873	2012-11-23 12:30:00	8
3607	244	1874	2012-11-23 13:00:00	12
3608	245	1874	2012-11-23 13:00:00	8
3609	244	1875	2012-11-23 13:30:00	12
3610	245	1875	2012-11-23 13:30:00	8
3611	244	1876	2012-11-23 14:00:00	12
3612	245	1876	2012-11-23 14:00:00	8
3613	244	1877	2012-11-23 14:30:00	12
3614	245	1877	2012-11-23 14:30:00	8
3615	244	1878	2012-11-23 15:00:00	12
3616	245	1878	2012-11-23 15:00:00	8
3617	244	1879	2012-11-23 15:30:00	12
3618	245	1879	2012-11-23 15:30:00	8
3619	244	1880	2012-11-23 16:00:00	12
3620	245	1880	2012-11-23 16:00:00	8
3621	244	1881	2012-11-23 16:30:00	12
3622	245	1881	2012-11-23 16:30:00	8
3623	244	1882	2012-11-23 17:00:00	12
3624	245	1882	2012-11-23 17:00:00	8
3625	244	1883	2012-11-23 17:30:00	12
3626	245	1883	2012-11-23 17:30:00	8
3627	244	1884	2012-11-23 18:00:00	12
3628	245	1884	2012-11-23 18:00:00	8
3629	244	1885	2012-11-23 18:30:00	12
3630	245	1885	2012-11-23 18:30:00	8
3631	244	1886	2012-11-23 19:00:00	12
3632	245	1886	2012-11-23 19:00:00	8
3633	244	1887	2012-11-23 19:30:00	12
3634	245	1887	2012-11-23 19:30:00	8
3635	244	1888	2012-11-23 20:00:00	12
3636	245	1888	2012-11-23 20:00:00	8
3637	244	1889	2012-11-23 20:30:00	12
3638	245	1889	2012-11-23 20:30:00	8
3639	244	1890	2012-11-23 21:00:00	12
3640	245	1890	2012-11-23 21:00:00	8
3641	244	1891	2012-11-23 21:30:00	12
3642	245	1891	2012-11-23 21:30:00	8
3643	244	1892	2012-11-23 22:00:00	12
3644	245	1892	2012-11-23 22:00:00	8
3645	244	1893	2012-11-23 22:30:00	12
3646	245	1893	2012-11-23 22:30:00	8
3647	244	1894	2012-11-23 23:00:00	12
3648	245	1894	2012-11-23 23:00:00	8
3649	244	1895	2012-11-23 23:30:00	12
3650	245	1895	2012-11-23 23:30:00	8
3651	244	1896	2012-11-24 00:00:00	12
3652	245	1896	2012-11-24 00:00:00	8
3653	244	1897	2012-11-24 00:30:00	12
3654	245	1897	2012-11-24 00:30:00	8
3655	244	1898	2012-11-24 01:00:00	12
3656	245	1898	2012-11-24 01:00:00	8
3657	244	1899	2012-11-24 01:30:00	12
3658	245	1899	2012-11-24 01:30:00	8
3659	244	1900	2012-11-24 02:00:00	12
3660	245	1900	2012-11-24 02:00:00	8
3661	244	1901	2012-11-24 02:30:00	12
3662	245	1901	2012-11-24 02:30:00	8
3663	244	1902	2012-11-24 03:00:00	12
3664	245	1902	2012-11-24 03:00:00	8
3665	244	1903	2012-11-24 03:30:00	12
3666	245	1903	2012-11-24 03:30:00	8
3667	244	1904	2012-11-24 04:00:00	12
3668	245	1904	2012-11-24 04:00:00	8
3669	244	1905	2012-11-24 04:30:00	12
3670	245	1905	2012-11-24 04:30:00	8
3671	244	1906	2012-11-24 05:00:00	12
3672	245	1906	2012-11-24 05:00:00	8
3673	244	1907	2012-11-24 05:30:00	12
3674	245	1907	2012-11-24 05:30:00	8
3675	244	1908	2012-11-24 06:00:00	12
3676	245	1908	2012-11-24 06:00:00	8
3677	244	1909	2012-11-24 06:30:00	12
3678	245	1909	2012-11-24 06:30:00	8
3679	244	1910	2012-11-24 07:00:00	12
3680	245	1910	2012-11-24 07:00:00	8
3681	244	1911	2012-11-24 07:30:00	12
3682	245	1911	2012-11-24 07:30:00	8
3683	244	1912	2012-11-24 08:00:00	12
3684	245	1912	2012-11-24 08:00:00	8
3685	244	1913	2012-11-24 08:30:00	12
3686	245	1913	2012-11-24 08:30:00	8
3687	244	1914	2012-11-24 09:00:00	12
3688	245	1914	2012-11-24 09:00:00	8
3689	244	1915	2012-11-24 09:30:00	12
3690	245	1915	2012-11-24 09:30:00	8
3691	244	1916	2012-11-24 10:00:00	12
3692	245	1916	2012-11-24 10:00:00	8
3693	244	1917	2012-11-24 10:30:00	12
3694	245	1917	2012-11-24 10:30:00	8
3695	244	1918	2012-11-24 11:00:00	12
3696	245	1918	2012-11-24 11:00:00	8
3697	244	1919	2012-11-24 11:30:00	12
3698	245	1919	2012-11-24 11:30:00	8
3699	244	1920	2012-11-24 12:00:00	12
3700	245	1920	2012-11-24 12:00:00	8
3701	244	1921	2012-11-24 12:30:00	12
3705	244	1923	2012-11-24 13:30:00	12
3709	244	1925	2012-11-24 14:30:00	12
3713	244	1927	2012-11-24 15:30:00	12
3717	244	1929	2012-11-24 16:30:00	12
3736	245	1938	2012-11-24 21:00:00	8
3748	245	1944	2012-11-25 00:00:00	8
3752	245	1946	2012-11-25 01:00:00	8
3764	245	1952	2012-11-25 04:00:00	8
3768	245	1954	2012-11-25 05:00:00	8
3772	245	1956	2012-11-25 06:00:00	8
3779	244	1960	2012-11-25 08:00:00	13
3784	245	1962	2012-11-25 09:00:00	9
3787	244	1964	2012-11-25 10:00:00	13
3791	244	1966	2012-11-25 11:00:00	13
3795	244	1968	2012-11-25 12:00:00	13
3803	244	1972	2012-11-25 14:00:00	13
3807	244	1974	2012-11-25 15:00:00	13
3811	244	1976	2012-11-25 16:00:00	13
3823	244	1982	2012-11-25 19:00:00	13
3874	245	2007	2012-11-26 07:30:00	9
3878	245	2009	2012-11-26 08:30:00	9
3882	245	2011	2012-11-26 09:30:00	9
3896	245	2018	2012-11-26 13:00:00	9
3901	244	2021	2012-11-26 14:30:00	13
3909	244	2025	2012-11-26 16:30:00	13
3935	244	2038	2012-11-26 23:00:00	13
3939	244	2040	2012-11-27 00:00:00	13
3949	244	2045	2012-11-27 02:30:00	13
3955	244	2048	2012-11-27 04:00:00	13
3963	244	2052	2012-11-27 06:00:00	13
3966	245	2053	2012-11-27 06:30:00	8
3970	245	2055	2012-11-27 07:30:00	8
3978	245	2059	2012-11-27 09:30:00	8
3991	244	2066	2012-11-27 13:00:00	13
3702	245	1921	2012-11-24 12:30:00	8
3710	245	1925	2012-11-24 14:30:00	8
3720	245	1930	2012-11-24 17:00:00	8
3726	245	1933	2012-11-24 18:30:00	8
3741	244	1941	2012-11-24 22:30:00	12
3745	244	1943	2012-11-24 23:30:00	12
3749	244	1945	2012-11-25 00:30:00	13
3753	244	1947	2012-11-25 01:30:00	13
3757	244	1949	2012-11-25 02:30:00	13
3776	245	1958	2012-11-25 07:00:00	8
3788	245	1964	2012-11-25 10:00:00	9
3792	245	1966	2012-11-25 11:00:00	9
3804	245	1972	2012-11-25 14:00:00	9
3808	245	1974	2012-11-25 15:00:00	9
3812	245	1976	2012-11-25 16:00:00	9
3819	244	1980	2012-11-25 18:00:00	13
3824	245	1982	2012-11-25 19:00:00	9
3827	244	1984	2012-11-25 20:00:00	13
3831	244	1986	2012-11-25 21:00:00	13
3835	244	1988	2012-11-25 22:00:00	13
3843	244	1992	2012-11-26 00:00:00	13
3847	244	1994	2012-11-26 01:00:00	13
3851	244	1996	2012-11-26 02:00:00	13
3863	244	2002	2012-11-26 05:00:00	13
3894	245	2017	2012-11-26 12:30:00	9
3899	244	2020	2012-11-26 14:00:00	13
3910	245	2025	2012-11-26 16:30:00	9
3914	245	2027	2012-11-26 17:30:00	9
3923	244	2032	2012-11-26 20:00:00	13
3934	245	2037	2012-11-26 22:30:00	9
3954	245	2047	2012-11-27 03:30:00	8
3983	244	2062	2012-11-27 11:00:00	13
3703	244	1922	2012-11-24 13:00:00	12
3754	245	1947	2012-11-25 01:30:00	8
3758	245	1949	2012-11-25 02:30:00	8
3762	245	1951	2012-11-25 03:30:00	8
3773	244	1957	2012-11-25 06:30:00	13
3777	244	1959	2012-11-25 07:30:00	13
3782	245	1961	2012-11-25 08:30:00	9
3790	245	1965	2012-11-25 10:30:00	9
3800	245	1970	2012-11-25 13:00:00	9
3806	245	1973	2012-11-25 14:30:00	9
3821	244	1981	2012-11-25 18:30:00	13
3825	244	1983	2012-11-25 19:30:00	13
3829	244	1985	2012-11-25 20:30:00	13
3833	244	1987	2012-11-25 21:30:00	13
3837	244	1989	2012-11-25 22:30:00	13
3856	245	1998	2012-11-26 03:00:00	9
3868	245	2004	2012-11-26 06:00:00	9
3872	245	2006	2012-11-26 07:00:00	9
3884	245	2012	2012-11-26 10:00:00	9
3888	245	2014	2012-11-26 11:00:00	9
3892	245	2016	2012-11-26 12:00:00	9
3895	244	2018	2012-11-26 13:00:00	13
3911	244	2026	2012-11-26 17:00:00	13
3917	244	2029	2012-11-26 18:30:00	13
3928	245	2034	2012-11-26 21:00:00	9
3951	244	2046	2012-11-27 03:00:00	13
3962	245	2051	2012-11-27 05:30:00	8
3975	244	2058	2012-11-27 09:00:00	13
3977	244	2059	2012-11-27 09:30:00	13
3989	244	2065	2012-11-27 12:30:00	13
3704	245	1922	2012-11-24 13:00:00	8
3707	244	1924	2012-11-24 14:00:00	12
3711	244	1926	2012-11-24 15:00:00	12
3715	244	1928	2012-11-24 16:00:00	12
3723	244	1932	2012-11-24 18:00:00	12
3727	244	1934	2012-11-24 19:00:00	12
3731	244	1936	2012-11-24 20:00:00	12
3743	244	1942	2012-11-24 23:00:00	12
3794	245	1967	2012-11-25 11:30:00	9
3798	245	1969	2012-11-25 12:30:00	9
3802	245	1971	2012-11-25 13:30:00	9
3813	244	1977	2012-11-25 16:30:00	13
3817	244	1979	2012-11-25 17:30:00	13
3822	245	1981	2012-11-25 18:30:00	9
3830	245	1985	2012-11-25 20:30:00	9
3840	245	1990	2012-11-25 23:00:00	9
3846	245	1993	2012-11-26 00:30:00	9
3861	244	2001	2012-11-26 04:30:00	13
3865	244	2003	2012-11-26 05:30:00	13
3869	244	2005	2012-11-26 06:30:00	13
3873	244	2007	2012-11-26 07:30:00	13
3877	244	2009	2012-11-26 08:30:00	13
3900	245	2020	2012-11-26 14:00:00	9
3913	244	2027	2012-11-26 17:30:00	12
3919	244	2030	2012-11-26 19:00:00	13
3924	245	2032	2012-11-26 20:00:00	9
3932	245	2036	2012-11-26 22:00:00	9
3936	245	2038	2012-11-26 23:00:00	9
3943	244	2042	2012-11-27 01:00:00	13
3946	245	2043	2012-11-27 01:30:00	9
3952	245	2046	2012-11-27 03:00:00	8
3968	245	2054	2012-11-27 07:00:00	8
3974	245	2057	2012-11-27 08:30:00	8
3976	245	2058	2012-11-27 09:00:00	8
3985	244	2063	2012-11-27 11:30:00	13
3706	245	1923	2012-11-24 13:30:00	8
3729	244	1935	2012-11-24 19:30:00	12
3756	245	1948	2012-11-25 02:00:00	8
3775	244	1958	2012-11-25 07:00:00	13
3780	245	1960	2012-11-25 08:00:00	9
3799	244	1970	2012-11-25 13:00:00	13
3801	244	1971	2012-11-25 13:30:00	13
3805	244	1973	2012-11-25 14:30:00	13
3810	245	1975	2012-11-25 15:30:00	9
3814	245	1977	2012-11-25 16:30:00	9
3818	245	1979	2012-11-25 17:30:00	9
3826	245	1983	2012-11-25 19:30:00	9
3849	244	1995	2012-11-26 01:30:00	13
3876	245	2008	2012-11-26 08:00:00	9
3902	245	2021	2012-11-26 14:30:00	9
3905	244	2023	2012-11-26 15:30:00	13
3907	244	2024	2012-11-26 16:00:00	13
3918	245	2029	2012-11-26 18:30:00	9
3926	245	2033	2012-11-26 20:30:00	9
3971	244	2056	2012-11-27 08:00:00	13
3980	245	2060	2012-11-27 10:00:00	8
3984	245	2062	2012-11-27 11:00:00	8
3708	245	1924	2012-11-24 14:00:00	8
3712	245	1926	2012-11-24 15:00:00	8
3724	245	1932	2012-11-24 18:00:00	8
3728	245	1934	2012-11-24 19:00:00	8
3732	245	1936	2012-11-24 20:00:00	8
3739	244	1940	2012-11-24 22:00:00	12
3744	245	1942	2012-11-24 23:00:00	8
3747	244	1944	2012-11-25 00:00:00	12
3751	244	1946	2012-11-25 01:00:00	13
3755	244	1948	2012-11-25 02:00:00	13
3763	244	1952	2012-11-25 04:00:00	13
3767	244	1954	2012-11-25 05:00:00	13
3771	244	1956	2012-11-25 06:00:00	13
3783	244	1962	2012-11-25 09:00:00	13
3834	245	1987	2012-11-25 21:30:00	8
3838	245	1989	2012-11-25 22:30:00	9
3842	245	1991	2012-11-25 23:30:00	9
3853	244	1997	2012-11-26 02:30:00	13
3857	244	1999	2012-11-26 03:30:00	13
3862	245	2001	2012-11-26 04:30:00	9
3870	245	2005	2012-11-26 06:30:00	9
3880	245	2010	2012-11-26 09:00:00	9
3886	245	2013	2012-11-26 10:30:00	9
3915	244	2028	2012-11-26 18:00:00	12
3941	244	2041	2012-11-27 00:30:00	13
3944	245	2042	2012-11-27 01:00:00	9
3965	244	2053	2012-11-27 06:30:00	13
3979	244	2060	2012-11-27 10:00:00	13
3982	245	2061	2012-11-27 10:30:00	8
3987	244	2064	2012-11-27 12:00:00	13
3990	245	2065	2012-11-27 12:30:00	8
3714	245	1927	2012-11-24 15:30:00	8
3718	245	1929	2012-11-24 16:30:00	8
3722	245	1931	2012-11-24 17:30:00	8
3733	244	1937	2012-11-24 20:30:00	12
3737	244	1939	2012-11-24 21:30:00	12
3742	245	1941	2012-11-24 22:30:00	8
3750	245	1945	2012-11-25 00:30:00	8
3760	245	1950	2012-11-25 03:00:00	8
3766	245	1953	2012-11-25 04:30:00	8
3781	244	1961	2012-11-25 08:30:00	13
3785	244	1963	2012-11-25 09:30:00	13
3789	244	1965	2012-11-25 10:30:00	13
3793	244	1967	2012-11-25 11:30:00	13
3797	244	1969	2012-11-25 12:30:00	13
3816	245	1978	2012-11-25 17:00:00	9
3828	245	1984	2012-11-25 20:00:00	9
3832	245	1986	2012-11-25 21:00:00	9
3844	245	1992	2012-11-26 00:00:00	9
3848	245	1994	2012-11-26 01:00:00	9
3852	245	1996	2012-11-26 02:00:00	9
3859	244	2000	2012-11-26 04:00:00	13
3864	245	2002	2012-11-26 05:00:00	9
3867	244	2004	2012-11-26 06:00:00	13
3871	244	2006	2012-11-26 07:00:00	13
3875	244	2008	2012-11-26 08:00:00	13
3883	244	2012	2012-11-26 10:00:00	13
3887	244	2014	2012-11-26 11:00:00	13
3891	244	2016	2012-11-26 12:00:00	13
3893	244	2017	2012-11-26 12:30:00	13
3904	245	2022	2012-11-26 15:00:00	9
3906	245	2023	2012-11-26 15:30:00	9
3912	245	2026	2012-11-26 17:00:00	9
3927	244	2034	2012-11-26 21:00:00	13
3930	245	2035	2012-11-26 21:30:00	9
3945	244	2043	2012-11-27 01:30:00	13
3948	245	2044	2012-11-27 02:00:00	8
3958	245	2049	2012-11-27 04:30:00	8
3960	245	2050	2012-11-27 05:00:00	8
3961	244	2051	2012-11-27 05:30:00	13
3981	244	2061	2012-11-27 10:30:00	13
3992	245	2066	2012-11-27 13:00:00	8
3716	245	1928	2012-11-24 16:00:00	8
3735	244	1938	2012-11-24 21:00:00	12
3740	245	1940	2012-11-24 22:00:00	8
3759	244	1950	2012-11-25 03:00:00	13
3761	244	1951	2012-11-25 03:30:00	13
3765	244	1953	2012-11-25 04:30:00	13
3770	245	1955	2012-11-25 05:30:00	8
3774	245	1957	2012-11-25 06:30:00	8
3778	245	1959	2012-11-25 07:30:00	8
3786	245	1963	2012-11-25 09:30:00	9
3809	244	1975	2012-11-25 15:30:00	13
3836	245	1988	2012-11-25 22:00:00	9
3855	244	1998	2012-11-26 03:00:00	13
3860	245	2000	2012-11-26 04:00:00	9
3879	244	2010	2012-11-26 09:00:00	13
3881	244	2011	2012-11-26 09:30:00	13
3885	244	2013	2012-11-26 10:30:00	13
3890	245	2015	2012-11-26 11:30:00	9
3898	245	2019	2012-11-26 13:30:00	9
3903	244	2022	2012-11-26 15:00:00	13
3916	245	2028	2012-11-26 18:00:00	9
3920	245	2030	2012-11-26 19:00:00	9
3921	244	2031	2012-11-26 19:30:00	13
3925	244	2033	2012-11-26 20:30:00	13
3929	244	2035	2012-11-26 21:30:00	13
3931	244	2036	2012-11-26 22:00:00	13
3933	244	2037	2012-11-26 22:30:00	13
3937	244	2039	2012-11-26 23:30:00	13
3940	245	2040	2012-11-27 00:00:00	9
3947	244	2044	2012-11-27 02:00:00	13
3953	244	2047	2012-11-27 03:30:00	13
3956	245	2048	2012-11-27 04:00:00	8
3959	244	2050	2012-11-27 05:00:00	13
3964	245	2052	2012-11-27 06:00:00	8
3967	244	2054	2012-11-27 07:00:00	13
3719	244	1930	2012-11-24 17:00:00	12
3721	244	1931	2012-11-24 17:30:00	12
3725	244	1933	2012-11-24 18:30:00	12
3730	245	1935	2012-11-24 19:30:00	8
3734	245	1937	2012-11-24 20:30:00	8
3738	245	1939	2012-11-24 21:30:00	8
3746	245	1943	2012-11-24 23:30:00	8
3769	244	1955	2012-11-25 05:30:00	13
3796	245	1968	2012-11-25 12:00:00	9
3815	244	1978	2012-11-25 17:00:00	13
3820	245	1980	2012-11-25 18:00:00	9
3839	244	1990	2012-11-25 23:00:00	13
3841	244	1991	2012-11-25 23:30:00	13
3845	244	1993	2012-11-26 00:30:00	13
3850	245	1995	2012-11-26 01:30:00	9
3854	245	1997	2012-11-26 02:30:00	9
3858	245	1999	2012-11-26 03:30:00	9
3866	245	2003	2012-11-26 05:30:00	9
3889	244	2015	2012-11-26 11:30:00	13
3897	244	2019	2012-11-26 13:30:00	13
3908	245	2024	2012-11-26 16:00:00	9
3922	245	2031	2012-11-26 19:30:00	9
3938	245	2039	2012-11-26 23:30:00	9
3942	245	2041	2012-11-27 00:30:00	9
3950	245	2045	2012-11-27 02:30:00	8
3957	244	2049	2012-11-27 04:30:00	13
3969	244	2055	2012-11-27 07:30:00	13
3972	245	2056	2012-11-27 08:00:00	8
3973	244	2057	2012-11-27 08:30:00	13
3986	245	2063	2012-11-27 11:30:00	8
3988	245	2064	2012-11-27 12:00:00	8
3993	244	2067	2012-11-27 13:30:00	13
3994	245	2067	2012-11-27 13:30:00	8
3995	244	2068	2012-11-27 14:00:00	13
3996	245	2068	2012-11-27 14:00:00	8
3997	244	2069	2012-11-27 14:30:00	13
3998	245	2069	2012-11-27 14:30:00	8
3999	244	2070	2012-11-27 15:00:00	13
4000	245	2070	2012-11-27 15:00:00	8
4001	244	2071	2012-11-27 15:30:00	13
4002	245	2071	2012-11-27 15:30:00	8
4003	244	2072	2012-11-27 16:00:00	13
4004	245	2072	2012-11-27 16:00:00	8
4005	244	2073	2012-11-27 16:30:00	13
4006	245	2073	2012-11-27 16:30:00	8
4007	244	2074	2012-11-27 17:00:00	13
4008	245	2074	2012-11-27 17:00:00	8
4009	244	2075	2012-11-27 17:30:00	13
4010	245	2075	2012-11-27 17:30:00	8
4011	244	2076	2012-11-27 18:00:00	13
4012	245	2076	2012-11-27 18:00:00	8
4013	244	2077	2012-11-27 18:30:00	13
4014	245	2077	2012-11-27 18:30:00	8
4015	244	2078	2012-11-27 19:00:00	13
4016	245	2078	2012-11-27 19:00:00	8
4017	244	2079	2012-11-27 19:30:00	13
4018	245	2079	2012-11-27 19:30:00	8
4019	244	2080	2012-11-27 20:00:00	13
4020	245	2080	2012-11-27 20:00:00	8
4021	244	2081	2012-11-27 20:30:00	13
4022	245	2081	2012-11-27 20:30:00	8
4023	244	2082	2012-11-27 21:00:00	13
4024	245	2082	2012-11-27 21:00:00	8
4025	244	2083	2012-11-27 21:30:00	13
4026	245	2083	2012-11-27 21:30:00	8
4027	244	2084	2012-11-27 22:00:00	13
4028	245	2084	2012-11-27 22:00:00	8
4029	244	2085	2012-11-27 22:30:00	13
4030	245	2085	2012-11-27 22:30:00	8
4031	244	2086	2012-11-27 23:00:00	13
4032	245	2086	2012-11-27 23:00:00	8
4033	244	2087	2012-11-27 23:30:00	13
4034	245	2087	2012-11-27 23:30:00	8
4035	244	2088	2012-11-28 00:00:00	13
4036	245	2088	2012-11-28 00:00:00	8
4037	244	2089	2012-11-28 00:30:00	13
4038	245	2089	2012-11-28 00:30:00	8
4039	244	2090	2012-11-28 01:00:00	13
4040	245	2090	2012-11-28 01:00:00	8
4041	244	2091	2012-11-28 01:30:00	13
4042	245	2091	2012-11-28 01:30:00	8
4043	244	2092	2012-11-28 02:00:00	13
4044	245	2092	2012-11-28 02:00:00	8
4045	244	2093	2012-11-28 02:30:00	13
4046	245	2093	2012-11-28 02:30:00	8
4047	244	2094	2012-11-28 03:00:00	13
4048	245	2094	2012-11-28 03:00:00	8
4049	244	2095	2012-11-28 03:30:00	13
4050	245	2095	2012-11-28 03:30:00	8
4051	244	2096	2012-11-28 04:00:00	13
4052	245	2096	2012-11-28 04:00:00	8
4053	244	2097	2012-11-28 04:30:00	13
4054	245	2097	2012-11-28 04:30:00	8
4055	244	2098	2012-11-28 05:00:00	13
4056	245	2098	2012-11-28 05:00:00	8
4057	244	2099	2012-11-28 05:30:00	13
4058	245	2099	2012-11-28 05:30:00	8
4059	244	2100	2012-11-28 06:00:00	13
4060	245	2100	2012-11-28 06:00:00	8
4061	244	2101	2012-11-28 06:30:00	13
4062	245	2101	2012-11-28 06:30:00	8
4063	244	2102	2012-11-28 07:00:00	13
4064	245	2102	2012-11-28 07:00:00	8
4065	244	2103	2012-11-28 07:30:00	13
4066	245	2103	2012-11-28 07:30:00	8
4067	244	2104	2012-11-28 08:00:00	13
4068	245	2104	2012-11-28 08:00:00	8
4069	244	2105	2012-11-28 08:30:00	13
4070	245	2105	2012-11-28 08:30:00	8
4071	244	2106	2012-11-28 09:00:00	13
4072	245	2106	2012-11-28 09:00:00	8
4073	244	2107	2012-11-28 09:30:00	13
4074	245	2107	2012-11-28 09:30:00	8
4075	244	2108	2012-11-28 10:00:00	13
4076	245	2108	2012-11-28 10:00:00	8
4077	244	2109	2012-11-28 10:30:00	13
4078	245	2109	2012-11-28 10:30:00	8
4079	244	2110	2012-11-28 11:00:00	13
4080	245	2110	2012-11-28 11:00:00	8
4081	244	2111	2012-11-28 11:30:00	13
4082	245	2111	2012-11-28 11:30:00	8
4097	244	2119	2012-11-28 15:30:00	13
4099	244	2120	2012-11-28 16:00:00	13
4112	245	2126	2012-11-28 19:00:00	8
4115	244	2128	2012-11-28 20:00:00	13
4118	245	2129	2012-11-28 20:30:00	8
4130	245	2135	2012-11-28 23:30:00	8
4135	244	2138	2012-11-29 01:00:00	11
4150	245	2145	2012-11-29 04:30:00	8
4155	244	2148	2012-11-29 06:00:00	10
4159	244	2150	2012-11-29 07:00:00	10
4172	245	2156	2012-11-29 10:00:00	8
4173	244	2157	2012-11-29 10:30:00	10
4181	244	2161	2012-11-29 12:30:00	10
4193	244	2167	2012-11-29 15:30:00	10
4210	245	2175	2012-11-29 19:30:00	8
4083	244	2112	2012-11-28 12:00:00	13
4087	244	2114	2012-11-28 13:00:00	13
4104	245	2122	2012-11-28 17:00:00	8
4106	245	2123	2012-11-28 17:30:00	8
4108	245	2124	2012-11-28 18:00:00	8
4121	244	2131	2012-11-28 21:30:00	13
4129	244	2135	2012-11-28 23:30:00	12
4132	245	2136	2012-11-29 00:00:00	8
4133	244	2137	2012-11-29 00:30:00	11
4138	245	2139	2012-11-29 01:30:00	8
4149	244	2145	2012-11-29 04:30:00	10
4163	244	2152	2012-11-29 08:00:00	10
4166	245	2153	2012-11-29 08:30:00	8
4176	245	2158	2012-11-29 11:00:00	8
4186	245	2163	2012-11-29 13:30:00	8
4188	245	2164	2012-11-29 14:00:00	8
4203	244	2172	2012-11-29 18:00:00	8
4212	245	2176	2012-11-29 20:00:00	8
4084	245	2112	2012-11-28 12:00:00	8
4092	245	2116	2012-11-28 14:00:00	8
4095	244	2118	2012-11-28 15:00:00	13
4101	244	2121	2012-11-28 16:30:00	13
4111	244	2126	2012-11-28 19:00:00	13
4120	245	2130	2012-11-28 21:00:00	8
4128	245	2134	2012-11-28 23:00:00	8
4139	244	2140	2012-11-29 02:00:00	10
4146	245	2143	2012-11-29 03:30:00	8
4148	245	2144	2012-11-29 04:00:00	8
4154	245	2147	2012-11-29 05:30:00	8
4167	244	2154	2012-11-29 09:00:00	10
4183	244	2162	2012-11-29 13:00:00	10
4199	244	2170	2012-11-29 17:00:00	8
4206	245	2173	2012-11-29 18:30:00	8
4085	244	2113	2012-11-28 12:30:00	13
4102	245	2121	2012-11-28 16:30:00	8
4105	244	2123	2012-11-28 17:30:00	13
4114	245	2127	2012-11-28 19:30:00	8
4116	245	2128	2012-11-28 20:00:00	8
4122	245	2131	2012-11-28 21:30:00	8
4127	244	2134	2012-11-28 23:00:00	13
4153	244	2147	2012-11-29 05:30:00	10
4169	244	2155	2012-11-29 09:30:00	10
4180	245	2160	2012-11-29 12:00:00	8
4184	245	2162	2012-11-29 13:00:00	8
4195	244	2168	2012-11-29 16:00:00	9
4204	245	2172	2012-11-29 18:00:00	8
4086	245	2113	2012-11-28 12:30:00	8
4098	245	2119	2012-11-28 15:30:00	8
4107	244	2124	2012-11-28 18:00:00	13
4119	244	2130	2012-11-28 21:00:00	13
4125	244	2133	2012-11-28 22:30:00	13
4140	245	2140	2012-11-29 02:00:00	8
4144	245	2142	2012-11-29 03:00:00	8
4152	245	2146	2012-11-29 05:00:00	8
4158	245	2149	2012-11-29 06:30:00	8
4178	245	2159	2012-11-29 11:30:00	8
4197	244	2169	2012-11-29 16:30:00	9
4207	244	2174	2012-11-29 19:00:00	8
4088	245	2114	2012-11-28 13:00:00	8
4093	244	2117	2012-11-28 14:30:00	13
4100	245	2120	2012-11-28 16:00:00	8
4126	245	2133	2012-11-28 22:30:00	8
4136	245	2138	2012-11-29 01:00:00	8
4141	244	2141	2012-11-29 02:30:00	10
4156	245	2148	2012-11-29 06:00:00	8
4171	244	2156	2012-11-29 10:00:00	10
4174	245	2157	2012-11-29 10:30:00	8
4185	244	2163	2012-11-29 13:30:00	10
4198	245	2169	2012-11-29 16:30:00	8
4209	244	2175	2012-11-29 19:30:00	8
4089	244	2115	2012-11-28 13:30:00	13
4113	244	2127	2012-11-28 19:30:00	13
4123	244	2132	2012-11-28 22:00:00	13
4131	244	2136	2012-11-29 00:00:00	12
4134	245	2137	2012-11-29 00:30:00	8
4143	244	2142	2012-11-29 03:00:00	10
4157	244	2149	2012-11-29 06:30:00	10
4160	245	2150	2012-11-29 07:00:00	8
4161	244	2151	2012-11-29 07:30:00	10
4164	245	2152	2012-11-29 08:00:00	8
4177	244	2159	2012-11-29 11:30:00	10
4179	244	2160	2012-11-29 12:00:00	10
4182	245	2161	2012-11-29 12:30:00	8
4187	244	2164	2012-11-29 14:00:00	10
4190	245	2165	2012-11-29 14:30:00	8
4196	245	2168	2012-11-29 16:00:00	8
4200	245	2170	2012-11-29 17:00:00	8
4202	245	2171	2012-11-29 17:30:00	8
4205	244	2173	2012-11-29 18:30:00	8
4090	245	2115	2012-11-28 13:30:00	8
4096	245	2118	2012-11-28 15:00:00	8
4103	244	2122	2012-11-28 17:00:00	13
4110	245	2125	2012-11-28 18:30:00	8
4117	244	2129	2012-11-28 20:30:00	13
4124	245	2132	2012-11-28 22:00:00	8
4145	244	2143	2012-11-29 03:30:00	10
4147	244	2144	2012-11-29 04:00:00	10
4170	245	2155	2012-11-29 09:30:00	8
4175	244	2158	2012-11-29 11:00:00	10
4189	244	2165	2012-11-29 14:30:00	10
4191	244	2166	2012-11-29 15:00:00	10
4194	245	2167	2012-11-29 15:30:00	8
4208	245	2174	2012-11-29 19:00:00	8
4091	244	2116	2012-11-28 14:00:00	13
4094	245	2117	2012-11-28 14:30:00	8
4109	244	2125	2012-11-28 18:30:00	13
4137	244	2139	2012-11-29 01:30:00	10
4142	245	2141	2012-11-29 02:30:00	8
4151	244	2146	2012-11-29 05:00:00	10
4162	245	2151	2012-11-29 07:30:00	8
4165	244	2153	2012-11-29 08:30:00	10
4168	245	2154	2012-11-29 09:00:00	8
4192	245	2166	2012-11-29 15:00:00	8
4201	244	2171	2012-11-29 17:30:00	8
4211	244	2176	2012-11-29 20:00:00	8
4213	244	2177	2012-11-29 20:30:00	8
4214	245	2177	2012-11-29 20:30:00	8
4215	244	2178	2012-11-29 21:00:00	9
4216	245	2178	2012-11-29 21:00:00	8
4217	244	2179	2012-11-29 21:30:00	9
4218	245	2179	2012-11-29 21:30:00	8
4219	244	2180	2012-11-29 22:00:00	9
4220	245	2180	2012-11-29 22:00:00	8
4221	244	2181	2012-11-29 22:30:00	9
4222	245	2181	2012-11-29 22:30:00	8
4223	244	2182	2012-11-29 23:00:00	9
4224	245	2182	2012-11-29 23:00:00	8
4225	244	2183	2012-11-29 23:30:00	8
4226	245	2183	2012-11-29 23:30:00	8
4227	244	2184	2012-11-30 00:00:00	8
4228	245	2184	2012-11-30 00:00:00	8
4229	244	2185	2012-11-30 00:30:00	8
4230	245	2185	2012-11-30 00:30:00	8
4231	244	2186	2012-11-30 01:00:00	8
4232	245	2186	2012-11-30 01:00:00	8
4233	244	2187	2012-11-30 01:30:00	8
4234	245	2187	2012-11-30 01:30:00	8
4235	244	2188	2012-11-30 02:00:00	8
4236	245	2188	2012-11-30 02:00:00	8
4237	244	2189	2012-11-30 02:30:00	8
4238	245	2189	2012-11-30 02:30:00	8
4239	244	2190	2012-11-30 03:00:00	8
4240	245	2190	2012-11-30 03:00:00	8
4241	244	2191	2012-11-30 03:30:00	8
4242	245	2191	2012-11-30 03:30:00	8
4243	244	2192	2012-11-30 04:00:00	8
4244	245	2192	2012-11-30 04:00:00	8
4245	244	2193	2012-11-30 04:30:00	8
4246	245	2193	2012-11-30 04:30:00	8
4247	244	2194	2012-11-30 05:00:00	8
4248	245	2194	2012-11-30 05:00:00	8
4249	244	2195	2012-11-30 05:30:00	8
4250	245	2195	2012-11-30 05:30:00	8
4251	244	2196	2012-11-30 06:00:00	8
4252	245	2196	2012-11-30 06:00:00	8
4281	244	2221	2012-11-30 06:30:00	8
4282	245	2221	2012-11-30 06:30:00	8
4283	244	2222	2012-11-30 07:00:00	8
4284	245	2222	2012-11-30 07:00:00	8
4301	244	2241	2012-11-30 07:30:00	8
4302	245	2241	2012-11-30 07:30:00	8
4303	244	2242	2012-11-30 08:00:00	8
4304	245	2242	2012-11-30 08:00:00	8
4305	244	2243	2012-11-30 08:30:00	8
4306	245	2243	2012-11-30 08:30:00	8
4307	244	2244	2012-11-30 09:00:00	8
4308	245	2244	2012-11-30 09:00:00	8
4309	244	2245	2012-11-30 09:30:00	8
4310	245	2245	2012-11-30 09:30:00	8
4311	244	2246	2012-11-30 10:00:00	8
4312	245	2246	2012-11-30 10:00:00	8
4313	244	2247	2012-11-30 10:30:00	8
4314	245	2247	2012-11-30 10:30:00	8
4315	244	2248	2012-11-30 11:00:00	8
4316	245	2248	2012-11-30 11:00:00	8
4317	244	2249	2012-11-30 11:30:00	8
4318	245	2249	2012-11-30 11:30:00	8
4319	244	2250	2012-11-30 12:00:00	8
4320	245	2250	2012-11-30 12:00:00	8
4321	244	2251	2012-11-30 12:30:00	8
4322	245	2251	2012-11-30 12:30:00	8
4323	244	2252	2012-11-30 13:00:00	8
4324	245	2252	2012-11-30 13:00:00	8
4325	244	2253	2012-11-30 13:30:00	8
4326	245	2253	2012-11-30 13:30:00	8
4327	244	2254	2012-11-30 14:00:00	8
4328	245	2254	2012-11-30 14:00:00	8
4329	244	2255	2012-11-30 14:30:00	8
4330	245	2255	2012-11-30 14:30:00	8
4331	244	2256	2012-11-30 15:00:00	8
4332	245	2256	2012-11-30 15:00:00	8
4333	244	2257	2012-11-30 15:30:00	8
4334	245	2257	2012-11-30 15:30:00	8
4335	244	2258	2012-11-30 16:00:00	8
4336	245	2258	2012-11-30 16:00:00	8
4337	244	2259	2012-11-30 16:30:00	8
4338	245	2259	2012-11-30 16:30:00	8
4339	244	2260	2012-11-30 17:00:00	8
4340	245	2260	2012-11-30 17:00:00	8
4341	244	2261	2012-11-30 17:30:00	8
4342	245	2261	2012-11-30 17:30:00	8
4343	244	2262	2012-11-30 18:00:00	8
4344	245	2262	2012-11-30 18:00:00	8
4345	244	2263	2012-11-30 18:30:00	8
4346	245	2263	2012-11-30 18:30:00	8
4347	244	2264	2012-11-30 19:00:00	8
4348	245	2264	2012-11-30 19:00:00	8
4361	244	2281	2012-11-30 19:30:00	8
4362	245	2281	2012-11-30 19:30:00	8
4363	244	2282	2012-11-30 20:00:00	8
4364	245	2282	2012-11-30 20:00:00	8
4381	244	2301	2012-11-30 20:30:00	8
4382	245	2301	2012-11-30 20:30:00	7
4383	244	2302	2012-11-30 21:00:00	8
4384	245	2302	2012-11-30 21:00:00	8
4385	244	2303	2012-11-30 21:30:00	8
4386	245	2303	2012-11-30 21:30:00	8
4387	244	2304	2012-11-30 22:00:00	8
4388	245	2304	2012-11-30 22:00:00	8
4401	244	2321	2012-11-30 22:30:00	8
4402	245	2321	2012-11-30 22:30:00	8
4403	244	2322	2012-11-30 23:00:00	8
4404	245	2322	2012-11-30 23:00:00	8
\.


--
-- Data for Name: s_data_pressures; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_pressures (id, sensor_id, sensor_data_id, date_time, pressure_pascal, pressure_bar) FROM stdin;
1581	247	1801	2012-11-22 00:30:00	\N	1023.5
1582	247	1802	2012-11-22 01:00:00	\N	1023.5
1583	247	1803	2012-11-22 01:30:00	\N	1023.7
1584	247	1804	2012-11-22 02:00:00	\N	1024
1585	247	1805	2012-11-22 02:30:00	\N	1024
1586	247	1806	2012-11-22 03:00:00	\N	1023.9
1587	247	1807	2012-11-22 03:30:00	\N	1023.9
1588	247	1808	2012-11-22 04:00:00	\N	1023.9
1589	247	1809	2012-11-22 04:30:00	\N	1024
1590	247	1810	2012-11-22 05:00:00	\N	1024.0999999999999
1591	247	1811	2012-11-22 05:30:00	\N	1024.5
1592	247	1812	2012-11-22 06:00:00	\N	1024.7
1593	247	1813	2012-11-22 06:30:00	\N	1024.8
1594	247	1814	2012-11-22 07:00:00	\N	1025.2
1595	247	1815	2012-11-22 07:30:00	\N	1025.5
1596	247	1816	2012-11-22 08:00:00	\N	1025.8
1597	247	1817	2012-11-22 08:30:00	\N	1026
1598	247	1818	2012-11-22 09:00:00	\N	1026.2
1599	247	1819	2012-11-22 09:30:00	\N	1026.5
1600	247	1820	2012-11-22 10:00:00	\N	1026.7
1601	247	1821	2012-11-22 10:30:00	\N	1026.8
1602	247	1822	2012-11-22 11:00:00	\N	1026.5999999999999
1603	247	1823	2012-11-22 11:30:00	\N	1026.3
1604	247	1824	2012-11-22 12:00:00	\N	1026.2
1605	247	1825	2012-11-22 12:30:00	\N	1026.0999999999999
1606	247	1826	2012-11-22 13:00:00	\N	1026
1607	247	1827	2012-11-22 13:30:00	\N	1025.8
1608	247	1828	2012-11-22 14:00:00	\N	1025.7
1609	247	1829	2012-11-22 14:30:00	\N	1025.5999999999999
1610	247	1830	2012-11-22 15:00:00	\N	1025.7
1611	247	1831	2012-11-22 15:30:00	\N	1025.8
1612	247	1832	2012-11-22 16:00:00	\N	1026
1613	247	1833	2012-11-22 16:30:00	\N	1026.0999999999999
1614	247	1834	2012-11-22 17:00:00	\N	1026.2
1615	247	1835	2012-11-22 17:30:00	\N	1026.0999999999999
1616	247	1836	2012-11-22 18:00:00	\N	1026.0999999999999
1617	247	1837	2012-11-22 18:30:00	\N	1026
1618	247	1838	2012-11-22 19:00:00	\N	1026.0999999999999
1619	247	1839	2012-11-22 19:30:00	\N	1025.9000000000001
1620	247	1840	2012-11-22 20:00:00	\N	1026
1621	247	1841	2012-11-22 20:30:00	\N	1026.0999999999999
1622	247	1842	2012-11-22 21:00:00	\N	1026.0999999999999
1623	247	1843	2012-11-22 21:30:00	\N	1025.9000000000001
1624	247	1844	2012-11-22 22:00:00	\N	1025.8
1625	247	1845	2012-11-22 22:30:00	\N	1025.8
1626	247	1846	2012-11-22 23:00:00	\N	1025.5999999999999
1627	247	1847	2012-11-22 23:30:00	\N	1025.5
1628	247	1848	2012-11-23 00:00:00	\N	1025.4000000000001
1629	247	1849	2012-11-23 00:30:00	\N	1025.2
1630	247	1850	2012-11-23 01:00:00	\N	1025
1631	247	1851	2012-11-23 01:30:00	\N	1025
1632	247	1852	2012-11-23 02:00:00	\N	1025.0999999999999
1633	247	1853	2012-11-23 02:30:00	\N	1024.9000000000001
1634	247	1854	2012-11-23 03:00:00	\N	1024.7
1635	247	1855	2012-11-23 03:30:00	\N	1024.4000000000001
1636	247	1856	2012-11-23 04:00:00	\N	1024.3
1637	247	1857	2012-11-23 04:30:00	\N	1024.0999999999999
1638	247	1858	2012-11-23 05:00:00	\N	1024
1639	247	1859	2012-11-23 05:30:00	\N	1023.9
1640	247	1860	2012-11-23 06:00:00	\N	1023.9
1641	247	1861	2012-11-23 06:30:00	\N	1024.0999999999999
1642	247	1862	2012-11-23 07:00:00	\N	1024.0999999999999
1643	247	1863	2012-11-23 07:30:00	\N	1024.4000000000001
1644	247	1864	2012-11-23 08:00:00	\N	1024.3
1645	247	1865	2012-11-23 08:30:00	\N	1024.4000000000001
1646	247	1866	2012-11-23 09:00:00	\N	1024.4000000000001
1647	247	1867	2012-11-23 09:30:00	\N	1024.5
1648	247	1868	2012-11-23 10:00:00	\N	1024.5
1649	247	1869	2012-11-23 10:30:00	\N	1024.7
1650	247	1870	2012-11-23 11:00:00	\N	1024.4000000000001
1651	247	1871	2012-11-23 11:30:00	\N	1024.2
1652	247	1872	2012-11-23 12:00:00	\N	1023.9
1653	247	1873	2012-11-23 12:30:00	\N	1023.6
1654	247	1874	2012-11-23 13:00:00	\N	1023.3
1655	247	1875	2012-11-23 13:30:00	\N	1023.4
1656	247	1876	2012-11-23 14:00:00	\N	1023.3
1657	247	1877	2012-11-23 14:30:00	\N	1023.3
1658	247	1878	2012-11-23 15:00:00	\N	1023.6
1659	247	1879	2012-11-23 15:30:00	\N	1023.8
1660	247	1880	2012-11-23 16:00:00	\N	1023.8
1661	247	1881	2012-11-23 16:30:00	\N	1023.7
1662	247	1882	2012-11-23 17:00:00	\N	1023.9
1663	247	1883	2012-11-23 17:30:00	\N	1024.2
1664	247	1884	2012-11-23 18:00:00	\N	1024.3
1665	247	1885	2012-11-23 18:30:00	\N	1024.5
1666	247	1886	2012-11-23 19:00:00	\N	1024.5999999999999
1667	247	1887	2012-11-23 19:30:00	\N	1024.8
1668	247	1888	2012-11-23 20:00:00	\N	1024.9000000000001
1669	247	1889	2012-11-23 20:30:00	\N	1025.2
1670	247	1890	2012-11-23 21:00:00	\N	1025.3
1671	247	1891	2012-11-23 21:30:00	\N	1025.3
1672	247	1892	2012-11-23 22:00:00	\N	1025.2
1673	247	1893	2012-11-23 22:30:00	\N	1025.3
1674	247	1894	2012-11-23 23:00:00	\N	1025.5
1675	247	1895	2012-11-23 23:30:00	\N	1025.4000000000001
1676	247	1896	2012-11-24 00:00:00	\N	1025.0999999999999
1677	247	1897	2012-11-24 00:30:00	\N	1025.2
1678	247	1898	2012-11-24 01:00:00	\N	1025.3
1679	247	1899	2012-11-24 01:30:00	\N	1025.3
1680	247	1900	2012-11-24 02:00:00	\N	1025.3
1681	247	1901	2012-11-24 02:30:00	\N	1025.0999999999999
1682	247	1902	2012-11-24 03:00:00	\N	1025
1683	247	1903	2012-11-24 03:30:00	\N	1024.8
1684	247	1904	2012-11-24 04:00:00	\N	1024.8
1685	247	1905	2012-11-24 04:30:00	\N	1024.9000000000001
1686	247	1906	2012-11-24 05:00:00	\N	1024.9000000000001
1687	247	1907	2012-11-24 05:30:00	\N	1024.9000000000001
1688	247	1908	2012-11-24 06:00:00	\N	1025
1689	247	1909	2012-11-24 06:30:00	\N	1024.9000000000001
1690	247	1910	2012-11-24 07:00:00	\N	1025
1691	247	1911	2012-11-24 07:30:00	\N	1025.2
1692	247	1912	2012-11-24 08:00:00	\N	1025.3
1693	247	1913	2012-11-24 08:30:00	\N	1025.5
1694	247	1914	2012-11-24 09:00:00	\N	1025.4000000000001
1695	247	1915	2012-11-24 09:30:00	\N	1025.5999999999999
1696	247	1916	2012-11-24 10:00:00	\N	1025.5
1697	247	1917	2012-11-24 10:30:00	\N	1025.5
1698	247	1918	2012-11-24 11:00:00	\N	1025.2
1699	247	1919	2012-11-24 11:30:00	\N	1025
1700	247	1920	2012-11-24 12:00:00	\N	1025
1701	247	1921	2012-11-24 12:30:00	\N	1024.8
1702	247	1922	2012-11-24 13:00:00	\N	1024.4000000000001
1703	247	1923	2012-11-24 13:30:00	\N	1024.4000000000001
1704	247	1924	2012-11-24 14:00:00	\N	1024.3
1705	247	1925	2012-11-24 14:30:00	\N	1024.3
1706	247	1926	2012-11-24 15:00:00	\N	1024
1707	247	1927	2012-11-24 15:30:00	\N	1024
1708	247	1928	2012-11-24 16:00:00	\N	1024.0999999999999
1709	247	1929	2012-11-24 16:30:00	\N	1024.0999999999999
1710	247	1930	2012-11-24 17:00:00	\N	1024
1711	247	1931	2012-11-24 17:30:00	\N	1024.0999999999999
1712	247	1932	2012-11-24 18:00:00	\N	1024.0999999999999
1713	247	1933	2012-11-24 18:30:00	\N	1024.2
1714	247	1934	2012-11-24 19:00:00	\N	1024.3
1715	247	1935	2012-11-24 19:30:00	\N	1024.0999999999999
1716	247	1936	2012-11-24 20:00:00	\N	1023.9
1717	247	1937	2012-11-24 20:30:00	\N	1024
1718	247	1938	2012-11-24 21:00:00	\N	1023.9
1719	247	1939	2012-11-24 21:30:00	\N	1023.9
1720	247	1940	2012-11-24 22:00:00	\N	1023.6
1721	247	1941	2012-11-24 22:30:00	\N	1023.5
1722	247	1942	2012-11-24 23:00:00	\N	1023.4
1723	247	1943	2012-11-24 23:30:00	\N	1023.4
1724	247	1944	2012-11-25 00:00:00	\N	1023.2
1725	247	1945	2012-11-25 00:30:00	\N	1023.1
1726	247	1946	2012-11-25 01:00:00	\N	1022.9
1727	247	1947	2012-11-25 01:30:00	\N	1022.7
1728	247	1948	2012-11-25 02:00:00	\N	1022.8
1729	247	1949	2012-11-25 02:30:00	\N	1022.6
1730	247	1950	2012-11-25 03:00:00	\N	1022.4
1731	247	1951	2012-11-25 03:30:00	\N	1021.8
1732	247	1952	2012-11-25 04:00:00	\N	1021.7
1733	247	1953	2012-11-25 04:30:00	\N	1021.6
1734	247	1954	2012-11-25 05:00:00	\N	1021.5
1735	247	1955	2012-11-25 05:30:00	\N	1021.3
1736	247	1956	2012-11-25 06:00:00	\N	1021.7
1737	247	1957	2012-11-25 06:30:00	\N	1021.6
1738	247	1958	2012-11-25 07:00:00	\N	1021.6
1739	247	1959	2012-11-25 07:30:00	\N	1021.9
1740	247	1960	2012-11-25 08:00:00	\N	1021.9
1741	247	1961	2012-11-25 08:30:00	\N	1022
1742	247	1962	2012-11-25 09:00:00	\N	1022.1
1743	247	1963	2012-11-25 09:30:00	\N	1022.3
1744	247	1964	2012-11-25 10:00:00	\N	1022.4
1745	247	1965	2012-11-25 10:30:00	\N	1022.3
1746	247	1966	2012-11-25 11:00:00	\N	1021.7
1747	247	1967	2012-11-25 11:30:00	\N	1021.5
1748	247	1968	2012-11-25 12:00:00	\N	1021.2
1749	247	1969	2012-11-25 12:30:00	\N	1021.1
1750	247	1970	2012-11-25 13:00:00	\N	1020.9
1751	247	1971	2012-11-25 13:30:00	\N	1020.7
1752	247	1972	2012-11-25 14:00:00	\N	1020.7
1753	247	1973	2012-11-25 14:30:00	\N	1020.7
1754	247	1974	2012-11-25 15:00:00	\N	1020.7
1755	247	1975	2012-11-25 15:30:00	\N	1020.9
1756	247	1976	2012-11-25 16:00:00	\N	1020.8
1757	247	1977	2012-11-25 16:30:00	\N	1020.9
1758	247	1978	2012-11-25 17:00:00	\N	1021
1759	247	1979	2012-11-25 17:30:00	\N	1020.9
1760	247	1980	2012-11-25 18:00:00	\N	1021
1761	247	1981	2012-11-25 18:30:00	\N	1020.9
1762	247	1982	2012-11-25 19:00:00	\N	1021.1
1763	247	1983	2012-11-25 19:30:00	\N	1021.3
1764	247	1984	2012-11-25 20:00:00	\N	1021.3
1765	247	1985	2012-11-25 20:30:00	\N	1021.3
1766	247	1986	2012-11-25 21:00:00	\N	1021.2
1767	247	1987	2012-11-25 21:30:00	\N	1021
1768	247	1988	2012-11-25 22:00:00	\N	1021
1769	247	1989	2012-11-25 22:30:00	\N	1021
1770	247	1990	2012-11-25 23:00:00	\N	1021
1771	247	1991	2012-11-25 23:30:00	\N	1021.1
1772	247	1992	2012-11-26 00:00:00	\N	1021.1
1773	247	1993	2012-11-26 00:30:00	\N	1020.8
1774	247	1994	2012-11-26 01:00:00	\N	1020.7
1775	247	1995	2012-11-26 01:30:00	\N	1020.7
1776	247	1996	2012-11-26 02:00:00	\N	1020.5
1777	247	1997	2012-11-26 02:30:00	\N	1020.4
1778	247	1998	2012-11-26 03:00:00	\N	1020.1
1779	247	1999	2012-11-26 03:30:00	\N	1020
1780	247	2000	2012-11-26 04:00:00	\N	1019.7
1781	247	2001	2012-11-26 04:30:00	\N	1019.8
1782	247	2002	2012-11-26 05:00:00	\N	1019.8
1783	247	2003	2012-11-26 05:30:00	\N	1019.7
1784	247	2004	2012-11-26 06:00:00	\N	1019.4
1785	247	2005	2012-11-26 06:30:00	\N	1019.4
1786	247	2006	2012-11-26 07:00:00	\N	1019.4
1787	247	2007	2012-11-26 07:30:00	\N	1019.4
1788	247	2008	2012-11-26 08:00:00	\N	1019.3
1789	247	2009	2012-11-26 08:30:00	\N	1019.3
1790	247	2010	2012-11-26 09:00:00	\N	1019
1791	247	2011	2012-11-26 09:30:00	\N	1019
1792	247	2012	2012-11-26 10:00:00	\N	1018.9
1793	247	2013	2012-11-26 10:30:00	\N	1018.6
1794	247	2014	2012-11-26 11:00:00	\N	1018
1795	247	2015	2012-11-26 11:30:00	\N	1017.4
1796	247	2016	2012-11-26 12:00:00	\N	1017.1
1797	247	2017	2012-11-26 12:30:00	\N	1016.9
1798	247	2018	2012-11-26 13:00:00	\N	1016.5
1799	247	2019	2012-11-26 13:30:00	\N	1016.3
1800	247	2020	2012-11-26 14:00:00	\N	1016
1801	247	2021	2012-11-26 14:30:00	\N	1015.8
1802	247	2022	2012-11-26 15:00:00	\N	1015.5
1803	247	2023	2012-11-26 15:30:00	\N	1015.3
1804	247	2024	2012-11-26 16:00:00	\N	1015.2
1805	247	2025	2012-11-26 16:30:00	\N	1015
1806	247	2026	2012-11-26 17:00:00	\N	1015
1807	247	2027	2012-11-26 17:30:00	\N	1015
1808	247	2028	2012-11-26 18:00:00	\N	1015.1
1809	247	2029	2012-11-26 18:30:00	\N	1015
1810	247	2030	2012-11-26 19:00:00	\N	1015
1811	247	2031	2012-11-26 19:30:00	\N	1014.9
1812	247	2032	2012-11-26 20:00:00	\N	1014.7
1813	247	2033	2012-11-26 20:30:00	\N	1014.6
1814	247	2034	2012-11-26 21:00:00	\N	1014.5
1815	247	2035	2012-11-26 21:30:00	\N	1014.5
1816	247	2036	2012-11-26 22:00:00	\N	1014.1
1817	247	2037	2012-11-26 22:30:00	\N	1014
1818	247	2038	2012-11-26 23:00:00	\N	1013.9
1819	247	2039	2012-11-26 23:30:00	\N	1014
1820	247	2040	2012-11-27 00:00:00	\N	1013.8
1821	247	2041	2012-11-27 00:30:00	\N	1013.4
1833	247	2053	2012-11-27 06:30:00	\N	1011.4
1836	247	2056	2012-11-27 08:00:00	\N	1011.6
1837	247	2057	2012-11-27 08:30:00	\N	1011.7
1838	247	2058	2012-11-27 09:00:00	\N	1011.9
1843	247	2063	2012-11-27 11:30:00	\N	1011.5
1846	247	2066	2012-11-27 13:00:00	\N	1010.6
1822	247	2042	2012-11-27 01:00:00	\N	1013.1
1823	247	2043	2012-11-27 01:30:00	\N	1012.7
1824	247	2044	2012-11-27 02:00:00	\N	1012.5
1839	247	2059	2012-11-27 09:30:00	\N	1012.1
1844	247	2064	2012-11-27 12:00:00	\N	1011.1
1825	247	2045	2012-11-27 02:30:00	\N	1012.2
1829	247	2049	2012-11-27 04:30:00	\N	1011.7
1842	247	2062	2012-11-27 11:00:00	\N	1011.9
1826	247	2046	2012-11-27 03:00:00	\N	1011.7
1832	247	2052	2012-11-27 06:00:00	\N	1011.5
1840	247	2060	2012-11-27 10:00:00	\N	1012.1
1827	247	2047	2012-11-27 03:30:00	\N	1011.8
1828	247	2048	2012-11-27 04:00:00	\N	1011.7
1835	247	2055	2012-11-27 07:30:00	\N	1011.4
1830	247	2050	2012-11-27 05:00:00	\N	1011.5
1831	247	2051	2012-11-27 05:30:00	\N	1011.4
1845	247	2065	2012-11-27 12:30:00	\N	1011
1834	247	2054	2012-11-27 07:00:00	\N	1011.5
1841	247	2061	2012-11-27 10:30:00	\N	1012.2
1847	247	2067	2012-11-27 13:30:00	\N	1010.5
1848	247	2068	2012-11-27 14:00:00	\N	1010.4
1849	247	2069	2012-11-27 14:30:00	\N	1010.1
1850	247	2070	2012-11-27 15:00:00	\N	1010
1851	247	2071	2012-11-27 15:30:00	\N	1009.9
1852	247	2072	2012-11-27 16:00:00	\N	1009.9
1853	247	2073	2012-11-27 16:30:00	\N	1009.8
1854	247	2074	2012-11-27 17:00:00	\N	1009.9
1855	247	2075	2012-11-27 17:30:00	\N	1009.8
1856	247	2076	2012-11-27 18:00:00	\N	1009.4
1857	247	2077	2012-11-27 18:30:00	\N	1009
1858	247	2078	2012-11-27 19:00:00	\N	1009.2
1859	247	2079	2012-11-27 19:30:00	\N	1009
1860	247	2080	2012-11-27 20:00:00	\N	1008.9
1861	247	2081	2012-11-27 20:30:00	\N	1008.9
1862	247	2082	2012-11-27 21:00:00	\N	1008.6
1863	247	2083	2012-11-27 21:30:00	\N	1008.4
1864	247	2084	2012-11-27 22:00:00	\N	1008.4
1865	247	2085	2012-11-27 22:30:00	\N	1008.2
1866	247	2086	2012-11-27 23:00:00	\N	1008.2
1867	247	2087	2012-11-27 23:30:00	\N	1008.1
1868	247	2088	2012-11-28 00:00:00	\N	1008
1869	247	2089	2012-11-28 00:30:00	\N	1007.8
1870	247	2090	2012-11-28 01:00:00	\N	1007.5
1871	247	2091	2012-11-28 01:30:00	\N	1007.3
1872	247	2092	2012-11-28 02:00:00	\N	1007.5
1873	247	2093	2012-11-28 02:30:00	\N	1007.3
1874	247	2094	2012-11-28 03:00:00	\N	1006.8
1875	247	2095	2012-11-28 03:30:00	\N	1006.6
1876	247	2096	2012-11-28 04:00:00	\N	1006.3
1877	247	2097	2012-11-28 04:30:00	\N	1006.1
1878	247	2098	2012-11-28 05:00:00	\N	1005.9
1879	247	2099	2012-11-28 05:30:00	\N	1005.6
1880	247	2100	2012-11-28 06:00:00	\N	1005.3
1881	247	2101	2012-11-28 06:30:00	\N	1005.5
1882	247	2102	2012-11-28 07:00:00	\N	1005.3
1883	247	2103	2012-11-28 07:30:00	\N	1005.3
1884	247	2104	2012-11-28 08:00:00	\N	1004.9
1885	247	2105	2012-11-28 08:30:00	\N	1004.7
1886	247	2106	2012-11-28 09:00:00	\N	1004.6
1887	247	2107	2012-11-28 09:30:00	\N	1004.6
1888	247	2108	2012-11-28 10:00:00	\N	1004.4
1889	247	2109	2012-11-28 10:30:00	\N	1004
1890	247	2110	2012-11-28 11:00:00	\N	1003.3
1891	247	2111	2012-11-28 11:30:00	\N	1002.7
1892	247	2112	2012-11-28 12:00:00	\N	1002
1893	247	2113	2012-11-28 12:30:00	\N	1001.7
1894	247	2114	2012-11-28 13:00:00	\N	1001.5
1895	247	2115	2012-11-28 13:30:00	\N	1000.6
1896	247	2116	2012-11-28 14:00:00	\N	1000.5
1897	247	2117	2012-11-28 14:30:00	\N	1000.2
1898	247	2118	2012-11-28 15:00:00	\N	999.79999999999995
1899	247	2119	2012-11-28 15:30:00	\N	999.89999999999998
1900	247	2120	2012-11-28 16:00:00	\N	999
1901	247	2121	2012-11-28 16:30:00	\N	998.89999999999998
1902	247	2122	2012-11-28 17:00:00	\N	998.60000000000002
1903	247	2123	2012-11-28 17:30:00	\N	998
1904	247	2124	2012-11-28 18:00:00	\N	997.39999999999998
1905	247	2125	2012-11-28 18:30:00	\N	996.70000000000005
1906	247	2126	2012-11-28 19:00:00	\N	995.89999999999998
1907	247	2127	2012-11-28 19:30:00	\N	995.10000000000002
1908	247	2128	2012-11-28 20:00:00	\N	995
1909	247	2129	2012-11-28 20:30:00	\N	994.5
1910	247	2130	2012-11-28 21:00:00	\N	994.5
1911	247	2131	2012-11-28 21:30:00	\N	994.89999999999998
1912	247	2132	2012-11-28 22:00:00	\N	996.10000000000002
1913	247	2133	2012-11-28 22:30:00	\N	996.29999999999995
1914	247	2134	2012-11-28 23:00:00	\N	994.29999999999995
1915	247	2135	2012-11-28 23:30:00	\N	994.39999999999998
1916	247	2136	2012-11-29 00:00:00	\N	994.29999999999995
1917	247	2137	2012-11-29 00:30:00	\N	994.20000000000005
1918	247	2138	2012-11-29 01:00:00	\N	994
1919	247	2139	2012-11-29 01:30:00	\N	993.79999999999995
1920	247	2140	2012-11-29 02:00:00	\N	993.5
1921	247	2141	2012-11-29 02:30:00	\N	993.20000000000005
1922	247	2142	2012-11-29 03:00:00	\N	993.29999999999995
1923	247	2143	2012-11-29 03:30:00	\N	993.39999999999998
1924	247	2144	2012-11-29 04:00:00	\N	993
1925	247	2145	2012-11-29 04:30:00	\N	992.89999999999998
1926	247	2146	2012-11-29 05:00:00	\N	992.79999999999995
1927	247	2147	2012-11-29 05:30:00	\N	993
1928	247	2148	2012-11-29 06:00:00	\N	993.29999999999995
1929	247	2149	2012-11-29 06:30:00	\N	993
1930	247	2150	2012-11-29 07:00:00	\N	992.89999999999998
1931	247	2151	2012-11-29 07:30:00	\N	993.29999999999995
1932	247	2152	2012-11-29 08:00:00	\N	993.70000000000005
1933	247	2153	2012-11-29 08:30:00	\N	993.70000000000005
1934	247	2154	2012-11-29 09:00:00	\N	993.70000000000005
1935	247	2155	2012-11-29 09:30:00	\N	993.70000000000005
1936	247	2156	2012-11-29 10:00:00	\N	993.70000000000005
1937	247	2157	2012-11-29 10:30:00	\N	993.70000000000005
1938	247	2158	2012-11-29 11:00:00	\N	993.5
1939	247	2159	2012-11-29 11:30:00	\N	993.29999999999995
1940	247	2160	2012-11-29 12:00:00	\N	992.89999999999998
1941	247	2161	2012-11-29 12:30:00	\N	992.70000000000005
1942	247	2162	2012-11-29 13:00:00	\N	992.89999999999998
1943	247	2163	2012-11-29 13:30:00	\N	993
1944	247	2164	2012-11-29 14:00:00	\N	992.89999999999998
1945	247	2165	2012-11-29 14:30:00	\N	993.20000000000005
1946	247	2166	2012-11-29 15:00:00	\N	994
1947	247	2167	2012-11-29 15:30:00	\N	994.29999999999995
1948	247	2168	2012-11-29 16:00:00	\N	994.29999999999995
1949	247	2169	2012-11-29 16:30:00	\N	994.5
1950	247	2170	2012-11-29 17:00:00	\N	994.60000000000002
1951	247	2171	2012-11-29 17:30:00	\N	994.70000000000005
1952	247	2172	2012-11-29 18:00:00	\N	995
1953	247	2173	2012-11-29 18:30:00	\N	994.79999999999995
1954	247	2174	2012-11-29 19:00:00	\N	995
1955	247	2175	2012-11-29 19:30:00	\N	994.89999999999998
1956	247	2176	2012-11-29 20:00:00	\N	995.10000000000002
1957	247	2177	2012-11-29 20:30:00	\N	995.5
1958	247	2178	2012-11-29 21:00:00	\N	995.5
1959	247	2179	2012-11-29 21:30:00	\N	995.60000000000002
1960	247	2180	2012-11-29 22:00:00	\N	995.60000000000002
1961	247	2181	2012-11-29 22:30:00	\N	996
1962	247	2182	2012-11-29 23:00:00	\N	996.20000000000005
1963	247	2183	2012-11-29 23:30:00	\N	996.60000000000002
1964	247	2184	2012-11-30 00:00:00	\N	997.70000000000005
1965	247	2185	2012-11-30 00:30:00	\N	998.60000000000002
1966	247	2186	2012-11-30 01:00:00	\N	998.79999999999995
1967	247	2187	2012-11-30 01:30:00	\N	999.5
1968	247	2188	2012-11-30 02:00:00	\N	999.5
1969	247	2189	2012-11-30 02:30:00	\N	999.70000000000005
1970	247	2190	2012-11-30 03:00:00	\N	999.89999999999998
1971	247	2191	2012-11-30 03:30:00	\N	1000
1972	247	2192	2012-11-30 04:00:00	\N	1000.6
1973	247	2193	2012-11-30 04:30:00	\N	1001.1
1974	247	2194	2012-11-30 05:00:00	\N	1001.6
1975	247	2195	2012-11-30 05:30:00	\N	1002
1976	247	2196	2012-11-30 06:00:00	\N	1002.3
2001	247	2221	2012-11-30 06:30:00	\N	1002.5
2002	247	2222	2012-11-30 07:00:00	\N	1002.8
2021	247	2241	2012-11-30 07:30:00	\N	1003.4
2022	247	2242	2012-11-30 08:00:00	\N	1003.6
2023	247	2243	2012-11-30 08:30:00	\N	1003.8
2024	247	2244	2012-11-30 09:00:00	\N	1004.5
2025	247	2245	2012-11-30 09:30:00	\N	1004.7
2026	247	2246	2012-11-30 10:00:00	\N	1005.4
2027	247	2247	2012-11-30 10:30:00	\N	1005.5
2028	247	2248	2012-11-30 11:00:00	\N	1005.5
2029	247	2249	2012-11-30 11:30:00	\N	1005.6
2030	247	2250	2012-11-30 12:00:00	\N	1005.7
2031	247	2251	2012-11-30 12:30:00	\N	1005.8
2032	247	2252	2012-11-30 13:00:00	\N	1005.9
2033	247	2253	2012-11-30 13:30:00	\N	1005.9
2034	247	2254	2012-11-30 14:00:00	\N	1006.3
2035	247	2255	2012-11-30 14:30:00	\N	1006.4
2036	247	2256	2012-11-30 15:00:00	\N	1006.8
2037	247	2257	2012-11-30 15:30:00	\N	1007.3
2038	247	2258	2012-11-30 16:00:00	\N	1007.4
2039	247	2259	2012-11-30 16:30:00	\N	1007.9
2040	247	2260	2012-11-30 17:00:00	\N	1007.8
2041	247	2261	2012-11-30 17:30:00	\N	1007.9
2042	247	2262	2012-11-30 18:00:00	\N	1008.3
2043	247	2263	2012-11-30 18:30:00	\N	1008.6
2044	247	2264	2012-11-30 19:00:00	\N	1009
2061	247	2281	2012-11-30 19:30:00	\N	1009.4
2062	247	2282	2012-11-30 20:00:00	\N	1009.7
2081	247	2301	2012-11-30 20:30:00	\N	1010
2082	247	2302	2012-11-30 21:00:00	\N	1010.3
2083	247	2303	2012-11-30 21:30:00	\N	1011
2084	247	2304	2012-11-30 22:00:00	\N	1011
2101	247	2321	2012-11-30 22:30:00	\N	1011
2102	247	2322	2012-11-30 23:00:00	\N	1011.2
\.


--
-- Data for Name: s_data_rains; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_rains (id, sensor_id, sensor_data_id, date_time, rain, raint_rate) FROM stdin;
1581	246	1801	2012-11-22 00:30:00	0	0
1582	246	1802	2012-11-22 01:00:00	0	0
1583	246	1803	2012-11-22 01:30:00	0	0
1584	246	1804	2012-11-22 02:00:00	0	0
1585	246	1805	2012-11-22 02:30:00	0	0
1586	246	1806	2012-11-22 03:00:00	0	0
1587	246	1807	2012-11-22 03:30:00	0	0
1588	246	1808	2012-11-22 04:00:00	0	0
1589	246	1809	2012-11-22 04:30:00	0	0
1590	246	1810	2012-11-22 05:00:00	0	0
1591	246	1811	2012-11-22 05:30:00	0	0
1592	246	1812	2012-11-22 06:00:00	0	0
1593	246	1813	2012-11-22 06:30:00	0	0
1594	246	1814	2012-11-22 07:00:00	0	0
1595	246	1815	2012-11-22 07:30:00	0	0
1596	246	1816	2012-11-22 08:00:00	0	0
1597	246	1817	2012-11-22 08:30:00	0	0
1598	246	1818	2012-11-22 09:00:00	0	0
1599	246	1819	2012-11-22 09:30:00	0	0
1600	246	1820	2012-11-22 10:00:00	0	0
1601	246	1821	2012-11-22 10:30:00	0	0
1602	246	1822	2012-11-22 11:00:00	0	0
1603	246	1823	2012-11-22 11:30:00	0	0
1604	246	1824	2012-11-22 12:00:00	0	0
1605	246	1825	2012-11-22 12:30:00	0	0
1606	246	1826	2012-11-22 13:00:00	0	0
1607	246	1827	2012-11-22 13:30:00	0	0
1608	246	1828	2012-11-22 14:00:00	0	0
1609	246	1829	2012-11-22 14:30:00	0	0
1610	246	1830	2012-11-22 15:00:00	0	0
1611	246	1831	2012-11-22 15:30:00	0	0
1612	246	1832	2012-11-22 16:00:00	0	0
1613	246	1833	2012-11-22 16:30:00	0	0
1614	246	1834	2012-11-22 17:00:00	0	0
1615	246	1835	2012-11-22 17:30:00	0	0
1616	246	1836	2012-11-22 18:00:00	0	0
1617	246	1837	2012-11-22 18:30:00	0	0
1618	246	1838	2012-11-22 19:00:00	0	0
1619	246	1839	2012-11-22 19:30:00	0	0
1620	246	1840	2012-11-22 20:00:00	0	0
1621	246	1841	2012-11-22 20:30:00	0	0
1622	246	1842	2012-11-22 21:00:00	0	0
1623	246	1843	2012-11-22 21:30:00	0	0
1624	246	1844	2012-11-22 22:00:00	0	0
1625	246	1845	2012-11-22 22:30:00	0	0
1626	246	1846	2012-11-22 23:00:00	0	0
1627	246	1847	2012-11-22 23:30:00	0	0
1628	246	1848	2012-11-23 00:00:00	0	0
1629	246	1849	2012-11-23 00:30:00	0	0
1630	246	1850	2012-11-23 01:00:00	0	0
1631	246	1851	2012-11-23 01:30:00	0	0
1632	246	1852	2012-11-23 02:00:00	0	0
1633	246	1853	2012-11-23 02:30:00	0	0
1634	246	1854	2012-11-23 03:00:00	0	0
1635	246	1855	2012-11-23 03:30:00	0	0
1636	246	1856	2012-11-23 04:00:00	0	0
1637	246	1857	2012-11-23 04:30:00	0	0
1638	246	1858	2012-11-23 05:00:00	0	0
1639	246	1859	2012-11-23 05:30:00	0	0
1640	246	1860	2012-11-23 06:00:00	0	0
1641	246	1861	2012-11-23 06:30:00	0	0
1642	246	1862	2012-11-23 07:00:00	0	0
1643	246	1863	2012-11-23 07:30:00	0	0
1644	246	1864	2012-11-23 08:00:00	0	0
1645	246	1865	2012-11-23 08:30:00	0	0
1646	246	1866	2012-11-23 09:00:00	0	0
1647	246	1867	2012-11-23 09:30:00	0	0
1648	246	1868	2012-11-23 10:00:00	0	0
1649	246	1869	2012-11-23 10:30:00	0	0
1650	246	1870	2012-11-23 11:00:00	0	0
1651	246	1871	2012-11-23 11:30:00	0	0
1652	246	1872	2012-11-23 12:00:00	0	0
1653	246	1873	2012-11-23 12:30:00	0	0
1654	246	1874	2012-11-23 13:00:00	0	0
1655	246	1875	2012-11-23 13:30:00	0	0
1656	246	1876	2012-11-23 14:00:00	0	0
1657	246	1877	2012-11-23 14:30:00	0	0
1658	246	1878	2012-11-23 15:00:00	0	0
1659	246	1879	2012-11-23 15:30:00	0	0
1660	246	1880	2012-11-23 16:00:00	0	0
1661	246	1881	2012-11-23 16:30:00	0	0
1662	246	1882	2012-11-23 17:00:00	0	0
1663	246	1883	2012-11-23 17:30:00	0	0
1664	246	1884	2012-11-23 18:00:00	0	0
1665	246	1885	2012-11-23 18:30:00	0	0
1666	246	1886	2012-11-23 19:00:00	0	0
1667	246	1887	2012-11-23 19:30:00	0	0
1668	246	1888	2012-11-23 20:00:00	0	0
1669	246	1889	2012-11-23 20:30:00	0	0
1670	246	1890	2012-11-23 21:00:00	0.20000000000000001	0
1671	246	1891	2012-11-23 21:30:00	0	0
1672	246	1892	2012-11-23 22:00:00	0	0
1673	246	1893	2012-11-23 22:30:00	0	0
1674	246	1894	2012-11-23 23:00:00	0	0
1675	246	1895	2012-11-23 23:30:00	0	0
1676	246	1896	2012-11-24 00:00:00	0	0
1677	246	1897	2012-11-24 00:30:00	0	0
1678	246	1898	2012-11-24 01:00:00	0	0
1679	246	1899	2012-11-24 01:30:00	0	0
1680	246	1900	2012-11-24 02:00:00	0	0
1681	246	1901	2012-11-24 02:30:00	0	0
1682	246	1902	2012-11-24 03:00:00	0	0
1683	246	1903	2012-11-24 03:30:00	0	0
1684	246	1904	2012-11-24 04:00:00	0	0
1685	246	1905	2012-11-24 04:30:00	0	0
1686	246	1906	2012-11-24 05:00:00	0	0
1687	246	1907	2012-11-24 05:30:00	0	0
1688	246	1908	2012-11-24 06:00:00	0	0
1689	246	1909	2012-11-24 06:30:00	0	0
1690	246	1910	2012-11-24 07:00:00	0	0
1691	246	1911	2012-11-24 07:30:00	0	0
1692	246	1912	2012-11-24 08:00:00	0	0
1693	246	1913	2012-11-24 08:30:00	0	0
1694	246	1914	2012-11-24 09:00:00	0	0
1695	246	1915	2012-11-24 09:30:00	0	0
1696	246	1916	2012-11-24 10:00:00	0	0
1697	246	1917	2012-11-24 10:30:00	0	0
1698	246	1918	2012-11-24 11:00:00	0	0
1699	246	1919	2012-11-24 11:30:00	0	0
1700	246	1920	2012-11-24 12:00:00	0	0
1701	246	1921	2012-11-24 12:30:00	0	0
1702	246	1922	2012-11-24 13:00:00	0	0
1703	246	1923	2012-11-24 13:30:00	0	0
1704	246	1924	2012-11-24 14:00:00	0	0
1705	246	1925	2012-11-24 14:30:00	0	0
1706	246	1926	2012-11-24 15:00:00	0	0
1707	246	1927	2012-11-24 15:30:00	0	0
1708	246	1928	2012-11-24 16:00:00	0	0
1709	246	1929	2012-11-24 16:30:00	0	0
1710	246	1930	2012-11-24 17:00:00	0	0
1711	246	1931	2012-11-24 17:30:00	0	0
1712	246	1932	2012-11-24 18:00:00	0	0
1713	246	1933	2012-11-24 18:30:00	0	0
1714	246	1934	2012-11-24 19:00:00	0	0
1715	246	1935	2012-11-24 19:30:00	0	0
1716	246	1936	2012-11-24 20:00:00	0	0
1717	246	1937	2012-11-24 20:30:00	0	0
1718	246	1938	2012-11-24 21:00:00	0	0
1719	246	1939	2012-11-24 21:30:00	0	0
1720	246	1940	2012-11-24 22:00:00	0	0
1721	246	1941	2012-11-24 22:30:00	0	0
1722	246	1942	2012-11-24 23:00:00	0.20000000000000001	0
1723	246	1943	2012-11-24 23:30:00	0	0
1724	246	1944	2012-11-25 00:00:00	0	0
1725	246	1945	2012-11-25 00:30:00	0	0
1726	246	1946	2012-11-25 01:00:00	0	0
1727	246	1947	2012-11-25 01:30:00	0	0
1728	246	1948	2012-11-25 02:00:00	0	0
1729	246	1949	2012-11-25 02:30:00	0	0
1730	246	1950	2012-11-25 03:00:00	0	0
1731	246	1951	2012-11-25 03:30:00	0	0
1732	246	1952	2012-11-25 04:00:00	0	0
1733	246	1953	2012-11-25 04:30:00	0	0
1734	246	1954	2012-11-25 05:00:00	0	0
1735	246	1955	2012-11-25 05:30:00	0	0
1736	246	1956	2012-11-25 06:00:00	0	0
1737	246	1957	2012-11-25 06:30:00	0	0
1738	246	1958	2012-11-25 07:00:00	0	0
1739	246	1959	2012-11-25 07:30:00	0	0
1740	246	1960	2012-11-25 08:00:00	0	0
1741	246	1961	2012-11-25 08:30:00	0	0
1742	246	1962	2012-11-25 09:00:00	0	0
1743	246	1963	2012-11-25 09:30:00	0	0
1744	246	1964	2012-11-25 10:00:00	0	0
1745	246	1965	2012-11-25 10:30:00	0	0
1746	246	1966	2012-11-25 11:00:00	0	0
1747	246	1967	2012-11-25 11:30:00	0	0
1748	246	1968	2012-11-25 12:00:00	0	0
1749	246	1969	2012-11-25 12:30:00	0	0
1750	246	1970	2012-11-25 13:00:00	0	0
1751	246	1971	2012-11-25 13:30:00	0	0
1752	246	1972	2012-11-25 14:00:00	0	0
1753	246	1973	2012-11-25 14:30:00	0	0
1754	246	1974	2012-11-25 15:00:00	0	0
1755	246	1975	2012-11-25 15:30:00	0	0
1756	246	1976	2012-11-25 16:00:00	0	0
1757	246	1977	2012-11-25 16:30:00	0	0
1758	246	1978	2012-11-25 17:00:00	0	0
1759	246	1979	2012-11-25 17:30:00	0	0
1760	246	1980	2012-11-25 18:00:00	0	0
1761	246	1981	2012-11-25 18:30:00	0	0
1762	246	1982	2012-11-25 19:00:00	0	0
1763	246	1983	2012-11-25 19:30:00	0	0
1764	246	1984	2012-11-25 20:00:00	0	0
1765	246	1985	2012-11-25 20:30:00	0	0
1766	246	1986	2012-11-25 21:00:00	0	0
1767	246	1987	2012-11-25 21:30:00	0	0
1768	246	1988	2012-11-25 22:00:00	0	0
1769	246	1989	2012-11-25 22:30:00	0	0
1770	246	1990	2012-11-25 23:00:00	0	0
1771	246	1991	2012-11-25 23:30:00	0	0
1772	246	1992	2012-11-26 00:00:00	0	0
1773	246	1993	2012-11-26 00:30:00	0	0
1774	246	1994	2012-11-26 01:00:00	0	0
1775	246	1995	2012-11-26 01:30:00	0	0
1776	246	1996	2012-11-26 02:00:00	0	0
1777	246	1997	2012-11-26 02:30:00	0	0
1778	246	1998	2012-11-26 03:00:00	0.20000000000000001	0
1779	246	1999	2012-11-26 03:30:00	0	0
1780	246	2000	2012-11-26 04:00:00	0	0
1781	246	2001	2012-11-26 04:30:00	0	0
1782	246	2002	2012-11-26 05:00:00	0	0
1783	246	2003	2012-11-26 05:30:00	0	0
1784	246	2004	2012-11-26 06:00:00	0	0
1785	246	2005	2012-11-26 06:30:00	0	0
1786	246	2006	2012-11-26 07:00:00	0	0
1787	246	2007	2012-11-26 07:30:00	0	0
1788	246	2008	2012-11-26 08:00:00	0	0
1789	246	2009	2012-11-26 08:30:00	0	0
1790	246	2010	2012-11-26 09:00:00	0	0
1791	246	2011	2012-11-26 09:30:00	0	0
1792	246	2012	2012-11-26 10:00:00	0	0
1793	246	2013	2012-11-26 10:30:00	0	0
1794	246	2014	2012-11-26 11:00:00	0	0
1795	246	2015	2012-11-26 11:30:00	0	0
1802	246	2022	2012-11-26 15:00:00	0	0
1810	246	2030	2012-11-26 19:00:00	0	0
1811	246	2031	2012-11-26 19:30:00	0	0
1812	246	2032	2012-11-26 20:00:00	0	0
1813	246	2033	2012-11-26 20:30:00	0	0
1826	246	2046	2012-11-27 03:00:00	0	0
1829	246	2049	2012-11-27 04:30:00	0	0
1796	246	2016	2012-11-26 12:00:00	0	0
1805	246	2025	2012-11-26 16:30:00	0	0
1814	246	2034	2012-11-26 21:00:00	0	0
1818	246	2038	2012-11-26 23:00:00	0	0
1820	246	2040	2012-11-27 00:00:00	0	0
1827	246	2047	2012-11-27 03:30:00	0	0
1838	246	2058	2012-11-27 09:00:00	0	0
1843	246	2063	2012-11-27 11:30:00	0	0
1845	246	2065	2012-11-27 12:30:00	0	0
1797	246	2017	2012-11-26 12:30:00	0	0
1801	246	2021	2012-11-26 14:30:00	0	0
1816	246	2036	2012-11-26 22:00:00	0	0
1817	246	2037	2012-11-26 22:30:00	0	0
1823	246	2043	2012-11-27 01:30:00	0.20000000000000001	0
1828	246	2048	2012-11-27 04:00:00	0	0
1834	246	2054	2012-11-27 07:00:00	0	0
1798	246	2018	2012-11-26 13:00:00	0	0
1815	246	2035	2012-11-26 21:30:00	0	0
1822	246	2042	2012-11-27 01:00:00	0	0
1836	246	2056	2012-11-27 08:00:00	0	0
1799	246	2019	2012-11-26 13:30:00	0	0
1804	246	2024	2012-11-26 16:00:00	0	0
1807	246	2027	2012-11-26 17:30:00	0	0
1808	246	2028	2012-11-26 18:00:00	0	0
1821	246	2041	2012-11-27 00:30:00	0	0
1837	246	2057	2012-11-27 08:30:00	0	0
1800	246	2020	2012-11-26 14:00:00	0	0
1806	246	2026	2012-11-26 17:00:00	0	0
1809	246	2029	2012-11-26 18:30:00	0	0
1825	246	2045	2012-11-27 02:30:00	0	0
1835	246	2055	2012-11-27 07:30:00	0	0
1842	246	2062	2012-11-27 11:00:00	0	0
1844	246	2064	2012-11-27 12:00:00	0	0
1803	246	2023	2012-11-26 15:30:00	0	0
1824	246	2044	2012-11-27 02:00:00	0	0
1832	246	2052	2012-11-27 06:00:00	0	0
1833	246	2053	2012-11-27 06:30:00	0	0
1840	246	2060	2012-11-27 10:00:00	0	0
1819	246	2039	2012-11-26 23:30:00	0	0
1830	246	2050	2012-11-27 05:00:00	0	0
1831	246	2051	2012-11-27 05:30:00	0	0
1846	246	2066	2012-11-27 13:00:00	0	0
1839	246	2059	2012-11-27 09:30:00	0	0
1841	246	2061	2012-11-27 10:30:00	0	0
1847	246	2067	2012-11-27 13:30:00	0	0
1848	246	2068	2012-11-27 14:00:00	0	0
1849	246	2069	2012-11-27 14:30:00	0	0
1850	246	2070	2012-11-27 15:00:00	0	0
1851	246	2071	2012-11-27 15:30:00	0	0
1852	246	2072	2012-11-27 16:00:00	0	0
1853	246	2073	2012-11-27 16:30:00	0	0
1854	246	2074	2012-11-27 17:00:00	0	0
1855	246	2075	2012-11-27 17:30:00	0	0
1856	246	2076	2012-11-27 18:00:00	0	0
1857	246	2077	2012-11-27 18:30:00	0	0
1858	246	2078	2012-11-27 19:00:00	0	0
1859	246	2079	2012-11-27 19:30:00	0	0
1860	246	2080	2012-11-27 20:00:00	0	0
1861	246	2081	2012-11-27 20:30:00	0	0
1862	246	2082	2012-11-27 21:00:00	0	0
1863	246	2083	2012-11-27 21:30:00	0	0
1864	246	2084	2012-11-27 22:00:00	0	0
1865	246	2085	2012-11-27 22:30:00	0	0
1866	246	2086	2012-11-27 23:00:00	0	0
1867	246	2087	2012-11-27 23:30:00	0	0
1868	246	2088	2012-11-28 00:00:00	0	0
1869	246	2089	2012-11-28 00:30:00	0	0
1870	246	2090	2012-11-28 01:00:00	0	0
1871	246	2091	2012-11-28 01:30:00	0	0
1872	246	2092	2012-11-28 02:00:00	0	0
1873	246	2093	2012-11-28 02:30:00	0	0
1874	246	2094	2012-11-28 03:00:00	0	0
1875	246	2095	2012-11-28 03:30:00	0	0
1876	246	2096	2012-11-28 04:00:00	0	0
1877	246	2097	2012-11-28 04:30:00	0	0
1878	246	2098	2012-11-28 05:00:00	0	0
1879	246	2099	2012-11-28 05:30:00	0	0
1880	246	2100	2012-11-28 06:00:00	0	0
1881	246	2101	2012-11-28 06:30:00	0	0
1882	246	2102	2012-11-28 07:00:00	0	0
1883	246	2103	2012-11-28 07:30:00	0	0
1884	246	2104	2012-11-28 08:00:00	0	0
1885	246	2105	2012-11-28 08:30:00	0	0
1886	246	2106	2012-11-28 09:00:00	0	0
1887	246	2107	2012-11-28 09:30:00	0	0
1888	246	2108	2012-11-28 10:00:00	0	0
1889	246	2109	2012-11-28 10:30:00	0	0
1890	246	2110	2012-11-28 11:00:00	0	0
1891	246	2111	2012-11-28 11:30:00	0	0
1892	246	2112	2012-11-28 12:00:00	0	0
1893	246	2113	2012-11-28 12:30:00	0	0
1894	246	2114	2012-11-28 13:00:00	0	0
1895	246	2115	2012-11-28 13:30:00	0	0
1896	246	2116	2012-11-28 14:00:00	0	0
1897	246	2117	2012-11-28 14:30:00	0	0
1898	246	2118	2012-11-28 15:00:00	0	0
1899	246	2119	2012-11-28 15:30:00	0	0
1900	246	2120	2012-11-28 16:00:00	0.40000000000000002	0
1901	246	2121	2012-11-28 16:30:00	0	0
1902	246	2122	2012-11-28 17:00:00	1.2	7.7999999999999998
1903	246	2123	2012-11-28 17:30:00	0	0
1904	246	2124	2012-11-28 18:00:00	0	0
1905	246	2125	2012-11-28 18:30:00	0	0
1906	246	2126	2012-11-28 19:00:00	0	0
1907	246	2127	2012-11-28 19:30:00	0	0
1908	246	2128	2012-11-28 20:00:00	0	0
1909	246	2129	2012-11-28 20:30:00	0	0
1910	246	2130	2012-11-28 21:00:00	0	0
1911	246	2131	2012-11-28 21:30:00	0.20000000000000001	0
1912	246	2132	2012-11-28 22:00:00	0.80000000000000004	3.7999999999999998
1913	246	2133	2012-11-28 22:30:00	1.8	9.4000000000000004
1914	246	2134	2012-11-28 23:00:00	2	8.5999999999999996
1915	246	2135	2012-11-28 23:30:00	0	0
1916	246	2136	2012-11-29 00:00:00	0	0
1917	246	2137	2012-11-29 00:30:00	0	0
1918	246	2138	2012-11-29 01:00:00	0	0
1919	246	2139	2012-11-29 01:30:00	0	0
1920	246	2140	2012-11-29 02:00:00	0	0
1921	246	2141	2012-11-29 02:30:00	0	0
1922	246	2142	2012-11-29 03:00:00	0	0
1923	246	2143	2012-11-29 03:30:00	0	0
1924	246	2144	2012-11-29 04:00:00	0	0
1925	246	2145	2012-11-29 04:30:00	0	0
1926	246	2146	2012-11-29 05:00:00	0	0
1927	246	2147	2012-11-29 05:30:00	0	0
1928	246	2148	2012-11-29 06:00:00	0	0
1929	246	2149	2012-11-29 06:30:00	0	0
1930	246	2150	2012-11-29 07:00:00	0	0
1931	246	2151	2012-11-29 07:30:00	0	0
1932	246	2152	2012-11-29 08:00:00	0	0
1933	246	2153	2012-11-29 08:30:00	0	0
1934	246	2154	2012-11-29 09:00:00	0	0
1935	246	2155	2012-11-29 09:30:00	0	0
1936	246	2156	2012-11-29 10:00:00	0	0
1937	246	2157	2012-11-29 10:30:00	0	0
1938	246	2158	2012-11-29 11:00:00	0	0
1939	246	2159	2012-11-29 11:30:00	0	0
1940	246	2160	2012-11-29 12:00:00	0	0
1941	246	2161	2012-11-29 12:30:00	0	0
1942	246	2162	2012-11-29 13:00:00	0	0
1943	246	2163	2012-11-29 13:30:00	0	0
1944	246	2164	2012-11-29 14:00:00	0	0
1945	246	2165	2012-11-29 14:30:00	0	0
1946	246	2166	2012-11-29 15:00:00	0	0
1947	246	2167	2012-11-29 15:30:00	2.3999999999999999	75.200000000000003
1948	246	2168	2012-11-29 16:00:00	0.20000000000000001	2.6000000000000001
1949	246	2169	2012-11-29 16:30:00	0	0
1950	246	2170	2012-11-29 17:00:00	0.20000000000000001	0
1951	246	2171	2012-11-29 17:30:00	0	0
1952	246	2172	2012-11-29 18:00:00	0	0
1953	246	2173	2012-11-29 18:30:00	0	0
1954	246	2174	2012-11-29 19:00:00	0	0
1955	246	2175	2012-11-29 19:30:00	0	0
1956	246	2176	2012-11-29 20:00:00	0	0
1957	246	2177	2012-11-29 20:30:00	0	0
1958	246	2178	2012-11-29 21:00:00	0	0
1959	246	2179	2012-11-29 21:30:00	0	0
1960	246	2180	2012-11-29 22:00:00	0	0
1961	246	2181	2012-11-29 22:30:00	0.40000000000000002	1.6000000000000001
1962	246	2182	2012-11-29 23:00:00	1.2	9.1999999999999993
1963	246	2183	2012-11-29 23:30:00	1.6000000000000001	5.4000000000000004
1964	246	2184	2012-11-30 00:00:00	0.80000000000000004	4.4000000000000004
1965	246	2185	2012-11-30 00:30:00	1.6000000000000001	7.4000000000000004
1966	246	2186	2012-11-30 01:00:00	1.2	5.5999999999999996
1967	246	2187	2012-11-30 01:30:00	0.80000000000000004	4
1968	246	2188	2012-11-30 02:00:00	1	4.7999999999999998
1969	246	2189	2012-11-30 02:30:00	0.59999999999999998	1.6000000000000001
1970	246	2190	2012-11-30 03:00:00	0.40000000000000002	1.8
1971	246	2191	2012-11-30 03:30:00	0.80000000000000004	3
1972	246	2192	2012-11-30 04:00:00	0.59999999999999998	2.7999999999999998
1973	246	2193	2012-11-30 04:30:00	1	4.4000000000000004
1974	246	2194	2012-11-30 05:00:00	0.59999999999999998	2
1975	246	2195	2012-11-30 05:30:00	0.59999999999999998	2.3999999999999999
1976	246	2196	2012-11-30 06:00:00	0.59999999999999998	2
2001	246	2221	2012-11-30 06:30:00	0.59999999999999998	2.7999999999999998
2002	246	2222	2012-11-30 07:00:00	0.40000000000000002	1.3999999999999999
2021	246	2241	2012-11-30 07:30:00	0	0
2022	246	2242	2012-11-30 08:00:00	0.40000000000000002	1.2
2023	246	2243	2012-11-30 08:30:00	0.40000000000000002	0.80000000000000004
2024	246	2244	2012-11-30 09:00:00	0	0
2025	246	2245	2012-11-30 09:30:00	0	0
2026	246	2246	2012-11-30 10:00:00	0.20000000000000001	0
2027	246	2247	2012-11-30 10:30:00	0	0
2028	246	2248	2012-11-30 11:00:00	0	0
2029	246	2249	2012-11-30 11:30:00	0.20000000000000001	0
2030	246	2250	2012-11-30 12:00:00	0	0
2031	246	2251	2012-11-30 12:30:00	0	0
2032	246	2252	2012-11-30 13:00:00	0	0
2033	246	2253	2012-11-30 13:30:00	0	0
2034	246	2254	2012-11-30 14:00:00	0	0
2035	246	2255	2012-11-30 14:30:00	0	0
2036	246	2256	2012-11-30 15:00:00	0	0
2037	246	2257	2012-11-30 15:30:00	0	0
2038	246	2258	2012-11-30 16:00:00	0	0
2039	246	2259	2012-11-30 16:30:00	0.20000000000000001	0
2040	246	2260	2012-11-30 17:00:00	0.20000000000000001	0
2041	246	2261	2012-11-30 17:30:00	0	0
2042	246	2262	2012-11-30 18:00:00	0	0
2043	246	2263	2012-11-30 18:30:00	0	0
2044	246	2264	2012-11-30 19:00:00	0	0
2061	246	2281	2012-11-30 19:30:00	0	0
2062	246	2282	2012-11-30 20:00:00	0	0
2081	246	2301	2012-11-30 20:30:00	0	0
2082	246	2302	2012-11-30 21:00:00	0	0
2083	246	2303	2012-11-30 21:30:00	0	0
2084	246	2304	2012-11-30 22:00:00	0	0
2101	246	2321	2012-11-30 22:30:00	0	0
2102	246	2322	2012-11-30 23:00:00	0	0
\.


--
-- Data for Name: s_data_temperatures; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_temperatures (id, sensor_id, sensor_data_id, date_time, temperature, heat, heatindex, thwindex) FROM stdin;
6781	252	1801	2012-11-22 00:30:00	18.699999999999999	17.800000000000001	\N	\N
6782	256	1801	2012-11-22 00:30:00	12.199999999999999	\N	\N	\N
6783	257	1801	2012-11-22 00:30:00	8.9000000000000004	\N	\N	\N
6784	241	1801	2012-11-22 00:30:00	8.5999999999999996	\N	8.8000000000000007	8.8000000000000007
6785	252	1802	2012-11-22 01:00:00	18.600000000000001	17.600000000000001	\N	\N
6786	256	1802	2012-11-22 01:00:00	12.199999999999999	\N	\N	\N
6787	257	1802	2012-11-22 01:00:00	8.9000000000000004	\N	\N	\N
6788	241	1802	2012-11-22 01:00:00	8.5999999999999996	\N	8.8000000000000007	8.8000000000000007
6789	252	1803	2012-11-22 01:30:00	18.600000000000001	17.600000000000001	\N	\N
6790	256	1803	2012-11-22 01:30:00	12.199999999999999	\N	\N	\N
6791	257	1803	2012-11-22 01:30:00	8.9000000000000004	\N	\N	\N
6792	241	1803	2012-11-22 01:30:00	8.5999999999999996	\N	8.8000000000000007	8.8000000000000007
6793	252	1804	2012-11-22 02:00:00	18.5	17.600000000000001	\N	\N
6794	256	1804	2012-11-22 02:00:00	12.199999999999999	\N	\N	\N
6795	257	1804	2012-11-22 02:00:00	8.9000000000000004	\N	\N	\N
6796	241	1804	2012-11-22 02:00:00	8.4000000000000004	\N	8.6999999999999993	8.6999999999999993
6797	252	1805	2012-11-22 02:30:00	18.5	17.600000000000001	\N	\N
6798	256	1805	2012-11-22 02:30:00	12.199999999999999	\N	\N	\N
6799	257	1805	2012-11-22 02:30:00	8.9000000000000004	\N	\N	\N
6800	241	1805	2012-11-22 02:30:00	8.4000000000000004	\N	8.6999999999999993	8.6999999999999993
6801	252	1806	2012-11-22 03:00:00	18.399999999999999	17.399999999999999	\N	\N
6802	256	1806	2012-11-22 03:00:00	12.199999999999999	\N	\N	\N
6803	257	1806	2012-11-22 03:00:00	8.9000000000000004	\N	\N	\N
6804	241	1806	2012-11-22 03:00:00	8.4000000000000004	\N	8.5999999999999996	8.5999999999999996
6805	252	1807	2012-11-22 03:30:00	18.399999999999999	17.399999999999999	\N	\N
6806	256	1807	2012-11-22 03:30:00	12.199999999999999	\N	\N	\N
6807	257	1807	2012-11-22 03:30:00	8.9000000000000004	\N	\N	\N
6808	241	1807	2012-11-22 03:30:00	8.4000000000000004	\N	8.6999999999999993	8.6999999999999993
6809	252	1808	2012-11-22 04:00:00	18.300000000000001	17.300000000000001	\N	\N
6810	256	1808	2012-11-22 04:00:00	12.199999999999999	\N	\N	\N
6811	257	1808	2012-11-22 04:00:00	8.9000000000000004	\N	\N	\N
6812	241	1808	2012-11-22 04:00:00	8.3000000000000007	\N	8.5	8.5
6813	252	1809	2012-11-22 04:30:00	18.300000000000001	17.300000000000001	\N	\N
6814	256	1809	2012-11-22 04:30:00	12.199999999999999	\N	\N	\N
6815	257	1809	2012-11-22 04:30:00	8.9000000000000004	\N	\N	\N
6816	241	1809	2012-11-22 04:30:00	8.3000000000000007	\N	8.5999999999999996	8.5999999999999996
6817	252	1810	2012-11-22 05:00:00	18.199999999999999	17.300000000000001	\N	\N
6818	256	1810	2012-11-22 05:00:00	12.199999999999999	\N	\N	\N
6819	257	1810	2012-11-22 05:00:00	8.9000000000000004	\N	\N	\N
6820	241	1810	2012-11-22 05:00:00	8.3000000000000007	\N	8.5	8.5
6821	252	1811	2012-11-22 05:30:00	18.199999999999999	17.300000000000001	\N	\N
6822	256	1811	2012-11-22 05:30:00	12.199999999999999	\N	\N	\N
6823	257	1811	2012-11-22 05:30:00	8.9000000000000004	\N	\N	\N
6824	241	1811	2012-11-22 05:30:00	8.3000000000000007	\N	8.5999999999999996	8.5999999999999996
6825	252	1812	2012-11-22 06:00:00	18.100000000000001	17.199999999999999	\N	\N
6826	256	1812	2012-11-22 06:00:00	12.199999999999999	\N	\N	\N
6827	257	1812	2012-11-22 06:00:00	8.9000000000000004	\N	\N	\N
6828	241	1812	2012-11-22 06:00:00	8.3000000000000007	\N	8.5	8.5
6829	252	1813	2012-11-22 06:30:00	18.100000000000001	17.199999999999999	\N	\N
6830	256	1813	2012-11-22 06:30:00	12.199999999999999	\N	\N	\N
6831	257	1813	2012-11-22 06:30:00	8.9000000000000004	\N	\N	\N
6832	241	1813	2012-11-22 06:30:00	8.3000000000000007	\N	8.5999999999999996	8.5999999999999996
6833	252	1814	2012-11-22 07:00:00	18.100000000000001	17.199999999999999	\N	\N
6834	256	1814	2012-11-22 07:00:00	12.199999999999999	\N	\N	\N
6835	257	1814	2012-11-22 07:00:00	8.9000000000000004	\N	\N	\N
6836	241	1814	2012-11-22 07:00:00	8.3000000000000007	\N	8.5999999999999996	8.5999999999999996
6837	252	1815	2012-11-22 07:30:00	18.100000000000001	17.100000000000001	\N	\N
6838	256	1815	2012-11-22 07:30:00	12.199999999999999	\N	\N	\N
6839	257	1815	2012-11-22 07:30:00	8.9000000000000004	\N	\N	\N
6840	241	1815	2012-11-22 07:30:00	8.4000000000000004	\N	8.6999999999999993	8.6999999999999993
6841	252	1816	2012-11-22 08:00:00	18.100000000000001	17.100000000000001	\N	\N
6842	256	1816	2012-11-22 08:00:00	12.199999999999999	\N	\N	\N
6843	257	1816	2012-11-22 08:00:00	8.9000000000000004	\N	\N	\N
6844	241	1816	2012-11-22 08:00:00	8.5999999999999996	\N	8.8000000000000007	8.8000000000000007
6845	252	1817	2012-11-22 08:30:00	18.100000000000001	17.100000000000001	\N	\N
6846	256	1817	2012-11-22 08:30:00	12.199999999999999	\N	\N	\N
6847	257	1817	2012-11-22 08:30:00	8.9000000000000004	\N	\N	\N
6848	241	1817	2012-11-22 08:30:00	8.9000000000000004	\N	9.0999999999999996	9.0999999999999996
6849	252	1818	2012-11-22 09:00:00	17.899999999999999	16.899999999999999	\N	\N
6850	256	1818	2012-11-22 09:00:00	12.199999999999999	\N	\N	\N
6851	257	1818	2012-11-22 09:00:00	8.9000000000000004	\N	\N	\N
6852	241	1818	2012-11-22 09:00:00	9.1999999999999993	\N	9.4000000000000004	9.4000000000000004
6853	252	1819	2012-11-22 09:30:00	17.899999999999999	16.899999999999999	\N	\N
6854	256	1819	2012-11-22 09:30:00	12.199999999999999	\N	\N	\N
6855	257	1819	2012-11-22 09:30:00	8.9000000000000004	\N	\N	\N
6856	241	1819	2012-11-22 09:30:00	9.3000000000000007	\N	9.5999999999999996	9.5999999999999996
6857	252	1820	2012-11-22 10:00:00	17.800000000000001	16.800000000000001	\N	\N
6858	256	1820	2012-11-22 10:00:00	12.199999999999999	\N	\N	\N
6859	257	1820	2012-11-22 10:00:00	8.9000000000000004	\N	\N	\N
6860	241	1820	2012-11-22 10:00:00	9.5999999999999996	\N	9.8000000000000007	9.8000000000000007
6861	252	1821	2012-11-22 10:30:00	17.800000000000001	16.800000000000001	\N	\N
6862	256	1821	2012-11-22 10:30:00	12.199999999999999	\N	\N	\N
6863	257	1821	2012-11-22 10:30:00	8.9000000000000004	\N	\N	\N
6864	241	1821	2012-11-22 10:30:00	9.6999999999999993	\N	9.9000000000000004	9.9000000000000004
6865	252	1822	2012-11-22 11:00:00	17.800000000000001	16.800000000000001	\N	\N
6866	256	1822	2012-11-22 11:00:00	12.199999999999999	\N	\N	\N
6867	257	1822	2012-11-22 11:00:00	8.9000000000000004	\N	\N	\N
6868	241	1822	2012-11-22 11:00:00	9.6999999999999993	\N	9.9000000000000004	9.9000000000000004
6869	252	1823	2012-11-22 11:30:00	17.800000000000001	16.899999999999999	\N	\N
6870	256	1823	2012-11-22 11:30:00	12.199999999999999	\N	\N	\N
6871	257	1823	2012-11-22 11:30:00	9.4000000000000004	\N	\N	\N
6872	241	1823	2012-11-22 11:30:00	10	\N	10.199999999999999	10.199999999999999
6873	252	1824	2012-11-22 12:00:00	18.399999999999999	17.800000000000001	\N	\N
6874	256	1824	2012-11-22 12:00:00	12.800000000000001	\N	\N	\N
6875	257	1824	2012-11-22 12:00:00	9.4000000000000004	\N	\N	\N
6876	241	1824	2012-11-22 12:00:00	10.1	\N	10.199999999999999	10.199999999999999
6877	252	1825	2012-11-22 12:30:00	18.800000000000001	18.300000000000001	\N	\N
6878	256	1825	2012-11-22 12:30:00	12.800000000000001	\N	\N	\N
6879	257	1825	2012-11-22 12:30:00	9.4000000000000004	\N	\N	\N
6880	241	1825	2012-11-22 12:30:00	10.199999999999999	\N	10.4	10.4
6881	252	1826	2012-11-22 13:00:00	19.300000000000001	18.899999999999999	\N	\N
6882	256	1826	2012-11-22 13:00:00	13.300000000000001	\N	\N	\N
6883	257	1826	2012-11-22 13:00:00	9.4000000000000004	\N	\N	\N
6884	241	1826	2012-11-22 13:00:00	10.300000000000001	\N	10.4	10.4
6885	252	1827	2012-11-22 13:30:00	19.600000000000001	19.300000000000001	\N	\N
6886	256	1827	2012-11-22 13:30:00	13.300000000000001	\N	\N	\N
6887	257	1827	2012-11-22 13:30:00	9.4000000000000004	\N	\N	\N
6888	241	1827	2012-11-22 13:30:00	10.199999999999999	\N	10.4	10.4
6889	252	1828	2012-11-22 14:00:00	19.600000000000001	19.199999999999999	\N	\N
6890	256	1828	2012-11-22 14:00:00	13.300000000000001	\N	\N	\N
6891	257	1828	2012-11-22 14:00:00	9.4000000000000004	\N	\N	\N
6892	241	1828	2012-11-22 14:00:00	10.199999999999999	\N	10.300000000000001	10.300000000000001
6893	252	1829	2012-11-22 14:30:00	19.699999999999999	19.300000000000001	\N	\N
6894	256	1829	2012-11-22 14:30:00	13.300000000000001	\N	\N	\N
6895	257	1829	2012-11-22 14:30:00	9.4000000000000004	\N	\N	\N
6896	241	1829	2012-11-22 14:30:00	10.199999999999999	\N	10.300000000000001	10.300000000000001
6897	252	1830	2012-11-22 15:00:00	19.699999999999999	19.300000000000001	\N	\N
6898	256	1830	2012-11-22 15:00:00	13.300000000000001	\N	\N	\N
6899	257	1830	2012-11-22 15:00:00	9.4000000000000004	\N	\N	\N
6900	241	1830	2012-11-22 15:00:00	10.199999999999999	\N	10.300000000000001	10.300000000000001
6901	252	1831	2012-11-22 15:30:00	19.800000000000001	19.399999999999999	\N	\N
6902	256	1831	2012-11-22 15:30:00	13.300000000000001	\N	\N	\N
6903	257	1831	2012-11-22 15:30:00	9.4000000000000004	\N	\N	\N
6904	241	1831	2012-11-22 15:30:00	10.1	\N	10.199999999999999	10.199999999999999
6905	252	1832	2012-11-22 16:00:00	19.899999999999999	19.5	\N	\N
6906	256	1832	2012-11-22 16:00:00	13.300000000000001	\N	\N	\N
6907	257	1832	2012-11-22 16:00:00	9.4000000000000004	\N	\N	\N
6908	241	1832	2012-11-22 16:00:00	9.9000000000000004	\N	10.199999999999999	10.199999999999999
6909	252	1833	2012-11-22 16:30:00	20	19.5	\N	\N
6910	256	1833	2012-11-22 16:30:00	13.300000000000001	\N	\N	\N
6911	257	1833	2012-11-22 16:30:00	9.4000000000000004	\N	\N	\N
6912	241	1833	2012-11-22 16:30:00	9.8000000000000007	\N	10.1	10.1
6913	252	1834	2012-11-22 17:00:00	20.100000000000001	19.600000000000001	\N	\N
6914	256	1834	2012-11-22 17:00:00	13.300000000000001	\N	\N	\N
6915	257	1834	2012-11-22 17:00:00	9.4000000000000004	\N	\N	\N
6916	241	1834	2012-11-22 17:00:00	9.6999999999999993	\N	9.9000000000000004	9.9000000000000004
6917	252	1835	2012-11-22 17:30:00	20.300000000000001	19.800000000000001	\N	\N
6918	256	1835	2012-11-22 17:30:00	13.9	\N	\N	\N
6919	257	1835	2012-11-22 17:30:00	9.4000000000000004	\N	\N	\N
6920	241	1835	2012-11-22 17:30:00	9.5999999999999996	\N	9.8000000000000007	9.8000000000000007
6921	252	1836	2012-11-22 18:00:00	20.5	19.899999999999999	\N	\N
6922	256	1836	2012-11-22 18:00:00	13.9	\N	\N	\N
6923	257	1836	2012-11-22 18:00:00	9.4000000000000004	\N	\N	\N
6924	241	1836	2012-11-22 18:00:00	9.4000000000000004	\N	9.6999999999999993	9.6999999999999993
6925	252	1837	2012-11-22 18:30:00	20.699999999999999	20.100000000000001	\N	\N
6926	256	1837	2012-11-22 18:30:00	13.9	\N	\N	\N
6927	257	1837	2012-11-22 18:30:00	9.4000000000000004	\N	\N	\N
6928	241	1837	2012-11-22 18:30:00	9.3000000000000007	\N	9.5999999999999996	9.5999999999999996
6929	252	1838	2012-11-22 19:00:00	20.800000000000001	20.100000000000001	\N	\N
6930	256	1838	2012-11-22 19:00:00	13.9	\N	\N	\N
6931	257	1838	2012-11-22 19:00:00	9.4000000000000004	\N	\N	\N
6932	241	1838	2012-11-22 19:00:00	9.3000000000000007	\N	9.5	9.5
6933	252	1839	2012-11-22 19:30:00	20.699999999999999	20.100000000000001	\N	\N
6934	256	1839	2012-11-22 19:30:00	13.9	\N	\N	\N
6935	257	1839	2012-11-22 19:30:00	9.4000000000000004	\N	\N	\N
6936	241	1839	2012-11-22 19:30:00	9.1999999999999993	\N	9.4000000000000004	9.4000000000000004
6937	252	1840	2012-11-22 20:00:00	20.699999999999999	20.100000000000001	\N	\N
6938	256	1840	2012-11-22 20:00:00	13.9	\N	\N	\N
6939	257	1840	2012-11-22 20:00:00	9.4000000000000004	\N	\N	\N
6940	241	1840	2012-11-22 20:00:00	9.0999999999999996	\N	9.3000000000000007	9.3000000000000007
6941	252	1841	2012-11-22 20:30:00	20.800000000000001	20.100000000000001	\N	\N
6942	256	1841	2012-11-22 20:30:00	13.9	\N	\N	\N
6943	257	1841	2012-11-22 20:30:00	9.4000000000000004	\N	\N	\N
6944	241	1841	2012-11-22 20:30:00	9	\N	9.1999999999999993	9.1999999999999993
6945	252	1842	2012-11-22 21:00:00	20.899999999999999	20.199999999999999	\N	\N
6946	256	1842	2012-11-22 21:00:00	13.9	\N	\N	\N
6947	257	1842	2012-11-22 21:00:00	9.4000000000000004	\N	\N	\N
6948	241	1842	2012-11-22 21:00:00	8.9000000000000004	\N	9.1999999999999993	9.1999999999999993
6949	252	1843	2012-11-22 21:30:00	20.899999999999999	20.199999999999999	\N	\N
6950	256	1843	2012-11-22 21:30:00	13.9	\N	\N	\N
6951	257	1843	2012-11-22 21:30:00	9.4000000000000004	\N	\N	\N
6952	241	1843	2012-11-22 21:30:00	8.9000000000000004	\N	9.0999999999999996	9.0999999999999996
6953	252	1844	2012-11-22 22:00:00	20.899999999999999	20.199999999999999	\N	\N
6954	256	1844	2012-11-22 22:00:00	13.9	\N	\N	\N
6955	257	1844	2012-11-22 22:00:00	9.4000000000000004	\N	\N	\N
6956	241	1844	2012-11-22 22:00:00	8.8000000000000007	\N	9.0999999999999996	9.0999999999999996
6957	252	1845	2012-11-22 22:30:00	20.899999999999999	20.199999999999999	\N	\N
6958	256	1845	2012-11-22 22:30:00	13.9	\N	\N	\N
6959	257	1845	2012-11-22 22:30:00	9.4000000000000004	\N	\N	\N
6960	241	1845	2012-11-22 22:30:00	8.8000000000000007	\N	9.0999999999999996	9.0999999999999996
6961	252	1846	2012-11-22 23:00:00	20.899999999999999	20.100000000000001	\N	\N
6962	256	1846	2012-11-22 23:00:00	13.9	\N	\N	\N
6963	257	1846	2012-11-22 23:00:00	9.4000000000000004	\N	\N	\N
6964	241	1846	2012-11-22 23:00:00	8.8000000000000007	\N	9	9
6965	252	1847	2012-11-22 23:30:00	20.800000000000001	20	\N	\N
6966	256	1847	2012-11-22 23:30:00	13.9	\N	\N	\N
6967	257	1847	2012-11-22 23:30:00	9.4000000000000004	\N	\N	\N
6968	241	1847	2012-11-22 23:30:00	8.6999999999999993	\N	8.9000000000000004	8.9000000000000004
6969	252	1848	2012-11-23 00:00:00	20.699999999999999	19.899999999999999	\N	\N
6970	256	1848	2012-11-23 00:00:00	13.9	\N	\N	\N
6971	257	1848	2012-11-23 00:00:00	9.4000000000000004	\N	\N	\N
6972	241	1848	2012-11-23 00:00:00	8.5999999999999996	\N	8.8000000000000007	8.8000000000000007
6973	252	1849	2012-11-23 00:30:00	20.600000000000001	19.899999999999999	\N	\N
6974	256	1849	2012-11-23 00:30:00	13.9	\N	\N	\N
6975	257	1849	2012-11-23 00:30:00	9.4000000000000004	\N	\N	\N
6976	241	1849	2012-11-23 00:30:00	8.5999999999999996	\N	8.6999999999999993	8.6999999999999993
6977	252	1850	2012-11-23 01:00:00	20.5	19.800000000000001	\N	\N
6978	256	1850	2012-11-23 01:00:00	13.9	\N	\N	\N
6979	257	1850	2012-11-23 01:00:00	9.4000000000000004	\N	\N	\N
6980	241	1850	2012-11-23 01:00:00	8.4000000000000004	\N	8.5999999999999996	8.5999999999999996
6981	252	1851	2012-11-23 01:30:00	20.399999999999999	19.699999999999999	\N	\N
6982	256	1851	2012-11-23 01:30:00	13.300000000000001	\N	\N	\N
6983	257	1851	2012-11-23 01:30:00	9.4000000000000004	\N	\N	\N
6984	241	1851	2012-11-23 01:30:00	8.3000000000000007	\N	8.5	8.5
6985	252	1852	2012-11-23 02:00:00	20.399999999999999	19.699999999999999	\N	\N
6986	256	1852	2012-11-23 02:00:00	13.300000000000001	\N	\N	\N
6987	257	1852	2012-11-23 02:00:00	9.4000000000000004	\N	\N	\N
6988	241	1852	2012-11-23 02:00:00	8.3000000000000007	\N	8.4000000000000004	8.4000000000000004
6989	252	1853	2012-11-23 02:30:00	20.300000000000001	19.600000000000001	\N	\N
6990	256	1853	2012-11-23 02:30:00	13.300000000000001	\N	\N	\N
6991	257	1853	2012-11-23 02:30:00	9.4000000000000004	\N	\N	\N
6992	241	1853	2012-11-23 02:30:00	8.1999999999999993	\N	8.4000000000000004	8.4000000000000004
6993	252	1854	2012-11-23 03:00:00	20.199999999999999	19.600000000000001	\N	\N
6994	256	1854	2012-11-23 03:00:00	13.300000000000001	\N	\N	\N
6995	257	1854	2012-11-23 03:00:00	9.4000000000000004	\N	\N	\N
6996	241	1854	2012-11-23 03:00:00	8.1999999999999993	\N	8.4000000000000004	8.4000000000000004
6997	252	1855	2012-11-23 03:30:00	20.100000000000001	19.399999999999999	\N	\N
6998	256	1855	2012-11-23 03:30:00	13.300000000000001	\N	\N	\N
6999	257	1855	2012-11-23 03:30:00	9.4000000000000004	\N	\N	\N
7000	241	1855	2012-11-23 03:30:00	8.1999999999999993	\N	8.3000000000000007	8.3000000000000007
7001	252	1856	2012-11-23 04:00:00	20	19.300000000000001	\N	\N
7028	241	1862	2012-11-23 07:00:00	8	\N	8.1999999999999993	8.1999999999999993
7030	256	1863	2012-11-23 07:30:00	13.300000000000001	\N	\N	\N
7044	241	1866	2012-11-23 09:00:00	8.3000000000000007	\N	8.5999999999999996	8.5999999999999996
7046	256	1867	2012-11-23 09:30:00	12.800000000000001	\N	\N	\N
7049	252	1868	2012-11-23 10:00:00	19.300000000000001	18.399999999999999	\N	\N
7052	241	1868	2012-11-23 10:00:00	8.6999999999999993	\N	8.9000000000000004	8.9000000000000004
7054	256	1869	2012-11-23 10:30:00	12.800000000000001	\N	\N	\N
7062	256	1871	2012-11-23 11:30:00	13.9	\N	\N	\N
7065	252	1872	2012-11-23 12:00:00	20.300000000000001	19.899999999999999	\N	\N
7076	241	1874	2012-11-23 13:00:00	9.8000000000000007	\N	10.1	10.1
7078	256	1875	2012-11-23 13:30:00	13.9	\N	\N	\N
7091	257	1878	2012-11-23 15:00:00	9.4000000000000004	\N	\N	\N
7139	257	1890	2012-11-23 21:00:00	9.4000000000000004	\N	\N	\N
7141	252	1891	2012-11-23 21:30:00	21.899999999999999	21.399999999999999	\N	\N
7147	257	1892	2012-11-23 22:00:00	9.4000000000000004	\N	\N	\N
7155	257	1894	2012-11-23 23:00:00	9.4000000000000004	\N	\N	\N
7163	257	1896	2012-11-24 00:00:00	9.4000000000000004	\N	\N	\N
7176	241	1899	2012-11-24 01:30:00	7.9000000000000004	\N	8.1999999999999993	8.1999999999999993
7178	256	1900	2012-11-24 02:00:00	13.9	\N	\N	\N
7181	252	1901	2012-11-24 02:30:00	21.199999999999999	20.399999999999999	\N	\N
7187	257	1902	2012-11-24 03:00:00	9.4000000000000004	\N	\N	\N
7200	241	1905	2012-11-24 04:30:00	5.9000000000000004	\N	6.0999999999999996	6.0999999999999996
7208	241	1907	2012-11-24 05:30:00	6.2000000000000002	\N	6.2999999999999998	6.2999999999999998
7210	256	1908	2012-11-24 06:00:00	13.9	\N	\N	\N
7213	252	1909	2012-11-24 06:30:00	20.800000000000001	20	\N	\N
7240	241	1915	2012-11-24 09:30:00	9.1999999999999993	\N	9.4000000000000004	9.4000000000000004
7297	252	1930	2012-11-24 17:00:00	20.699999999999999	19.800000000000001	\N	\N
7327	257	1937	2012-11-24 20:30:00	9.4000000000000004	\N	\N	\N
7335	257	1939	2012-11-24 21:30:00	9.4000000000000004	\N	\N	\N
7359	257	1945	2012-11-25 00:30:00	8.9000000000000004	\N	\N	\N
7361	252	1946	2012-11-25 01:00:00	19.399999999999999	18.600000000000001	\N	\N
7367	257	1947	2012-11-25 01:30:00	8.9000000000000004	\N	\N	\N
7375	257	1949	2012-11-25 02:30:00	8.9000000000000004	\N	\N	\N
7383	257	1951	2012-11-25 03:30:00	8.3000000000000007	\N	\N	\N
7391	257	1953	2012-11-25 04:30:00	8.3000000000000007	\N	\N	\N
7406	256	1957	2012-11-25 06:30:00	12.199999999999999	\N	\N	\N
7409	252	1958	2012-11-25 07:00:00	18.5	17.399999999999999	\N	\N
7412	241	1958	2012-11-25 07:00:00	3.2000000000000002	\N	3.2999999999999998	3.2999999999999998
7414	256	1959	2012-11-25 07:30:00	12.199999999999999	\N	\N	\N
7417	252	1960	2012-11-25 08:00:00	18.300000000000001	17.199999999999999	\N	\N
7423	257	1961	2012-11-25 08:30:00	8.3000000000000007	\N	\N	\N
7431	257	1963	2012-11-25 09:30:00	8.3000000000000007	\N	\N	\N
7433	252	1964	2012-11-25 10:00:00	18.100000000000001	17	\N	\N
7436	241	1964	2012-11-25 10:00:00	5.0999999999999996	\N	5.2000000000000002	5.2000000000000002
7438	256	1965	2012-11-25 10:30:00	12.199999999999999	\N	\N	\N
7458	256	1970	2012-11-25 13:00:00	12.800000000000001	\N	\N	\N
7468	241	1972	2012-11-25 14:00:00	10.199999999999999	\N	10.4	10.4
7470	256	1973	2012-11-25 14:30:00	12.800000000000001	\N	\N	\N
7473	252	1974	2012-11-25 15:00:00	19.300000000000001	18.399999999999999	\N	\N
7479	257	1975	2012-11-25 15:30:00	8.9000000000000004	\N	\N	\N
7481	252	1976	2012-11-25 16:00:00	19.600000000000001	18.699999999999999	\N	\N
7508	241	1982	2012-11-25 19:00:00	7.7999999999999998	\N	8	8
7510	256	1983	2012-11-25 19:30:00	13.300000000000001	\N	\N	\N
7524	241	1986	2012-11-25 21:00:00	7.7000000000000002	\N	7.9000000000000004	7.9000000000000004
7526	256	1987	2012-11-25 21:30:00	13.300000000000001	\N	\N	\N
7529	252	1988	2012-11-25 22:00:00	20.100000000000001	19.300000000000001	\N	\N
7532	241	1988	2012-11-25 22:00:00	7.4000000000000004	\N	7.5999999999999996	7.5999999999999996
7534	256	1989	2012-11-25 22:30:00	13.300000000000001	\N	\N	\N
7542	256	1991	2012-11-25 23:30:00	13.300000000000001	\N	\N	\N
7545	252	1992	2012-11-26 00:00:00	19.800000000000001	19.100000000000001	\N	\N
7556	241	1994	2012-11-26 01:00:00	6.5999999999999996	\N	6.7999999999999998	6.7999999999999998
7558	256	1995	2012-11-26 01:30:00	12.800000000000001	\N	\N	\N
7571	257	1998	2012-11-26 03:00:00	8.9000000000000004	\N	\N	\N
7619	257	2010	2012-11-26 09:00:00	8.9000000000000004	\N	\N	\N
7621	252	2011	2012-11-26 09:30:00	18.600000000000001	17.5	\N	\N
7627	257	2012	2012-11-26 10:00:00	8.9000000000000004	\N	\N	\N
7635	257	2014	2012-11-26 11:00:00	8.9000000000000004	\N	\N	\N
7643	257	2016	2012-11-26 12:00:00	8.9000000000000004	\N	\N	\N
7648	241	2017	2012-11-26 12:30:00	13.6	\N	13.300000000000001	12.4
7664	241	2021	2012-11-26 14:30:00	16.300000000000001	\N	15.9	15.9
7696	241	2029	2012-11-26 18:30:00	13.699999999999999	\N	13.4	12.800000000000001
7702	256	2031	2012-11-26 19:30:00	13.9	\N	\N	\N
7705	252	2032	2012-11-26 20:00:00	19.699999999999999	18.899999999999999	\N	\N
7718	256	2035	2012-11-26 21:30:00	13.9	\N	\N	\N
7721	252	2036	2012-11-26 22:00:00	19.600000000000001	18.699999999999999	\N	\N
7740	241	2040	2012-11-27 00:00:00	11.699999999999999	\N	11.6	11.6
7747	257	2042	2012-11-27 01:00:00	9.4000000000000004	\N	\N	\N
7768	241	2047	2012-11-27 03:30:00	12.4	\N	12.1	9.5999999999999996
7770	256	2048	2012-11-27 04:00:00	13.300000000000001	\N	\N	\N
7773	252	2049	2012-11-27 04:30:00	19.100000000000001	18.199999999999999	\N	\N
7779	257	2050	2012-11-27 05:00:00	9.4000000000000004	\N	\N	\N
7786	256	2052	2012-11-27 06:00:00	13.300000000000001	\N	\N	\N
7789	252	2053	2012-11-27 06:30:00	18.899999999999999	17.899999999999999	\N	\N
7816	241	2059	2012-11-27 09:30:00	13.300000000000001	\N	12.800000000000001	10.699999999999999
7822	256	2061	2012-11-27 10:30:00	13.300000000000001	\N	\N	\N
7827	257	2062	2012-11-27 11:00:00	9.4000000000000004	\N	\N	\N
7829	252	2063	2012-11-27 11:30:00	18.699999999999999	17.699999999999999	\N	\N
7831	257	2063	2012-11-27 11:30:00	9.4000000000000004	\N	\N	\N
7835	257	2064	2012-11-27 12:00:00	9.4000000000000004	\N	\N	\N
7837	252	2065	2012-11-27 12:30:00	18.699999999999999	17.699999999999999	\N	\N
7845	252	2067	2012-11-27 13:30:00	18.800000000000001	17.800000000000001	\N	\N
7002	256	1856	2012-11-23 04:00:00	13.300000000000001	\N	\N	\N
7005	252	1857	2012-11-23 04:30:00	19.899999999999999	19.300000000000001	\N	\N
7024	241	1861	2012-11-23 06:30:00	8	\N	8.1999999999999993	8.1999999999999993
7026	256	1862	2012-11-23 07:00:00	13.300000000000001	\N	\N	\N
7029	252	1863	2012-11-23 07:30:00	19.600000000000001	18.800000000000001	\N	\N
7032	241	1863	2012-11-23 07:30:00	8	\N	8.1999999999999993	8.1999999999999993
7084	241	1876	2012-11-23 14:00:00	10.199999999999999	\N	10.4	10.4
7100	241	1880	2012-11-23 16:00:00	9.5999999999999996	\N	9.8000000000000007	9.8000000000000007
7102	256	1881	2012-11-23 16:30:00	14.4	\N	\N	\N
7105	252	1882	2012-11-23 17:00:00	21.199999999999999	20.399999999999999	\N	\N
7115	257	1884	2012-11-23 18:00:00	9.4000000000000004	\N	\N	\N
7123	257	1886	2012-11-23 19:00:00	9.4000000000000004	\N	\N	\N
7131	257	1888	2012-11-23 20:00:00	9.4000000000000004	\N	\N	\N
7168	241	1897	2012-11-24 00:30:00	7.7999999999999998	\N	8	8
7170	256	1898	2012-11-24 01:00:00	14.4	\N	\N	\N
7173	252	1899	2012-11-24 01:30:00	21.300000000000001	20.600000000000001	\N	\N
7179	257	1900	2012-11-24 02:00:00	9.4000000000000004	\N	\N	\N
7194	256	1904	2012-11-24 04:00:00	13.9	\N	\N	\N
7197	252	1905	2012-11-24 04:30:00	21.100000000000001	20.199999999999999	\N	\N
7202	256	1906	2012-11-24 05:00:00	13.9	\N	\N	\N
7205	252	1907	2012-11-24 05:30:00	20.899999999999999	20.100000000000001	\N	\N
7216	241	1909	2012-11-24 06:30:00	6.2000000000000002	\N	6.2999999999999998	6.2999999999999998
7220	241	1910	2012-11-24 07:00:00	6.0999999999999996	\N	6.2000000000000002	6.2000000000000002
7224	241	1911	2012-11-24 07:30:00	6.4000000000000004	\N	6.5999999999999996	6.5999999999999996
7226	256	1912	2012-11-24 08:00:00	13.9	\N	\N	\N
7229	252	1913	2012-11-24 08:30:00	20.399999999999999	19.600000000000001	\N	\N
7232	241	1913	2012-11-24 08:30:00	7.5999999999999996	\N	7.7000000000000002	7.7000000000000002
7234	256	1914	2012-11-24 09:00:00	13.300000000000001	\N	\N	\N
7237	252	1915	2012-11-24 09:30:00	20.300000000000001	19.5	\N	\N
7242	256	1916	2012-11-24 10:00:00	13.300000000000001	\N	\N	\N
7245	252	1917	2012-11-24 10:30:00	20.199999999999999	19.5	\N	\N
7264	241	1921	2012-11-24 12:30:00	12.199999999999999	\N	12.1	12.1
7266	256	1922	2012-11-24 13:00:00	14.4	\N	\N	\N
7269	252	1923	2012-11-24 13:30:00	20.699999999999999	19.899999999999999	\N	\N
7272	241	1923	2012-11-24 13:30:00	12.300000000000001	\N	12.1	12.1
7324	241	1936	2012-11-24 20:00:00	4.4000000000000004	\N	4.4000000000000004	4.4000000000000004
7340	241	1940	2012-11-24 22:00:00	3.7000000000000002	\N	3.7000000000000002	3.7000000000000002
7342	256	1941	2012-11-24 22:30:00	13.300000000000001	\N	\N	\N
7345	252	1942	2012-11-24 23:00:00	19.699999999999999	18.899999999999999	\N	\N
7355	257	1944	2012-11-25 00:00:00	8.9000000000000004	\N	\N	\N
7363	257	1946	2012-11-25 01:00:00	8.9000000000000004	\N	\N	\N
7371	257	1948	2012-11-25 02:00:00	8.9000000000000004	\N	\N	\N
7408	241	1957	2012-11-25 06:30:00	3.3999999999999999	\N	3.5	3.5
7410	256	1958	2012-11-25 07:00:00	12.199999999999999	\N	\N	\N
7413	252	1959	2012-11-25 07:30:00	18.399999999999999	17.300000000000001	\N	\N
7419	257	1960	2012-11-25 08:00:00	8.3000000000000007	\N	\N	\N
7434	256	1964	2012-11-25 10:00:00	11.699999999999999	\N	\N	\N
7437	252	1965	2012-11-25 10:30:00	18.399999999999999	17.300000000000001	\N	\N
7442	256	1966	2012-11-25 11:00:00	12.800000000000001	\N	\N	\N
7445	252	1967	2012-11-25 11:30:00	18.800000000000001	17.800000000000001	\N	\N
7456	241	1969	2012-11-25 12:30:00	9.4000000000000004	\N	9.6999999999999993	9.6999999999999993
7460	241	1970	2012-11-25 13:00:00	10.1	\N	10.300000000000001	10.300000000000001
7464	241	1971	2012-11-25 13:30:00	10.4	\N	10.6	10.6
7466	256	1972	2012-11-25 14:00:00	12.800000000000001	\N	\N	\N
7469	252	1973	2012-11-25 14:30:00	19.100000000000001	18.199999999999999	\N	\N
7472	241	1973	2012-11-25 14:30:00	9.8000000000000007	\N	10.1	10.1
7474	256	1974	2012-11-25 15:00:00	13.300000000000001	\N	\N	\N
7477	252	1975	2012-11-25 15:30:00	19.399999999999999	18.600000000000001	\N	\N
7482	256	1976	2012-11-25 16:00:00	13.300000000000001	\N	\N	\N
7485	252	1977	2012-11-25 16:30:00	19.699999999999999	18.800000000000001	\N	\N
7504	241	1981	2012-11-25 18:30:00	7.9000000000000004	\N	8.1999999999999993	8.1999999999999993
7506	256	1982	2012-11-25 19:00:00	13.300000000000001	\N	\N	\N
7509	252	1983	2012-11-25 19:30:00	20.100000000000001	19.300000000000001	\N	\N
7512	241	1983	2012-11-25 19:30:00	7.7999999999999998	\N	8	8
7564	241	1996	2012-11-26 02:00:00	6.5999999999999996	\N	6.7000000000000002	6.7000000000000002
7580	241	2000	2012-11-26 04:00:00	6.2000000000000002	\N	6.2999999999999998	6.2999999999999998
7582	256	2001	2012-11-26 04:30:00	12.800000000000001	\N	\N	\N
7585	252	2002	2012-11-26 05:00:00	19.100000000000001	18.199999999999999	\N	\N
7595	257	2004	2012-11-26 06:00:00	8.9000000000000004	\N	\N	\N
7603	257	2006	2012-11-26 07:00:00	8.9000000000000004	\N	\N	\N
7611	257	2008	2012-11-26 08:00:00	8.9000000000000004	\N	\N	\N
7655	257	2019	2012-11-26 13:30:00	9.4000000000000004	\N	\N	\N
7666	256	2022	2012-11-26 15:00:00	13.9	\N	\N	\N
7669	252	2023	2012-11-26 15:30:00	19.600000000000001	18.699999999999999	\N	\N
7673	252	2024	2012-11-26 16:00:00	19.600000000000001	18.800000000000001	\N	\N
7690	256	2028	2012-11-26 18:00:00	13.9	\N	\N	\N
7695	257	2029	2012-11-26 18:30:00	10	\N	\N	\N
7699	257	2030	2012-11-26 19:00:00	10	\N	\N	\N
7701	252	2031	2012-11-26 19:30:00	19.800000000000001	19.100000000000001	\N	\N
7712	241	2033	2012-11-26 20:30:00	11.699999999999999	\N	11.6	11.199999999999999
7723	257	2036	2012-11-26 22:00:00	9.4000000000000004	\N	\N	\N
7725	252	2037	2012-11-26 22:30:00	19.600000000000001	18.699999999999999	\N	\N
7733	252	2039	2012-11-26 23:30:00	19.399999999999999	18.600000000000001	\N	\N
7741	252	2041	2012-11-27 00:30:00	19.399999999999999	18.600000000000001	\N	\N
7748	241	2042	2012-11-27 01:00:00	11.800000000000001	\N	11.6	11.300000000000001
7757	252	2045	2012-11-27 02:30:00	19.199999999999999	18.300000000000001	\N	\N
7764	241	2046	2012-11-27 03:00:00	12.699999999999999	\N	12.300000000000001	9.8000000000000007
7775	257	2049	2012-11-27 04:30:00	9.4000000000000004	\N	\N	\N
7778	256	2050	2012-11-27 05:00:00	13.300000000000001	\N	\N	\N
7784	241	2051	2012-11-27 05:30:00	11.1	\N	10.9	9.8000000000000007
7801	252	2056	2012-11-27 08:00:00	18.800000000000001	17.800000000000001	\N	\N
7818	256	2060	2012-11-27 10:00:00	13.300000000000001	\N	\N	\N
7826	256	2062	2012-11-27 11:00:00	13.300000000000001	\N	\N	\N
7840	241	2065	2012-11-27 12:30:00	16.800000000000001	\N	16.199999999999999	16.199999999999999
7842	256	2066	2012-11-27 13:00:00	13.300000000000001	\N	\N	\N
7003	257	1856	2012-11-23 04:00:00	9.4000000000000004	\N	\N	\N
7016	241	1859	2012-11-23 05:30:00	8.0999999999999996	\N	8.1999999999999993	8.1999999999999993
7018	256	1860	2012-11-23 06:00:00	13.300000000000001	\N	\N	\N
7021	252	1861	2012-11-23 06:30:00	19.699999999999999	18.899999999999999	\N	\N
7027	257	1862	2012-11-23 07:00:00	9.4000000000000004	\N	\N	\N
7040	241	1865	2012-11-23 08:30:00	8.1999999999999993	\N	8.4000000000000004	8.4000000000000004
7048	241	1867	2012-11-23 09:30:00	8.5	\N	8.6999999999999993	8.6999999999999993
7050	256	1868	2012-11-23 10:00:00	12.800000000000001	\N	\N	\N
7053	252	1869	2012-11-23 10:30:00	19.300000000000001	18.399999999999999	\N	\N
7080	241	1875	2012-11-23 13:30:00	10.1	\N	10.300000000000001	10.300000000000001
7137	252	1890	2012-11-23 21:00:00	22	21.600000000000001	\N	\N
7167	257	1897	2012-11-24 00:30:00	9.4000000000000004	\N	\N	\N
7175	257	1899	2012-11-24 01:30:00	9.4000000000000004	\N	\N	\N
7199	257	1905	2012-11-24 04:30:00	9.4000000000000004	\N	\N	\N
7201	252	1906	2012-11-24 05:00:00	20.899999999999999	20.100000000000001	\N	\N
7207	257	1907	2012-11-24 05:30:00	9.4000000000000004	\N	\N	\N
7215	257	1909	2012-11-24 06:30:00	8.9000000000000004	\N	\N	\N
7223	257	1911	2012-11-24 07:30:00	8.9000000000000004	\N	\N	\N
7231	257	1913	2012-11-24 08:30:00	8.9000000000000004	\N	\N	\N
7246	256	1917	2012-11-24 10:30:00	13.300000000000001	\N	\N	\N
7249	252	1918	2012-11-24 11:00:00	20.199999999999999	19.600000000000001	\N	\N
7252	241	1918	2012-11-24 11:00:00	11.6	\N	11.6	11.6
7254	256	1919	2012-11-24 11:30:00	13.9	\N	\N	\N
7257	252	1920	2012-11-24 12:00:00	20.5	19.800000000000001	\N	\N
7263	257	1921	2012-11-24 12:30:00	9.4000000000000004	\N	\N	\N
7271	257	1923	2012-11-24 13:30:00	9.4000000000000004	\N	\N	\N
7273	252	1924	2012-11-24 14:00:00	20.699999999999999	19.899999999999999	\N	\N
7276	241	1924	2012-11-24 14:00:00	12.300000000000001	\N	12.1	12.1
7278	256	1925	2012-11-24 14:30:00	14.4	\N	\N	\N
7298	256	1930	2012-11-24 17:00:00	14.4	\N	\N	\N
7308	241	1932	2012-11-24 18:00:00	7.2000000000000002	\N	7.2999999999999998	7.2999999999999998
7310	256	1933	2012-11-24 18:30:00	13.9	\N	\N	\N
7313	252	1934	2012-11-24 19:00:00	20.399999999999999	19.600000000000001	\N	\N
7319	257	1935	2012-11-24 19:30:00	9.4000000000000004	\N	\N	\N
7321	252	1936	2012-11-24 20:00:00	20.300000000000001	19.5	\N	\N
7348	241	1942	2012-11-24 23:00:00	2.7999999999999998	\N	2.7999999999999998	2.7999999999999998
7350	256	1943	2012-11-24 23:30:00	13.300000000000001	\N	\N	\N
7364	241	1946	2012-11-25 01:00:00	1.8	\N	1.8	1.8
7366	256	1947	2012-11-25 01:30:00	12.800000000000001	\N	\N	\N
7369	252	1948	2012-11-25 02:00:00	19.300000000000001	18.300000000000001	\N	\N
7372	241	1948	2012-11-25 02:00:00	2.3999999999999999	\N	2.3999999999999999	2.3999999999999999
7374	256	1949	2012-11-25 02:30:00	12.800000000000001	\N	\N	\N
7382	256	1951	2012-11-25 03:30:00	12.800000000000001	\N	\N	\N
7385	252	1952	2012-11-25 04:00:00	18.899999999999999	17.899999999999999	\N	\N
7396	241	1954	2012-11-25 05:00:00	3.3999999999999999	\N	3.3999999999999999	3.3999999999999999
7398	256	1955	2012-11-25 05:30:00	12.199999999999999	\N	\N	\N
7411	257	1958	2012-11-25 07:00:00	8.3000000000000007	\N	\N	\N
7459	257	1970	2012-11-25 13:00:00	8.3000000000000007	\N	\N	\N
7461	252	1971	2012-11-25 13:30:00	19.100000000000001	18.199999999999999	\N	\N
7467	257	1972	2012-11-25 14:00:00	8.3000000000000007	\N	\N	\N
7475	257	1974	2012-11-25 15:00:00	8.9000000000000004	\N	\N	\N
7483	257	1976	2012-11-25 16:00:00	8.9000000000000004	\N	\N	\N
7496	241	1979	2012-11-25 17:30:00	8	\N	8.1999999999999993	8.1999999999999993
7498	256	1980	2012-11-25 18:00:00	13.300000000000001	\N	\N	\N
7501	252	1981	2012-11-25 18:30:00	19.899999999999999	19.199999999999999	\N	\N
7507	257	1982	2012-11-25 19:00:00	8.9000000000000004	\N	\N	\N
7520	241	1985	2012-11-25 20:30:00	7.7999999999999998	\N	8	8
7528	241	1987	2012-11-25 21:30:00	7.5999999999999996	\N	7.7999999999999998	7.7999999999999998
7530	256	1988	2012-11-25 22:00:00	13.300000000000001	\N	\N	\N
7533	252	1989	2012-11-25 22:30:00	20	19.199999999999999	\N	\N
7560	241	1995	2012-11-26 01:30:00	6.5999999999999996	\N	6.7999999999999998	6.7999999999999998
7617	252	2010	2012-11-26 09:00:00	18.699999999999999	17.699999999999999	\N	\N
7645	252	2017	2012-11-26 12:30:00	19.100000000000001	18.199999999999999	\N	\N
7647	257	2017	2012-11-26 12:30:00	8.9000000000000004	\N	\N	\N
7678	256	2025	2012-11-26 16:30:00	13.9	\N	\N	\N
7694	256	2029	2012-11-26 18:30:00	13.9	\N	\N	\N
7698	256	2030	2012-11-26 19:00:00	13.9	\N	\N	\N
7708	241	2032	2012-11-26 20:00:00	12.6	\N	12.300000000000001	11.800000000000001
7724	241	2036	2012-11-26 22:00:00	11.9	\N	11.699999999999999	11.1
7726	256	2037	2012-11-26 22:30:00	13.300000000000001	\N	\N	\N
7730	256	2038	2012-11-26 23:00:00	13.300000000000001	\N	\N	\N
7735	257	2039	2012-11-26 23:30:00	9.4000000000000004	\N	\N	\N
7737	252	2040	2012-11-27 00:00:00	19.399999999999999	18.600000000000001	\N	\N
7749	252	2043	2012-11-27 01:30:00	19.399999999999999	18.600000000000001	\N	\N
7760	241	2045	2012-11-27 02:30:00	12.5	\N	12.199999999999999	9.6999999999999993
7766	256	2047	2012-11-27 03:30:00	13.300000000000001	\N	\N	\N
7769	252	2048	2012-11-27 04:00:00	19.100000000000001	18.199999999999999	\N	\N
7783	257	2051	2012-11-27 05:30:00	9.4000000000000004	\N	\N	\N
7788	241	2052	2012-11-27 06:00:00	10.6	\N	10.6	10
7794	256	2054	2012-11-27 07:00:00	13.300000000000001	\N	\N	\N
7799	257	2055	2012-11-27 07:30:00	9.4000000000000004	\N	\N	\N
7810	256	2058	2012-11-27 09:00:00	13.300000000000001	\N	\N	\N
7820	241	2060	2012-11-27 10:00:00	14.6	\N	14.1	13.1
7823	257	2061	2012-11-27 10:30:00	9.4000000000000004	\N	\N	\N
7832	241	2063	2012-11-27 11:30:00	16.100000000000001	\N	15.4	15.300000000000001
7834	256	2064	2012-11-27 12:00:00	13.300000000000001	\N	\N	\N
7004	241	1856	2012-11-23 04:00:00	8.1999999999999993	\N	8.3000000000000007	8.3000000000000007
7020	241	1860	2012-11-23 06:00:00	8.0999999999999996	\N	8.1999999999999993	8.1999999999999993
7022	256	1861	2012-11-23 06:30:00	13.300000000000001	\N	\N	\N
7025	252	1862	2012-11-23 07:00:00	19.699999999999999	18.899999999999999	\N	\N
7035	257	1864	2012-11-23 08:00:00	9.4000000000000004	\N	\N	\N
7043	257	1866	2012-11-23 09:00:00	9.4000000000000004	\N	\N	\N
7051	257	1868	2012-11-23 10:00:00	9.4000000000000004	\N	\N	\N
7088	241	1877	2012-11-23 14:30:00	10.1	\N	10.300000000000001	10.300000000000001
7090	256	1878	2012-11-23 15:00:00	14.4	\N	\N	\N
7093	252	1879	2012-11-23 15:30:00	20.899999999999999	20.199999999999999	\N	\N
7099	257	1880	2012-11-23 16:00:00	9.4000000000000004	\N	\N	\N
7114	256	1884	2012-11-23 18:00:00	15	\N	\N	\N
7117	252	1885	2012-11-23 18:30:00	21.600000000000001	21	\N	\N
7122	256	1886	2012-11-23 19:00:00	15	\N	\N	\N
7125	252	1887	2012-11-23 19:30:00	21.800000000000001	21.199999999999999	\N	\N
7136	241	1889	2012-11-23 20:30:00	8.9000000000000004	\N	9.1999999999999993	9.1999999999999993
7140	241	1890	2012-11-23 21:00:00	8.8000000000000007	\N	9.0999999999999996	9.0999999999999996
7144	241	1891	2012-11-23 21:30:00	8.8000000000000007	\N	9.0999999999999996	9.0999999999999996
7146	256	1892	2012-11-23 22:00:00	14.4	\N	\N	\N
7149	252	1893	2012-11-23 22:30:00	21.699999999999999	21.199999999999999	\N	\N
7152	241	1893	2012-11-23 22:30:00	8.8000000000000007	\N	9.0999999999999996	9.0999999999999996
7154	256	1894	2012-11-23 23:00:00	14.4	\N	\N	\N
7157	252	1895	2012-11-23 23:30:00	21.5	20.800000000000001	\N	\N
7162	256	1896	2012-11-24 00:00:00	14.4	\N	\N	\N
7165	252	1897	2012-11-24 00:30:00	21.399999999999999	20.800000000000001	\N	\N
7184	241	1901	2012-11-24 02:30:00	7.4000000000000004	\N	7.5999999999999996	7.5999999999999996
7186	256	1902	2012-11-24 03:00:00	14.4	\N	\N	\N
7189	252	1903	2012-11-24 03:30:00	21.199999999999999	20.300000000000001	\N	\N
7192	241	1903	2012-11-24 03:30:00	6.7000000000000002	\N	6.7999999999999998	6.7999999999999998
7244	241	1916	2012-11-24 10:00:00	9.9000000000000004	\N	10.300000000000001	10.300000000000001
7260	241	1920	2012-11-24 12:00:00	11.800000000000001	\N	11.699999999999999	11.699999999999999
7262	256	1921	2012-11-24 12:30:00	13.9	\N	\N	\N
7265	252	1922	2012-11-24 13:00:00	20.600000000000001	19.800000000000001	\N	\N
7275	257	1924	2012-11-24 14:00:00	9.4000000000000004	\N	\N	\N
7283	257	1926	2012-11-24 15:00:00	9.4000000000000004	\N	\N	\N
7291	257	1928	2012-11-24 16:00:00	10	\N	\N	\N
7328	241	1937	2012-11-24 20:30:00	4.2000000000000002	\N	4.2000000000000002	4.2000000000000002
7330	256	1938	2012-11-24 21:00:00	13.9	\N	\N	\N
7333	252	1939	2012-11-24 21:30:00	20	19.199999999999999	\N	\N
7339	257	1940	2012-11-24 22:00:00	9.4000000000000004	\N	\N	\N
7354	256	1944	2012-11-25 00:00:00	13.300000000000001	\N	\N	\N
7357	252	1945	2012-11-25 00:30:00	19.600000000000001	18.699999999999999	\N	\N
7362	256	1946	2012-11-25 01:00:00	12.800000000000001	\N	\N	\N
7365	252	1947	2012-11-25 01:30:00	19.399999999999999	18.5	\N	\N
7376	241	1949	2012-11-25 02:30:00	2.7999999999999998	\N	2.8999999999999999	2.8999999999999999
7380	241	1950	2012-11-25 03:00:00	3	\N	3.1000000000000001	3.1000000000000001
7384	241	1951	2012-11-25 03:30:00	3	\N	3	3
7386	256	1952	2012-11-25 04:00:00	12.199999999999999	\N	\N	\N
7389	252	1953	2012-11-25 04:30:00	18.800000000000001	17.800000000000001	\N	\N
7392	241	1953	2012-11-25 04:30:00	3.3999999999999999	\N	3.5	3.5
7394	256	1954	2012-11-25 05:00:00	12.199999999999999	\N	\N	\N
7397	252	1955	2012-11-25 05:30:00	18.699999999999999	17.600000000000001	\N	\N
7402	256	1956	2012-11-25 06:00:00	12.199999999999999	\N	\N	\N
7405	252	1957	2012-11-25 06:30:00	18.600000000000001	17.399999999999999	\N	\N
7424	241	1961	2012-11-25 08:30:00	3.2999999999999998	\N	3.3999999999999999	3.3999999999999999
7426	256	1962	2012-11-25 09:00:00	11.699999999999999	\N	\N	\N
7429	252	1963	2012-11-25 09:30:00	18.100000000000001	16.899999999999999	\N	\N
7432	241	1963	2012-11-25 09:30:00	4.4000000000000004	\N	4.5	4.5
7484	241	1976	2012-11-25 16:00:00	8.1999999999999993	\N	8.4000000000000004	8.4000000000000004
7500	241	1980	2012-11-25 18:00:00	8.0999999999999996	\N	8.3000000000000007	8.3000000000000007
7502	256	1981	2012-11-25 18:30:00	13.300000000000001	\N	\N	\N
7505	252	1982	2012-11-25 19:00:00	20	19.199999999999999	\N	\N
7515	257	1984	2012-11-25 20:00:00	8.9000000000000004	\N	\N	\N
7523	257	1986	2012-11-25 21:00:00	8.9000000000000004	\N	\N	\N
7531	257	1988	2012-11-25 22:00:00	8.9000000000000004	\N	\N	\N
7568	241	1997	2012-11-26 02:30:00	6.5	\N	6.7000000000000002	6.7000000000000002
7570	256	1998	2012-11-26 03:00:00	12.800000000000001	\N	\N	\N
7573	252	1999	2012-11-26 03:30:00	19.300000000000001	18.300000000000001	\N	\N
7579	257	2000	2012-11-26 04:00:00	8.9000000000000004	\N	\N	\N
7594	256	2004	2012-11-26 06:00:00	12.800000000000001	\N	\N	\N
7597	252	2005	2012-11-26 06:30:00	18.899999999999999	17.899999999999999	\N	\N
7602	256	2006	2012-11-26 07:00:00	12.199999999999999	\N	\N	\N
7605	252	2007	2012-11-26 07:30:00	18.800000000000001	17.800000000000001	\N	\N
7616	241	2009	2012-11-26 08:30:00	7.5	\N	7.7000000000000002	7.7000000000000002
7620	241	2010	2012-11-26 09:00:00	8.3000000000000007	\N	8.5999999999999996	8.5999999999999996
7624	241	2011	2012-11-26 09:30:00	10.1	\N	10.4	10.4
7626	256	2012	2012-11-26 10:00:00	12.199999999999999	\N	\N	\N
7629	252	2013	2012-11-26 10:30:00	18.699999999999999	17.699999999999999	\N	\N
7632	241	2013	2012-11-26 10:30:00	12.300000000000001	\N	12.199999999999999	11.1
7634	256	2014	2012-11-26 11:00:00	12.800000000000001	\N	\N	\N
7637	252	2015	2012-11-26 11:30:00	18.800000000000001	17.899999999999999	\N	\N
7642	256	2016	2012-11-26 12:00:00	13.300000000000001	\N	\N	\N
7658	256	2020	2012-11-26 14:00:00	13.9	\N	\N	\N
7661	252	2021	2012-11-26 14:30:00	19.399999999999999	18.600000000000001	\N	\N
7671	257	2023	2012-11-26 15:30:00	9.4000000000000004	\N	\N	\N
7675	257	2024	2012-11-26 16:00:00	9.4000000000000004	\N	\N	\N
7680	241	2025	2012-11-26 16:30:00	14.6	\N	14.199999999999999	14.199999999999999
7684	241	2026	2012-11-26 17:00:00	14.699999999999999	\N	14.300000000000001	14.300000000000001
7693	252	2029	2012-11-26 18:30:00	19.899999999999999	19.199999999999999	\N	\N
7697	252	2030	2012-11-26 19:00:00	19.800000000000001	19.100000000000001	\N	\N
7706	256	2032	2012-11-26 20:00:00	13.9	\N	\N	\N
7720	241	2035	2012-11-26 21:30:00	11.699999999999999	\N	11.5	10.800000000000001
7734	256	2039	2012-11-26 23:30:00	13.300000000000001	\N	\N	\N
7751	257	2043	2012-11-27 01:30:00	9.4000000000000004	\N	\N	\N
7754	256	2044	2012-11-27 02:00:00	13.300000000000001	\N	\N	\N
7761	252	2046	2012-11-27 03:00:00	19.199999999999999	18.300000000000001	\N	\N
7774	256	2049	2012-11-27 04:30:00	13.300000000000001	\N	\N	\N
7781	252	2051	2012-11-27 05:30:00	19	18	\N	\N
7803	257	2056	2012-11-27 08:00:00	9.4000000000000004	\N	\N	\N
7817	252	2060	2012-11-27 10:00:00	18.699999999999999	17.699999999999999	\N	\N
7825	252	2062	2012-11-27 11:00:00	18.699999999999999	17.699999999999999	\N	\N
7847	257	2067	2012-11-27 13:30:00	9.4000000000000004	\N	\N	\N
7006	256	1857	2012-11-23 04:30:00	13.300000000000001	\N	\N	\N
7009	252	1858	2012-11-23 05:00:00	19.899999999999999	19.199999999999999	\N	\N
7012	241	1858	2012-11-23 05:00:00	8.0999999999999996	\N	8.1999999999999993	8.1999999999999993
7014	256	1859	2012-11-23 05:30:00	13.300000000000001	\N	\N	\N
7017	252	1860	2012-11-23 06:00:00	19.699999999999999	18.899999999999999	\N	\N
7023	257	1861	2012-11-23 06:30:00	9.4000000000000004	\N	\N	\N
7031	257	1863	2012-11-23 07:30:00	9.4000000000000004	\N	\N	\N
7033	252	1864	2012-11-23 08:00:00	19.399999999999999	18.699999999999999	\N	\N
7036	241	1864	2012-11-23 08:00:00	8.0999999999999996	\N	8.3000000000000007	8.3000000000000007
7038	256	1865	2012-11-23 08:30:00	12.800000000000001	\N	\N	\N
7058	256	1870	2012-11-23 11:00:00	13.300000000000001	\N	\N	\N
7068	241	1872	2012-11-23 12:00:00	9.0999999999999996	\N	9.4000000000000004	9.4000000000000004
7070	256	1873	2012-11-23 12:30:00	13.9	\N	\N	\N
7073	252	1874	2012-11-23 13:00:00	20.699999999999999	20.100000000000001	\N	\N
7079	257	1875	2012-11-23 13:30:00	9.4000000000000004	\N	\N	\N
7081	252	1876	2012-11-23 14:00:00	20.899999999999999	20.199999999999999	\N	\N
7108	241	1882	2012-11-23 17:00:00	9.3000000000000007	\N	9.5999999999999996	9.5999999999999996
7110	256	1883	2012-11-23 17:30:00	15	\N	\N	\N
7124	241	1886	2012-11-23 19:00:00	9.0999999999999996	\N	9.3000000000000007	9.3000000000000007
7126	256	1887	2012-11-23 19:30:00	15	\N	\N	\N
7129	252	1888	2012-11-23 20:00:00	21.899999999999999	21.399999999999999	\N	\N
7132	241	1888	2012-11-23 20:00:00	9	\N	9.3000000000000007	9.3000000000000007
7134	256	1889	2012-11-23 20:30:00	15	\N	\N	\N
7142	256	1891	2012-11-23 21:30:00	15	\N	\N	\N
7145	252	1892	2012-11-23 22:00:00	21.800000000000001	21.199999999999999	\N	\N
7156	241	1894	2012-11-23 23:00:00	8.5999999999999996	\N	8.8000000000000007	8.8000000000000007
7158	256	1895	2012-11-23 23:30:00	14.4	\N	\N	\N
7171	257	1898	2012-11-24 01:00:00	9.4000000000000004	\N	\N	\N
7219	257	1910	2012-11-24 07:00:00	8.9000000000000004	\N	\N	\N
7221	252	1911	2012-11-24 07:30:00	20.600000000000001	19.800000000000001	\N	\N
7227	257	1912	2012-11-24 08:00:00	8.9000000000000004	\N	\N	\N
7235	257	1914	2012-11-24 09:00:00	8.9000000000000004	\N	\N	\N
7243	257	1916	2012-11-24 10:00:00	8.9000000000000004	\N	\N	\N
7256	241	1919	2012-11-24 11:30:00	11.5	\N	11.5	11.5
7258	256	1920	2012-11-24 12:00:00	13.9	\N	\N	\N
7261	252	1921	2012-11-24 12:30:00	20.600000000000001	19.800000000000001	\N	\N
7267	257	1922	2012-11-24 13:00:00	9.4000000000000004	\N	\N	\N
7280	241	1925	2012-11-24 14:30:00	12.4	\N	12.199999999999999	12.199999999999999
7288	241	1927	2012-11-24 15:30:00	11.699999999999999	\N	11.6	11.6
7290	256	1928	2012-11-24 16:00:00	14.4	\N	\N	\N
7293	252	1929	2012-11-24 16:30:00	20.800000000000001	19.899999999999999	\N	\N
7320	241	1935	2012-11-24 19:30:00	4.7000000000000002	\N	4.7999999999999998	4.7999999999999998
7377	252	1950	2012-11-25 03:00:00	19.100000000000001	18.100000000000001	\N	\N
7407	257	1957	2012-11-25 06:30:00	8.3000000000000007	\N	\N	\N
7415	257	1959	2012-11-25 07:30:00	8.3000000000000007	\N	\N	\N
7439	257	1965	2012-11-25 10:30:00	8.3000000000000007	\N	\N	\N
7441	252	1966	2012-11-25 11:00:00	18.699999999999999	17.699999999999999	\N	\N
7447	257	1967	2012-11-25 11:30:00	8.3000000000000007	\N	\N	\N
7455	257	1969	2012-11-25 12:30:00	8.3000000000000007	\N	\N	\N
7463	257	1971	2012-11-25 13:30:00	8.3000000000000007	\N	\N	\N
7471	257	1973	2012-11-25 14:30:00	8.9000000000000004	\N	\N	\N
7486	256	1977	2012-11-25 16:30:00	13.300000000000001	\N	\N	\N
7489	252	1978	2012-11-25 17:00:00	19.699999999999999	18.899999999999999	\N	\N
7492	241	1978	2012-11-25 17:00:00	8	\N	8.1999999999999993	8.1999999999999993
7494	256	1979	2012-11-25 17:30:00	13.300000000000001	\N	\N	\N
7497	252	1980	2012-11-25 18:00:00	19.800000000000001	19.100000000000001	\N	\N
7503	257	1981	2012-11-25 18:30:00	8.9000000000000004	\N	\N	\N
7511	257	1983	2012-11-25 19:30:00	8.9000000000000004	\N	\N	\N
7513	252	1984	2012-11-25 20:00:00	20.199999999999999	19.399999999999999	\N	\N
7516	241	1984	2012-11-25 20:00:00	7.7999999999999998	\N	8.0999999999999996	8.0999999999999996
7518	256	1985	2012-11-25 20:30:00	13.300000000000001	\N	\N	\N
7538	256	1990	2012-11-25 23:00:00	13.300000000000001	\N	\N	\N
7548	241	1992	2012-11-26 00:00:00	6.9000000000000004	\N	7.0999999999999996	7.0999999999999996
7550	256	1993	2012-11-26 00:30:00	12.800000000000001	\N	\N	\N
7553	252	1994	2012-11-26 01:00:00	19.699999999999999	18.800000000000001	\N	\N
7559	257	1995	2012-11-26 01:30:00	8.9000000000000004	\N	\N	\N
7561	252	1996	2012-11-26 02:00:00	19.399999999999999	18.600000000000001	\N	\N
7588	241	2002	2012-11-26 05:00:00	6.2999999999999998	\N	6.5	6.5
7590	256	2003	2012-11-26 05:30:00	12.800000000000001	\N	\N	\N
7604	241	2006	2012-11-26 07:00:00	6.7000000000000002	\N	6.7999999999999998	6.7999999999999998
7606	256	2007	2012-11-26 07:30:00	12.199999999999999	\N	\N	\N
7609	252	2008	2012-11-26 08:00:00	18.800000000000001	17.800000000000001	\N	\N
7612	241	2008	2012-11-26 08:00:00	7.0999999999999996	\N	7.2000000000000002	7.2000000000000002
7614	256	2009	2012-11-26 08:30:00	12.199999999999999	\N	\N	\N
7622	256	2011	2012-11-26 09:30:00	12.199999999999999	\N	\N	\N
7625	252	2012	2012-11-26 10:00:00	18.600000000000001	17.600000000000001	\N	\N
7636	241	2014	2012-11-26 11:00:00	12.699999999999999	\N	12.5	11.5
7638	256	2015	2012-11-26 11:30:00	12.800000000000001	\N	\N	\N
7652	241	2018	2012-11-26 13:00:00	13.800000000000001	\N	13.6	13
7654	256	2019	2012-11-26 13:30:00	13.300000000000001	\N	\N	\N
7657	252	2020	2012-11-26 14:00:00	19.399999999999999	18.600000000000001	\N	\N
7668	241	2022	2012-11-26 15:00:00	16.199999999999999	\N	15.800000000000001	15.800000000000001
7672	241	2023	2012-11-26 15:30:00	15.6	\N	15.199999999999999	15.199999999999999
7676	241	2024	2012-11-26 16:00:00	14.5	\N	14.1	14.1
7682	256	2026	2012-11-26 17:00:00	13.9	\N	\N	\N
7687	257	2027	2012-11-26 17:30:00	9.4000000000000004	\N	\N	\N
7689	252	2028	2012-11-26 18:00:00	19.800000000000001	19.100000000000001	\N	\N
7691	257	2028	2012-11-26 18:00:00	10	\N	\N	\N
7704	241	2031	2012-11-26 19:30:00	12.9	\N	12.6	11.800000000000001
7710	256	2033	2012-11-26 20:30:00	13.9	\N	\N	\N
7715	257	2034	2012-11-26 21:00:00	10	\N	\N	\N
7717	252	2035	2012-11-26 21:30:00	19.699999999999999	18.899999999999999	\N	\N
7732	241	2038	2012-11-26 23:00:00	12.6	\N	12.300000000000001	11.5
7756	241	2044	2012-11-27 02:00:00	12.6	\N	12.300000000000001	10.4
7762	256	2046	2012-11-27 03:00:00	13.300000000000001	\N	\N	\N
7765	252	2047	2012-11-27 03:30:00	19.100000000000001	18.199999999999999	\N	\N
7776	241	2049	2012-11-27 04:30:00	12.199999999999999	\N	12	10.5
7791	257	2053	2012-11-27 06:30:00	9.4000000000000004	\N	\N	\N
7798	256	2055	2012-11-27 07:30:00	13.300000000000001	\N	\N	\N
7806	256	2057	2012-11-27 08:30:00	13.300000000000001	\N	\N	\N
7814	256	2059	2012-11-27 09:30:00	13.300000000000001	\N	\N	\N
7828	241	2062	2012-11-27 11:00:00	15.6	\N	15.1	13.800000000000001
7833	252	2064	2012-11-27 12:00:00	18.600000000000001	17.600000000000001	\N	\N
7844	241	2066	2012-11-27 13:00:00	16.600000000000001	\N	16	15.800000000000001
7846	256	2067	2012-11-27 13:30:00	13.300000000000001	\N	\N	\N
7007	257	1857	2012-11-23 04:30:00	9.4000000000000004	\N	\N	\N
7015	257	1859	2012-11-23 05:30:00	9.4000000000000004	\N	\N	\N
7039	257	1865	2012-11-23 08:30:00	9.4000000000000004	\N	\N	\N
7041	252	1866	2012-11-23 09:00:00	19.399999999999999	18.600000000000001	\N	\N
7047	257	1867	2012-11-23 09:30:00	9.4000000000000004	\N	\N	\N
7055	257	1869	2012-11-23 10:30:00	9.4000000000000004	\N	\N	\N
7063	257	1871	2012-11-23 11:30:00	9.4000000000000004	\N	\N	\N
7071	257	1873	2012-11-23 12:30:00	9.4000000000000004	\N	\N	\N
7086	256	1877	2012-11-23 14:30:00	14.4	\N	\N	\N
7089	252	1878	2012-11-23 15:00:00	20.899999999999999	20.199999999999999	\N	\N
7092	241	1878	2012-11-23 15:00:00	10	\N	10.199999999999999	10.199999999999999
7094	256	1879	2012-11-23 15:30:00	14.4	\N	\N	\N
7097	252	1880	2012-11-23 16:00:00	20.899999999999999	20.199999999999999	\N	\N
7103	257	1881	2012-11-23 16:30:00	9.4000000000000004	\N	\N	\N
7111	257	1883	2012-11-23 17:30:00	9.4000000000000004	\N	\N	\N
7113	252	1884	2012-11-23 18:00:00	21.399999999999999	20.800000000000001	\N	\N
7116	241	1884	2012-11-23 18:00:00	9.0999999999999996	\N	9.4000000000000004	9.4000000000000004
7118	256	1885	2012-11-23 18:30:00	15	\N	\N	\N
7138	256	1890	2012-11-23 21:00:00	15	\N	\N	\N
7148	241	1892	2012-11-23 22:00:00	8.8000000000000007	\N	9.0999999999999996	9.0999999999999996
7150	256	1893	2012-11-23 22:30:00	14.4	\N	\N	\N
7153	252	1894	2012-11-23 23:00:00	21.600000000000001	21	\N	\N
7159	257	1895	2012-11-23 23:30:00	9.4000000000000004	\N	\N	\N
7161	252	1896	2012-11-24 00:00:00	21.5	20.800000000000001	\N	\N
7188	241	1902	2012-11-24 03:00:00	7.0999999999999996	\N	7.2000000000000002	7.2000000000000002
7190	256	1903	2012-11-24 03:30:00	13.9	\N	\N	\N
7204	241	1906	2012-11-24 05:00:00	6.0999999999999996	\N	6.2000000000000002	6.2000000000000002
7206	256	1907	2012-11-24 05:30:00	13.9	\N	\N	\N
7209	252	1908	2012-11-24 06:00:00	20.899999999999999	20.100000000000001	\N	\N
7212	241	1908	2012-11-24 06:00:00	6.2000000000000002	\N	6.2999999999999998	6.2999999999999998
7214	256	1909	2012-11-24 06:30:00	13.9	\N	\N	\N
7222	256	1911	2012-11-24 07:30:00	13.9	\N	\N	\N
7225	252	1912	2012-11-24 08:00:00	20.5	19.699999999999999	\N	\N
7236	241	1914	2012-11-24 09:00:00	7.9000000000000004	\N	8.1999999999999993	8.1999999999999993
7238	256	1915	2012-11-24 09:30:00	13.300000000000001	\N	\N	\N
7251	257	1918	2012-11-24 11:00:00	8.9000000000000004	\N	\N	\N
7299	257	1930	2012-11-24 17:00:00	10	\N	\N	\N
7301	252	1931	2012-11-24 17:30:00	20.600000000000001	19.800000000000001	\N	\N
7307	257	1932	2012-11-24 18:00:00	10	\N	\N	\N
7315	257	1934	2012-11-24 19:00:00	9.4000000000000004	\N	\N	\N
7323	257	1936	2012-11-24 20:00:00	9.4000000000000004	\N	\N	\N
7336	241	1939	2012-11-24 21:30:00	3.7000000000000002	\N	3.7000000000000002	3.7000000000000002
7338	256	1940	2012-11-24 22:00:00	13.300000000000001	\N	\N	\N
7341	252	1941	2012-11-24 22:30:00	19.899999999999999	19.199999999999999	\N	\N
7347	257	1942	2012-11-24 23:00:00	8.9000000000000004	\N	\N	\N
7360	241	1945	2012-11-25 00:30:00	1.8999999999999999	\N	1.8999999999999999	1.8999999999999999
7368	241	1947	2012-11-25 01:30:00	1.8999999999999999	\N	1.8999999999999999	1.8999999999999999
7370	256	1948	2012-11-25 02:00:00	12.800000000000001	\N	\N	\N
7373	252	1949	2012-11-25 02:30:00	19.199999999999999	18.199999999999999	\N	\N
7400	241	1955	2012-11-25 05:30:00	3.6000000000000001	\N	3.6000000000000001	3.6000000000000001
7457	252	1970	2012-11-25 13:00:00	19.199999999999999	18.300000000000001	\N	\N
7487	257	1977	2012-11-25 16:30:00	8.9000000000000004	\N	\N	\N
7495	257	1979	2012-11-25 17:30:00	8.9000000000000004	\N	\N	\N
7519	257	1985	2012-11-25 20:30:00	8.9000000000000004	\N	\N	\N
7521	252	1986	2012-11-25 21:00:00	20.199999999999999	19.399999999999999	\N	\N
7527	257	1987	2012-11-25 21:30:00	8.9000000000000004	\N	\N	\N
7535	257	1989	2012-11-25 22:30:00	8.9000000000000004	\N	\N	\N
7543	257	1991	2012-11-25 23:30:00	8.9000000000000004	\N	\N	\N
7551	257	1993	2012-11-26 00:30:00	8.9000000000000004	\N	\N	\N
7566	256	1997	2012-11-26 02:30:00	12.800000000000001	\N	\N	\N
7569	252	1998	2012-11-26 03:00:00	19.399999999999999	18.5	\N	\N
7572	241	1998	2012-11-26 03:00:00	6.4000000000000004	\N	6.5999999999999996	6.5999999999999996
7574	256	1999	2012-11-26 03:30:00	12.800000000000001	\N	\N	\N
7577	252	2000	2012-11-26 04:00:00	19.300000000000001	18.300000000000001	\N	\N
7583	257	2001	2012-11-26 04:30:00	8.9000000000000004	\N	\N	\N
7591	257	2003	2012-11-26 05:30:00	8.9000000000000004	\N	\N	\N
7593	252	2004	2012-11-26 06:00:00	19	18	\N	\N
7596	241	2004	2012-11-26 06:00:00	6.4000000000000004	\N	6.5999999999999996	6.5999999999999996
7598	256	2005	2012-11-26 06:30:00	12.199999999999999	\N	\N	\N
7618	256	2010	2012-11-26 09:00:00	12.199999999999999	\N	\N	\N
7628	241	2012	2012-11-26 10:00:00	11.800000000000001	\N	11.800000000000001	10.800000000000001
7630	256	2013	2012-11-26 10:30:00	12.800000000000001	\N	\N	\N
7633	252	2014	2012-11-26 11:00:00	18.800000000000001	17.800000000000001	\N	\N
7639	257	2015	2012-11-26 11:30:00	8.9000000000000004	\N	\N	\N
7641	252	2016	2012-11-26 12:00:00	18.899999999999999	18	\N	\N
7646	256	2017	2012-11-26 12:30:00	13.300000000000001	\N	\N	\N
7649	252	2018	2012-11-26 13:00:00	19.199999999999999	18.300000000000001	\N	\N
7656	241	2019	2012-11-26 13:30:00	14.699999999999999	\N	14.4	14.1
7663	257	2021	2012-11-26 14:30:00	9.4000000000000004	\N	\N	\N
7670	256	2023	2012-11-26 15:30:00	13.9	\N	\N	\N
7679	257	2025	2012-11-26 16:30:00	9.4000000000000004	\N	\N	\N
7681	252	2026	2012-11-26 17:00:00	19.699999999999999	18.899999999999999	\N	\N
7692	241	2028	2012-11-26 18:00:00	14.300000000000001	\N	13.9	13.4
7700	241	2030	2012-11-26 19:00:00	13.300000000000001	\N	12.9	12.6
7714	256	2034	2012-11-26 21:00:00	13.9	\N	\N	\N
7729	252	2038	2012-11-26 23:00:00	19.399999999999999	18.600000000000001	\N	\N
7731	257	2038	2012-11-26 23:00:00	9.4000000000000004	\N	\N	\N
7736	241	2039	2012-11-26 23:30:00	12.199999999999999	\N	11.9	11.300000000000001
7739	257	2040	2012-11-27 00:00:00	9.4000000000000004	\N	\N	\N
7750	256	2043	2012-11-27 01:30:00	13.300000000000001	\N	\N	\N
7753	252	2044	2012-11-27 02:00:00	19.300000000000001	18.399999999999999	\N	\N
7759	257	2045	2012-11-27 02:30:00	9.4000000000000004	\N	\N	\N
7771	257	2048	2012-11-27 04:00:00	9.4000000000000004	\N	\N	\N
7787	257	2052	2012-11-27 06:00:00	9.4000000000000004	\N	\N	\N
7797	252	2055	2012-11-27 07:30:00	18.800000000000001	17.800000000000001	\N	\N
7805	252	2057	2012-11-27 08:30:00	18.800000000000001	17.800000000000001	\N	\N
7807	257	2057	2012-11-27 08:30:00	9.4000000000000004	\N	\N	\N
7811	257	2058	2012-11-27 09:00:00	8.9000000000000004	\N	\N	\N
7813	252	2059	2012-11-27 09:30:00	18.800000000000001	17.800000000000001	\N	\N
7830	256	2063	2012-11-27 11:30:00	13.300000000000001	\N	\N	\N
7843	257	2066	2012-11-27 13:00:00	9.4000000000000004	\N	\N	\N
7008	241	1857	2012-11-23 04:30:00	8.0999999999999996	\N	8.3000000000000007	8.3000000000000007
7010	256	1858	2012-11-23 05:00:00	13.300000000000001	\N	\N	\N
7013	252	1859	2012-11-23 05:30:00	19.800000000000001	19.100000000000001	\N	\N
7019	257	1860	2012-11-23 06:00:00	9.4000000000000004	\N	\N	\N
7034	256	1864	2012-11-23 08:00:00	12.800000000000001	\N	\N	\N
7037	252	1865	2012-11-23 08:30:00	19.399999999999999	18.699999999999999	\N	\N
7042	256	1866	2012-11-23 09:00:00	12.800000000000001	\N	\N	\N
7045	252	1867	2012-11-23 09:30:00	19.399999999999999	18.600000000000001	\N	\N
7056	241	1869	2012-11-23 10:30:00	8.5999999999999996	\N	8.9000000000000004	8.9000000000000004
7060	241	1870	2012-11-23 11:00:00	8.6999999999999993	\N	9	9
7064	241	1871	2012-11-23 11:30:00	8.8000000000000007	\N	9.0999999999999996	9.0999999999999996
7066	256	1872	2012-11-23 12:00:00	13.9	\N	\N	\N
7069	252	1873	2012-11-23 12:30:00	20.600000000000001	20.100000000000001	\N	\N
7072	241	1873	2012-11-23 12:30:00	9.4000000000000004	\N	9.6999999999999993	9.6999999999999993
7074	256	1874	2012-11-23 13:00:00	13.9	\N	\N	\N
7077	252	1875	2012-11-23 13:30:00	20.800000000000001	20.100000000000001	\N	\N
7082	256	1876	2012-11-23 14:00:00	13.9	\N	\N	\N
7085	252	1877	2012-11-23 14:30:00	20.899999999999999	20.199999999999999	\N	\N
7104	241	1881	2012-11-23 16:30:00	9.4000000000000004	\N	9.6999999999999993	9.6999999999999993
7106	256	1882	2012-11-23 17:00:00	15	\N	\N	\N
7109	252	1883	2012-11-23 17:30:00	21.300000000000001	20.600000000000001	\N	\N
7112	241	1883	2012-11-23 17:30:00	9.1999999999999993	\N	9.5	9.5
7164	241	1896	2012-11-24 00:00:00	8.0999999999999996	\N	8.3000000000000007	8.3000000000000007
7180	241	1900	2012-11-24 02:00:00	7.7000000000000002	\N	7.9000000000000004	7.9000000000000004
7182	256	1901	2012-11-24 02:30:00	14.4	\N	\N	\N
7185	252	1902	2012-11-24 03:00:00	21.199999999999999	20.399999999999999	\N	\N
7195	257	1904	2012-11-24 04:00:00	9.4000000000000004	\N	\N	\N
7203	257	1906	2012-11-24 05:00:00	9.4000000000000004	\N	\N	\N
7211	257	1908	2012-11-24 06:00:00	9.4000000000000004	\N	\N	\N
7248	241	1917	2012-11-24 10:30:00	10.5	\N	10.699999999999999	10.699999999999999
7250	256	1918	2012-11-24 11:00:00	13.9	\N	\N	\N
7253	252	1919	2012-11-24 11:30:00	20.399999999999999	19.699999999999999	\N	\N
7259	257	1920	2012-11-24 12:00:00	9.4000000000000004	\N	\N	\N
7274	256	1924	2012-11-24 14:00:00	14.4	\N	\N	\N
7277	252	1925	2012-11-24 14:30:00	20.800000000000001	20	\N	\N
7282	256	1926	2012-11-24 15:00:00	14.4	\N	\N	\N
7285	252	1927	2012-11-24 15:30:00	20.800000000000001	19.899999999999999	\N	\N
7296	241	1929	2012-11-24 16:30:00	9.6999999999999993	\N	9.9000000000000004	9.9000000000000004
7300	241	1930	2012-11-24 17:00:00	8.9000000000000004	\N	9.0999999999999996	9.0999999999999996
7304	241	1931	2012-11-24 17:30:00	8.3000000000000007	\N	8.5	8.5
7306	256	1932	2012-11-24 18:00:00	13.9	\N	\N	\N
7309	252	1933	2012-11-24 18:30:00	20.5	19.699999999999999	\N	\N
7312	241	1933	2012-11-24 18:30:00	6.4000000000000004	\N	6.5999999999999996	6.5999999999999996
7314	256	1934	2012-11-24 19:00:00	13.9	\N	\N	\N
7317	252	1935	2012-11-24 19:30:00	20.300000000000001	19.5	\N	\N
7322	256	1936	2012-11-24 20:00:00	13.9	\N	\N	\N
7325	252	1937	2012-11-24 20:30:00	20.199999999999999	19.399999999999999	\N	\N
7344	241	1941	2012-11-24 22:30:00	3.3999999999999999	\N	3.3999999999999999	3.3999999999999999
7346	256	1942	2012-11-24 23:00:00	13.300000000000001	\N	\N	\N
7349	252	1943	2012-11-24 23:30:00	19.699999999999999	18.800000000000001	\N	\N
7352	241	1943	2012-11-24 23:30:00	2.2999999999999998	\N	2.2999999999999998	2.2999999999999998
7404	241	1956	2012-11-25 06:00:00	3.5	\N	3.6000000000000001	3.6000000000000001
7420	241	1960	2012-11-25 08:00:00	3.2999999999999998	\N	3.2999999999999998	3.2999999999999998
7422	256	1961	2012-11-25 08:30:00	11.699999999999999	\N	\N	\N
7425	252	1962	2012-11-25 09:00:00	18.100000000000001	17	\N	\N
7435	257	1964	2012-11-25 10:00:00	8.3000000000000007	\N	\N	\N
7443	257	1966	2012-11-25 11:00:00	8.3000000000000007	\N	\N	\N
7451	257	1968	2012-11-25 12:00:00	8.3000000000000007	\N	\N	\N
7488	241	1977	2012-11-25 16:30:00	8	\N	8.1999999999999993	8.1999999999999993
7490	256	1978	2012-11-25 17:00:00	13.300000000000001	\N	\N	\N
7493	252	1979	2012-11-25 17:30:00	19.699999999999999	18.899999999999999	\N	\N
7499	257	1980	2012-11-25 18:00:00	8.9000000000000004	\N	\N	\N
7514	256	1984	2012-11-25 20:00:00	13.300000000000001	\N	\N	\N
7517	252	1985	2012-11-25 20:30:00	20.199999999999999	19.399999999999999	\N	\N
7522	256	1986	2012-11-25 21:00:00	13.300000000000001	\N	\N	\N
7525	252	1987	2012-11-25 21:30:00	20.199999999999999	19.399999999999999	\N	\N
7536	241	1989	2012-11-25 22:30:00	7.2999999999999998	\N	7.4000000000000004	7.4000000000000004
7540	241	1990	2012-11-25 23:00:00	7.0999999999999996	\N	7.2999999999999998	7.2999999999999998
7544	241	1991	2012-11-25 23:30:00	7.0999999999999996	\N	7.2999999999999998	7.2999999999999998
7546	256	1992	2012-11-26 00:00:00	12.800000000000001	\N	\N	\N
7549	252	1993	2012-11-26 00:30:00	19.699999999999999	18.899999999999999	\N	\N
7552	241	1993	2012-11-26 00:30:00	6.5999999999999996	\N	6.7999999999999998	6.7999999999999998
7554	256	1994	2012-11-26 01:00:00	12.800000000000001	\N	\N	\N
7557	252	1995	2012-11-26 01:30:00	19.600000000000001	18.699999999999999	\N	\N
7562	256	1996	2012-11-26 02:00:00	12.800000000000001	\N	\N	\N
7565	252	1997	2012-11-26 02:30:00	19.399999999999999	18.600000000000001	\N	\N
7584	241	2001	2012-11-26 04:30:00	6.2999999999999998	\N	6.4000000000000004	6.4000000000000004
7586	256	2002	2012-11-26 05:00:00	12.800000000000001	\N	\N	\N
7589	252	2003	2012-11-26 05:30:00	19	18	\N	\N
7592	241	2003	2012-11-26 05:30:00	6.4000000000000004	\N	6.5999999999999996	6.5999999999999996
7644	241	2016	2012-11-26 12:00:00	13.199999999999999	\N	12.9	12
7650	256	2018	2012-11-26 13:00:00	13.300000000000001	\N	\N	\N
7653	252	2019	2012-11-26 13:30:00	19.300000000000001	18.399999999999999	\N	\N
7667	257	2022	2012-11-26 15:00:00	9.4000000000000004	\N	\N	\N
7686	256	2027	2012-11-26 17:30:00	13.9	\N	\N	\N
7709	252	2033	2012-11-26 20:30:00	19.699999999999999	18.899999999999999	\N	\N
7711	257	2033	2012-11-26 20:30:00	10	\N	\N	\N
7716	241	2034	2012-11-26 21:00:00	11.5	\N	11.300000000000001	10.9
7719	257	2035	2012-11-26 21:30:00	9.4000000000000004	\N	\N	\N
7727	257	2037	2012-11-26 22:30:00	9.4000000000000004	\N	\N	\N
7744	241	2041	2012-11-27 00:30:00	12	\N	11.800000000000001	11.4
7746	256	2042	2012-11-27 01:00:00	13.300000000000001	\N	\N	\N
7755	257	2044	2012-11-27 02:00:00	9.4000000000000004	\N	\N	\N
7767	257	2047	2012-11-27 03:30:00	9.4000000000000004	\N	\N	\N
7782	256	2051	2012-11-27 05:30:00	13.300000000000001	\N	\N	\N
7785	252	2052	2012-11-27 06:00:00	18.899999999999999	17.899999999999999	\N	\N
7792	241	2053	2012-11-27 06:30:00	10.300000000000001	\N	10.300000000000001	10.199999999999999
7795	257	2054	2012-11-27 07:00:00	9.4000000000000004	\N	\N	\N
7800	241	2055	2012-11-27 07:30:00	11.5	\N	11.300000000000001	10
7804	241	2056	2012-11-27 08:00:00	11.800000000000001	\N	11.6	10.4
7812	241	2058	2012-11-27 09:00:00	13.6	\N	13.1	11.1
7815	257	2059	2012-11-27 09:30:00	9.4000000000000004	\N	\N	\N
7819	257	2060	2012-11-27 10:00:00	9.4000000000000004	\N	\N	\N
7821	252	2061	2012-11-27 10:30:00	18.699999999999999	17.699999999999999	\N	\N
7848	241	2067	2012-11-27 13:30:00	16.800000000000001	\N	16.199999999999999	16.199999999999999
7011	257	1858	2012-11-23 05:00:00	9.4000000000000004	\N	\N	\N
7059	257	1870	2012-11-23 11:00:00	9.4000000000000004	\N	\N	\N
7061	252	1871	2012-11-23 11:30:00	19.899999999999999	19.600000000000001	\N	\N
7067	257	1872	2012-11-23 12:00:00	9.4000000000000004	\N	\N	\N
7075	257	1874	2012-11-23 13:00:00	9.4000000000000004	\N	\N	\N
7083	257	1876	2012-11-23 14:00:00	9.4000000000000004	\N	\N	\N
7096	241	1879	2012-11-23 15:30:00	9.8000000000000007	\N	10.1	10.1
7098	256	1880	2012-11-23 16:00:00	14.4	\N	\N	\N
7101	252	1881	2012-11-23 16:30:00	20.899999999999999	20.199999999999999	\N	\N
7107	257	1882	2012-11-23 17:00:00	9.4000000000000004	\N	\N	\N
7120	241	1885	2012-11-23 18:30:00	9.0999999999999996	\N	9.3000000000000007	9.3000000000000007
7128	241	1887	2012-11-23 19:30:00	9	\N	9.3000000000000007	9.3000000000000007
7130	256	1888	2012-11-23 20:00:00	15	\N	\N	\N
7133	252	1889	2012-11-23 20:30:00	22	21.600000000000001	\N	\N
7160	241	1895	2012-11-23 23:30:00	8.3000000000000007	\N	8.5999999999999996	8.5999999999999996
7217	252	1910	2012-11-24 07:00:00	20.699999999999999	19.800000000000001	\N	\N
7247	257	1917	2012-11-24 10:30:00	8.9000000000000004	\N	\N	\N
7255	257	1919	2012-11-24 11:30:00	9.4000000000000004	\N	\N	\N
7279	257	1925	2012-11-24 14:30:00	9.4000000000000004	\N	\N	\N
7281	252	1926	2012-11-24 15:00:00	20.800000000000001	19.899999999999999	\N	\N
7287	257	1927	2012-11-24 15:30:00	10	\N	\N	\N
7295	257	1929	2012-11-24 16:30:00	10	\N	\N	\N
7303	257	1931	2012-11-24 17:30:00	10	\N	\N	\N
7311	257	1933	2012-11-24 18:30:00	10	\N	\N	\N
7326	256	1937	2012-11-24 20:30:00	13.9	\N	\N	\N
7329	252	1938	2012-11-24 21:00:00	20.100000000000001	19.300000000000001	\N	\N
7332	241	1938	2012-11-24 21:00:00	4.0999999999999996	\N	4.0999999999999996	4.0999999999999996
7334	256	1939	2012-11-24 21:30:00	13.300000000000001	\N	\N	\N
7337	252	1940	2012-11-24 22:00:00	19.899999999999999	19.199999999999999	\N	\N
7343	257	1941	2012-11-24 22:30:00	9.4000000000000004	\N	\N	\N
7351	257	1943	2012-11-24 23:30:00	8.9000000000000004	\N	\N	\N
7353	252	1944	2012-11-25 00:00:00	19.699999999999999	18.800000000000001	\N	\N
7356	241	1944	2012-11-25 00:00:00	2.2999999999999998	\N	2.2999999999999998	2.2999999999999998
7358	256	1945	2012-11-25 00:30:00	12.800000000000001	\N	\N	\N
7378	256	1950	2012-11-25 03:00:00	12.800000000000001	\N	\N	\N
7388	241	1952	2012-11-25 04:00:00	3.2000000000000002	\N	3.2999999999999998	3.2999999999999998
7390	256	1953	2012-11-25 04:30:00	12.199999999999999	\N	\N	\N
7393	252	1954	2012-11-25 05:00:00	18.800000000000001	17.699999999999999	\N	\N
7399	257	1955	2012-11-25 05:30:00	8.3000000000000007	\N	\N	\N
7401	252	1956	2012-11-25 06:00:00	18.699999999999999	17.600000000000001	\N	\N
7428	241	1962	2012-11-25 09:00:00	4	\N	4.0999999999999996	4.0999999999999996
7430	256	1963	2012-11-25 09:30:00	11.699999999999999	\N	\N	\N
7444	241	1966	2012-11-25 11:00:00	6.7999999999999998	\N	6.9000000000000004	6.9000000000000004
7446	256	1967	2012-11-25 11:30:00	12.800000000000001	\N	\N	\N
7449	252	1968	2012-11-25 12:00:00	19	18	\N	\N
7452	241	1968	2012-11-25 12:00:00	8.1999999999999993	\N	8.4000000000000004	8.4000000000000004
7454	256	1969	2012-11-25 12:30:00	12.800000000000001	\N	\N	\N
7462	256	1971	2012-11-25 13:30:00	12.800000000000001	\N	\N	\N
7465	252	1972	2012-11-25 14:00:00	19.100000000000001	18.199999999999999	\N	\N
7476	241	1974	2012-11-25 15:00:00	8.9000000000000004	\N	9.1999999999999993	9.1999999999999993
7478	256	1975	2012-11-25 15:30:00	13.300000000000001	\N	\N	\N
7491	257	1978	2012-11-25 17:00:00	8.9000000000000004	\N	\N	\N
7539	257	1990	2012-11-25 23:00:00	8.9000000000000004	\N	\N	\N
7541	252	1991	2012-11-25 23:30:00	19.899999999999999	19.199999999999999	\N	\N
7547	257	1992	2012-11-26 00:00:00	8.9000000000000004	\N	\N	\N
7555	257	1994	2012-11-26 01:00:00	8.9000000000000004	\N	\N	\N
7563	257	1996	2012-11-26 02:00:00	8.9000000000000004	\N	\N	\N
7576	241	1999	2012-11-26 03:30:00	6.2999999999999998	\N	6.5	6.5
7578	256	2000	2012-11-26 04:00:00	12.800000000000001	\N	\N	\N
7581	252	2001	2012-11-26 04:30:00	19.199999999999999	18.300000000000001	\N	\N
7587	257	2002	2012-11-26 05:00:00	8.9000000000000004	\N	\N	\N
7600	241	2005	2012-11-26 06:30:00	6.5999999999999996	\N	6.7000000000000002	6.7000000000000002
7608	241	2007	2012-11-26 07:30:00	6.7999999999999998	\N	6.9000000000000004	6.9000000000000004
7610	256	2008	2012-11-26 08:00:00	12.199999999999999	\N	\N	\N
7613	252	2009	2012-11-26 08:30:00	18.800000000000001	17.800000000000001	\N	\N
7640	241	2015	2012-11-26 11:30:00	13.1	\N	12.800000000000001	11.5
7651	257	2018	2012-11-26 13:00:00	8.9000000000000004	\N	\N	\N
7660	241	2020	2012-11-26 14:00:00	15.699999999999999	\N	15.4	15.199999999999999
7662	256	2021	2012-11-26 14:30:00	13.9	\N	\N	\N
7665	252	2022	2012-11-26 15:00:00	19.600000000000001	18.699999999999999	\N	\N
7683	257	2026	2012-11-26 17:00:00	9.4000000000000004	\N	\N	\N
7688	241	2027	2012-11-26 17:30:00	14.699999999999999	\N	14.300000000000001	14.1
7713	252	2034	2012-11-26 21:00:00	19.699999999999999	18.899999999999999	\N	\N
7728	241	2037	2012-11-26 22:30:00	12.699999999999999	\N	12.4	11.6
7738	256	2040	2012-11-27 00:00:00	13.300000000000001	\N	\N	\N
7743	257	2041	2012-11-27 00:30:00	9.4000000000000004	\N	\N	\N
7745	252	2042	2012-11-27 01:00:00	19.399999999999999	18.600000000000001	\N	\N
7763	257	2046	2012-11-27 03:00:00	9.4000000000000004	\N	\N	\N
7772	241	2048	2012-11-27 04:00:00	12.4	\N	12.199999999999999	9.9000000000000004
7780	241	2050	2012-11-27 05:00:00	11.800000000000001	\N	11.6	10.1
7796	241	2054	2012-11-27 07:00:00	11.300000000000001	\N	11.1	10.1
7802	256	2056	2012-11-27 08:00:00	13.300000000000001	\N	\N	\N
7809	252	2058	2012-11-27 09:00:00	18.800000000000001	17.800000000000001	\N	\N
7824	241	2061	2012-11-27 10:30:00	15.6	\N	15	13.699999999999999
7839	257	2065	2012-11-27 12:30:00	9.4000000000000004	\N	\N	\N
7057	252	1870	2012-11-23 11:00:00	19.399999999999999	18.899999999999999	\N	\N
7087	257	1877	2012-11-23 14:30:00	9.4000000000000004	\N	\N	\N
7095	257	1879	2012-11-23 15:30:00	9.4000000000000004	\N	\N	\N
7119	257	1885	2012-11-23 18:30:00	9.4000000000000004	\N	\N	\N
7121	252	1886	2012-11-23 19:00:00	21.699999999999999	21.199999999999999	\N	\N
7127	257	1887	2012-11-23 19:30:00	9.4000000000000004	\N	\N	\N
7135	257	1889	2012-11-23 20:30:00	9.4000000000000004	\N	\N	\N
7143	257	1891	2012-11-23 21:30:00	9.4000000000000004	\N	\N	\N
7151	257	1893	2012-11-23 22:30:00	9.4000000000000004	\N	\N	\N
7166	256	1897	2012-11-24 00:30:00	14.4	\N	\N	\N
7169	252	1898	2012-11-24 01:00:00	21.399999999999999	20.800000000000001	\N	\N
7172	241	1898	2012-11-24 01:00:00	7.9000000000000004	\N	8.0999999999999996	8.0999999999999996
7174	256	1899	2012-11-24 01:30:00	13.9	\N	\N	\N
7177	252	1900	2012-11-24 02:00:00	21.199999999999999	20.399999999999999	\N	\N
7183	257	1901	2012-11-24 02:30:00	9.4000000000000004	\N	\N	\N
7191	257	1903	2012-11-24 03:30:00	9.4000000000000004	\N	\N	\N
7193	252	1904	2012-11-24 04:00:00	21.100000000000001	20.199999999999999	\N	\N
7196	241	1904	2012-11-24 04:00:00	6.0999999999999996	\N	6.2000000000000002	6.2000000000000002
7198	256	1905	2012-11-24 04:30:00	13.9	\N	\N	\N
7218	256	1910	2012-11-24 07:00:00	13.9	\N	\N	\N
7228	241	1912	2012-11-24 08:00:00	6.9000000000000004	\N	7.0999999999999996	7.0999999999999996
7230	256	1913	2012-11-24 08:30:00	13.9	\N	\N	\N
7233	252	1914	2012-11-24 09:00:00	20.399999999999999	19.600000000000001	\N	\N
7239	257	1915	2012-11-24 09:30:00	8.9000000000000004	\N	\N	\N
7241	252	1916	2012-11-24 10:00:00	20.199999999999999	19.600000000000001	\N	\N
7268	241	1922	2012-11-24 13:00:00	12.199999999999999	\N	12	12
7270	256	1923	2012-11-24 13:30:00	14.4	\N	\N	\N
7284	241	1926	2012-11-24 15:00:00	12.800000000000001	\N	12.4	12.4
7286	256	1927	2012-11-24 15:30:00	14.4	\N	\N	\N
7289	252	1928	2012-11-24 16:00:00	20.699999999999999	19.800000000000001	\N	\N
7292	241	1928	2012-11-24 16:00:00	10.800000000000001	\N	10.9	10.9
7294	256	1929	2012-11-24 16:30:00	14.4	\N	\N	\N
7302	256	1931	2012-11-24 17:30:00	14.4	\N	\N	\N
7305	252	1932	2012-11-24 18:00:00	20.600000000000001	19.800000000000001	\N	\N
7316	241	1934	2012-11-24 19:00:00	5.7000000000000002	\N	5.7999999999999998	5.7999999999999998
7318	256	1935	2012-11-24 19:30:00	13.9	\N	\N	\N
7331	257	1938	2012-11-24 21:00:00	9.4000000000000004	\N	\N	\N
7379	257	1950	2012-11-25 03:00:00	8.9000000000000004	\N	\N	\N
7381	252	1951	2012-11-25 03:30:00	19	17.899999999999999	\N	\N
7387	257	1952	2012-11-25 04:00:00	8.3000000000000007	\N	\N	\N
7395	257	1954	2012-11-25 05:00:00	8.3000000000000007	\N	\N	\N
7403	257	1956	2012-11-25 06:00:00	8.3000000000000007	\N	\N	\N
7416	241	1959	2012-11-25 07:30:00	3.2000000000000002	\N	3.2999999999999998	3.2999999999999998
7418	256	1960	2012-11-25 08:00:00	12.199999999999999	\N	\N	\N
7421	252	1961	2012-11-25 08:30:00	18.199999999999999	17.100000000000001	\N	\N
7427	257	1962	2012-11-25 09:00:00	8.3000000000000007	\N	\N	\N
7440	241	1965	2012-11-25 10:30:00	5.9000000000000004	\N	6.0999999999999996	6.0999999999999996
7448	241	1967	2012-11-25 11:30:00	7.7000000000000002	\N	7.9000000000000004	7.9000000000000004
7450	256	1968	2012-11-25 12:00:00	12.800000000000001	\N	\N	\N
7453	252	1969	2012-11-25 12:30:00	19.100000000000001	18.199999999999999	\N	\N
7480	241	1975	2012-11-25 15:30:00	8.3000000000000007	\N	8.5	8.5
7537	252	1990	2012-11-25 23:00:00	20	19.199999999999999	\N	\N
7567	257	1997	2012-11-26 02:30:00	8.9000000000000004	\N	\N	\N
7575	257	1999	2012-11-26 03:30:00	8.9000000000000004	\N	\N	\N
7599	257	2005	2012-11-26 06:30:00	8.9000000000000004	\N	\N	\N
7601	252	2006	2012-11-26 07:00:00	18.899999999999999	17.899999999999999	\N	\N
7607	257	2007	2012-11-26 07:30:00	8.9000000000000004	\N	\N	\N
7615	257	2009	2012-11-26 08:30:00	8.9000000000000004	\N	\N	\N
7623	257	2011	2012-11-26 09:30:00	8.9000000000000004	\N	\N	\N
7631	257	2013	2012-11-26 10:30:00	8.9000000000000004	\N	\N	\N
7659	257	2020	2012-11-26 14:00:00	9.4000000000000004	\N	\N	\N
7674	256	2024	2012-11-26 16:00:00	13.9	\N	\N	\N
7677	252	2025	2012-11-26 16:30:00	19.600000000000001	18.800000000000001	\N	\N
7685	252	2027	2012-11-26 17:30:00	19.800000000000001	19.100000000000001	\N	\N
7703	257	2031	2012-11-26 19:30:00	10	\N	\N	\N
7707	257	2032	2012-11-26 20:00:00	10	\N	\N	\N
7722	256	2036	2012-11-26 22:00:00	13.300000000000001	\N	\N	\N
7742	256	2041	2012-11-27 00:30:00	13.300000000000001	\N	\N	\N
7752	241	2043	2012-11-27 01:30:00	12	\N	11.800000000000001	11.1
7758	256	2045	2012-11-27 02:30:00	13.300000000000001	\N	\N	\N
7777	252	2050	2012-11-27 05:00:00	19	18	\N	\N
7790	256	2053	2012-11-27 06:30:00	13.300000000000001	\N	\N	\N
7793	252	2054	2012-11-27 07:00:00	18.800000000000001	17.800000000000001	\N	\N
7808	241	2057	2012-11-27 08:30:00	12.800000000000001	\N	12.4	11
7836	241	2064	2012-11-27 12:00:00	16.399999999999999	\N	15.800000000000001	15.800000000000001
7838	256	2065	2012-11-27 12:30:00	13.300000000000001	\N	\N	\N
7841	252	2066	2012-11-27 13:00:00	18.800000000000001	17.800000000000001	\N	\N
7849	252	2068	2012-11-27 14:00:00	18.800000000000001	17.800000000000001	\N	\N
7850	256	2068	2012-11-27 14:00:00	13.300000000000001	\N	\N	\N
7851	257	2068	2012-11-27 14:00:00	10	\N	\N	\N
7852	241	2068	2012-11-27 14:00:00	16.699999999999999	\N	15.9	15.9
7853	252	2069	2012-11-27 14:30:00	18.800000000000001	17.800000000000001	\N	\N
7854	256	2069	2012-11-27 14:30:00	13.300000000000001	\N	\N	\N
7855	257	2069	2012-11-27 14:30:00	10	\N	\N	\N
7856	241	2069	2012-11-27 14:30:00	16.699999999999999	\N	15.9	15.9
7857	252	2070	2012-11-27 15:00:00	18.800000000000001	17.800000000000001	\N	\N
7858	256	2070	2012-11-27 15:00:00	13.300000000000001	\N	\N	\N
7859	257	2070	2012-11-27 15:00:00	10	\N	\N	\N
7860	241	2070	2012-11-27 15:00:00	16	\N	15.300000000000001	14.9
7861	252	2071	2012-11-27 15:30:00	18.800000000000001	17.800000000000001	\N	\N
7862	256	2071	2012-11-27 15:30:00	13.300000000000001	\N	\N	\N
7863	257	2071	2012-11-27 15:30:00	10	\N	\N	\N
7864	241	2071	2012-11-27 15:30:00	15.699999999999999	\N	15	14.6
7865	252	2072	2012-11-27 16:00:00	18.800000000000001	17.800000000000001	\N	\N
7866	256	2072	2012-11-27 16:00:00	13.300000000000001	\N	\N	\N
7867	257	2072	2012-11-27 16:00:00	10	\N	\N	\N
7868	241	2072	2012-11-27 16:00:00	15.199999999999999	\N	14.6	14.300000000000001
7869	252	2073	2012-11-27 16:30:00	18.800000000000001	17.699999999999999	\N	\N
7870	256	2073	2012-11-27 16:30:00	13.300000000000001	\N	\N	\N
7871	257	2073	2012-11-27 16:30:00	10	\N	\N	\N
7872	241	2073	2012-11-27 16:30:00	14.300000000000001	\N	13.699999999999999	13.699999999999999
7873	252	2074	2012-11-27 17:00:00	18.699999999999999	17.600000000000001	\N	\N
7874	256	2074	2012-11-27 17:00:00	13.300000000000001	\N	\N	\N
7875	257	2074	2012-11-27 17:00:00	10	\N	\N	\N
7876	241	2074	2012-11-27 17:00:00	14.300000000000001	\N	13.699999999999999	13.699999999999999
7877	252	2075	2012-11-27 17:30:00	18.699999999999999	17.600000000000001	\N	\N
7878	256	2075	2012-11-27 17:30:00	13.300000000000001	\N	\N	\N
7879	257	2075	2012-11-27 17:30:00	10	\N	\N	\N
7880	241	2075	2012-11-27 17:30:00	13.300000000000001	\N	12.9	12.9
7881	252	2076	2012-11-27 18:00:00	18.699999999999999	17.600000000000001	\N	\N
7882	256	2076	2012-11-27 18:00:00	13.300000000000001	\N	\N	\N
7883	257	2076	2012-11-27 18:00:00	10	\N	\N	\N
7891	257	2078	2012-11-27 19:00:00	10	\N	\N	\N
7900	241	2080	2012-11-27 20:00:00	11.6	\N	11.300000000000001	11.300000000000001
7907	257	2082	2012-11-27 21:00:00	10	\N	\N	\N
7913	252	2084	2012-11-27 22:00:00	18.699999999999999	17.699999999999999	\N	\N
7928	241	2087	2012-11-27 23:30:00	10.9	\N	10.800000000000001	10.800000000000001
7932	241	2088	2012-11-28 00:00:00	10.6	\N	10.5	10.5
7935	257	2089	2012-11-28 00:30:00	10	\N	\N	\N
7946	256	2092	2012-11-28 02:00:00	13.300000000000001	\N	\N	\N
7952	241	2093	2012-11-28 02:30:00	8.9000000000000004	\N	9	9
7953	252	2094	2012-11-28 03:00:00	18.600000000000001	17.600000000000001	\N	\N
7996	241	2104	2012-11-28 08:00:00	8.0999999999999996	\N	8.1999999999999993	8.1999999999999993
7998	256	2105	2012-11-28 08:30:00	13.300000000000001	\N	\N	\N
8008	241	2107	2012-11-28 09:30:00	10.300000000000001	\N	10.4	10.4
8018	256	2110	2012-11-28 11:00:00	13.300000000000001	\N	\N	\N
8021	252	2111	2012-11-28 11:30:00	18.399999999999999	17.399999999999999	\N	\N
8032	241	2113	2012-11-28 12:30:00	15.699999999999999	\N	15.4	15.4
8039	257	2115	2012-11-28 13:30:00	10	\N	\N	\N
8041	252	2116	2012-11-28 14:00:00	19.199999999999999	18.399999999999999	\N	\N
8054	256	2119	2012-11-28 15:30:00	14.4	\N	\N	\N
8057	252	2120	2012-11-28 16:00:00	19.899999999999999	19.300000000000001	\N	\N
8068	241	2122	2012-11-28 17:00:00	11.4	\N	11.5	11.5
8072	241	2123	2012-11-28 17:30:00	11.199999999999999	\N	11.300000000000001	11.300000000000001
8084	241	2126	2012-11-28 19:00:00	11.300000000000001	\N	11.4	11.4
8087	257	2127	2012-11-28 19:30:00	10.6	\N	\N	\N
8123	257	2136	2012-11-29 00:00:00	10.6	\N	\N	\N
8175	257	2149	2012-11-29 06:30:00	9.4000000000000004	\N	\N	\N
8199	257	2155	2012-11-29 09:30:00	9.4000000000000004	\N	\N	\N
8208	241	2157	2012-11-29 10:30:00	13.1	\N	12.800000000000001	12.1
8228	241	2162	2012-11-29 13:00:00	14.1	\N	13.699999999999999	13.699999999999999
8233	252	2164	2012-11-29 14:00:00	18.899999999999999	18.100000000000001	\N	\N
8244	241	2166	2012-11-29 15:00:00	12.699999999999999	\N	12.6	12.6
8246	256	2167	2012-11-29 15:30:00	13.300000000000001	\N	\N	\N
8249	252	2168	2012-11-29 16:00:00	18.899999999999999	18.100000000000001	\N	\N
8256	241	2169	2012-11-29 16:30:00	9.8000000000000007	\N	10.1	10.1
8261	252	2171	2012-11-29 17:30:00	19.399999999999999	18.699999999999999	\N	\N
8271	257	2173	2012-11-29 18:30:00	10	\N	\N	\N
8278	256	2175	2012-11-29 19:30:00	14.4	\N	\N	\N
7884	241	2076	2012-11-27 18:00:00	13.699999999999999	\N	13.1	13.1
7888	241	2077	2012-11-27 18:30:00	13.699999999999999	\N	13.1	13.1
7899	257	2080	2012-11-27 20:00:00	10	\N	\N	\N
7910	256	2083	2012-11-27 21:30:00	13.300000000000001	\N	\N	\N
7914	256	2084	2012-11-27 22:00:00	13.300000000000001	\N	\N	\N
7917	252	2085	2012-11-27 22:30:00	18.699999999999999	17.699999999999999	\N	\N
7921	252	2086	2012-11-27 23:00:00	18.699999999999999	17.699999999999999	\N	\N
7929	252	2088	2012-11-28 00:00:00	18.699999999999999	17.699999999999999	\N	\N
7933	252	2089	2012-11-28 00:30:00	18.699999999999999	17.699999999999999	\N	\N
7938	256	2090	2012-11-28 01:00:00	13.300000000000001	\N	\N	\N
7944	241	2091	2012-11-28 01:30:00	8.8000000000000007	\N	8.9000000000000004	8.9000000000000004
7951	257	2093	2012-11-28 02:30:00	10	\N	\N	\N
7954	256	2094	2012-11-28 03:00:00	13.300000000000001	\N	\N	\N
7961	252	2096	2012-11-28 04:00:00	18.600000000000001	17.600000000000001	\N	\N
7985	252	2102	2012-11-28 07:00:00	18.399999999999999	17.399999999999999	\N	\N
8010	256	2108	2012-11-28 10:00:00	13.300000000000001	\N	\N	\N
8013	252	2109	2012-11-28 10:30:00	18.300000000000001	17.300000000000001	\N	\N
8017	252	2110	2012-11-28 11:00:00	18.300000000000001	17.300000000000001	\N	\N
8024	241	2111	2012-11-28 11:30:00	15.800000000000001	\N	15.6	15.6
8033	252	2114	2012-11-28 13:00:00	18.899999999999999	18.100000000000001	\N	\N
8040	241	2115	2012-11-28 13:30:00	15.6	\N	15.199999999999999	15.199999999999999
8042	256	2116	2012-11-28 14:00:00	14.4	\N	\N	\N
8045	252	2117	2012-11-28 14:30:00	19.399999999999999	18.699999999999999	\N	\N
8047	257	2117	2012-11-28 14:30:00	10	\N	\N	\N
8064	241	2121	2012-11-28 16:30:00	12	\N	11.9	11.9
8076	241	2124	2012-11-28 18:00:00	11.1	\N	11.199999999999999	11.199999999999999
8091	257	2128	2012-11-28 20:00:00	10.6	\N	\N	\N
8093	252	2129	2012-11-28 20:30:00	20.600000000000001	19.800000000000001	\N	\N
8106	256	2132	2012-11-28 22:00:00	14.4	\N	\N	\N
8116	241	2134	2012-11-28 23:00:00	11.699999999999999	\N	11.9	11.9
8118	256	2135	2012-11-28 23:30:00	14.4	\N	\N	\N
8126	256	2137	2012-11-29 00:30:00	14.4	\N	\N	\N
8140	241	2140	2012-11-29 02:00:00	10	\N	10.300000000000001	10.300000000000001
8143	257	2141	2012-11-29 02:30:00	10	\N	\N	\N
8148	241	2142	2012-11-29 03:00:00	9.0999999999999996	\N	9.3000000000000007	9.3000000000000007
8153	252	2144	2012-11-29 04:00:00	19.899999999999999	19.199999999999999	\N	\N
8164	241	2146	2012-11-29 05:00:00	5.5999999999999996	\N	5.5999999999999996	5.5999999999999996
8166	256	2147	2012-11-29 05:30:00	13.9	\N	\N	\N
8169	252	2148	2012-11-29 06:00:00	19.600000000000001	18.699999999999999	\N	\N
8182	256	2151	2012-11-29 07:30:00	13.9	\N	\N	\N
8190	256	2153	2012-11-29 08:30:00	13.9	\N	\N	\N
8203	257	2156	2012-11-29 10:00:00	9.4000000000000004	\N	\N	\N
8222	256	2161	2012-11-29 12:30:00	13.9	\N	\N	\N
8227	257	2162	2012-11-29 13:00:00	9.4000000000000004	\N	\N	\N
8229	252	2163	2012-11-29 13:30:00	18.899999999999999	18.100000000000001	\N	\N
8231	257	2163	2012-11-29 13:30:00	9.4000000000000004	\N	\N	\N
8235	257	2164	2012-11-29 14:00:00	10	\N	\N	\N
8237	252	2165	2012-11-29 14:30:00	18.800000000000001	17.899999999999999	\N	\N
8250	256	2168	2012-11-29 16:00:00	13.9	\N	\N	\N
8253	252	2169	2012-11-29 16:30:00	19.100000000000001	18.300000000000001	\N	\N
8257	252	2170	2012-11-29 17:00:00	19.300000000000001	18.5	\N	\N
8268	241	2172	2012-11-29 18:00:00	9.1999999999999993	\N	9.4000000000000004	9.4000000000000004
8272	241	2173	2012-11-29 18:30:00	8.9000000000000004	\N	9.1999999999999993	9.1999999999999993
8279	257	2175	2012-11-29 19:30:00	10	\N	\N	\N
8282	256	2176	2012-11-29 20:00:00	14.4	\N	\N	\N
7885	252	2077	2012-11-27 18:30:00	18.699999999999999	17.600000000000001	\N	\N
7887	257	2077	2012-11-27 18:30:00	10	\N	\N	\N
7904	241	2081	2012-11-27 20:30:00	10.800000000000001	\N	10.699999999999999	10.699999999999999
7906	256	2082	2012-11-27 21:00:00	13.300000000000001	\N	\N	\N
7909	252	2083	2012-11-27 21:30:00	18.699999999999999	17.699999999999999	\N	\N
7920	241	2085	2012-11-27 22:30:00	10.4	\N	10.4	10.4
7926	256	2087	2012-11-27 23:30:00	13.300000000000001	\N	\N	\N
7934	256	2089	2012-11-28 00:30:00	13.300000000000001	\N	\N	\N
7943	257	2091	2012-11-28 01:30:00	10	\N	\N	\N
7949	252	2093	2012-11-28 02:30:00	18.600000000000001	17.600000000000001	\N	\N
7956	241	2094	2012-11-28 03:00:00	8.9000000000000004	\N	9	9
7962	256	2096	2012-11-28 04:00:00	13.300000000000001	\N	\N	\N
7965	252	2097	2012-11-28 04:30:00	18.5	17.5	\N	\N
7967	257	2097	2012-11-28 04:30:00	9.4000000000000004	\N	\N	\N
7980	241	2100	2012-11-28 06:00:00	8.5	\N	8.5999999999999996	8.5999999999999996
7982	256	2101	2012-11-28 06:30:00	13.300000000000001	\N	\N	\N
7987	257	2102	2012-11-28 07:00:00	9.4000000000000004	\N	\N	\N
7989	252	2103	2012-11-28 07:30:00	18.399999999999999	17.399999999999999	\N	\N
7993	252	2104	2012-11-28 08:00:00	18.399999999999999	17.399999999999999	\N	\N
8000	241	2105	2012-11-28 08:30:00	9.1999999999999993	\N	9.4000000000000004	9.4000000000000004
8002	256	2106	2012-11-28 09:00:00	13.300000000000001	\N	\N	\N
8005	252	2107	2012-11-28 09:30:00	18.300000000000001	17.300000000000001	\N	\N
8031	257	2113	2012-11-28 12:30:00	10	\N	\N	\N
8036	241	2114	2012-11-28 13:00:00	15.699999999999999	\N	15.4	15.4
8044	241	2116	2012-11-28 14:00:00	14.699999999999999	\N	14.300000000000001	14.300000000000001
8050	256	2118	2012-11-28 15:00:00	14.4	\N	\N	\N
8055	257	2119	2012-11-28 15:30:00	10.6	\N	\N	\N
8058	256	2120	2012-11-28 16:00:00	15	\N	\N	\N
8061	252	2121	2012-11-28 16:30:00	20.100000000000001	19.399999999999999	\N	\N
8071	257	2123	2012-11-28 17:30:00	10.6	\N	\N	\N
8078	256	2125	2012-11-28 18:30:00	15	\N	\N	\N
8100	241	2130	2012-11-28 21:00:00	11.199999999999999	\N	11.300000000000001	11.300000000000001
8108	241	2132	2012-11-28 22:00:00	10.699999999999999	\N	10.9	10.9
8110	256	2133	2012-11-28 22:30:00	14.4	\N	\N	\N
8132	241	2138	2012-11-29 01:00:00	11.1	\N	11.199999999999999	11.199999999999999
8134	256	2139	2012-11-29 01:30:00	14.4	\N	\N	\N
8138	256	2140	2012-11-29 02:00:00	14.4	\N	\N	\N
8141	252	2141	2012-11-29 02:30:00	20.399999999999999	19.600000000000001	\N	\N
8152	241	2143	2012-11-29 03:30:00	8.6999999999999993	\N	8.9000000000000004	8.9000000000000004
8167	257	2147	2012-11-29 05:30:00	10	\N	\N	\N
8188	241	2152	2012-11-29 08:00:00	7.5	\N	7.7000000000000002	6.7000000000000002
8192	241	2153	2012-11-29 08:30:00	9.8000000000000007	\N	10	9.3000000000000007
8194	256	2154	2012-11-29 09:00:00	13.9	\N	\N	\N
8201	252	2156	2012-11-29 10:00:00	19.100000000000001	18.199999999999999	\N	\N
8214	256	2159	2012-11-29 11:30:00	13.9	\N	\N	\N
8225	252	2162	2012-11-29 13:00:00	18.899999999999999	18.100000000000001	\N	\N
8251	257	2168	2012-11-29 16:00:00	10	\N	\N	\N
7886	256	2077	2012-11-27 18:30:00	13.300000000000001	\N	\N	\N
7889	252	2078	2012-11-27 19:00:00	18.699999999999999	17.600000000000001	\N	\N
7902	256	2081	2012-11-27 20:30:00	13.300000000000001	\N	\N	\N
7905	252	2082	2012-11-27 21:00:00	18.699999999999999	17.699999999999999	\N	\N
7912	241	2083	2012-11-27 21:30:00	10.800000000000001	\N	10.699999999999999	10.699999999999999
7918	256	2085	2012-11-27 22:30:00	13.300000000000001	\N	\N	\N
7940	241	2090	2012-11-28 01:00:00	8.9000000000000004	\N	9	9
7957	252	2095	2012-11-28 03:30:00	18.600000000000001	17.600000000000001	\N	\N
7964	241	2096	2012-11-28 04:00:00	9.1999999999999993	\N	9.3000000000000007	9.3000000000000007
7968	241	2097	2012-11-28 04:30:00	9.1999999999999993	\N	9.3000000000000007	9.3000000000000007
7970	256	2098	2012-11-28 05:00:00	13.300000000000001	\N	\N	\N
7973	252	2099	2012-11-28 05:30:00	18.5	17.5	\N	\N
7979	257	2100	2012-11-28 06:00:00	9.4000000000000004	\N	\N	\N
7981	252	2101	2012-11-28 06:30:00	18.5	17.5	\N	\N
8007	257	2107	2012-11-28 09:30:00	9.4000000000000004	\N	\N	\N
8030	256	2113	2012-11-28 12:30:00	13.9	\N	\N	\N
8035	257	2114	2012-11-28 13:00:00	10	\N	\N	\N
8037	252	2115	2012-11-28 13:30:00	19	18.199999999999999	\N	\N
8046	256	2117	2012-11-28 14:30:00	14.4	\N	\N	\N
8049	252	2118	2012-11-28 15:00:00	19.600000000000001	18.800000000000001	\N	\N
8067	257	2122	2012-11-28 17:00:00	10.6	\N	\N	\N
8073	252	2124	2012-11-28 18:00:00	20.600000000000001	19.800000000000001	\N	\N
8088	241	2127	2012-11-28 19:30:00	11	\N	11.1	11.1
8092	241	2128	2012-11-28 20:00:00	10.9	\N	11.1	11.1
8095	257	2129	2012-11-28 20:30:00	10.6	\N	\N	\N
8098	256	2130	2012-11-28 21:00:00	14.4	\N	\N	\N
8105	252	2132	2012-11-28 22:00:00	20.399999999999999	19.600000000000001	\N	\N
8136	241	2139	2012-11-29 01:30:00	10.6	\N	10.800000000000001	10.699999999999999
8142	256	2141	2012-11-29 02:30:00	13.9	\N	\N	\N
8147	257	2142	2012-11-29 03:00:00	10	\N	\N	\N
8149	252	2143	2012-11-29 03:30:00	19.899999999999999	19.199999999999999	\N	\N
8151	257	2143	2012-11-29 03:30:00	10	\N	\N	\N
8155	257	2144	2012-11-29 04:00:00	10	\N	\N	\N
8178	256	2150	2012-11-29 07:00:00	13.9	\N	\N	\N
8197	252	2155	2012-11-29 09:30:00	19.199999999999999	18.300000000000001	\N	\N
8205	252	2157	2012-11-29 10:30:00	19	18	\N	\N
8207	257	2157	2012-11-29 10:30:00	9.4000000000000004	\N	\N	\N
8209	252	2158	2012-11-29 11:00:00	18.899999999999999	17.899999999999999	\N	\N
8211	257	2158	2012-11-29 11:00:00	9.4000000000000004	\N	\N	\N
8230	256	2163	2012-11-29 13:30:00	13.9	\N	\N	\N
8239	257	2165	2012-11-29 14:30:00	10	\N	\N	\N
8258	256	2170	2012-11-29 17:00:00	14.4	\N	\N	\N
8266	256	2172	2012-11-29 18:00:00	14.4	\N	\N	\N
8269	252	2173	2012-11-29 18:30:00	19.600000000000001	18.800000000000001	\N	\N
8284	241	2176	2012-11-29 20:00:00	8.1999999999999993	\N	8.4000000000000004	8.4000000000000004
7890	256	2078	2012-11-27 19:00:00	13.300000000000001	\N	\N	\N
7893	252	2079	2012-11-27 19:30:00	18.699999999999999	17.600000000000001	\N	\N
7895	257	2079	2012-11-27 19:30:00	10	\N	\N	\N
7897	252	2080	2012-11-27 20:00:00	18.699999999999999	17.699999999999999	\N	\N
7915	257	2084	2012-11-27 22:00:00	10	\N	\N	\N
7924	241	2086	2012-11-27 23:00:00	10.9	\N	10.800000000000001	10.800000000000001
7927	257	2087	2012-11-27 23:30:00	10	\N	\N	\N
7963	257	2096	2012-11-28 04:00:00	10	\N	\N	\N
7976	241	2099	2012-11-28 05:30:00	9.0999999999999996	\N	9.1999999999999993	9.1999999999999993
7978	256	2100	2012-11-28 06:00:00	13.300000000000001	\N	\N	\N
7991	257	2103	2012-11-28 07:30:00	9.4000000000000004	\N	\N	\N
7995	257	2104	2012-11-28 08:00:00	9.4000000000000004	\N	\N	\N
8015	257	2109	2012-11-28 10:30:00	9.4000000000000004	\N	\N	\N
8034	256	2114	2012-11-28 13:00:00	13.9	\N	\N	\N
8048	241	2117	2012-11-28 14:30:00	14.699999999999999	\N	14.300000000000001	14.300000000000001
8059	257	2120	2012-11-28 16:00:00	10.6	\N	\N	\N
8074	256	2124	2012-11-28 18:00:00	15	\N	\N	\N
8077	252	2125	2012-11-28 18:30:00	20.699999999999999	19.800000000000001	\N	\N
8081	252	2126	2012-11-28 19:00:00	20.699999999999999	19.800000000000001	\N	\N
8089	252	2128	2012-11-28 20:00:00	20.600000000000001	19.800000000000001	\N	\N
8097	252	2130	2012-11-28 21:00:00	20.5	19.699999999999999	\N	\N
8104	241	2131	2012-11-28 21:30:00	10.9	\N	11	11
8115	257	2134	2012-11-28 23:00:00	10.6	\N	\N	\N
8125	252	2137	2012-11-29 00:30:00	20.100000000000001	19.399999999999999	\N	\N
8127	257	2137	2012-11-29 00:30:00	10	\N	\N	\N
8129	252	2138	2012-11-29 01:00:00	20.100000000000001	19.399999999999999	\N	\N
8131	257	2138	2012-11-29 01:00:00	10	\N	\N	\N
8144	241	2141	2012-11-29 02:30:00	9.5	\N	9.8000000000000007	9.8000000000000007
8154	256	2144	2012-11-29 04:00:00	13.9	\N	\N	\N
8157	252	2145	2012-11-29 04:30:00	19.800000000000001	19.100000000000001	\N	\N
8171	257	2148	2012-11-29 06:00:00	10	\N	\N	\N
8176	241	2149	2012-11-29 06:30:00	5.2999999999999998	\N	5.4000000000000004	5.4000000000000004
8191	257	2153	2012-11-29 08:30:00	9.4000000000000004	\N	\N	\N
8193	252	2154	2012-11-29 09:00:00	19.199999999999999	18.300000000000001	\N	\N
8223	257	2161	2012-11-29 12:30:00	9.4000000000000004	\N	\N	\N
8232	241	2163	2012-11-29 13:30:00	14.800000000000001	\N	14.300000000000001	14.300000000000001
8247	257	2167	2012-11-29 15:30:00	10	\N	\N	\N
8264	241	2171	2012-11-29 17:30:00	9.3000000000000007	\N	9.5999999999999996	9.5999999999999996
8274	256	2174	2012-11-29 19:00:00	14.4	\N	\N	\N
8277	252	2175	2012-11-29 19:30:00	19.699999999999999	18.899999999999999	\N	\N
8281	252	2176	2012-11-29 20:00:00	19.699999999999999	18.899999999999999	\N	\N
7892	241	2078	2012-11-27 19:00:00	12.4	\N	12.1	12.1
7896	241	2079	2012-11-27 19:30:00	12	\N	11.699999999999999	11.699999999999999
7898	256	2080	2012-11-27 20:00:00	13.300000000000001	\N	\N	\N
7901	252	2081	2012-11-27 20:30:00	18.699999999999999	17.699999999999999	\N	\N
7922	256	2086	2012-11-27 23:00:00	13.300000000000001	\N	\N	\N
7925	252	2087	2012-11-27 23:30:00	18.699999999999999	17.699999999999999	\N	\N
7936	241	2089	2012-11-28 00:30:00	9.5	\N	9.5999999999999996	9.5999999999999996
7948	241	2092	2012-11-28 02:00:00	8.8000000000000007	\N	8.9000000000000004	8.9000000000000004
7950	256	2093	2012-11-28 02:30:00	13.300000000000001	\N	\N	\N
7958	256	2095	2012-11-28 03:30:00	13.300000000000001	\N	\N	\N
7975	257	2099	2012-11-28 05:30:00	9.4000000000000004	\N	\N	\N
7988	241	2102	2012-11-28 07:00:00	8.3000000000000007	\N	8.4000000000000004	8.4000000000000004
7990	256	2103	2012-11-28 07:30:00	13.300000000000001	\N	\N	\N
7999	257	2105	2012-11-28 08:30:00	9.4000000000000004	\N	\N	\N
8001	252	2106	2012-11-28 09:00:00	18.300000000000001	17.300000000000001	\N	\N
8014	256	2109	2012-11-28 10:30:00	13.300000000000001	\N	\N	\N
8019	257	2110	2012-11-28 11:00:00	9.4000000000000004	\N	\N	\N
8023	257	2111	2012-11-28 11:30:00	9.4000000000000004	\N	\N	\N
8028	241	2112	2012-11-28 12:00:00	15.699999999999999	\N	15.4	15.4
8043	257	2116	2012-11-28 14:00:00	10	\N	\N	\N
8066	256	2122	2012-11-28 17:00:00	15	\N	\N	\N
8069	252	2123	2012-11-28 17:30:00	20.5	19.800000000000001	\N	\N
8079	257	2125	2012-11-28 18:30:00	10.6	\N	\N	\N
8099	257	2130	2012-11-28 21:00:00	10.6	\N	\N	\N
8101	252	2131	2012-11-28 21:30:00	20.399999999999999	19.600000000000001	\N	\N
8114	256	2134	2012-11-28 23:00:00	14.4	\N	\N	\N
8117	252	2135	2012-11-28 23:30:00	20.199999999999999	19.600000000000001	\N	\N
8120	241	2135	2012-11-28 23:30:00	11.300000000000001	\N	11.5	11.5
8124	241	2136	2012-11-29 00:00:00	10.9	\N	11.1	11.1
8130	256	2138	2012-11-29 01:00:00	14.4	\N	\N	\N
8135	257	2139	2012-11-29 01:30:00	10	\N	\N	\N
8163	257	2146	2012-11-29 05:00:00	10	\N	\N	\N
8174	256	2149	2012-11-29 06:30:00	13.9	\N	\N	\N
8179	257	2150	2012-11-29 07:00:00	9.4000000000000004	\N	\N	\N
8181	252	2151	2012-11-29 07:30:00	19.699999999999999	18.800000000000001	\N	\N
8189	252	2153	2012-11-29 08:30:00	19.300000000000001	18.300000000000001	\N	\N
8200	241	2155	2012-11-29 09:30:00	11.9	\N	11.800000000000001	11.800000000000001
8204	241	2156	2012-11-29 10:00:00	12.5	\N	12.300000000000001	11.800000000000001
8210	256	2158	2012-11-29 11:00:00	13.9	\N	\N	\N
8215	257	2159	2012-11-29 11:30:00	9.4000000000000004	\N	\N	\N
8217	252	2160	2012-11-29 12:00:00	18.899999999999999	18	\N	\N
8221	252	2161	2012-11-29 12:30:00	18.899999999999999	18.100000000000001	\N	\N
8241	252	2166	2012-11-29 15:00:00	18.899999999999999	18.100000000000001	\N	\N
8248	241	2167	2012-11-29 15:30:00	10.300000000000001	\N	10.4	8.9000000000000004
8259	257	2170	2012-11-29 17:00:00	10	\N	\N	\N
8263	257	2171	2012-11-29 17:30:00	10	\N	\N	\N
8270	256	2173	2012-11-29 18:30:00	14.4	\N	\N	\N
8273	252	2174	2012-11-29 19:00:00	19.699999999999999	18.899999999999999	\N	\N
8283	257	2176	2012-11-29 20:00:00	10	\N	\N	\N
7894	256	2079	2012-11-27 19:30:00	13.300000000000001	\N	\N	\N
7911	257	2083	2012-11-27 21:30:00	10	\N	\N	\N
7923	257	2086	2012-11-27 23:00:00	10	\N	\N	\N
7930	256	2088	2012-11-28 00:00:00	13.300000000000001	\N	\N	\N
7937	252	2090	2012-11-28 01:00:00	18.699999999999999	17.699999999999999	\N	\N
7945	252	2092	2012-11-28 02:00:00	18.600000000000001	17.600000000000001	\N	\N
7947	257	2092	2012-11-28 02:00:00	10	\N	\N	\N
7959	257	2095	2012-11-28 03:30:00	10	\N	\N	\N
7972	241	2098	2012-11-28 05:00:00	9.4000000000000004	\N	9.5	9.5
7974	256	2099	2012-11-28 05:30:00	13.300000000000001	\N	\N	\N
7983	257	2101	2012-11-28 06:30:00	9.4000000000000004	\N	\N	\N
7992	241	2103	2012-11-28 07:30:00	7.7000000000000002	\N	7.7999999999999998	7.7999999999999998
7994	256	2104	2012-11-28 08:00:00	13.300000000000001	\N	\N	\N
7997	252	2105	2012-11-28 08:30:00	18.300000000000001	17.300000000000001	\N	\N
8011	257	2108	2012-11-28 10:00:00	9.4000000000000004	\N	\N	\N
8016	241	2109	2012-11-28 10:30:00	13.699999999999999	\N	13.4	13.4
8022	256	2111	2012-11-28 11:30:00	13.300000000000001	\N	\N	\N
8025	252	2112	2012-11-28 12:00:00	18.600000000000001	17.600000000000001	\N	\N
8038	256	2115	2012-11-28 13:30:00	13.9	\N	\N	\N
8051	257	2118	2012-11-28 15:00:00	10.6	\N	\N	\N
8056	241	2119	2012-11-28 15:30:00	13.4	\N	13.199999999999999	13.199999999999999
8063	257	2121	2012-11-28 16:30:00	10.6	\N	\N	\N
8070	256	2123	2012-11-28 17:30:00	15	\N	\N	\N
8083	257	2126	2012-11-28 19:00:00	10.6	\N	\N	\N
8090	256	2128	2012-11-28 20:00:00	15	\N	\N	\N
8113	252	2134	2012-11-28 23:00:00	20.300000000000001	19.600000000000001	\N	\N
8128	241	2137	2012-11-29 00:30:00	11.199999999999999	\N	11.4	11.300000000000001
8133	252	2139	2012-11-29 01:30:00	20.100000000000001	19.399999999999999	\N	\N
8139	257	2140	2012-11-29 02:00:00	10	\N	\N	\N
8146	256	2142	2012-11-29 03:00:00	13.9	\N	\N	\N
8160	241	2145	2012-11-29 04:30:00	6.7000000000000002	\N	6.7999999999999998	6.7999999999999998
8162	256	2146	2012-11-29 05:00:00	13.9	\N	\N	\N
8165	252	2147	2012-11-29 05:30:00	19.699999999999999	18.800000000000001	\N	\N
8186	256	2152	2012-11-29 08:00:00	13.9	\N	\N	\N
8195	257	2154	2012-11-29 09:00:00	9.4000000000000004	\N	\N	\N
8212	241	2158	2012-11-29 11:00:00	13.300000000000001	\N	13.1	12.199999999999999
8219	257	2160	2012-11-29 12:00:00	9.4000000000000004	\N	\N	\N
8236	241	2164	2012-11-29 14:00:00	14.199999999999999	\N	13.699999999999999	13.699999999999999
8238	256	2165	2012-11-29 14:30:00	13.9	\N	\N	\N
8243	257	2166	2012-11-29 15:00:00	10	\N	\N	\N
8245	252	2167	2012-11-29 15:30:00	18.800000000000001	17.899999999999999	\N	\N
8262	256	2171	2012-11-29 17:30:00	14.4	\N	\N	\N
8265	252	2172	2012-11-29 18:00:00	19.600000000000001	18.800000000000001	\N	\N
7903	257	2081	2012-11-27 20:30:00	10	\N	\N	\N
7916	241	2084	2012-11-27 22:00:00	10.300000000000001	\N	10.300000000000001	10.300000000000001
7931	257	2088	2012-11-28 00:00:00	10	\N	\N	\N
7942	256	2091	2012-11-28 01:30:00	13.300000000000001	\N	\N	\N
7960	241	2095	2012-11-28 03:30:00	9.0999999999999996	\N	9.1999999999999993	9.1999999999999993
7971	257	2098	2012-11-28 05:00:00	9.4000000000000004	\N	\N	\N
7986	256	2102	2012-11-28 07:00:00	13.300000000000001	\N	\N	\N
8004	241	2106	2012-11-28 09:00:00	10.1	\N	10.199999999999999	10.199999999999999
8006	256	2107	2012-11-28 09:30:00	13.300000000000001	\N	\N	\N
8009	252	2108	2012-11-28 10:00:00	18.300000000000001	17.300000000000001	\N	\N
8027	257	2112	2012-11-28 12:00:00	9.4000000000000004	\N	\N	\N
8052	241	2118	2012-11-28 15:00:00	14.1	\N	13.800000000000001	13.800000000000001
8080	241	2125	2012-11-28 18:30:00	11.199999999999999	\N	11.300000000000001	11.300000000000001
8086	256	2127	2012-11-28 19:30:00	15	\N	\N	\N
8094	256	2129	2012-11-28 20:30:00	14.4	\N	\N	\N
8103	257	2131	2012-11-28 21:30:00	10.6	\N	\N	\N
8112	241	2133	2012-11-28 22:30:00	12.199999999999999	\N	12.199999999999999	11.6
8119	257	2135	2012-11-28 23:30:00	10.6	\N	\N	\N
8121	252	2136	2012-11-29 00:00:00	20.199999999999999	19.600000000000001	\N	\N
8150	256	2143	2012-11-29 03:30:00	13.9	\N	\N	\N
8159	257	2145	2012-11-29 04:30:00	10	\N	\N	\N
8161	252	2146	2012-11-29 05:00:00	19.699999999999999	18.899999999999999	\N	\N
8172	241	2148	2012-11-29 06:00:00	5.2999999999999998	\N	5.2999999999999998	5.2999999999999998
8180	241	2150	2012-11-29 07:00:00	5.2999999999999998	\N	5.4000000000000004	5.4000000000000004
8184	241	2151	2012-11-29 07:30:00	6	\N	6.0999999999999996	6.0999999999999996
8187	257	2152	2012-11-29 08:00:00	9.4000000000000004	\N	\N	\N
8196	241	2154	2012-11-29 09:00:00	10.800000000000001	\N	10.9	10.800000000000001
8198	256	2155	2012-11-29 09:30:00	13.9	\N	\N	\N
8206	256	2157	2012-11-29 10:30:00	13.9	\N	\N	\N
8216	241	2159	2012-11-29 11:30:00	14.199999999999999	\N	13.9	13.4
8218	256	2160	2012-11-29 12:00:00	13.9	\N	\N	\N
8226	256	2162	2012-11-29 13:00:00	13.9	\N	\N	\N
8240	241	2165	2012-11-29 14:30:00	13.800000000000001	\N	13.4	13.4
8242	256	2166	2012-11-29 15:00:00	13.300000000000001	\N	\N	\N
8252	241	2168	2012-11-29 16:00:00	9.9000000000000004	\N	10.199999999999999	10.199999999999999
8254	256	2169	2012-11-29 16:30:00	13.9	\N	\N	\N
8267	257	2172	2012-11-29 18:00:00	10	\N	\N	\N
8276	241	2174	2012-11-29 19:00:00	8.5	\N	8.6999999999999993	8.6999999999999993
7908	241	2082	2012-11-27 21:00:00	11.300000000000001	\N	11.199999999999999	11.199999999999999
7919	257	2085	2012-11-27 22:30:00	10	\N	\N	\N
7939	257	2090	2012-11-28 01:00:00	10	\N	\N	\N
7941	252	2091	2012-11-28 01:30:00	18.600000000000001	17.600000000000001	\N	\N
7955	257	2094	2012-11-28 03:00:00	10	\N	\N	\N
7966	256	2097	2012-11-28 04:30:00	13.300000000000001	\N	\N	\N
7969	252	2098	2012-11-28 05:00:00	18.5	17.5	\N	\N
7977	252	2100	2012-11-28 06:00:00	18.5	17.5	\N	\N
7984	241	2101	2012-11-28 06:30:00	8.4000000000000004	\N	8.5999999999999996	8.5999999999999996
8003	257	2106	2012-11-28 09:00:00	9.4000000000000004	\N	\N	\N
8012	241	2108	2012-11-28 10:00:00	12.300000000000001	\N	12.1	12.1
8020	241	2110	2012-11-28 11:00:00	14.300000000000001	\N	13.9	13.9
8026	256	2112	2012-11-28 12:00:00	13.9	\N	\N	\N
8029	252	2113	2012-11-28 12:30:00	18.800000000000001	17.899999999999999	\N	\N
8053	252	2119	2012-11-28 15:30:00	19.699999999999999	19.100000000000001	\N	\N
8060	241	2120	2012-11-28 16:00:00	12.300000000000001	\N	12.199999999999999	12.199999999999999
8062	256	2121	2012-11-28 16:30:00	15	\N	\N	\N
8065	252	2122	2012-11-28 17:00:00	20.300000000000001	19.600000000000001	\N	\N
8075	257	2124	2012-11-28 18:00:00	10.6	\N	\N	\N
8082	256	2126	2012-11-28 19:00:00	15	\N	\N	\N
8085	252	2127	2012-11-28 19:30:00	20.699999999999999	19.800000000000001	\N	\N
8096	241	2129	2012-11-28 20:30:00	10.9	\N	11.1	11.1
8102	256	2131	2012-11-28 21:30:00	14.4	\N	\N	\N
8107	257	2132	2012-11-28 22:00:00	10.6	\N	\N	\N
8109	252	2133	2012-11-28 22:30:00	20.300000000000001	19.5	\N	\N
8111	257	2133	2012-11-28 22:30:00	10.6	\N	\N	\N
8122	256	2136	2012-11-29 00:00:00	14.4	\N	\N	\N
8137	252	2140	2012-11-29 02:00:00	20	19.300000000000001	\N	\N
8145	252	2142	2012-11-29 03:00:00	20.100000000000001	19.399999999999999	\N	\N
8156	241	2144	2012-11-29 04:00:00	7.2999999999999998	\N	7.4000000000000004	7.4000000000000004
8158	256	2145	2012-11-29 04:30:00	13.9	\N	\N	\N
8168	241	2147	2012-11-29 05:30:00	5.7999999999999998	\N	5.9000000000000004	5.9000000000000004
8170	256	2148	2012-11-29 06:00:00	13.9	\N	\N	\N
8173	252	2149	2012-11-29 06:30:00	19.600000000000001	18.699999999999999	\N	\N
8177	252	2150	2012-11-29 07:00:00	19.399999999999999	18.600000000000001	\N	\N
8183	257	2151	2012-11-29 07:30:00	9.4000000000000004	\N	\N	\N
8185	252	2152	2012-11-29 08:00:00	19.399999999999999	18.600000000000001	\N	\N
8202	256	2156	2012-11-29 10:00:00	13.9	\N	\N	\N
8213	252	2159	2012-11-29 11:30:00	18.899999999999999	18	\N	\N
8220	241	2160	2012-11-29 12:00:00	14	\N	13.699999999999999	13.699999999999999
8224	241	2161	2012-11-29 12:30:00	14.699999999999999	\N	14.199999999999999	14.199999999999999
8234	256	2164	2012-11-29 14:00:00	13.9	\N	\N	\N
8255	257	2169	2012-11-29 16:30:00	10	\N	\N	\N
8260	241	2170	2012-11-29 17:00:00	9.5999999999999996	\N	9.8000000000000007	9.8000000000000007
8275	257	2174	2012-11-29 19:00:00	10	\N	\N	\N
8280	241	2175	2012-11-29 19:30:00	8.3000000000000007	\N	8.5	8.5
8285	252	2177	2012-11-29 20:30:00	19.800000000000001	19.100000000000001	\N	\N
8286	256	2177	2012-11-29 20:30:00	14.4	\N	\N	\N
8287	257	2177	2012-11-29 20:30:00	10	\N	\N	\N
8288	241	2177	2012-11-29 20:30:00	8.4000000000000004	\N	8.5999999999999996	8.5999999999999996
8289	252	2178	2012-11-29 21:00:00	19.800000000000001	19.100000000000001	\N	\N
8290	256	2178	2012-11-29 21:00:00	14.4	\N	\N	\N
8291	257	2178	2012-11-29 21:00:00	10	\N	\N	\N
8292	241	2178	2012-11-29 21:00:00	8.5999999999999996	\N	8.8000000000000007	8.8000000000000007
8293	252	2179	2012-11-29 21:30:00	20	19.300000000000001	\N	\N
8294	256	2179	2012-11-29 21:30:00	14.4	\N	\N	\N
8295	257	2179	2012-11-29 21:30:00	10	\N	\N	\N
8296	241	2179	2012-11-29 21:30:00	8.5999999999999996	\N	8.8000000000000007	8.8000000000000007
8297	252	2180	2012-11-29 22:00:00	20	19.300000000000001	\N	\N
8298	256	2180	2012-11-29 22:00:00	14.4	\N	\N	\N
8299	257	2180	2012-11-29 22:00:00	10	\N	\N	\N
8300	241	2180	2012-11-29 22:00:00	8.5	\N	8.6999999999999993	8.6999999999999993
8301	252	2181	2012-11-29 22:30:00	20.100000000000001	19.399999999999999	\N	\N
8302	256	2181	2012-11-29 22:30:00	14.4	\N	\N	\N
8303	257	2181	2012-11-29 22:30:00	10	\N	\N	\N
8304	241	2181	2012-11-29 22:30:00	8.5	\N	8.6999999999999993	8.6999999999999993
8305	252	2182	2012-11-29 23:00:00	20.100000000000001	19.399999999999999	\N	\N
8306	256	2182	2012-11-29 23:00:00	14.4	\N	\N	\N
8307	257	2182	2012-11-29 23:00:00	10	\N	\N	\N
8308	241	2182	2012-11-29 23:00:00	8.6999999999999993	\N	8.9000000000000004	8.9000000000000004
8309	252	2183	2012-11-29 23:30:00	20.100000000000001	19.399999999999999	\N	\N
8310	256	2183	2012-11-29 23:30:00	14.4	\N	\N	\N
8311	257	2183	2012-11-29 23:30:00	10	\N	\N	\N
8312	241	2183	2012-11-29 23:30:00	7.0999999999999996	\N	7.2000000000000002	5.7000000000000002
8313	252	2184	2012-11-30 00:00:00	20	19.199999999999999	\N	\N
8314	256	2184	2012-11-30 00:00:00	14.4	\N	\N	\N
8315	257	2184	2012-11-30 00:00:00	10	\N	\N	\N
8316	241	2184	2012-11-30 00:00:00	6.0999999999999996	\N	6.2000000000000002	4.5
8317	252	2185	2012-11-30 00:30:00	19.899999999999999	19.199999999999999	\N	\N
8318	256	2185	2012-11-30 00:30:00	13.9	\N	\N	\N
8319	257	2185	2012-11-30 00:30:00	10	\N	\N	\N
8320	241	2185	2012-11-30 00:30:00	5.5999999999999996	\N	5.5999999999999996	3.7999999999999998
8321	252	2186	2012-11-30 01:00:00	19.699999999999999	18.800000000000001	\N	\N
8322	256	2186	2012-11-30 01:00:00	13.9	\N	\N	\N
8323	257	2186	2012-11-30 01:00:00	9.4000000000000004	\N	\N	\N
8324	241	2186	2012-11-30 01:00:00	5.2000000000000002	\N	5.2000000000000002	3.3999999999999999
8325	252	2187	2012-11-30 01:30:00	19.699999999999999	18.699999999999999	\N	\N
8326	256	2187	2012-11-30 01:30:00	13.9	\N	\N	\N
8327	257	2187	2012-11-30 01:30:00	9.4000000000000004	\N	\N	\N
8328	241	2187	2012-11-30 01:30:00	4.9000000000000004	\N	4.9000000000000004	4.9000000000000004
8329	252	2188	2012-11-30 02:00:00	19.600000000000001	18.600000000000001	\N	\N
8330	256	2188	2012-11-30 02:00:00	13.9	\N	\N	\N
8331	257	2188	2012-11-30 02:00:00	9.4000000000000004	\N	\N	\N
8332	241	2188	2012-11-30 02:00:00	4.2000000000000002	\N	4.2000000000000002	3.2999999999999998
8333	252	2189	2012-11-30 02:30:00	19.399999999999999	18.399999999999999	\N	\N
8334	256	2189	2012-11-30 02:30:00	13.300000000000001	\N	\N	\N
8335	257	2189	2012-11-30 02:30:00	9.4000000000000004	\N	\N	\N
8336	241	2189	2012-11-30 02:30:00	3.8999999999999999	\N	3.8999999999999999	2.3999999999999999
8337	252	2190	2012-11-30 03:00:00	19.399999999999999	18.300000000000001	\N	\N
8338	256	2190	2012-11-30 03:00:00	13.300000000000001	\N	\N	\N
8339	257	2190	2012-11-30 03:00:00	8.9000000000000004	\N	\N	\N
8340	241	2190	2012-11-30 03:00:00	3.7999999999999998	\N	3.7999999999999998	2.2000000000000002
8341	252	2191	2012-11-30 03:30:00	19.300000000000001	18.199999999999999	\N	\N
8342	256	2191	2012-11-30 03:30:00	13.300000000000001	\N	\N	\N
8343	257	2191	2012-11-30 03:30:00	8.9000000000000004	\N	\N	\N
8344	241	2191	2012-11-30 03:30:00	3.7000000000000002	\N	3.7000000000000002	3.5
8345	252	2192	2012-11-30 04:00:00	19.199999999999999	18.100000000000001	\N	\N
8346	256	2192	2012-11-30 04:00:00	13.300000000000001	\N	\N	\N
8347	257	2192	2012-11-30 04:00:00	8.9000000000000004	\N	\N	\N
8348	241	2192	2012-11-30 04:00:00	3.5	\N	3.5	3.5
8349	252	2193	2012-11-30 04:30:00	19.100000000000001	17.899999999999999	\N	\N
8350	256	2193	2012-11-30 04:30:00	13.300000000000001	\N	\N	\N
8351	257	2193	2012-11-30 04:30:00	8.9000000000000004	\N	\N	\N
8352	241	2193	2012-11-30 04:30:00	3.2999999999999998	\N	3.2999999999999998	3.1000000000000001
8353	252	2194	2012-11-30 05:00:00	19	17.800000000000001	\N	\N
8354	256	2194	2012-11-30 05:00:00	12.800000000000001	\N	\N	\N
8355	257	2194	2012-11-30 05:00:00	8.9000000000000004	\N	\N	\N
8356	241	2194	2012-11-30 05:00:00	3.2999999999999998	\N	3.2999999999999998	3.1000000000000001
8357	252	2195	2012-11-30 05:30:00	18.899999999999999	17.699999999999999	\N	\N
8358	256	2195	2012-11-30 05:30:00	12.800000000000001	\N	\N	\N
8359	257	2195	2012-11-30 05:30:00	8.3000000000000007	\N	\N	\N
8360	241	2195	2012-11-30 05:30:00	3.2000000000000002	\N	3.2000000000000002	2.2000000000000002
8361	252	2196	2012-11-30 06:00:00	18.800000000000001	17.600000000000001	\N	\N
8362	256	2196	2012-11-30 06:00:00	12.800000000000001	\N	\N	\N
8363	257	2196	2012-11-30 06:00:00	8.3000000000000007	\N	\N	\N
8364	241	2196	2012-11-30 06:00:00	3.1000000000000001	\N	3.1000000000000001	1.8999999999999999
8381	252	2221	2012-11-30 06:30:00	18.800000000000001	17.5	\N	\N
8382	256	2221	2012-11-30 06:30:00	12.800000000000001	\N	\N	\N
8383	257	2221	2012-11-30 06:30:00	8.3000000000000007	\N	\N	\N
8384	241	2221	2012-11-30 06:30:00	2.7999999999999998	\N	2.7999999999999998	2.6000000000000001
8385	252	2222	2012-11-30 07:00:00	18.699999999999999	17.399999999999999	\N	\N
8386	256	2222	2012-11-30 07:00:00	12.800000000000001	\N	\N	\N
8387	257	2222	2012-11-30 07:00:00	8.3000000000000007	\N	\N	\N
8388	241	2222	2012-11-30 07:00:00	2.7999999999999998	\N	2.7999999999999998	2.5
8401	252	2241	2012-11-30 07:30:00	18.600000000000001	17.300000000000001	\N	\N
8402	256	2241	2012-11-30 07:30:00	12.800000000000001	\N	\N	\N
8403	257	2241	2012-11-30 07:30:00	8.3000000000000007	\N	\N	\N
8404	241	2241	2012-11-30 07:30:00	2.7999999999999998	\N	2.7999999999999998	2.7999999999999998
8405	252	2242	2012-11-30 08:00:00	18.600000000000001	17.300000000000001	\N	\N
8406	256	2242	2012-11-30 08:00:00	12.800000000000001	\N	\N	\N
8407	257	2242	2012-11-30 08:00:00	8.3000000000000007	\N	\N	\N
8408	241	2242	2012-11-30 08:00:00	2.8999999999999999	\N	2.8999999999999999	2.8999999999999999
8409	252	2243	2012-11-30 08:30:00	18.699999999999999	17.5	\N	\N
8410	256	2243	2012-11-30 08:30:00	12.800000000000001	\N	\N	\N
8411	257	2243	2012-11-30 08:30:00	8.3000000000000007	\N	\N	\N
8412	241	2243	2012-11-30 08:30:00	3.1000000000000001	\N	3.1000000000000001	3.1000000000000001
8413	252	2244	2012-11-30 09:00:00	18.800000000000001	17.699999999999999	\N	\N
8414	256	2244	2012-11-30 09:00:00	12.800000000000001	\N	\N	\N
8415	257	2244	2012-11-30 09:00:00	8.3000000000000007	\N	\N	\N
8416	241	2244	2012-11-30 09:00:00	3.3999999999999999	\N	3.3999999999999999	3.3999999999999999
8417	252	2245	2012-11-30 09:30:00	19	17.800000000000001	\N	\N
8418	256	2245	2012-11-30 09:30:00	13.300000000000001	\N	\N	\N
8419	257	2245	2012-11-30 09:30:00	8.3000000000000007	\N	\N	\N
8420	241	2245	2012-11-30 09:30:00	4	\N	4.0999999999999996	4.0999999999999996
8421	252	2246	2012-11-30 10:00:00	19.100000000000001	18.100000000000001	\N	\N
8422	256	2246	2012-11-30 10:00:00	13.300000000000001	\N	\N	\N
8423	257	2246	2012-11-30 10:00:00	7.7999999999999998	\N	\N	\N
8424	241	2246	2012-11-30 10:00:00	4.0999999999999996	\N	4.0999999999999996	4.0999999999999996
8425	252	2247	2012-11-30 10:30:00	19.100000000000001	18.100000000000001	\N	\N
8426	256	2247	2012-11-30 10:30:00	13.300000000000001	\N	\N	\N
8427	257	2247	2012-11-30 10:30:00	7.7999999999999998	\N	\N	\N
8428	241	2247	2012-11-30 10:30:00	4.5999999999999996	\N	4.5999999999999996	4.4000000000000004
8429	252	2248	2012-11-30 11:00:00	19.199999999999999	18.199999999999999	\N	\N
8430	256	2248	2012-11-30 11:00:00	13.300000000000001	\N	\N	\N
8431	257	2248	2012-11-30 11:00:00	7.7999999999999998	\N	\N	\N
8432	241	2248	2012-11-30 11:00:00	4.7999999999999998	\N	4.7999999999999998	4.7999999999999998
8433	252	2249	2012-11-30 11:30:00	19.199999999999999	18.100000000000001	\N	\N
8434	256	2249	2012-11-30 11:30:00	13.300000000000001	\N	\N	\N
8435	257	2249	2012-11-30 11:30:00	8.3000000000000007	\N	\N	\N
8436	241	2249	2012-11-30 11:30:00	5.0999999999999996	\N	5	5
8437	252	2250	2012-11-30 12:00:00	19.100000000000001	18	\N	\N
8438	256	2250	2012-11-30 12:00:00	13.300000000000001	\N	\N	\N
8439	257	2250	2012-11-30 12:00:00	8.3000000000000007	\N	\N	\N
8440	241	2250	2012-11-30 12:00:00	5.2000000000000002	\N	5.2000000000000002	5.2000000000000002
8441	252	2251	2012-11-30 12:30:00	19.199999999999999	18.100000000000001	\N	\N
8442	256	2251	2012-11-30 12:30:00	13.300000000000001	\N	\N	\N
8443	257	2251	2012-11-30 12:30:00	8.3000000000000007	\N	\N	\N
8444	241	2251	2012-11-30 12:30:00	5.4000000000000004	\N	5.4000000000000004	5.4000000000000004
8445	252	2252	2012-11-30 13:00:00	19.199999999999999	18.100000000000001	\N	\N
8446	256	2252	2012-11-30 13:00:00	13.300000000000001	\N	\N	\N
8447	257	2252	2012-11-30 13:00:00	8.3000000000000007	\N	\N	\N
8448	241	2252	2012-11-30 13:00:00	5.5999999999999996	\N	5.5	5.5
8449	252	2253	2012-11-30 13:30:00	19.100000000000001	18	\N	\N
8450	256	2253	2012-11-30 13:30:00	13.300000000000001	\N	\N	\N
8451	257	2253	2012-11-30 13:30:00	8.3000000000000007	\N	\N	\N
8452	241	2253	2012-11-30 13:30:00	5.7000000000000002	\N	5.5999999999999996	5.5999999999999996
8453	252	2254	2012-11-30 14:00:00	19	17.800000000000001	\N	\N
8454	256	2254	2012-11-30 14:00:00	13.300000000000001	\N	\N	\N
8455	257	2254	2012-11-30 14:00:00	8.3000000000000007	\N	\N	\N
8456	241	2254	2012-11-30 14:00:00	5.7999999999999998	\N	5.7000000000000002	5.7000000000000002
8457	252	2255	2012-11-30 14:30:00	18.899999999999999	17.800000000000001	\N	\N
8458	256	2255	2012-11-30 14:30:00	13.300000000000001	\N	\N	\N
8459	257	2255	2012-11-30 14:30:00	8.3000000000000007	\N	\N	\N
8460	241	2255	2012-11-30 14:30:00	5.7000000000000002	\N	5.5999999999999996	5.5999999999999996
8461	252	2256	2012-11-30 15:00:00	18.899999999999999	17.800000000000001	\N	\N
8462	256	2256	2012-11-30 15:00:00	13.300000000000001	\N	\N	\N
8463	257	2256	2012-11-30 15:00:00	8.3000000000000007	\N	\N	\N
8464	241	2256	2012-11-30 15:00:00	5.7000000000000002	\N	5.5	5.5
8465	252	2257	2012-11-30 15:30:00	19	17.800000000000001	\N	\N
8466	256	2257	2012-11-30 15:30:00	13.300000000000001	\N	\N	\N
8467	257	2257	2012-11-30 15:30:00	8.3000000000000007	\N	\N	\N
8468	241	2257	2012-11-30 15:30:00	5.4000000000000004	\N	5.2999999999999998	5.2999999999999998
8469	252	2258	2012-11-30 16:00:00	19	17.800000000000001	\N	\N
8470	256	2258	2012-11-30 16:00:00	13.300000000000001	\N	\N	\N
8471	257	2258	2012-11-30 16:00:00	8.3000000000000007	\N	\N	\N
8472	241	2258	2012-11-30 16:00:00	5.2999999999999998	\N	5.2000000000000002	5.2000000000000002
8473	252	2259	2012-11-30 16:30:00	19.100000000000001	18	\N	\N
8474	256	2259	2012-11-30 16:30:00	13.300000000000001	\N	\N	\N
8475	257	2259	2012-11-30 16:30:00	8.3000000000000007	\N	\N	\N
8476	241	2259	2012-11-30 16:30:00	4.9000000000000004	\N	4.7999999999999998	4.7999999999999998
8477	252	2260	2012-11-30 17:00:00	19.199999999999999	18.100000000000001	\N	\N
8478	256	2260	2012-11-30 17:00:00	13.300000000000001	\N	\N	\N
8479	257	2260	2012-11-30 17:00:00	8.3000000000000007	\N	\N	\N
8480	241	2260	2012-11-30 17:00:00	4.5999999999999996	\N	4.5	4.5
8481	252	2261	2012-11-30 17:30:00	19.300000000000001	18.199999999999999	\N	\N
8482	256	2261	2012-11-30 17:30:00	13.300000000000001	\N	\N	\N
8483	257	2261	2012-11-30 17:30:00	8.3000000000000007	\N	\N	\N
8484	241	2261	2012-11-30 17:30:00	4.4000000000000004	\N	4.4000000000000004	4.4000000000000004
8485	252	2262	2012-11-30 18:00:00	19.300000000000001	18.199999999999999	\N	\N
8486	256	2262	2012-11-30 18:00:00	13.300000000000001	\N	\N	\N
8487	257	2262	2012-11-30 18:00:00	8.3000000000000007	\N	\N	\N
8488	241	2262	2012-11-30 18:00:00	4.2000000000000002	\N	4.0999999999999996	4.0999999999999996
8489	252	2263	2012-11-30 18:30:00	19.399999999999999	18.300000000000001	\N	\N
8490	256	2263	2012-11-30 18:30:00	13.300000000000001	\N	\N	\N
8491	257	2263	2012-11-30 18:30:00	8.3000000000000007	\N	\N	\N
8492	241	2263	2012-11-30 18:30:00	4.0999999999999996	\N	4	4
8493	252	2264	2012-11-30 19:00:00	19.399999999999999	18.300000000000001	\N	\N
8494	256	2264	2012-11-30 19:00:00	13.300000000000001	\N	\N	\N
8495	257	2264	2012-11-30 19:00:00	8.3000000000000007	\N	\N	\N
8496	241	2264	2012-11-30 19:00:00	4	\N	3.8999999999999999	3.8999999999999999
8521	252	2281	2012-11-30 19:30:00	19.399999999999999	18.300000000000001	\N	\N
8522	256	2281	2012-11-30 19:30:00	13.300000000000001	\N	\N	\N
8523	257	2281	2012-11-30 19:30:00	8.3000000000000007	\N	\N	\N
8524	241	2281	2012-11-30 19:30:00	3.7999999999999998	\N	3.7999999999999998	3.7999999999999998
8525	252	2282	2012-11-30 20:00:00	19.399999999999999	18.300000000000001	\N	\N
8526	256	2282	2012-11-30 20:00:00	13.300000000000001	\N	\N	\N
8527	257	2282	2012-11-30 20:00:00	8.3000000000000007	\N	\N	\N
8528	241	2282	2012-11-30 20:00:00	4.0999999999999996	\N	4	4
8541	252	2301	2012-11-30 20:30:00	19.300000000000001	18.199999999999999	\N	\N
8542	256	2301	2012-11-30 20:30:00	13.300000000000001	\N	\N	\N
8543	257	2301	2012-11-30 20:30:00	8.3000000000000007	\N	\N	\N
8544	241	2301	2012-11-30 20:30:00	4.5999999999999996	\N	4.5	4.4000000000000004
8545	252	2302	2012-11-30 21:00:00	19.300000000000001	18.199999999999999	\N	\N
8546	256	2302	2012-11-30 21:00:00	13.300000000000001	\N	\N	\N
8547	257	2302	2012-11-30 21:00:00	8.3000000000000007	\N	\N	\N
8548	241	2302	2012-11-30 21:00:00	4.5	\N	4.4000000000000004	4.4000000000000004
8549	252	2303	2012-11-30 21:30:00	19.199999999999999	18.100000000000001	\N	\N
8550	256	2303	2012-11-30 21:30:00	13.300000000000001	\N	\N	\N
8551	257	2303	2012-11-30 21:30:00	8.3000000000000007	\N	\N	\N
8552	241	2303	2012-11-30 21:30:00	4.4000000000000004	\N	4.4000000000000004	4.4000000000000004
8553	252	2304	2012-11-30 22:00:00	19.100000000000001	18	\N	\N
8554	256	2304	2012-11-30 22:00:00	13.300000000000001	\N	\N	\N
8555	257	2304	2012-11-30 22:00:00	7.7999999999999998	\N	\N	\N
8556	241	2304	2012-11-30 22:00:00	4.2999999999999998	\N	4.2999999999999998	4.2999999999999998
8581	252	2321	2012-11-30 22:30:00	19	17.800000000000001	\N	\N
8582	256	2321	2012-11-30 22:30:00	13.300000000000001	\N	\N	\N
8583	257	2321	2012-11-30 22:30:00	7.7999999999999998	\N	\N	\N
8584	241	2321	2012-11-30 22:30:00	4.2999999999999998	\N	4.2999999999999998	4.2999999999999998
8585	252	2322	2012-11-30 23:00:00	18.800000000000001	17.600000000000001	\N	\N
8586	256	2322	2012-11-30 23:00:00	13.300000000000001	\N	\N	\N
8587	257	2322	2012-11-30 23:00:00	7.7999999999999998	\N	\N	\N
8588	241	2322	2012-11-30 23:00:00	4.2999999999999998	\N	4.2000000000000002	4.2000000000000002
\.


--
-- Data for Name: s_data_temperatures_high_low; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_temperatures_high_low (id, sensor_id, sensor_data_id, date_time, heat_high, heat_low, temperature_high, temperature_low) FROM stdin;
1801	241	1801	2012-11-22 00:30:00	\N	\N	8.5999999999999996	8.5999999999999996
1802	241	1802	2012-11-22 01:00:00	\N	\N	8.5999999999999996	8.5999999999999996
1803	241	1803	2012-11-22 01:30:00	\N	\N	8.5999999999999996	8.5999999999999996
1804	241	1804	2012-11-22 02:00:00	\N	\N	8.5999999999999996	8.4000000000000004
1805	241	1805	2012-11-22 02:30:00	\N	\N	8.5	8.4000000000000004
1806	241	1806	2012-11-22 03:00:00	\N	\N	8.4000000000000004	8.4000000000000004
1807	241	1807	2012-11-22 03:30:00	\N	\N	8.4000000000000004	8.4000000000000004
1808	241	1808	2012-11-22 04:00:00	\N	\N	8.4000000000000004	8.3000000000000007
1809	241	1809	2012-11-22 04:30:00	\N	\N	8.3000000000000007	8.3000000000000007
1810	241	1810	2012-11-22 05:00:00	\N	\N	8.3000000000000007	8.3000000000000007
1811	241	1811	2012-11-22 05:30:00	\N	\N	8.3000000000000007	8.3000000000000007
1812	241	1812	2012-11-22 06:00:00	\N	\N	8.3000000000000007	8.3000000000000007
1813	241	1813	2012-11-22 06:30:00	\N	\N	8.3000000000000007	8.3000000000000007
1814	241	1814	2012-11-22 07:00:00	\N	\N	8.3000000000000007	8.3000000000000007
1815	241	1815	2012-11-22 07:30:00	\N	\N	8.4000000000000004	8.3000000000000007
1816	241	1816	2012-11-22 08:00:00	\N	\N	8.6999999999999993	8.4000000000000004
1817	241	1817	2012-11-22 08:30:00	\N	\N	8.9000000000000004	8.5999999999999996
1818	241	1818	2012-11-22 09:00:00	\N	\N	9.1999999999999993	8.9000000000000004
1819	241	1819	2012-11-22 09:30:00	\N	\N	9.3000000000000007	9.1999999999999993
1820	241	1820	2012-11-22 10:00:00	\N	\N	9.5999999999999996	9.3000000000000007
1821	241	1821	2012-11-22 10:30:00	\N	\N	9.6999999999999993	9.5999999999999996
1822	241	1822	2012-11-22 11:00:00	\N	\N	9.6999999999999993	9.6999999999999993
1823	241	1823	2012-11-22 11:30:00	\N	\N	10	9.6999999999999993
1824	241	1824	2012-11-22 12:00:00	\N	\N	10.1	10
1825	241	1825	2012-11-22 12:30:00	\N	\N	10.199999999999999	10.1
1826	241	1826	2012-11-22 13:00:00	\N	\N	10.300000000000001	10.199999999999999
1827	241	1827	2012-11-22 13:30:00	\N	\N	10.300000000000001	10.199999999999999
1828	241	1828	2012-11-22 14:00:00	\N	\N	10.300000000000001	10.199999999999999
1829	241	1829	2012-11-22 14:30:00	\N	\N	10.199999999999999	10.1
1830	241	1830	2012-11-22 15:00:00	\N	\N	10.199999999999999	10.199999999999999
1831	241	1831	2012-11-22 15:30:00	\N	\N	10.199999999999999	10.1
1832	241	1832	2012-11-22 16:00:00	\N	\N	10.1	9.9000000000000004
1833	241	1833	2012-11-22 16:30:00	\N	\N	10	9.8000000000000007
1834	241	1834	2012-11-22 17:00:00	\N	\N	9.8000000000000007	9.6999999999999993
1835	241	1835	2012-11-22 17:30:00	\N	\N	9.6999999999999993	9.5999999999999996
1836	241	1836	2012-11-22 18:00:00	\N	\N	9.5999999999999996	9.4000000000000004
1837	241	1837	2012-11-22 18:30:00	\N	\N	9.4000000000000004	9.3000000000000007
1838	241	1838	2012-11-22 19:00:00	\N	\N	9.3000000000000007	9.3000000000000007
1839	241	1839	2012-11-22 19:30:00	\N	\N	9.3000000000000007	9.1999999999999993
1840	241	1840	2012-11-22 20:00:00	\N	\N	9.1999999999999993	9.0999999999999996
1841	241	1841	2012-11-22 20:30:00	\N	\N	9.0999999999999996	8.9000000000000004
1842	241	1842	2012-11-22 21:00:00	\N	\N	9	8.9000000000000004
1843	241	1843	2012-11-22 21:30:00	\N	\N	8.9000000000000004	8.9000000000000004
1844	241	1844	2012-11-22 22:00:00	\N	\N	8.9000000000000004	8.8000000000000007
1845	241	1845	2012-11-22 22:30:00	\N	\N	8.8000000000000007	8.8000000000000007
1846	241	1846	2012-11-22 23:00:00	\N	\N	8.8000000000000007	8.8000000000000007
1847	241	1847	2012-11-22 23:30:00	\N	\N	8.8000000000000007	8.6999999999999993
1848	241	1848	2012-11-23 00:00:00	\N	\N	8.6999999999999993	8.5999999999999996
1849	241	1849	2012-11-23 00:30:00	\N	\N	8.5999999999999996	8.5
1850	241	1850	2012-11-23 01:00:00	\N	\N	8.5999999999999996	8.4000000000000004
1851	241	1851	2012-11-23 01:30:00	\N	\N	8.4000000000000004	8.3000000000000007
1852	241	1852	2012-11-23 02:00:00	\N	\N	8.3000000000000007	8.3000000000000007
1853	241	1853	2012-11-23 02:30:00	\N	\N	8.3000000000000007	8.1999999999999993
1854	241	1854	2012-11-23 03:00:00	\N	\N	8.1999999999999993	8.1999999999999993
1855	241	1855	2012-11-23 03:30:00	\N	\N	8.1999999999999993	8.1999999999999993
1856	241	1856	2012-11-23 04:00:00	\N	\N	8.1999999999999993	8.0999999999999996
1857	241	1857	2012-11-23 04:30:00	\N	\N	8.1999999999999993	8.0999999999999996
1858	241	1858	2012-11-23 05:00:00	\N	\N	8.1999999999999993	8.0999999999999996
1859	241	1859	2012-11-23 05:30:00	\N	\N	8.0999999999999996	8.0999999999999996
1860	241	1860	2012-11-23 06:00:00	\N	\N	8.0999999999999996	8
1861	241	1861	2012-11-23 06:30:00	\N	\N	8.0999999999999996	8
1862	241	1862	2012-11-23 07:00:00	\N	\N	8	8
1863	241	1863	2012-11-23 07:30:00	\N	\N	8	7.9000000000000004
1864	241	1864	2012-11-23 08:00:00	\N	\N	8.0999999999999996	8
1865	241	1865	2012-11-23 08:30:00	\N	\N	8.1999999999999993	8.0999999999999996
1866	241	1866	2012-11-23 09:00:00	\N	\N	8.4000000000000004	8.1999999999999993
1867	241	1867	2012-11-23 09:30:00	\N	\N	8.5999999999999996	8.3000000000000007
1868	241	1868	2012-11-23 10:00:00	\N	\N	8.6999999999999993	8.5
1869	241	1869	2012-11-23 10:30:00	\N	\N	8.6999999999999993	8.5999999999999996
1870	241	1870	2012-11-23 11:00:00	\N	\N	8.6999999999999993	8.5999999999999996
1871	241	1871	2012-11-23 11:30:00	\N	\N	8.8000000000000007	8.6999999999999993
1872	241	1872	2012-11-23 12:00:00	\N	\N	9.0999999999999996	8.8000000000000007
1873	241	1873	2012-11-23 12:30:00	\N	\N	9.4000000000000004	9.0999999999999996
1874	241	1874	2012-11-23 13:00:00	\N	\N	9.8000000000000007	9.4000000000000004
1875	241	1875	2012-11-23 13:30:00	\N	\N	10.199999999999999	9.8000000000000007
1876	241	1876	2012-11-23 14:00:00	\N	\N	10.199999999999999	10.1
1877	241	1877	2012-11-23 14:30:00	\N	\N	10.199999999999999	10.1
1878	241	1878	2012-11-23 15:00:00	\N	\N	10.1	10
1879	241	1879	2012-11-23 15:30:00	\N	\N	10	9.8000000000000007
1880	241	1880	2012-11-23 16:00:00	\N	\N	9.8000000000000007	9.5999999999999996
1881	241	1881	2012-11-23 16:30:00	\N	\N	9.5999999999999996	9.4000000000000004
1882	241	1882	2012-11-23 17:00:00	\N	\N	9.4000000000000004	9.3000000000000007
1883	241	1883	2012-11-23 17:30:00	\N	\N	9.3000000000000007	9.1999999999999993
1884	241	1884	2012-11-23 18:00:00	\N	\N	9.1999999999999993	9.0999999999999996
1885	241	1885	2012-11-23 18:30:00	\N	\N	9.0999999999999996	9.0999999999999996
1886	241	1886	2012-11-23 19:00:00	\N	\N	9.0999999999999996	9
1887	241	1887	2012-11-23 19:30:00	\N	\N	9.0999999999999996	9
1888	241	1888	2012-11-23 20:00:00	\N	\N	9.0999999999999996	9
1889	241	1889	2012-11-23 20:30:00	\N	\N	9	8.9000000000000004
1890	241	1890	2012-11-23 21:00:00	\N	\N	8.9000000000000004	8.8000000000000007
1891	241	1891	2012-11-23 21:30:00	\N	\N	8.8000000000000007	8.8000000000000007
1892	241	1892	2012-11-23 22:00:00	\N	\N	8.8000000000000007	8.8000000000000007
1893	241	1893	2012-11-23 22:30:00	\N	\N	8.8000000000000007	8.8000000000000007
1894	241	1894	2012-11-23 23:00:00	\N	\N	8.8000000000000007	8.5
1895	241	1895	2012-11-23 23:30:00	\N	\N	8.5999999999999996	8.3000000000000007
1896	241	1896	2012-11-24 00:00:00	\N	\N	8.3000000000000007	8.0999999999999996
1897	241	1897	2012-11-24 00:30:00	\N	\N	8.0999999999999996	7.7999999999999998
1898	241	1898	2012-11-24 01:00:00	\N	\N	7.9000000000000004	7.7000000000000002
1899	241	1899	2012-11-24 01:30:00	\N	\N	7.9000000000000004	7.9000000000000004
1900	241	1900	2012-11-24 02:00:00	\N	\N	7.9000000000000004	7.7000000000000002
1901	241	1901	2012-11-24 02:30:00	\N	\N	7.7000000000000002	7.4000000000000004
1902	241	1902	2012-11-24 03:00:00	\N	\N	7.4000000000000004	7.0999999999999996
1903	241	1903	2012-11-24 03:30:00	\N	\N	7.0999999999999996	6.7000000000000002
1904	241	1904	2012-11-24 04:00:00	\N	\N	6.7000000000000002	6.0999999999999996
1905	241	1905	2012-11-24 04:30:00	\N	\N	6.0999999999999996	5.9000000000000004
1906	241	1906	2012-11-24 05:00:00	\N	\N	6.0999999999999996	5.7999999999999998
1907	241	1907	2012-11-24 05:30:00	\N	\N	6.2000000000000002	6.0999999999999996
1908	241	1908	2012-11-24 06:00:00	\N	\N	6.2000000000000002	6.2000000000000002
1909	241	1909	2012-11-24 06:30:00	\N	\N	6.2000000000000002	6.2000000000000002
1910	241	1910	2012-11-24 07:00:00	\N	\N	6.2000000000000002	6.0999999999999996
1911	241	1911	2012-11-24 07:30:00	\N	\N	6.4000000000000004	6.2000000000000002
1912	241	1912	2012-11-24 08:00:00	\N	\N	6.9000000000000004	6.4000000000000004
1913	241	1913	2012-11-24 08:30:00	\N	\N	7.5999999999999996	6.9000000000000004
1914	241	1914	2012-11-24 09:00:00	\N	\N	7.9000000000000004	7.5999999999999996
1915	241	1915	2012-11-24 09:30:00	\N	\N	9.1999999999999993	7.9000000000000004
1916	241	1916	2012-11-24 10:00:00	\N	\N	9.9000000000000004	9.1999999999999993
1917	241	1917	2012-11-24 10:30:00	\N	\N	10.5	9.9000000000000004
1918	241	1918	2012-11-24 11:00:00	\N	\N	11.6	10.6
1919	241	1919	2012-11-24 11:30:00	\N	\N	11.6	11.4
1920	241	1920	2012-11-24 12:00:00	\N	\N	11.800000000000001	11.5
1921	241	1921	2012-11-24 12:30:00	\N	\N	12.199999999999999	11.699999999999999
1922	241	1922	2012-11-24 13:00:00	\N	\N	12.300000000000001	12.199999999999999
1923	241	1923	2012-11-24 13:30:00	\N	\N	12.300000000000001	12.199999999999999
1924	241	1924	2012-11-24 14:00:00	\N	\N	12.5	12.300000000000001
1925	241	1925	2012-11-24 14:30:00	\N	\N	12.4	12.300000000000001
1926	241	1926	2012-11-24 15:00:00	\N	\N	12.800000000000001	12.4
1927	241	1927	2012-11-24 15:30:00	\N	\N	12.800000000000001	11.699999999999999
1928	241	1928	2012-11-24 16:00:00	\N	\N	11.6	10.800000000000001
1929	241	1929	2012-11-24 16:30:00	\N	\N	10.800000000000001	9.6999999999999993
1930	241	1930	2012-11-24 17:00:00	\N	\N	9.6999999999999993	8.9000000000000004
1931	241	1931	2012-11-24 17:30:00	\N	\N	8.9000000000000004	8.3000000000000007
1932	241	1932	2012-11-24 18:00:00	\N	\N	8.3000000000000007	7.2000000000000002
1933	241	1933	2012-11-24 18:30:00	\N	\N	7.2000000000000002	6.4000000000000004
1934	241	1934	2012-11-24 19:00:00	\N	\N	6.4000000000000004	5.7000000000000002
1935	241	1935	2012-11-24 19:30:00	\N	\N	5.7000000000000002	4.7000000000000002
1936	241	1936	2012-11-24 20:00:00	\N	\N	4.7000000000000002	4.4000000000000004
1937	241	1937	2012-11-24 20:30:00	\N	\N	4.4000000000000004	4.2000000000000002
1938	241	1938	2012-11-24 21:00:00	\N	\N	4.2000000000000002	4.0999999999999996
1939	241	1939	2012-11-24 21:30:00	\N	\N	4.0999999999999996	3.7000000000000002
1940	241	1940	2012-11-24 22:00:00	\N	\N	3.7999999999999998	3.7000000000000002
1941	241	1941	2012-11-24 22:30:00	\N	\N	3.7000000000000002	3.3999999999999999
1942	241	1942	2012-11-24 23:00:00	\N	\N	3.3999999999999999	2.7999999999999998
1943	241	1943	2012-11-24 23:30:00	\N	\N	2.7999999999999998	2.2999999999999998
1944	241	1944	2012-11-25 00:00:00	\N	\N	2.2999999999999998	2.2999999999999998
1945	241	1945	2012-11-25 00:30:00	\N	\N	2.2999999999999998	1.8999999999999999
1946	241	1946	2012-11-25 01:00:00	\N	\N	1.8999999999999999	1.8
1947	241	1947	2012-11-25 01:30:00	\N	\N	1.8999999999999999	1.8
1948	241	1948	2012-11-25 02:00:00	\N	\N	2.3999999999999999	1.8999999999999999
1949	241	1949	2012-11-25 02:30:00	\N	\N	2.7999999999999998	2.3999999999999999
1950	241	1950	2012-11-25 03:00:00	\N	\N	3	2.7999999999999998
1951	241	1951	2012-11-25 03:30:00	\N	\N	3.1000000000000001	2.8999999999999999
1952	241	1952	2012-11-25 04:00:00	\N	\N	3.2000000000000002	3
1953	241	1953	2012-11-25 04:30:00	\N	\N	3.3999999999999999	3.2000000000000002
1954	241	1954	2012-11-25 05:00:00	\N	\N	3.3999999999999999	3.3999999999999999
1955	241	1955	2012-11-25 05:30:00	\N	\N	3.6000000000000001	3.3999999999999999
1956	241	1956	2012-11-25 06:00:00	\N	\N	3.6000000000000001	3.5
1957	241	1957	2012-11-25 06:30:00	\N	\N	3.5	3.3999999999999999
1958	241	1958	2012-11-25 07:00:00	\N	\N	3.3999999999999999	3.2000000000000002
1959	241	1959	2012-11-25 07:30:00	\N	\N	3.2000000000000002	3.2000000000000002
1960	241	1960	2012-11-25 08:00:00	\N	\N	3.2999999999999998	3.2000000000000002
1961	241	1961	2012-11-25 08:30:00	\N	\N	3.3999999999999999	3.2999999999999998
1962	241	1962	2012-11-25 09:00:00	\N	\N	4	3.2999999999999998
1963	241	1963	2012-11-25 09:30:00	\N	\N	4.4000000000000004	4
1964	241	1964	2012-11-25 10:00:00	\N	\N	5.0999999999999996	4.4000000000000004
1965	241	1965	2012-11-25 10:30:00	\N	\N	6	5.0999999999999996
1966	241	1966	2012-11-25 11:00:00	\N	\N	6.7999999999999998	5.9000000000000004
1967	241	1967	2012-11-25 11:30:00	\N	\N	7.7000000000000002	6.7999999999999998
1968	241	1968	2012-11-25 12:00:00	\N	\N	8.1999999999999993	7.5999999999999996
1969	241	1969	2012-11-25 12:30:00	\N	\N	9.4000000000000004	8.1999999999999993
1970	241	1970	2012-11-25 13:00:00	\N	\N	10.1	9.4000000000000004
1971	241	1971	2012-11-25 13:30:00	\N	\N	10.4	10.1
1972	241	1972	2012-11-25 14:00:00	\N	\N	10.4	10.199999999999999
1973	241	1973	2012-11-25 14:30:00	\N	\N	10.300000000000001	9.8000000000000007
1974	241	1974	2012-11-25 15:00:00	\N	\N	9.8000000000000007	8.9000000000000004
1975	241	1975	2012-11-25 15:30:00	\N	\N	9	8.3000000000000007
1976	241	1976	2012-11-25 16:00:00	\N	\N	8.3000000000000007	8.0999999999999996
1977	241	1977	2012-11-25 16:30:00	\N	\N	8.1999999999999993	8
1978	241	1978	2012-11-25 17:00:00	\N	\N	8.0999999999999996	8
1979	241	1979	2012-11-25 17:30:00	\N	\N	8.0999999999999996	7.9000000000000004
1980	241	1980	2012-11-25 18:00:00	\N	\N	8.0999999999999996	7.9000000000000004
1981	241	1981	2012-11-25 18:30:00	\N	\N	8.0999999999999996	7.9000000000000004
1982	241	1982	2012-11-25 19:00:00	\N	\N	7.9000000000000004	7.7999999999999998
1983	241	1983	2012-11-25 19:30:00	\N	\N	7.7999999999999998	7.7999999999999998
1984	241	1984	2012-11-25 20:00:00	\N	\N	7.7999999999999998	7.7999999999999998
1985	241	1985	2012-11-25 20:30:00	\N	\N	7.7999999999999998	7.7999999999999998
1986	241	1986	2012-11-25 21:00:00	\N	\N	7.7999999999999998	7.7000000000000002
1987	241	1987	2012-11-25 21:30:00	\N	\N	7.7000000000000002	7.5999999999999996
1988	241	1988	2012-11-25 22:00:00	\N	\N	7.5999999999999996	7.4000000000000004
1989	241	1989	2012-11-25 22:30:00	\N	\N	7.4000000000000004	7.2999999999999998
1990	241	1990	2012-11-25 23:00:00	\N	\N	7.2999999999999998	7.0999999999999996
1991	241	1991	2012-11-25 23:30:00	\N	\N	7.2000000000000002	7.0999999999999996
1992	241	1992	2012-11-26 00:00:00	\N	\N	7.0999999999999996	6.9000000000000004
1993	241	1993	2012-11-26 00:30:00	\N	\N	6.9000000000000004	6.5999999999999996
1994	241	1994	2012-11-26 01:00:00	\N	\N	6.7000000000000002	6.5999999999999996
1995	241	1995	2012-11-26 01:30:00	\N	\N	6.7000000000000002	6.5999999999999996
1996	241	1996	2012-11-26 02:00:00	\N	\N	6.5999999999999996	6.5999999999999996
1997	241	1997	2012-11-26 02:30:00	\N	\N	6.5999999999999996	6.5
1998	241	1998	2012-11-26 03:00:00	\N	\N	6.5	6.4000000000000004
1999	241	1999	2012-11-26 03:30:00	\N	\N	6.4000000000000004	6.2999999999999998
2000	241	2000	2012-11-26 04:00:00	\N	\N	6.2999999999999998	6.2000000000000002
2001	241	2001	2012-11-26 04:30:00	\N	\N	6.2999999999999998	6.2000000000000002
2002	241	2002	2012-11-26 05:00:00	\N	\N	6.4000000000000004	6.2999999999999998
2003	241	2003	2012-11-26 05:30:00	\N	\N	6.4000000000000004	6.2999999999999998
2004	241	2004	2012-11-26 06:00:00	\N	\N	6.4000000000000004	6.2999999999999998
2005	241	2005	2012-11-26 06:30:00	\N	\N	6.5999999999999996	6.4000000000000004
2006	241	2006	2012-11-26 07:00:00	\N	\N	6.7000000000000002	6.5999999999999996
2007	241	2007	2012-11-26 07:30:00	\N	\N	6.7999999999999998	6.7000000000000002
2008	241	2008	2012-11-26 08:00:00	\N	\N	7.0999999999999996	6.7000000000000002
2009	241	2009	2012-11-26 08:30:00	\N	\N	7.5	7.0999999999999996
2010	241	2010	2012-11-26 09:00:00	\N	\N	8.3000000000000007	7.5
2011	241	2011	2012-11-26 09:30:00	\N	\N	10.1	8.3000000000000007
2012	241	2012	2012-11-26 10:00:00	\N	\N	11.800000000000001	10.1
2013	241	2013	2012-11-26 10:30:00	\N	\N	12.300000000000001	11.800000000000001
2014	241	2014	2012-11-26 11:00:00	\N	\N	12.699999999999999	12.300000000000001
2015	241	2015	2012-11-26 11:30:00	\N	\N	13.1	12.699999999999999
2022	241	2022	2012-11-26 15:00:00	\N	\N	16.399999999999999	16.199999999999999
2027	241	2027	2012-11-26 17:30:00	\N	\N	14.9	14.699999999999999
2028	241	2028	2012-11-26 18:00:00	\N	\N	14.699999999999999	14.300000000000001
2041	241	2041	2012-11-27 00:30:00	\N	\N	12	11.699999999999999
2059	241	2059	2012-11-27 09:30:00	\N	\N	13.6	13.300000000000001
2061	241	2061	2012-11-27 10:30:00	\N	\N	15.6	14.699999999999999
2066	241	2066	2012-11-27 13:00:00	\N	\N	16.800000000000001	16.600000000000001
2016	241	2016	2012-11-26 12:00:00	\N	\N	13.199999999999999	12.9
2029	241	2029	2012-11-26 18:30:00	\N	\N	14.300000000000001	13.699999999999999
2037	241	2037	2012-11-26 22:30:00	\N	\N	12.699999999999999	11.9
2047	241	2047	2012-11-27 03:30:00	\N	\N	12.699999999999999	12.4
2051	241	2051	2012-11-27 05:30:00	\N	\N	11.800000000000001	11.1
2054	241	2054	2012-11-27 07:00:00	\N	\N	11.300000000000001	9.9000000000000004
2056	241	2056	2012-11-27 08:00:00	\N	\N	11.800000000000001	11.4
2064	241	2064	2012-11-27 12:00:00	\N	\N	16.600000000000001	16.100000000000001
2017	241	2017	2012-11-26 12:30:00	\N	\N	13.6	13.199999999999999
2034	241	2034	2012-11-26 21:00:00	\N	\N	11.699999999999999	11.5
2038	241	2038	2012-11-26 23:00:00	\N	\N	12.800000000000001	12.6
2040	241	2040	2012-11-27 00:00:00	\N	\N	12.199999999999999	11.699999999999999
2043	241	2043	2012-11-27 01:30:00	\N	\N	12	11.800000000000001
2044	241	2044	2012-11-27 02:00:00	\N	\N	12.699999999999999	12
2048	241	2048	2012-11-27 04:00:00	\N	\N	12.4	12.300000000000001
2050	241	2050	2012-11-27 05:00:00	\N	\N	12.300000000000001	11.800000000000001
2052	241	2052	2012-11-27 06:00:00	\N	\N	11.1	10.6
2053	241	2053	2012-11-27 06:30:00	\N	\N	10.6	10.300000000000001
2067	241	2067	2012-11-27 13:30:00	\N	\N	17.100000000000001	16.600000000000001
2018	241	2018	2012-11-26 13:00:00	\N	\N	13.800000000000001	13.6
2024	241	2024	2012-11-26 16:00:00	\N	\N	15.699999999999999	14.5
2019	241	2019	2012-11-26 13:30:00	\N	\N	14.699999999999999	13.800000000000001
2023	241	2023	2012-11-26 15:30:00	\N	\N	16.199999999999999	15.6
2026	241	2026	2012-11-26 17:00:00	\N	\N	14.699999999999999	14.6
2058	241	2058	2012-11-27 09:00:00	\N	\N	13.6	12.800000000000001
2060	241	2060	2012-11-27 10:00:00	\N	\N	14.6	13.199999999999999
2020	241	2020	2012-11-26 14:00:00	\N	\N	15.699999999999999	14.699999999999999
2030	241	2030	2012-11-26 19:00:00	\N	\N	13.699999999999999	13.300000000000001
2042	241	2042	2012-11-27 01:00:00	\N	\N	12.1	11.800000000000001
2021	241	2021	2012-11-26 14:30:00	\N	\N	16.300000000000001	15.699999999999999
2046	241	2046	2012-11-27 03:00:00	\N	\N	12.699999999999999	12.4
2049	241	2049	2012-11-27 04:30:00	\N	\N	12.4	11.9
2065	241	2065	2012-11-27 12:30:00	\N	\N	16.800000000000001	16.300000000000001
2025	241	2025	2012-11-26 16:30:00	\N	\N	14.699999999999999	14.4
2039	241	2039	2012-11-26 23:30:00	\N	\N	12.6	12.199999999999999
2031	241	2031	2012-11-26 19:30:00	\N	\N	13.300000000000001	12.9
2032	241	2032	2012-11-26 20:00:00	\N	\N	12.9	12.6
2033	241	2033	2012-11-26 20:30:00	\N	\N	12.6	11.699999999999999
2035	241	2035	2012-11-26 21:30:00	\N	\N	11.699999999999999	11.300000000000001
2036	241	2036	2012-11-26 22:00:00	\N	\N	11.9	11.699999999999999
2045	241	2045	2012-11-27 02:30:00	\N	\N	12.699999999999999	12.4
2055	241	2055	2012-11-27 07:30:00	\N	\N	11.5	11.199999999999999
2057	241	2057	2012-11-27 08:30:00	\N	\N	12.800000000000001	11.9
2062	241	2062	2012-11-27 11:00:00	\N	\N	15.6	15.5
2063	241	2063	2012-11-27 11:30:00	\N	\N	16.100000000000001	15.6
2068	241	2068	2012-11-27 14:00:00	\N	\N	16.800000000000001	16.600000000000001
2069	241	2069	2012-11-27 14:30:00	\N	\N	16.800000000000001	16.699999999999999
2070	241	2070	2012-11-27 15:00:00	\N	\N	16.699999999999999	16
2071	241	2071	2012-11-27 15:30:00	\N	\N	16	15.699999999999999
2072	241	2072	2012-11-27 16:00:00	\N	\N	15.699999999999999	15.199999999999999
2073	241	2073	2012-11-27 16:30:00	\N	\N	15.199999999999999	14.300000000000001
2074	241	2074	2012-11-27 17:00:00	\N	\N	14.300000000000001	14.199999999999999
2075	241	2075	2012-11-27 17:30:00	\N	\N	14.300000000000001	13.300000000000001
2076	241	2076	2012-11-27 18:00:00	\N	\N	13.699999999999999	13.1
2077	241	2077	2012-11-27 18:30:00	\N	\N	13.699999999999999	13.6
2078	241	2078	2012-11-27 19:00:00	\N	\N	13.699999999999999	12.4
2079	241	2079	2012-11-27 19:30:00	\N	\N	12.4	12
2080	241	2080	2012-11-27 20:00:00	\N	\N	12	11.6
2081	241	2081	2012-11-27 20:30:00	\N	\N	11.6	10.800000000000001
2082	241	2082	2012-11-27 21:00:00	\N	\N	11.4	10.800000000000001
2083	241	2083	2012-11-27 21:30:00	\N	\N	11.300000000000001	10.800000000000001
2084	241	2084	2012-11-27 22:00:00	\N	\N	10.800000000000001	10.300000000000001
2085	241	2085	2012-11-27 22:30:00	\N	\N	10.4	10.300000000000001
2086	241	2086	2012-11-27 23:00:00	\N	\N	10.9	10.4
2087	241	2087	2012-11-27 23:30:00	\N	\N	11	10.9
2088	241	2088	2012-11-28 00:00:00	\N	\N	10.9	10.6
2089	241	2089	2012-11-28 00:30:00	\N	\N	10.6	9.5
2090	241	2090	2012-11-28 01:00:00	\N	\N	9.5	8.9000000000000004
2091	241	2091	2012-11-28 01:30:00	\N	\N	8.9000000000000004	8.8000000000000007
2092	241	2092	2012-11-28 02:00:00	\N	\N	8.9000000000000004	8.8000000000000007
2093	241	2093	2012-11-28 02:30:00	\N	\N	8.9000000000000004	8.8000000000000007
2094	241	2094	2012-11-28 03:00:00	\N	\N	8.9000000000000004	8.8000000000000007
2095	241	2095	2012-11-28 03:30:00	\N	\N	9.1999999999999993	8.9000000000000004
2096	241	2096	2012-11-28 04:00:00	\N	\N	9.1999999999999993	9.0999999999999996
2097	241	2097	2012-11-28 04:30:00	\N	\N	9.1999999999999993	9.1999999999999993
2098	241	2098	2012-11-28 05:00:00	\N	\N	9.4000000000000004	9.1999999999999993
2099	241	2099	2012-11-28 05:30:00	\N	\N	9.4000000000000004	9.0999999999999996
2100	241	2100	2012-11-28 06:00:00	\N	\N	9.0999999999999996	8.5
2101	241	2101	2012-11-28 06:30:00	\N	\N	8.5	8.3000000000000007
2102	241	2102	2012-11-28 07:00:00	\N	\N	8.5	8.3000000000000007
2103	241	2103	2012-11-28 07:30:00	\N	\N	8.1999999999999993	7.7000000000000002
2104	241	2104	2012-11-28 08:00:00	\N	\N	8.0999999999999996	7.7000000000000002
2105	241	2105	2012-11-28 08:30:00	\N	\N	9.1999999999999993	8.0999999999999996
2106	241	2106	2012-11-28 09:00:00	\N	\N	10.1	9.3000000000000007
2107	241	2107	2012-11-28 09:30:00	\N	\N	10.300000000000001	10.1
2108	241	2108	2012-11-28 10:00:00	\N	\N	12.300000000000001	10.300000000000001
2109	241	2109	2012-11-28 10:30:00	\N	\N	13.699999999999999	12.300000000000001
2110	241	2110	2012-11-28 11:00:00	\N	\N	14.300000000000001	13.699999999999999
2111	241	2111	2012-11-28 11:30:00	\N	\N	15.800000000000001	14.300000000000001
2112	241	2112	2012-11-28 12:00:00	\N	\N	15.800000000000001	15.6
2113	241	2113	2012-11-28 12:30:00	\N	\N	15.699999999999999	15.6
2114	241	2114	2012-11-28 13:00:00	\N	\N	15.699999999999999	15.300000000000001
2115	241	2115	2012-11-28 13:30:00	\N	\N	16.100000000000001	15.6
2116	241	2116	2012-11-28 14:00:00	\N	\N	15.6	14.699999999999999
2117	241	2117	2012-11-28 14:30:00	\N	\N	14.9	14.699999999999999
2118	241	2118	2012-11-28 15:00:00	\N	\N	14.699999999999999	14.1
2119	241	2119	2012-11-28 15:30:00	\N	\N	14.1	13.4
2120	241	2120	2012-11-28 16:00:00	\N	\N	13.4	12.300000000000001
2121	241	2121	2012-11-28 16:30:00	\N	\N	12.300000000000001	12
2122	241	2122	2012-11-28 17:00:00	\N	\N	12	11.4
2123	241	2123	2012-11-28 17:30:00	\N	\N	11.4	11.199999999999999
2124	241	2124	2012-11-28 18:00:00	\N	\N	11.199999999999999	11.1
2125	241	2125	2012-11-28 18:30:00	\N	\N	11.199999999999999	11.1
2126	241	2126	2012-11-28 19:00:00	\N	\N	11.300000000000001	11.199999999999999
2127	241	2127	2012-11-28 19:30:00	\N	\N	11.300000000000001	11
2128	241	2128	2012-11-28 20:00:00	\N	\N	11	10.9
2129	241	2129	2012-11-28 20:30:00	\N	\N	10.9	10.800000000000001
2130	241	2130	2012-11-28 21:00:00	\N	\N	11.199999999999999	10.9
2131	241	2131	2012-11-28 21:30:00	\N	\N	11.199999999999999	10.9
2132	241	2132	2012-11-28 22:00:00	\N	\N	10.9	10.699999999999999
2133	241	2133	2012-11-28 22:30:00	\N	\N	12.199999999999999	10.699999999999999
2134	241	2134	2012-11-28 23:00:00	\N	\N	12.199999999999999	11.699999999999999
2135	241	2135	2012-11-28 23:30:00	\N	\N	11.699999999999999	11.300000000000001
2136	241	2136	2012-11-29 00:00:00	\N	\N	11.300000000000001	10.9
2137	241	2137	2012-11-29 00:30:00	\N	\N	11.300000000000001	10.9
2138	241	2138	2012-11-29 01:00:00	\N	\N	11.199999999999999	11.1
2139	241	2139	2012-11-29 01:30:00	\N	\N	11.1	10.6
2140	241	2140	2012-11-29 02:00:00	\N	\N	10.6	10
2141	241	2141	2012-11-29 02:30:00	\N	\N	9.9000000000000004	9.4000000000000004
2142	241	2142	2012-11-29 03:00:00	\N	\N	9.4000000000000004	9.0999999999999996
2143	241	2143	2012-11-29 03:30:00	\N	\N	9.0999999999999996	8.6999999999999993
2144	241	2144	2012-11-29 04:00:00	\N	\N	8.6999999999999993	7.2999999999999998
2145	241	2145	2012-11-29 04:30:00	\N	\N	7.2999999999999998	6.7000000000000002
2146	241	2146	2012-11-29 05:00:00	\N	\N	6.7000000000000002	5.4000000000000004
2147	241	2147	2012-11-29 05:30:00	\N	\N	5.7999999999999998	5.5999999999999996
2148	241	2148	2012-11-29 06:00:00	\N	\N	5.9000000000000004	5.2000000000000002
2149	241	2149	2012-11-29 06:30:00	\N	\N	5.4000000000000004	5.2999999999999998
2150	241	2150	2012-11-29 07:00:00	\N	\N	5.7999999999999998	5.2999999999999998
2151	241	2151	2012-11-29 07:30:00	\N	\N	6	5.2000000000000002
2152	241	2152	2012-11-29 08:00:00	\N	\N	7.5	6
2153	241	2153	2012-11-29 08:30:00	\N	\N	9.8000000000000007	7.5
2154	241	2154	2012-11-29 09:00:00	\N	\N	10.800000000000001	9.8000000000000007
2155	241	2155	2012-11-29 09:30:00	\N	\N	11.9	10.800000000000001
2156	241	2156	2012-11-29 10:00:00	\N	\N	12.5	11.9
2157	241	2157	2012-11-29 10:30:00	\N	\N	13.1	12.5
2158	241	2158	2012-11-29 11:00:00	\N	\N	13.4	13.1
2159	241	2159	2012-11-29 11:30:00	\N	\N	14.199999999999999	13.300000000000001
2160	241	2160	2012-11-29 12:00:00	\N	\N	14.300000000000001	13.9
2161	241	2161	2012-11-29 12:30:00	\N	\N	14.699999999999999	14
2162	241	2162	2012-11-29 13:00:00	\N	\N	14.699999999999999	14.1
2163	241	2163	2012-11-29 13:30:00	\N	\N	14.800000000000001	14.1
2164	241	2164	2012-11-29 14:00:00	\N	\N	14.800000000000001	14.199999999999999
2165	241	2165	2012-11-29 14:30:00	\N	\N	14.199999999999999	13.800000000000001
2166	241	2166	2012-11-29 15:00:00	\N	\N	13.800000000000001	12.699999999999999
2167	241	2167	2012-11-29 15:30:00	\N	\N	12.699999999999999	10.300000000000001
2173	241	2173	2012-11-29 18:30:00	\N	\N	9.1999999999999993	8.9000000000000004
2168	241	2168	2012-11-29 16:00:00	\N	\N	10.300000000000001	9.9000000000000004
2169	241	2169	2012-11-29 16:30:00	\N	\N	9.9000000000000004	9.8000000000000007
2170	241	2170	2012-11-29 17:00:00	\N	\N	9.8000000000000007	9.5999999999999996
2171	241	2171	2012-11-29 17:30:00	\N	\N	9.5999999999999996	9.3000000000000007
2175	241	2175	2012-11-29 19:30:00	\N	\N	8.5	8.3000000000000007
2172	241	2172	2012-11-29 18:00:00	\N	\N	9.3000000000000007	9.1999999999999993
2174	241	2174	2012-11-29 19:00:00	\N	\N	8.9000000000000004	8.5
2176	241	2176	2012-11-29 20:00:00	\N	\N	8.3000000000000007	8.1999999999999993
2177	241	2177	2012-11-29 20:30:00	\N	\N	8.4000000000000004	8
2178	241	2178	2012-11-29 21:00:00	\N	\N	8.5999999999999996	8.4000000000000004
2179	241	2179	2012-11-29 21:30:00	\N	\N	8.6999999999999993	8.5999999999999996
2180	241	2180	2012-11-29 22:00:00	\N	\N	8.5999999999999996	8.5
2181	241	2181	2012-11-29 22:30:00	\N	\N	8.5	8.4000000000000004
2182	241	2182	2012-11-29 23:00:00	\N	\N	8.6999999999999993	8.5
2183	241	2183	2012-11-29 23:30:00	\N	\N	8.6999999999999993	7.0999999999999996
2184	241	2184	2012-11-30 00:00:00	\N	\N	7.0999999999999996	6.0999999999999996
2185	241	2185	2012-11-30 00:30:00	\N	\N	6.0999999999999996	5.5999999999999996
2186	241	2186	2012-11-30 01:00:00	\N	\N	5.5999999999999996	5.2000000000000002
2187	241	2187	2012-11-30 01:30:00	\N	\N	5.2000000000000002	4.9000000000000004
2188	241	2188	2012-11-30 02:00:00	\N	\N	4.9000000000000004	4.2000000000000002
2189	241	2189	2012-11-30 02:30:00	\N	\N	4.2000000000000002	3.8999999999999999
2190	241	2190	2012-11-30 03:00:00	\N	\N	3.8999999999999999	3.7999999999999998
2191	241	2191	2012-11-30 03:30:00	\N	\N	3.7999999999999998	3.7000000000000002
2192	241	2192	2012-11-30 04:00:00	\N	\N	3.7000000000000002	3.5
2193	241	2193	2012-11-30 04:30:00	\N	\N	3.5	3.2999999999999998
2194	241	2194	2012-11-30 05:00:00	\N	\N	3.2999999999999998	3.2999999999999998
2195	241	2195	2012-11-30 05:30:00	\N	\N	3.2999999999999998	3.2000000000000002
2196	241	2196	2012-11-30 06:00:00	\N	\N	3.2000000000000002	3.1000000000000001
2221	241	2221	2012-11-30 06:30:00	\N	\N	3.1000000000000001	2.7999999999999998
2222	241	2222	2012-11-30 07:00:00	\N	\N	2.7999999999999998	2.7000000000000002
2241	241	2241	2012-11-30 07:30:00	\N	\N	2.7999999999999998	2.7000000000000002
2242	241	2242	2012-11-30 08:00:00	\N	\N	2.8999999999999999	2.7999999999999998
2243	241	2243	2012-11-30 08:30:00	\N	\N	3.1000000000000001	2.8999999999999999
2244	241	2244	2012-11-30 09:00:00	\N	\N	3.3999999999999999	3.1000000000000001
2245	241	2245	2012-11-30 09:30:00	\N	\N	4	3.3999999999999999
2246	241	2246	2012-11-30 10:00:00	\N	\N	4.2000000000000002	4
2247	241	2247	2012-11-30 10:30:00	\N	\N	4.5999999999999996	4.0999999999999996
2248	241	2248	2012-11-30 11:00:00	\N	\N	4.7999999999999998	4.5999999999999996
2249	241	2249	2012-11-30 11:30:00	\N	\N	5.0999999999999996	4.7999999999999998
2250	241	2250	2012-11-30 12:00:00	\N	\N	5.2000000000000002	5.0999999999999996
2251	241	2251	2012-11-30 12:30:00	\N	\N	5.4000000000000004	5.2000000000000002
2252	241	2252	2012-11-30 13:00:00	\N	\N	5.7000000000000002	5.4000000000000004
2253	241	2253	2012-11-30 13:30:00	\N	\N	5.7999999999999998	5.7000000000000002
2254	241	2254	2012-11-30 14:00:00	\N	\N	5.7999999999999998	5.7000000000000002
2255	241	2255	2012-11-30 14:30:00	\N	\N	5.7999999999999998	5.7000000000000002
2256	241	2256	2012-11-30 15:00:00	\N	\N	5.7999999999999998	5.7000000000000002
2257	241	2257	2012-11-30 15:30:00	\N	\N	5.7000000000000002	5.4000000000000004
2258	241	2258	2012-11-30 16:00:00	\N	\N	5.5	5.2999999999999998
2259	241	2259	2012-11-30 16:30:00	\N	\N	5.2999999999999998	4.9000000000000004
2260	241	2260	2012-11-30 17:00:00	\N	\N	4.9000000000000004	4.5999999999999996
2261	241	2261	2012-11-30 17:30:00	\N	\N	4.5999999999999996	4.4000000000000004
2262	241	2262	2012-11-30 18:00:00	\N	\N	4.4000000000000004	4.2000000000000002
2263	241	2263	2012-11-30 18:30:00	\N	\N	4.2000000000000002	4
2264	241	2264	2012-11-30 19:00:00	\N	\N	4.0999999999999996	3.8999999999999999
2281	241	2281	2012-11-30 19:30:00	\N	\N	4	3.7999999999999998
2282	241	2282	2012-11-30 20:00:00	\N	\N	4.0999999999999996	3.7999999999999998
2301	241	2301	2012-11-30 20:30:00	\N	\N	4.5999999999999996	4.0999999999999996
2302	241	2302	2012-11-30 21:00:00	\N	\N	4.5999999999999996	4.5
2303	241	2303	2012-11-30 21:30:00	\N	\N	4.5999999999999996	4.4000000000000004
2304	241	2304	2012-11-30 22:00:00	\N	\N	4.4000000000000004	4.2999999999999998
2321	241	2321	2012-11-30 22:30:00	\N	\N	4.2999999999999998	4.2999999999999998
2322	241	2322	2012-11-30 23:00:00	\N	\N	4.4000000000000004	4.2999999999999998
\.


--
-- Data for Name: s_data_wetness; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_wetness (id, sensor_id, sensor_data_id, date_time, wetness, dry, dew_point, precipitation) FROM stdin;
5141	250	1801	2012-11-22 00:30:00	\N	\N	8	\N
5142	253	1801	2012-11-22 00:30:00	\N	\N	8	\N
5143	259	1801	2012-11-22 00:30:00	0	\N	\N	\N
5144	250	1802	2012-11-22 01:00:00	\N	\N	8	\N
5145	253	1802	2012-11-22 01:00:00	\N	\N	7.9000000000000004	\N
5146	259	1802	2012-11-22 01:00:00	0	\N	\N	\N
5147	250	1803	2012-11-22 01:30:00	\N	\N	8	\N
5148	253	1803	2012-11-22 01:30:00	\N	\N	7.9000000000000004	\N
5149	259	1803	2012-11-22 01:30:00	0	\N	\N	\N
5150	250	1804	2012-11-22 02:00:00	\N	\N	7.7999999999999998	\N
5151	253	1804	2012-11-22 02:00:00	\N	\N	7.9000000000000004	\N
5152	259	1804	2012-11-22 02:00:00	0	\N	\N	\N
5153	250	1805	2012-11-22 02:30:00	\N	\N	7.7999999999999998	\N
5154	253	1805	2012-11-22 02:30:00	\N	\N	7.9000000000000004	\N
5155	259	1805	2012-11-22 02:30:00	0	\N	\N	\N
5156	250	1806	2012-11-22 03:00:00	\N	\N	7.7999999999999998	\N
5157	253	1806	2012-11-22 03:00:00	\N	\N	7.7999999999999998	\N
5158	259	1806	2012-11-22 03:00:00	0	\N	\N	\N
5159	250	1807	2012-11-22 03:30:00	\N	\N	7.7999999999999998	\N
5160	253	1807	2012-11-22 03:30:00	\N	\N	7.7999999999999998	\N
5161	259	1807	2012-11-22 03:30:00	0	\N	\N	\N
5162	250	1808	2012-11-22 04:00:00	\N	\N	7.7000000000000002	\N
5163	253	1808	2012-11-22 04:00:00	\N	\N	7.7000000000000002	\N
5164	259	1808	2012-11-22 04:00:00	0	\N	\N	\N
5165	250	1809	2012-11-22 04:30:00	\N	\N	7.9000000000000004	\N
5166	253	1809	2012-11-22 04:30:00	\N	\N	7.7000000000000002	\N
5167	259	1809	2012-11-22 04:30:00	0	\N	\N	\N
5168	250	1810	2012-11-22 05:00:00	\N	\N	7.7999999999999998	\N
5169	253	1810	2012-11-22 05:00:00	\N	\N	7.5999999999999996	\N
5170	259	1810	2012-11-22 05:00:00	0	\N	\N	\N
5171	250	1811	2012-11-22 05:30:00	\N	\N	7.9000000000000004	\N
5172	253	1811	2012-11-22 05:30:00	\N	\N	7.5999999999999996	\N
5173	259	1811	2012-11-22 05:30:00	0	\N	\N	\N
5174	250	1812	2012-11-22 06:00:00	\N	\N	7.7999999999999998	\N
5175	253	1812	2012-11-22 06:00:00	\N	\N	7.5	\N
5176	259	1812	2012-11-22 06:00:00	0	\N	\N	\N
5177	250	1813	2012-11-22 06:30:00	\N	\N	7.9000000000000004	\N
5178	253	1813	2012-11-22 06:30:00	\N	\N	7.5	\N
5179	259	1813	2012-11-22 06:30:00	0	\N	\N	\N
5180	250	1814	2012-11-22 07:00:00	\N	\N	7.9000000000000004	\N
5181	253	1814	2012-11-22 07:00:00	\N	\N	7.5	\N
5182	259	1814	2012-11-22 07:00:00	0	\N	\N	\N
5183	250	1815	2012-11-22 07:30:00	\N	\N	8	\N
5184	253	1815	2012-11-22 07:30:00	\N	\N	7.5	\N
5185	259	1815	2012-11-22 07:30:00	0	\N	\N	\N
5186	250	1816	2012-11-22 08:00:00	\N	\N	8.1999999999999993	\N
5187	253	1816	2012-11-22 08:00:00	\N	\N	7.5	\N
5188	259	1816	2012-11-22 08:00:00	0	\N	\N	\N
5189	250	1817	2012-11-22 08:30:00	\N	\N	8.3000000000000007	\N
5190	253	1817	2012-11-22 08:30:00	\N	\N	7.5	\N
5191	259	1817	2012-11-22 08:30:00	0	\N	\N	\N
5192	250	1818	2012-11-22 09:00:00	\N	\N	8.4000000000000004	\N
5193	253	1818	2012-11-22 09:00:00	\N	\N	7.4000000000000004	\N
5194	259	1818	2012-11-22 09:00:00	0	\N	\N	\N
5195	250	1819	2012-11-22 09:30:00	\N	\N	8.3000000000000007	\N
5196	253	1819	2012-11-22 09:30:00	\N	\N	7.4000000000000004	\N
5197	259	1819	2012-11-22 09:30:00	0	\N	\N	\N
5198	250	1820	2012-11-22 10:00:00	\N	\N	8.5	\N
5199	253	1820	2012-11-22 10:00:00	\N	\N	7.2999999999999998	\N
5200	259	1820	2012-11-22 10:00:00	0	\N	\N	\N
5201	250	1821	2012-11-22 10:30:00	\N	\N	8.5999999999999996	\N
5202	253	1821	2012-11-22 10:30:00	\N	\N	7.2999999999999998	\N
5203	259	1821	2012-11-22 10:30:00	0	\N	\N	\N
5204	250	1822	2012-11-22 11:00:00	\N	\N	8.5	\N
5205	253	1822	2012-11-22 11:00:00	\N	\N	7.2000000000000002	\N
5206	259	1822	2012-11-22 11:00:00	0	\N	\N	\N
5207	250	1823	2012-11-22 11:30:00	\N	\N	8.5999999999999996	\N
5208	253	1823	2012-11-22 11:30:00	\N	\N	7.7999999999999998	\N
5209	259	1823	2012-11-22 11:30:00	0	\N	\N	\N
5210	250	1824	2012-11-22 12:00:00	\N	\N	8.6999999999999993	\N
5211	253	1824	2012-11-22 12:00:00	\N	\N	9.4000000000000004	\N
5212	259	1824	2012-11-22 12:00:00	0	\N	\N	\N
5213	250	1825	2012-11-22 12:30:00	\N	\N	8.6999999999999993	\N
5214	253	1825	2012-11-22 12:30:00	\N	\N	10.4	\N
5215	259	1825	2012-11-22 12:30:00	0	\N	\N	\N
5216	250	1826	2012-11-22 13:00:00	\N	\N	8.8000000000000007	\N
5217	253	1826	2012-11-22 13:00:00	\N	\N	11.300000000000001	\N
5218	259	1826	2012-11-22 13:00:00	0	\N	\N	\N
5219	250	1827	2012-11-22 13:30:00	\N	\N	8.8000000000000007	\N
5220	253	1827	2012-11-22 13:30:00	\N	\N	11.6	\N
5221	259	1827	2012-11-22 13:30:00	0	\N	\N	\N
5222	250	1828	2012-11-22 14:00:00	\N	\N	8.8000000000000007	\N
5223	253	1828	2012-11-22 14:00:00	\N	\N	10.800000000000001	\N
5224	259	1828	2012-11-22 14:00:00	0	\N	\N	\N
5225	250	1829	2012-11-22 14:30:00	\N	\N	8.8000000000000007	\N
5226	253	1829	2012-11-22 14:30:00	\N	\N	10.9	\N
5227	259	1829	2012-11-22 14:30:00	0	\N	\N	\N
5228	250	1830	2012-11-22 15:00:00	\N	\N	8.8000000000000007	\N
5229	253	1830	2012-11-22 15:00:00	\N	\N	10.699999999999999	\N
5230	259	1830	2012-11-22 15:00:00	0	\N	\N	\N
5231	250	1831	2012-11-22 15:30:00	\N	\N	8.6999999999999993	\N
5232	253	1831	2012-11-22 15:30:00	\N	\N	10.5	\N
5233	259	1831	2012-11-22 15:30:00	0	\N	\N	\N
5234	250	1832	2012-11-22 16:00:00	\N	\N	8.6999999999999993	\N
5235	253	1832	2012-11-22 16:00:00	\N	\N	10.6	\N
5236	259	1832	2012-11-22 16:00:00	0	\N	\N	\N
5237	250	1833	2012-11-22 16:30:00	\N	\N	8.5999999999999996	\N
5238	253	1833	2012-11-22 16:30:00	\N	\N	10.4	\N
5239	259	1833	2012-11-22 16:30:00	0	\N	\N	\N
5240	250	1834	2012-11-22 17:00:00	\N	\N	8.5999999999999996	\N
5241	253	1834	2012-11-22 17:00:00	\N	\N	10.5	\N
5242	259	1834	2012-11-22 17:00:00	0	\N	\N	\N
5243	250	1835	2012-11-22 17:30:00	\N	\N	8.5	\N
5244	253	1835	2012-11-22 17:30:00	\N	\N	10.9	\N
5245	259	1835	2012-11-22 17:30:00	0	\N	\N	\N
5246	250	1836	2012-11-22 18:00:00	\N	\N	8.5	\N
5247	253	1836	2012-11-22 18:00:00	\N	\N	11.1	\N
5248	259	1836	2012-11-22 18:00:00	0	\N	\N	\N
5249	250	1837	2012-11-22 18:30:00	\N	\N	8.4000000000000004	\N
5250	253	1837	2012-11-22 18:30:00	\N	\N	11.300000000000001	\N
5251	259	1837	2012-11-22 18:30:00	0	\N	\N	\N
5252	250	1838	2012-11-22 19:00:00	\N	\N	8.4000000000000004	\N
5253	253	1838	2012-11-22 19:00:00	\N	\N	11.1	\N
5254	259	1838	2012-11-22 19:00:00	0	\N	\N	\N
5255	250	1839	2012-11-22 19:30:00	\N	\N	8.3000000000000007	\N
5256	253	1839	2012-11-22 19:30:00	\N	\N	11	\N
5257	259	1839	2012-11-22 19:30:00	0	\N	\N	\N
5258	250	1840	2012-11-22 20:00:00	\N	\N	8.4000000000000004	\N
5259	253	1840	2012-11-22 20:00:00	\N	\N	11	\N
5260	259	1840	2012-11-22 20:00:00	0	\N	\N	\N
5261	250	1841	2012-11-22 20:30:00	\N	\N	8.1999999999999993	\N
5262	253	1841	2012-11-22 20:30:00	\N	\N	10.800000000000001	\N
5263	259	1841	2012-11-22 20:30:00	0	\N	\N	\N
5264	250	1842	2012-11-22 21:00:00	\N	\N	8.1999999999999993	\N
5265	253	1842	2012-11-22 21:00:00	\N	\N	10.9	\N
5266	259	1842	2012-11-22 21:00:00	0	\N	\N	\N
5267	250	1843	2012-11-22 21:30:00	\N	\N	8.0999999999999996	\N
5268	253	1843	2012-11-22 21:30:00	\N	\N	10.9	\N
5269	259	1843	2012-11-22 21:30:00	0	\N	\N	\N
5270	250	1844	2012-11-22 22:00:00	\N	\N	8.1999999999999993	\N
5271	253	1844	2012-11-22 22:00:00	\N	\N	11	\N
5272	259	1844	2012-11-22 22:00:00	0	\N	\N	\N
5273	250	1845	2012-11-22 22:30:00	\N	\N	8.1999999999999993	\N
5274	253	1845	2012-11-22 22:30:00	\N	\N	10.699999999999999	\N
5275	259	1845	2012-11-22 22:30:00	0	\N	\N	\N
5276	250	1846	2012-11-22 23:00:00	\N	\N	8.1999999999999993	\N
5277	253	1846	2012-11-22 23:00:00	\N	\N	10.699999999999999	\N
5278	259	1846	2012-11-22 23:00:00	0	\N	\N	\N
5279	250	1847	2012-11-22 23:30:00	\N	\N	7.9000000000000004	\N
5280	253	1847	2012-11-22 23:30:00	\N	\N	10.6	\N
5281	259	1847	2012-11-22 23:30:00	0	\N	\N	\N
5282	250	1848	2012-11-23 00:00:00	\N	\N	7.9000000000000004	\N
5283	253	1848	2012-11-23 00:00:00	\N	\N	10.5	\N
5284	259	1848	2012-11-23 00:00:00	0	\N	\N	\N
5285	250	1849	2012-11-23 00:30:00	\N	\N	7.7999999999999998	\N
5286	253	1849	2012-11-23 00:30:00	\N	\N	10.4	\N
5287	259	1849	2012-11-23 00:30:00	0	\N	\N	\N
5288	250	1850	2012-11-23 01:00:00	\N	\N	7.7000000000000002	\N
5289	253	1850	2012-11-23 01:00:00	\N	\N	10	\N
5290	259	1850	2012-11-23 01:00:00	0	\N	\N	\N
5291	250	1851	2012-11-23 01:30:00	\N	\N	7.5999999999999996	\N
5292	253	1851	2012-11-23 01:30:00	\N	\N	9.9000000000000004	\N
5293	259	1851	2012-11-23 01:30:00	0	\N	\N	\N
5294	250	1852	2012-11-23 02:00:00	\N	\N	7.7000000000000002	\N
5295	253	1852	2012-11-23 02:00:00	\N	\N	9.9000000000000004	\N
5296	259	1852	2012-11-23 02:00:00	0	\N	\N	\N
5297	250	1853	2012-11-23 02:30:00	\N	\N	7.5999999999999996	\N
5298	253	1853	2012-11-23 02:30:00	\N	\N	9.8000000000000007	\N
5299	259	1853	2012-11-23 02:30:00	0	\N	\N	\N
5300	250	1854	2012-11-23 03:00:00	\N	\N	7.5999999999999996	\N
5301	253	1854	2012-11-23 03:00:00	\N	\N	9.8000000000000007	\N
5302	259	1854	2012-11-23 03:00:00	9	\N	\N	\N
5303	250	1855	2012-11-23 03:30:00	\N	\N	7.5999999999999996	\N
5304	253	1855	2012-11-23 03:30:00	\N	\N	9.6999999999999993	\N
5305	259	1855	2012-11-23 03:30:00	8	\N	\N	\N
5306	250	1856	2012-11-23 04:00:00	\N	\N	7.5999999999999996	\N
5307	253	1856	2012-11-23 04:00:00	\N	\N	9.5999999999999996	\N
5308	259	1856	2012-11-23 04:00:00	4	\N	\N	\N
5309	250	1857	2012-11-23 04:30:00	\N	\N	7.5	\N
5310	253	1857	2012-11-23 04:30:00	\N	\N	9.5	\N
5311	259	1857	2012-11-23 04:30:00	2	\N	\N	\N
5312	250	1858	2012-11-23 05:00:00	\N	\N	7.5	\N
5313	253	1858	2012-11-23 05:00:00	\N	\N	9.1999999999999993	\N
5314	259	1858	2012-11-23 05:00:00	0	\N	\N	\N
5315	250	1859	2012-11-23 05:30:00	\N	\N	7.5	\N
5316	253	1859	2012-11-23 05:30:00	\N	\N	9.0999999999999996	\N
5317	259	1859	2012-11-23 05:30:00	0	\N	\N	\N
5318	250	1860	2012-11-23 06:00:00	\N	\N	7.5	\N
5319	253	1860	2012-11-23 06:00:00	\N	\N	9	\N
5320	259	1860	2012-11-23 06:00:00	0	\N	\N	\N
5321	250	1861	2012-11-23 06:30:00	\N	\N	7.4000000000000004	\N
5322	253	1861	2012-11-23 06:30:00	\N	\N	9	\N
5323	259	1861	2012-11-23 06:30:00	1	\N	\N	\N
5324	250	1862	2012-11-23 07:00:00	\N	\N	7.5999999999999996	\N
5325	253	1862	2012-11-23 07:00:00	\N	\N	8.9000000000000004	\N
5326	259	1862	2012-11-23 07:00:00	1	\N	\N	\N
5327	250	1863	2012-11-23 07:30:00	\N	\N	7.5999999999999996	\N
5328	253	1863	2012-11-23 07:30:00	\N	\N	8.8000000000000007	\N
5329	259	1863	2012-11-23 07:30:00	2	\N	\N	\N
5330	250	1864	2012-11-23 08:00:00	\N	\N	7.5999999999999996	\N
5331	253	1864	2012-11-23 08:00:00	\N	\N	8.6999999999999993	\N
5332	259	1864	2012-11-23 08:00:00	4	\N	\N	\N
5333	250	1865	2012-11-23 08:30:00	\N	\N	7.7999999999999998	\N
5334	253	1865	2012-11-23 08:30:00	\N	\N	8.6999999999999993	\N
5335	259	1865	2012-11-23 08:30:00	15	\N	\N	\N
5336	250	1866	2012-11-23 09:00:00	\N	\N	7.9000000000000004	\N
5337	253	1866	2012-11-23 09:00:00	\N	\N	8.6999999999999993	\N
5338	259	1866	2012-11-23 09:00:00	15	\N	\N	\N
5339	250	1867	2012-11-23 09:30:00	\N	\N	8.1999999999999993	\N
5340	253	1867	2012-11-23 09:30:00	\N	\N	8.6999999999999993	\N
5341	259	1867	2012-11-23 09:30:00	15	\N	\N	\N
5342	250	1868	2012-11-23 10:00:00	\N	\N	8.4000000000000004	\N
5343	253	1868	2012-11-23 10:00:00	\N	\N	8.5999999999999996	\N
5344	259	1868	2012-11-23 10:00:00	15	\N	\N	\N
5345	250	1869	2012-11-23 10:30:00	\N	\N	8.3000000000000007	\N
5346	253	1869	2012-11-23 10:30:00	\N	\N	8.5999999999999996	\N
5347	259	1869	2012-11-23 10:30:00	15	\N	\N	\N
5348	250	1870	2012-11-23 11:00:00	\N	\N	8.4000000000000004	\N
5349	253	1870	2012-11-23 11:00:00	\N	\N	9.9000000000000004	\N
5350	259	1870	2012-11-23 11:00:00	15	\N	\N	\N
5351	250	1871	2012-11-23 11:30:00	\N	\N	8.5	\N
5352	253	1871	2012-11-23 11:30:00	\N	\N	11.199999999999999	\N
5353	259	1871	2012-11-23 11:30:00	15	\N	\N	\N
5354	250	1872	2012-11-23 12:00:00	\N	\N	8.8000000000000007	\N
5355	253	1872	2012-11-23 12:00:00	\N	\N	11.699999999999999	\N
5356	259	1872	2012-11-23 12:00:00	1	\N	\N	\N
5357	250	1873	2012-11-23 12:30:00	\N	\N	9	\N
5358	253	1873	2012-11-23 12:30:00	\N	\N	11.5	\N
5359	259	1873	2012-11-23 12:30:00	1	\N	\N	\N
5360	250	1874	2012-11-23 13:00:00	\N	\N	9.1999999999999993	\N
5361	253	1874	2012-11-23 13:00:00	\N	\N	11.300000000000001	\N
5362	259	1874	2012-11-23 13:00:00	1	\N	\N	\N
5363	250	1875	2012-11-23 13:30:00	\N	\N	9.0999999999999996	\N
5364	253	1875	2012-11-23 13:30:00	\N	\N	11.1	\N
5365	259	1875	2012-11-23 13:30:00	0	\N	\N	\N
5366	250	1876	2012-11-23 14:00:00	\N	\N	9.1999999999999993	\N
5367	253	1876	2012-11-23 14:00:00	\N	\N	10.9	\N
5368	259	1876	2012-11-23 14:00:00	0	\N	\N	\N
5369	250	1877	2012-11-23 14:30:00	\N	\N	9.1999999999999993	\N
5370	253	1877	2012-11-23 14:30:00	\N	\N	11	\N
5371	259	1877	2012-11-23 14:30:00	0	\N	\N	\N
5372	250	1878	2012-11-23 15:00:00	\N	\N	8.9000000000000004	\N
5373	253	1878	2012-11-23 15:00:00	\N	\N	11.199999999999999	\N
5374	259	1878	2012-11-23 15:00:00	0	\N	\N	\N
5375	250	1879	2012-11-23 15:30:00	\N	\N	8.9000000000000004	\N
5376	253	1879	2012-11-23 15:30:00	\N	\N	11.199999999999999	\N
5377	259	1879	2012-11-23 15:30:00	0	\N	\N	\N
5378	250	1880	2012-11-23 16:00:00	\N	\N	8.5999999999999996	\N
5379	253	1880	2012-11-23 16:00:00	\N	\N	11.199999999999999	\N
5380	259	1880	2012-11-23 16:00:00	0	\N	\N	\N
5381	250	1881	2012-11-23 16:30:00	\N	\N	8.5999999999999996	\N
5383	259	1881	2012-11-23 16:30:00	0	\N	\N	\N
5389	259	1883	2012-11-23 17:30:00	3	\N	\N	\N
5393	250	1885	2012-11-23 18:30:00	\N	\N	8.5	\N
5395	259	1885	2012-11-23 18:30:00	10	\N	\N	\N
5399	250	1887	2012-11-23 19:30:00	\N	\N	8.5	\N
5401	259	1887	2012-11-23 19:30:00	15	\N	\N	\N
5405	250	1889	2012-11-23 20:30:00	\N	\N	8.5	\N
5407	259	1889	2012-11-23 20:30:00	15	\N	\N	\N
5417	250	1893	2012-11-23 22:30:00	\N	\N	8.3000000000000007	\N
5423	250	1895	2012-11-23 23:30:00	\N	\N	7.9000000000000004	\N
5425	259	1895	2012-11-23 23:30:00	15	\N	\N	\N
5429	250	1897	2012-11-24 00:30:00	\N	\N	7.4000000000000004	\N
5433	253	1898	2012-11-24 01:00:00	\N	\N	11.699999999999999	\N
5439	253	1900	2012-11-24 02:00:00	\N	\N	11.300000000000001	\N
5447	250	1903	2012-11-24 03:30:00	\N	\N	6.2000000000000002	\N
5451	253	1904	2012-11-24 04:00:00	\N	\N	10.800000000000001	\N
5463	253	1908	2012-11-24 06:00:00	\N	\N	10.4	\N
5470	259	1910	2012-11-24 07:00:00	13	\N	\N	\N
5475	253	1912	2012-11-24 08:00:00	\N	\N	9.6999999999999993	\N
5481	253	1914	2012-11-24 09:00:00	\N	\N	9.5999999999999996	\N
5487	253	1916	2012-11-24 10:00:00	\N	\N	9.8000000000000007	\N
5505	253	1922	2012-11-24 13:00:00	\N	\N	10.1	\N
5516	250	1926	2012-11-24 15:00:00	\N	\N	8.0999999999999996	\N
5518	259	1926	2012-11-24 15:00:00	0	\N	\N	\N
5524	259	1928	2012-11-24 16:00:00	0	\N	\N	\N
5552	250	1938	2012-11-24 21:00:00	\N	\N	3.5	\N
5558	250	1940	2012-11-24 22:00:00	\N	\N	3.2000000000000002	\N
5560	259	1940	2012-11-24 22:00:00	4	\N	\N	\N
5572	259	1944	2012-11-25 00:00:00	15	\N	\N	\N
5588	250	1950	2012-11-25 03:00:00	\N	\N	2.7000000000000002	\N
5606	250	1956	2012-11-25 06:00:00	\N	\N	3.2000000000000002	\N
5608	259	1956	2012-11-25 06:00:00	15	\N	\N	\N
5616	253	1959	2012-11-25 07:30:00	\N	\N	6.9000000000000004	\N
5624	250	1962	2012-11-25 09:00:00	\N	\N	3.7000000000000002	\N
5626	259	1962	2012-11-25 09:00:00	12	\N	\N	\N
5630	250	1964	2012-11-25 10:00:00	\N	\N	4.7999999999999998	\N
5642	250	1968	2012-11-25 12:00:00	\N	\N	7.9000000000000004	\N
5658	253	1973	2012-11-25 14:30:00	\N	\N	8.0999999999999996	\N
5664	253	1975	2012-11-25 15:30:00	\N	\N	8.4000000000000004	\N
5670	253	1977	2012-11-25 16:30:00	\N	\N	8.5999999999999996	\N
5688	253	1983	2012-11-25 19:30:00	\N	\N	9.0999999999999996	\N
5711	250	1991	2012-11-25 23:30:00	\N	\N	6.7999999999999998	\N
5713	259	1991	2012-11-25 23:30:00	15	\N	\N	\N
5719	259	1993	2012-11-26 00:30:00	14	\N	\N	\N
5741	250	2001	2012-11-26 04:30:00	\N	\N	6	\N
5743	259	2001	2012-11-26 04:30:00	10	\N	\N	\N
5749	259	2003	2012-11-26 05:30:00	9	\N	\N	\N
5753	250	2005	2012-11-26 06:30:00	\N	\N	6.2999999999999998	\N
5755	259	2005	2012-11-26 06:30:00	7	\N	\N	\N
5759	250	2007	2012-11-26 07:30:00	\N	\N	6.5	\N
5761	259	2007	2012-11-26 07:30:00	6	\N	\N	\N
5765	250	2009	2012-11-26 08:30:00	\N	\N	7.2000000000000002	\N
5767	259	2009	2012-11-26 08:30:00	2	\N	\N	\N
5777	250	2013	2012-11-26 10:30:00	\N	\N	9.3000000000000007	\N
5783	250	2015	2012-11-26 11:30:00	\N	\N	9.3000000000000007	\N
5785	259	2015	2012-11-26 11:30:00	0	\N	\N	\N
5793	253	2018	2012-11-26 13:00:00	\N	\N	8.1999999999999993	\N
5796	253	2019	2012-11-26 13:30:00	\N	\N	8.3000000000000007	\N
5797	259	2019	2012-11-26 13:30:00	0	\N	\N	\N
5812	259	2024	2012-11-26 16:00:00	0	\N	\N	\N
5813	250	2025	2012-11-26 16:30:00	\N	\N	9.5999999999999996	\N
5821	259	2027	2012-11-26 17:30:00	0	\N	\N	\N
5824	259	2028	2012-11-26 18:00:00	0	\N	\N	\N
5825	250	2029	2012-11-26 18:30:00	\N	\N	9	\N
5832	253	2031	2012-11-26 19:30:00	\N	\N	9.0999999999999996	\N
5833	259	2031	2012-11-26 19:30:00	0	\N	\N	\N
5871	253	2044	2012-11-27 02:00:00	\N	\N	8.3000000000000007	\N
5889	253	2050	2012-11-27 05:00:00	\N	\N	7.7000000000000002	\N
5890	259	2050	2012-11-27 05:00:00	0	\N	\N	\N
5900	250	2054	2012-11-27 07:00:00	\N	\N	7.4000000000000004	\N
5910	253	2057	2012-11-27 08:30:00	\N	\N	7.5	\N
5911	259	2057	2012-11-27 08:30:00	0	\N	\N	\N
5912	250	2058	2012-11-27 09:00:00	\N	\N	7.7999999999999998	\N
5916	253	2059	2012-11-27 09:30:00	\N	\N	7.5	\N
5917	259	2059	2012-11-27 09:30:00	0	\N	\N	\N
5925	253	2062	2012-11-27 11:00:00	\N	\N	7.4000000000000004	\N
5926	259	2062	2012-11-27 11:00:00	0	\N	\N	\N
5930	250	2064	2012-11-27 12:00:00	\N	\N	8.6999999999999993	\N
5934	253	2065	2012-11-27 12:30:00	\N	\N	7.7000000000000002	\N
5935	259	2065	2012-11-27 12:30:00	0	\N	\N	\N
5941	259	2067	2012-11-27 13:30:00	0	\N	\N	\N
5382	253	1881	2012-11-23 16:30:00	\N	\N	11.300000000000001	\N
5409	253	1890	2012-11-23 21:00:00	\N	\N	12.300000000000001	\N
5431	259	1897	2012-11-24 00:30:00	15	\N	\N	\N
5435	250	1899	2012-11-24 01:30:00	\N	\N	7.5999999999999996	\N
5437	259	1899	2012-11-24 01:30:00	15	\N	\N	\N
5457	253	1906	2012-11-24 05:00:00	\N	\N	10.4	\N
5474	250	1912	2012-11-24 08:00:00	\N	\N	6.7000000000000002	\N
5476	259	1912	2012-11-24 08:00:00	10	\N	\N	\N
5480	250	1914	2012-11-24 09:00:00	\N	\N	7.5999999999999996	\N
5482	259	1914	2012-11-24 09:00:00	1	\N	\N	\N
5494	259	1918	2012-11-24 11:00:00	0	\N	\N	\N
5514	253	1925	2012-11-24 14:30:00	\N	\N	10.300000000000001	\N
5520	253	1927	2012-11-24 15:30:00	\N	\N	9.6999999999999993	\N
5526	253	1929	2012-11-24 16:30:00	\N	\N	10	\N
5532	253	1931	2012-11-24 17:30:00	\N	\N	9.8000000000000007	\N
5562	253	1941	2012-11-24 22:30:00	\N	\N	8.9000000000000004	\N
5589	253	1950	2012-11-25 03:00:00	\N	\N	7.5	\N
5611	259	1957	2012-11-25 06:30:00	15	\N	\N	\N
5615	250	1959	2012-11-25 07:30:00	\N	\N	2.8999999999999999	\N
5617	259	1959	2012-11-25 07:30:00	15	\N	\N	\N
5637	253	1966	2012-11-25 11:00:00	\N	\N	7.4000000000000004	\N
5654	250	1972	2012-11-25 14:00:00	\N	\N	9	\N
5656	259	1972	2012-11-25 14:00:00	0	\N	\N	\N
5660	250	1974	2012-11-25 15:00:00	\N	\N	8	\N
5662	259	1974	2012-11-25 15:00:00	0	\N	\N	\N
5674	259	1978	2012-11-25 17:00:00	0	\N	\N	\N
5694	253	1985	2012-11-25 20:30:00	\N	\N	9.1999999999999993	\N
5700	253	1987	2012-11-25 21:30:00	\N	\N	9.1999999999999993	\N
5706	253	1989	2012-11-25 22:30:00	\N	\N	9	\N
5712	253	1991	2012-11-25 23:30:00	\N	\N	8.9000000000000004	\N
5742	253	2001	2012-11-26 04:30:00	\N	\N	7.9000000000000004	\N
5769	253	2010	2012-11-26 09:00:00	\N	\N	7.4000000000000004	\N
5794	259	2018	2012-11-26 13:00:00	0	\N	\N	\N
5834	250	2032	2012-11-26 20:00:00	\N	\N	8.5	\N
5842	259	2034	2012-11-26 21:00:00	0	\N	\N	\N
5849	250	2037	2012-11-26 22:30:00	\N	\N	8.3000000000000007	\N
5854	259	2038	2012-11-26 23:00:00	0	\N	\N	\N
5855	250	2039	2012-11-26 23:30:00	\N	\N	8.3000000000000007	\N
5859	253	2040	2012-11-27 00:00:00	\N	\N	8.4000000000000004	\N
5860	259	2040	2012-11-27 00:00:00	0	\N	\N	\N
5895	253	2052	2012-11-27 06:00:00	\N	\N	7.7000000000000002	\N
5913	253	2058	2012-11-27 09:00:00	\N	\N	7.5	\N
5914	259	2058	2012-11-27 09:00:00	0	\N	\N	\N
5929	259	2063	2012-11-27 11:30:00	0	\N	\N	\N
5932	259	2064	2012-11-27 12:00:00	0	\N	\N	\N
5384	250	1882	2012-11-23 17:00:00	\N	\N	8.5999999999999996	\N
5386	259	1882	2012-11-23 17:00:00	1	\N	\N	\N
5390	250	1884	2012-11-23 18:00:00	\N	\N	8.5	\N
5402	250	1888	2012-11-23 20:00:00	\N	\N	8.5	\N
5418	253	1893	2012-11-23 22:30:00	\N	\N	12	\N
5424	253	1895	2012-11-23 23:30:00	\N	\N	11.800000000000001	\N
5430	253	1897	2012-11-24 00:30:00	\N	\N	11.699999999999999	\N
5448	253	1903	2012-11-24 03:30:00	\N	\N	10.9	\N
5471	250	1911	2012-11-24 07:30:00	\N	\N	6.0999999999999996	\N
5473	259	1911	2012-11-24 07:30:00	12	\N	\N	\N
5479	259	1913	2012-11-24 08:30:00	3	\N	\N	\N
5501	250	1921	2012-11-24 12:30:00	\N	\N	9.4000000000000004	\N
5503	259	1921	2012-11-24 12:30:00	0	\N	\N	\N
5509	259	1923	2012-11-24 13:30:00	0	\N	\N	\N
5513	250	1925	2012-11-24 14:30:00	\N	\N	7.9000000000000004	\N
5515	259	1925	2012-11-24 14:30:00	0	\N	\N	\N
5519	250	1927	2012-11-24 15:30:00	\N	\N	9.4000000000000004	\N
5521	259	1927	2012-11-24 15:30:00	0	\N	\N	\N
5525	250	1929	2012-11-24 16:30:00	\N	\N	8.3000000000000007	\N
5527	259	1929	2012-11-24 16:30:00	0	\N	\N	\N
5537	250	1933	2012-11-24 18:30:00	\N	\N	5.7000000000000002	\N
5543	250	1935	2012-11-24 19:30:00	\N	\N	4	\N
5545	259	1935	2012-11-24 19:30:00	1	\N	\N	\N
5549	250	1937	2012-11-24 20:30:00	\N	\N	3.6000000000000001	\N
5553	253	1938	2012-11-24 21:00:00	\N	\N	9.0999999999999996	\N
5559	253	1940	2012-11-24 22:00:00	\N	\N	8.9000000000000004	\N
5567	250	1943	2012-11-24 23:30:00	\N	\N	1.8999999999999999	\N
5571	253	1944	2012-11-25 00:00:00	\N	\N	8.3000000000000007	\N
5583	253	1948	2012-11-25 02:00:00	\N	\N	8	\N
5590	259	1950	2012-11-25 03:00:00	15	\N	\N	\N
5595	253	1952	2012-11-25 04:00:00	\N	\N	7.4000000000000004	\N
5601	253	1954	2012-11-25 05:00:00	\N	\N	7.2000000000000002	\N
5607	253	1956	2012-11-25 06:00:00	\N	\N	7.0999999999999996	\N
5625	253	1962	2012-11-25 09:00:00	\N	\N	6.5999999999999996	\N
5636	250	1966	2012-11-25 11:00:00	\N	\N	6.5	\N
5638	259	1966	2012-11-25 11:00:00	0	\N	\N	\N
5644	259	1968	2012-11-25 12:00:00	0	\N	\N	\N
5672	250	1978	2012-11-25 17:00:00	\N	\N	7.5999999999999996	\N
5678	250	1980	2012-11-25 18:00:00	\N	\N	7.7999999999999998	\N
5680	259	1980	2012-11-25 18:00:00	1	\N	\N	\N
5692	259	1984	2012-11-25 20:00:00	8	\N	\N	\N
5708	250	1990	2012-11-25 23:00:00	\N	\N	6.7999999999999998	\N
5726	250	1996	2012-11-26 02:00:00	\N	\N	6.2999999999999998	\N
5728	259	1996	2012-11-26 02:00:00	12	\N	\N	\N
5736	253	1999	2012-11-26 03:30:00	\N	\N	8	\N
5744	250	2002	2012-11-26 05:00:00	\N	\N	6	\N
5746	259	2002	2012-11-26 05:00:00	10	\N	\N	\N
5750	250	2004	2012-11-26 06:00:00	\N	\N	6.2000000000000002	\N
5762	250	2008	2012-11-26 08:00:00	\N	\N	6.7999999999999998	\N
5778	253	2013	2012-11-26 10:30:00	\N	\N	7.7000000000000002	\N
5784	253	2015	2012-11-26 11:30:00	\N	\N	7.9000000000000004	\N
5789	250	2017	2012-11-26 12:30:00	\N	\N	9.5999999999999996	\N
5792	250	2018	2012-11-26 13:00:00	\N	\N	10	\N
5804	250	2022	2012-11-26 15:00:00	\N	\N	10.300000000000001	\N
5810	250	2024	2012-11-26 16:00:00	\N	\N	9.5	\N
5823	253	2028	2012-11-26 18:00:00	\N	\N	9.0999999999999996	\N
5831	250	2031	2012-11-26 19:30:00	\N	\N	8.5999999999999996	\N
5843	250	2035	2012-11-26 21:30:00	\N	\N	8.0999999999999996	\N
5857	259	2039	2012-11-26 23:30:00	0	\N	\N	\N
5868	253	2043	2012-11-27 01:30:00	\N	\N	8.4000000000000004	\N
5882	250	2048	2012-11-27 04:00:00	\N	\N	8.5	\N
5892	253	2051	2012-11-27 05:30:00	\N	\N	7.7000000000000002	\N
5893	259	2051	2012-11-27 05:30:00	0	\N	\N	\N
5894	250	2052	2012-11-27 06:00:00	\N	\N	7.2999999999999998	\N
5905	259	2055	2012-11-27 07:30:00	0	\N	\N	\N
5921	250	2061	2012-11-27 10:30:00	\N	\N	8.5999999999999996	\N
5937	253	2066	2012-11-27 13:00:00	\N	\N	7.7999999999999998	\N
5938	259	2066	2012-11-27 13:00:00	0	\N	\N	\N
5385	253	1882	2012-11-23 17:00:00	\N	\N	11.5	\N
5396	250	1886	2012-11-23 19:00:00	\N	\N	8.5999999999999996	\N
5398	259	1886	2012-11-23 19:00:00	12	\N	\N	\N
5404	259	1888	2012-11-23 20:00:00	15	\N	\N	\N
5432	250	1898	2012-11-24 01:00:00	\N	\N	7.5999999999999996	\N
5438	250	1900	2012-11-24 02:00:00	\N	\N	7.4000000000000004	\N
5440	259	1900	2012-11-24 02:00:00	15	\N	\N	\N
5452	259	1904	2012-11-24 04:00:00	15	\N	\N	\N
5468	250	1910	2012-11-24 07:00:00	\N	\N	5.7999999999999998	\N
5486	250	1916	2012-11-24 10:00:00	\N	\N	9.5999999999999996	\N
5488	259	1916	2012-11-24 10:00:00	0	\N	\N	\N
5496	253	1919	2012-11-24 11:30:00	\N	\N	9.9000000000000004	\N
5504	250	1922	2012-11-24 13:00:00	\N	\N	8.3000000000000007	\N
5506	259	1922	2012-11-24 13:00:00	0	\N	\N	\N
5510	250	1924	2012-11-24 14:00:00	\N	\N	8.1999999999999993	\N
5522	250	1928	2012-11-24 16:00:00	\N	\N	9	\N
5538	253	1933	2012-11-24 18:30:00	\N	\N	9.6999999999999993	\N
5544	253	1935	2012-11-24 19:30:00	\N	\N	9.5	\N
5550	253	1937	2012-11-24 20:30:00	\N	\N	9.1999999999999993	\N
5568	253	1943	2012-11-24 23:30:00	\N	\N	8.4000000000000004	\N
5591	250	1951	2012-11-25 03:30:00	\N	\N	2.6000000000000001	\N
5593	259	1951	2012-11-25 03:30:00	15	\N	\N	\N
5599	259	1953	2012-11-25 04:30:00	15	\N	\N	\N
5621	250	1961	2012-11-25 08:30:00	\N	\N	3	\N
5623	259	1961	2012-11-25 08:30:00	13	\N	\N	\N
5629	259	1963	2012-11-25 09:30:00	8	\N	\N	\N
5633	250	1965	2012-11-25 10:30:00	\N	\N	5.7000000000000002	\N
5635	259	1965	2012-11-25 10:30:00	0	\N	\N	\N
5639	250	1967	2012-11-25 11:30:00	\N	\N	7.4000000000000004	\N
5641	259	1967	2012-11-25 11:30:00	0	\N	\N	\N
5645	250	1969	2012-11-25 12:30:00	\N	\N	8.8000000000000007	\N
5647	259	1969	2012-11-25 12:30:00	0	\N	\N	\N
5657	250	1973	2012-11-25 14:30:00	\N	\N	8.5999999999999996	\N
5663	250	1975	2012-11-25 15:30:00	\N	\N	7.5999999999999996	\N
5665	259	1975	2012-11-25 15:30:00	0	\N	\N	\N
5669	250	1977	2012-11-25 16:30:00	\N	\N	7.5999999999999996	\N
5673	253	1978	2012-11-25 17:00:00	\N	\N	8.6999999999999993	\N
5679	253	1980	2012-11-25 18:00:00	\N	\N	8.8000000000000007	\N
5687	250	1983	2012-11-25 19:30:00	\N	\N	7.5	\N
5691	253	1984	2012-11-25 20:00:00	\N	\N	9.1999999999999993	\N
5703	253	1988	2012-11-25 22:00:00	\N	\N	9.0999999999999996	\N
5710	259	1990	2012-11-25 23:00:00	15	\N	\N	\N
5715	253	1992	2012-11-26 00:00:00	\N	\N	8.8000000000000007	\N
5721	253	1994	2012-11-26 01:00:00	\N	\N	8.5999999999999996	\N
5727	253	1996	2012-11-26 02:00:00	\N	\N	8.0999999999999996	\N
5745	253	2002	2012-11-26 05:00:00	\N	\N	7.7999999999999998	\N
5756	250	2006	2012-11-26 07:00:00	\N	\N	6.4000000000000004	\N
5758	259	2006	2012-11-26 07:00:00	6	\N	\N	\N
5764	259	2008	2012-11-26 08:00:00	4	\N	\N	\N
5798	250	2020	2012-11-26 14:00:00	\N	\N	10.5	\N
5805	253	2022	2012-11-26 15:00:00	\N	\N	8.5	\N
5806	259	2022	2012-11-26 15:00:00	0	\N	\N	\N
5807	250	2023	2012-11-26 15:30:00	\N	\N	9.9000000000000004	\N
5820	253	2027	2012-11-26 17:30:00	\N	\N	9.0999999999999996	\N
5828	250	2030	2012-11-26 19:00:00	\N	\N	8.6999999999999993	\N
5836	259	2032	2012-11-26 20:00:00	0	\N	\N	\N
5839	259	2033	2012-11-26 20:30:00	0	\N	\N	\N
5840	250	2034	2012-11-26 21:00:00	\N	\N	8.1999999999999993	\N
5844	253	2035	2012-11-26 21:30:00	\N	\N	8.9000000000000004	\N
5845	259	2035	2012-11-26 21:30:00	0	\N	\N	\N
5847	253	2036	2012-11-26 22:00:00	\N	\N	8.5	\N
5848	259	2036	2012-11-26 22:00:00	0	\N	\N	\N
5862	253	2041	2012-11-27 00:30:00	\N	\N	8.4000000000000004	\N
5863	259	2041	2012-11-27 00:30:00	0	\N	\N	\N
5877	253	2046	2012-11-27 03:00:00	\N	\N	7.9000000000000004	\N
5878	259	2046	2012-11-27 03:00:00	0	\N	\N	\N
5886	253	2049	2012-11-27 04:30:00	\N	\N	7.7999999999999998	\N
5887	259	2049	2012-11-27 04:30:00	0	\N	\N	\N
5898	253	2053	2012-11-27 06:30:00	\N	\N	7.7000000000000002	\N
5927	250	2063	2012-11-27 11:30:00	\N	\N	8.5	\N
5387	250	1883	2012-11-23 17:30:00	\N	\N	8.5999999999999996	\N
5391	253	1884	2012-11-23 18:00:00	\N	\N	11.699999999999999	\N
5403	253	1888	2012-11-23 20:00:00	\N	\N	12.199999999999999	\N
5410	259	1890	2012-11-23 21:00:00	15	\N	\N	\N
5415	253	1892	2012-11-23 22:00:00	\N	\N	12.1	\N
5421	253	1894	2012-11-23 23:00:00	\N	\N	11.9	\N
5427	253	1896	2012-11-24 00:00:00	\N	\N	11.800000000000001	\N
5445	253	1902	2012-11-24 03:00:00	\N	\N	11	\N
5456	250	1906	2012-11-24 05:00:00	\N	\N	5.7999999999999998	\N
5458	259	1906	2012-11-24 05:00:00	15	\N	\N	\N
5464	259	1908	2012-11-24 06:00:00	13	\N	\N	\N
5492	250	1918	2012-11-24 11:00:00	\N	\N	9.8000000000000007	\N
5498	250	1920	2012-11-24 12:00:00	\N	\N	9.1999999999999993	\N
5500	259	1920	2012-11-24 12:00:00	0	\N	\N	\N
5512	259	1924	2012-11-24 14:00:00	0	\N	\N	\N
5528	250	1930	2012-11-24 17:00:00	\N	\N	7.9000000000000004	\N
5546	250	1936	2012-11-24 20:00:00	\N	\N	3.7000000000000002	\N
5548	259	1936	2012-11-24 20:00:00	1	\N	\N	\N
5556	253	1939	2012-11-24 21:30:00	\N	\N	9	\N
5564	250	1942	2012-11-24 23:00:00	\N	\N	2.2999999999999998	\N
5566	259	1942	2012-11-24 23:00:00	15	\N	\N	\N
5570	250	1944	2012-11-25 00:00:00	\N	\N	1.8999999999999999	\N
5582	250	1948	2012-11-25 02:00:00	\N	\N	2	\N
5598	253	1953	2012-11-25 04:30:00	\N	\N	7.2999999999999998	\N
5604	253	1955	2012-11-25 05:30:00	\N	\N	7.0999999999999996	\N
5610	253	1957	2012-11-25 06:30:00	\N	\N	7	\N
5628	253	1963	2012-11-25 09:30:00	\N	\N	6.5999999999999996	\N
5651	250	1971	2012-11-25 13:30:00	\N	\N	9	\N
5653	259	1971	2012-11-25 13:30:00	0	\N	\N	\N
5659	259	1973	2012-11-25 14:30:00	0	\N	\N	\N
5681	250	1981	2012-11-25 18:30:00	\N	\N	7.5999999999999996	\N
5683	259	1981	2012-11-25 18:30:00	1	\N	\N	\N
5689	259	1983	2012-11-25 19:30:00	3	\N	\N	\N
5693	250	1985	2012-11-25 20:30:00	\N	\N	7.5	\N
5695	259	1985	2012-11-25 20:30:00	14	\N	\N	\N
5699	250	1987	2012-11-25 21:30:00	\N	\N	7.2999999999999998	\N
5701	259	1987	2012-11-25 21:30:00	15	\N	\N	\N
5705	250	1989	2012-11-25 22:30:00	\N	\N	7	\N
5707	259	1989	2012-11-25 22:30:00	15	\N	\N	\N
5717	250	1993	2012-11-26 00:30:00	\N	\N	6.2999999999999998	\N
5723	250	1995	2012-11-26 01:30:00	\N	\N	6.2999999999999998	\N
5725	259	1995	2012-11-26 01:30:00	13	\N	\N	\N
5729	250	1997	2012-11-26 02:30:00	\N	\N	6.2000000000000002	\N
5733	253	1998	2012-11-26 03:00:00	\N	\N	8.0999999999999996	\N
5739	253	2000	2012-11-26 04:00:00	\N	\N	8	\N
5747	250	2003	2012-11-26 05:30:00	\N	\N	6.0999999999999996	\N
5751	253	2004	2012-11-26 06:00:00	\N	\N	7.7000000000000002	\N
5763	253	2008	2012-11-26 08:00:00	\N	\N	7.5	\N
5770	259	2010	2012-11-26 09:00:00	1	\N	\N	\N
5775	253	2012	2012-11-26 10:00:00	\N	\N	7.5999999999999996	\N
5781	253	2014	2012-11-26 11:00:00	\N	\N	7.7999999999999998	\N
5787	253	2016	2012-11-26 12:00:00	\N	\N	8	\N
5790	253	2017	2012-11-26 12:30:00	\N	\N	8.0999999999999996	\N
5802	253	2021	2012-11-26 14:30:00	\N	\N	8.4000000000000004	\N
5838	253	2033	2012-11-26 20:30:00	\N	\N	9	\N
5841	253	2034	2012-11-26 21:00:00	\N	\N	8.9000000000000004	\N
5846	250	2036	2012-11-26 22:00:00	\N	\N	8.1999999999999993	\N
5850	253	2037	2012-11-26 22:30:00	\N	\N	8.5	\N
5853	253	2038	2012-11-26 23:00:00	\N	\N	8.4000000000000004	\N
5856	253	2039	2012-11-26 23:30:00	\N	\N	8.4000000000000004	\N
5861	250	2041	2012-11-27 00:30:00	\N	\N	8.0999999999999996	\N
5865	253	2042	2012-11-27 01:00:00	\N	\N	8.4000000000000004	\N
5866	259	2042	2012-11-27 01:00:00	0	\N	\N	\N
5870	250	2044	2012-11-27 02:00:00	\N	\N	7.9000000000000004	\N
5897	250	2053	2012-11-27 06:30:00	\N	\N	7	\N
5904	253	2055	2012-11-27 07:30:00	\N	\N	7.5999999999999996	\N
5907	253	2056	2012-11-27 08:00:00	\N	\N	7.5999999999999996	\N
5908	259	2056	2012-11-27 08:00:00	0	\N	\N	\N
5909	250	2057	2012-11-27 08:30:00	\N	\N	7.5	\N
5933	250	2065	2012-11-27 12:30:00	\N	\N	9.3000000000000007	\N
5388	253	1883	2012-11-23 17:30:00	\N	\N	11.6	\N
5411	250	1891	2012-11-23 21:30:00	\N	\N	8.4000000000000004	\N
5413	259	1891	2012-11-23 21:30:00	15	\N	\N	\N
5419	259	1893	2012-11-23 22:30:00	15	\N	\N	\N
5441	250	1901	2012-11-24 02:30:00	\N	\N	7	\N
5443	259	1901	2012-11-24 02:30:00	15	\N	\N	\N
5449	259	1903	2012-11-24 03:30:00	15	\N	\N	\N
5453	250	1905	2012-11-24 04:30:00	\N	\N	5.5	\N
5455	259	1905	2012-11-24 04:30:00	15	\N	\N	\N
5459	250	1907	2012-11-24 05:30:00	\N	\N	5.9000000000000004	\N
5461	259	1907	2012-11-24 05:30:00	14	\N	\N	\N
5465	250	1909	2012-11-24 06:30:00	\N	\N	5.9000000000000004	\N
5467	259	1909	2012-11-24 06:30:00	13	\N	\N	\N
5477	250	1913	2012-11-24 08:30:00	\N	\N	7.2999999999999998	\N
5483	250	1915	2012-11-24 09:30:00	\N	\N	8.9000000000000004	\N
5485	259	1915	2012-11-24 09:30:00	1	\N	\N	\N
5489	250	1917	2012-11-24 10:30:00	\N	\N	9.4000000000000004	\N
5493	253	1918	2012-11-24 11:00:00	\N	\N	9.8000000000000007	\N
5499	253	1920	2012-11-24 12:00:00	\N	\N	10	\N
5507	250	1923	2012-11-24 13:30:00	\N	\N	8.1999999999999993	\N
5511	253	1924	2012-11-24 14:00:00	\N	\N	10.199999999999999	\N
5523	253	1928	2012-11-24 16:00:00	\N	\N	9.9000000000000004	\N
5530	259	1930	2012-11-24 17:00:00	0	\N	\N	\N
5535	253	1932	2012-11-24 18:00:00	\N	\N	9.8000000000000007	\N
5541	253	1934	2012-11-24 19:00:00	\N	\N	9.5999999999999996	\N
5547	253	1936	2012-11-24 20:00:00	\N	\N	9.5	\N
5565	253	1942	2012-11-24 23:00:00	\N	\N	8.6999999999999993	\N
5576	250	1946	2012-11-25 01:00:00	\N	\N	1.3999999999999999	\N
5578	259	1946	2012-11-25 01:00:00	15	\N	\N	\N
5584	259	1948	2012-11-25 02:00:00	15	\N	\N	\N
5612	250	1958	2012-11-25 07:00:00	\N	\N	2.8999999999999999	\N
5618	250	1960	2012-11-25 08:00:00	\N	\N	3	\N
5620	259	1960	2012-11-25 08:00:00	14	\N	\N	\N
5632	259	1964	2012-11-25 10:00:00	0	\N	\N	\N
5648	250	1970	2012-11-25 13:00:00	\N	\N	9	\N
5666	250	1976	2012-11-25 16:00:00	\N	\N	7.7000000000000002	\N
5668	259	1976	2012-11-25 16:00:00	0	\N	\N	\N
5676	253	1979	2012-11-25 17:30:00	\N	\N	8.6999999999999993	\N
5684	250	1982	2012-11-25 19:00:00	\N	\N	7.5	\N
5686	259	1982	2012-11-25 19:00:00	2	\N	\N	\N
5690	250	1984	2012-11-25 20:00:00	\N	\N	7.5	\N
5702	250	1988	2012-11-25 22:00:00	\N	\N	7.0999999999999996	\N
5718	253	1993	2012-11-26 00:30:00	\N	\N	8.6999999999999993	\N
5724	253	1995	2012-11-26 01:30:00	\N	\N	8.5	\N
5730	253	1997	2012-11-26 02:30:00	\N	\N	8.0999999999999996	\N
5748	253	2003	2012-11-26 05:30:00	\N	\N	7.7000000000000002	\N
5771	250	2011	2012-11-26 09:30:00	\N	\N	9.8000000000000007	\N
5773	259	2011	2012-11-26 09:30:00	0	\N	\N	\N
5779	259	2013	2012-11-26 10:30:00	0	\N	\N	\N
5801	250	2021	2012-11-26 14:30:00	\N	\N	10.800000000000001	\N
5808	253	2023	2012-11-26 15:30:00	\N	\N	8.5	\N
5809	259	2023	2012-11-26 15:30:00	0	\N	\N	\N
5852	250	2038	2012-11-26 23:00:00	\N	\N	8.3000000000000007	\N
5858	250	2040	2012-11-27 00:00:00	\N	\N	8.1999999999999993	\N
5869	259	2043	2012-11-27 01:30:00	0	\N	\N	\N
5872	259	2044	2012-11-27 02:00:00	0	\N	\N	\N
5880	253	2047	2012-11-27 03:30:00	\N	\N	7.7999999999999998	\N
5881	259	2047	2012-11-27 03:30:00	0	\N	\N	\N
5885	250	2049	2012-11-27 04:30:00	\N	\N	8.3000000000000007	\N
5896	259	2052	2012-11-27 06:00:00	0	\N	\N	\N
5899	259	2053	2012-11-27 06:30:00	0	\N	\N	\N
5906	250	2056	2012-11-27 08:00:00	\N	\N	7.5	\N
5919	253	2060	2012-11-27 10:00:00	\N	\N	7.4000000000000004	\N
5920	259	2060	2012-11-27 10:00:00	0	\N	\N	\N
5939	250	2067	2012-11-27 13:30:00	\N	\N	8.8000000000000007	\N
5392	259	1884	2012-11-23 18:00:00	10	\N	\N	\N
5408	250	1890	2012-11-23 21:00:00	\N	\N	8.4000000000000004	\N
5426	250	1896	2012-11-24 00:00:00	\N	\N	7.5999999999999996	\N
5428	259	1896	2012-11-24 00:00:00	15	\N	\N	\N
5436	253	1899	2012-11-24 01:30:00	\N	\N	11.4	\N
5444	250	1902	2012-11-24 03:00:00	\N	\N	6.5999999999999996	\N
5446	259	1902	2012-11-24 03:00:00	15	\N	\N	\N
5450	250	1904	2012-11-24 04:00:00	\N	\N	5.5999999999999996	\N
5462	250	1908	2012-11-24 06:00:00	\N	\N	5.9000000000000004	\N
5478	253	1913	2012-11-24 08:30:00	\N	\N	9.5999999999999996	\N
5484	253	1915	2012-11-24 09:30:00	\N	\N	9.5	\N
5490	253	1917	2012-11-24 10:30:00	\N	\N	9.5	\N
5508	253	1923	2012-11-24 13:30:00	\N	\N	10.199999999999999	\N
5531	250	1931	2012-11-24 17:30:00	\N	\N	7.4000000000000004	\N
5533	259	1931	2012-11-24 17:30:00	0	\N	\N	\N
5539	259	1933	2012-11-24 18:30:00	1	\N	\N	\N
5561	250	1941	2012-11-24 22:30:00	\N	\N	3	\N
5563	259	1941	2012-11-24 22:30:00	13	\N	\N	\N
5569	259	1943	2012-11-24 23:30:00	15	\N	\N	\N
5573	250	1945	2012-11-25 00:30:00	\N	\N	1.5	\N
5575	259	1945	2012-11-25 00:30:00	15	\N	\N	\N
5579	250	1947	2012-11-25 01:30:00	\N	\N	1.5	\N
5581	259	1947	2012-11-25 01:30:00	15	\N	\N	\N
5585	250	1949	2012-11-25 02:30:00	\N	\N	2.5	\N
5587	259	1949	2012-11-25 02:30:00	15	\N	\N	\N
5597	250	1953	2012-11-25 04:30:00	\N	\N	3.2000000000000002	\N
5603	250	1955	2012-11-25 05:30:00	\N	\N	3.2999999999999998	\N
5605	259	1955	2012-11-25 05:30:00	15	\N	\N	\N
5609	250	1957	2012-11-25 06:30:00	\N	\N	3.2000000000000002	\N
5613	253	1958	2012-11-25 07:00:00	\N	\N	7	\N
5619	253	1960	2012-11-25 08:00:00	\N	\N	6.7999999999999998	\N
5627	250	1963	2012-11-25 09:30:00	\N	\N	4.0999999999999996	\N
5631	253	1964	2012-11-25 10:00:00	\N	\N	6.5999999999999996	\N
5643	253	1968	2012-11-25 12:00:00	\N	\N	7.7000000000000002	\N
5650	259	1970	2012-11-25 13:00:00	0	\N	\N	\N
5655	253	1972	2012-11-25 14:00:00	\N	\N	8.0999999999999996	\N
5661	253	1974	2012-11-25 15:00:00	\N	\N	8.3000000000000007	\N
5667	253	1976	2012-11-25 16:00:00	\N	\N	8.5	\N
5685	253	1982	2012-11-25 19:00:00	\N	\N	9	\N
5696	250	1986	2012-11-25 21:00:00	\N	\N	7.4000000000000004	\N
5698	259	1986	2012-11-25 21:00:00	15	\N	\N	\N
5704	259	1988	2012-11-25 22:00:00	15	\N	\N	\N
5732	250	1998	2012-11-26 03:00:00	\N	\N	6.0999999999999996	\N
5738	250	2000	2012-11-26 04:00:00	\N	\N	5.9000000000000004	\N
5740	259	2000	2012-11-26 04:00:00	10	\N	\N	\N
5752	259	2004	2012-11-26 06:00:00	8	\N	\N	\N
5768	250	2010	2012-11-26 09:00:00	\N	\N	8	\N
5786	250	2016	2012-11-26 12:00:00	\N	\N	9.4000000000000004	\N
5788	259	2016	2012-11-26 12:00:00	0	\N	\N	\N
5791	259	2017	2012-11-26 12:30:00	0	\N	\N	\N
5795	250	2019	2012-11-26 13:30:00	\N	\N	10.300000000000001	\N
5803	259	2021	2012-11-26 14:30:00	0	\N	\N	\N
5816	250	2026	2012-11-26 17:00:00	\N	\N	9.6999999999999993	\N
5826	253	2029	2012-11-26 18:30:00	\N	\N	9.1999999999999993	\N
5829	253	2030	2012-11-26 19:00:00	\N	\N	9.0999999999999996	\N
5837	250	2033	2012-11-26 20:30:00	\N	\N	8.1999999999999993	\N
5851	259	2037	2012-11-26 22:30:00	0	\N	\N	\N
5873	250	2045	2012-11-27 02:30:00	\N	\N	7.7999999999999998	\N
5876	250	2046	2012-11-27 03:00:00	\N	\N	7.7000000000000002	\N
5883	253	2048	2012-11-27 04:00:00	\N	\N	7.7999999999999998	\N
5884	259	2048	2012-11-27 04:00:00	0	\N	\N	\N
5901	253	2054	2012-11-27 07:00:00	\N	\N	7.5999999999999996	\N
5902	259	2054	2012-11-27 07:00:00	0	\N	\N	\N
5903	250	2055	2012-11-27 07:30:00	\N	\N	7.4000000000000004	\N
5915	250	2059	2012-11-27 09:30:00	\N	\N	7.5	\N
5394	253	1885	2012-11-23 18:30:00	\N	\N	11.9	\N
5400	253	1887	2012-11-23 19:30:00	\N	\N	12.1	\N
5406	253	1889	2012-11-23 20:30:00	\N	\N	12.300000000000001	\N
5412	253	1891	2012-11-23 21:30:00	\N	\N	12.199999999999999	\N
5442	253	1901	2012-11-24 02:30:00	\N	\N	11.300000000000001	\N
5469	253	1910	2012-11-24 07:00:00	\N	\N	9.9000000000000004	\N
5491	259	1917	2012-11-24 10:30:00	0	\N	\N	\N
5495	250	1919	2012-11-24 11:30:00	\N	\N	9.4000000000000004	\N
5497	259	1919	2012-11-24 11:30:00	0	\N	\N	\N
5517	253	1926	2012-11-24 15:00:00	\N	\N	10	\N
5534	250	1932	2012-11-24 18:00:00	\N	\N	6.2999999999999998	\N
5536	259	1932	2012-11-24 18:00:00	1	\N	\N	\N
5540	250	1934	2012-11-24 19:00:00	\N	\N	5	\N
5542	259	1934	2012-11-24 19:00:00	1	\N	\N	\N
5554	259	1938	2012-11-24 21:00:00	2	\N	\N	\N
5574	253	1945	2012-11-25 00:30:00	\N	\N	8.1999999999999993	\N
5580	253	1947	2012-11-25 01:30:00	\N	\N	8.0999999999999996	\N
5586	253	1949	2012-11-25 02:30:00	\N	\N	7.5999999999999996	\N
5592	253	1951	2012-11-25 03:30:00	\N	\N	7.4000000000000004	\N
5622	253	1961	2012-11-25 08:30:00	\N	\N	6.7000000000000002	\N
5649	253	1970	2012-11-25 13:00:00	\N	\N	8.1999999999999993	\N
5671	259	1977	2012-11-25 16:30:00	0	\N	\N	\N
5675	250	1979	2012-11-25 17:30:00	\N	\N	7.5999999999999996	\N
5677	259	1979	2012-11-25 17:30:00	0	\N	\N	\N
5697	253	1986	2012-11-25 21:00:00	\N	\N	9.1999999999999993	\N
5714	250	1992	2012-11-26 00:00:00	\N	\N	6.7000000000000002	\N
5716	259	1992	2012-11-26 00:00:00	15	\N	\N	\N
5720	250	1994	2012-11-26 01:00:00	\N	\N	6.2999999999999998	\N
5722	259	1994	2012-11-26 01:00:00	14	\N	\N	\N
5734	259	1998	2012-11-26 03:00:00	10	\N	\N	\N
5754	253	2005	2012-11-26 06:30:00	\N	\N	7.7000000000000002	\N
5760	253	2007	2012-11-26 07:30:00	\N	\N	7.5999999999999996	\N
5766	253	2009	2012-11-26 08:30:00	\N	\N	7.5	\N
5772	253	2011	2012-11-26 09:30:00	\N	\N	7.2999999999999998	\N
5799	253	2020	2012-11-26 14:00:00	\N	\N	8.4000000000000004	\N
5800	259	2020	2012-11-26 14:00:00	0	\N	\N	\N
5815	259	2025	2012-11-26 16:30:00	0	\N	\N	\N
5822	250	2028	2012-11-26 18:00:00	\N	\N	9.3000000000000007	\N
5835	253	2032	2012-11-26 20:00:00	\N	\N	9	\N
5867	250	2043	2012-11-27 01:30:00	\N	\N	8.0999999999999996	\N
5879	250	2047	2012-11-27 03:30:00	\N	\N	8.3000000000000007	\N
5918	250	2060	2012-11-27 10:00:00	\N	\N	8.5	\N
5922	253	2061	2012-11-27 10:30:00	\N	\N	7.4000000000000004	\N
5923	259	2061	2012-11-27 10:30:00	0	\N	\N	\N
5924	250	2062	2012-11-27 11:00:00	\N	\N	9	\N
5928	253	2063	2012-11-27 11:30:00	\N	\N	7.4000000000000004	\N
5931	253	2064	2012-11-27 12:00:00	\N	\N	7.5999999999999996	\N
5940	253	2067	2012-11-27 13:30:00	\N	\N	7.5	\N
5397	253	1886	2012-11-23 19:00:00	\N	\N	12	\N
5414	250	1892	2012-11-23 22:00:00	\N	\N	8.3000000000000007	\N
5416	259	1892	2012-11-23 22:00:00	15	\N	\N	\N
5420	250	1894	2012-11-23 23:00:00	\N	\N	8.0999999999999996	\N
5422	259	1894	2012-11-23 23:00:00	15	\N	\N	\N
5434	259	1898	2012-11-24 01:00:00	15	\N	\N	\N
5454	253	1905	2012-11-24 04:30:00	\N	\N	10.5	\N
5460	253	1907	2012-11-24 05:30:00	\N	\N	10.4	\N
5466	253	1909	2012-11-24 06:30:00	\N	\N	10.300000000000001	\N
5472	253	1911	2012-11-24 07:30:00	\N	\N	9.8000000000000007	\N
5502	253	1921	2012-11-24 12:30:00	\N	\N	10.1	\N
5529	253	1930	2012-11-24 17:00:00	\N	\N	9.9000000000000004	\N
5551	259	1937	2012-11-24 20:30:00	2	\N	\N	\N
5555	250	1939	2012-11-24 21:30:00	\N	\N	3.1000000000000001	\N
5557	259	1939	2012-11-24 21:30:00	2	\N	\N	\N
5577	253	1946	2012-11-25 01:00:00	\N	\N	8.0999999999999996	\N
5594	250	1952	2012-11-25 04:00:00	\N	\N	2.8999999999999999	\N
5596	259	1952	2012-11-25 04:00:00	15	\N	\N	\N
5600	250	1954	2012-11-25 05:00:00	\N	\N	3.1000000000000001	\N
5602	259	1954	2012-11-25 05:00:00	15	\N	\N	\N
5614	259	1958	2012-11-25 07:00:00	15	\N	\N	\N
5634	253	1965	2012-11-25 10:30:00	\N	\N	7.2000000000000002	\N
5640	253	1967	2012-11-25 11:30:00	\N	\N	7.5999999999999996	\N
5646	253	1969	2012-11-25 12:30:00	\N	\N	7.7999999999999998	\N
5652	253	1971	2012-11-25 13:30:00	\N	\N	8.0999999999999996	\N
5682	253	1981	2012-11-25 18:30:00	\N	\N	8.9000000000000004	\N
5709	253	1990	2012-11-25 23:00:00	\N	\N	9	\N
5731	259	1997	2012-11-26 02:30:00	11	\N	\N	\N
5735	250	1999	2012-11-26 03:30:00	\N	\N	6	\N
5737	259	1999	2012-11-26 03:30:00	10	\N	\N	\N
5757	253	2006	2012-11-26 07:00:00	\N	\N	7.7000000000000002	\N
5774	250	2012	2012-11-26 10:00:00	\N	\N	9.1999999999999993	\N
5776	259	2012	2012-11-26 10:00:00	0	\N	\N	\N
5780	250	2014	2012-11-26 11:00:00	\N	\N	9.0999999999999996	\N
5782	259	2014	2012-11-26 11:00:00	0	\N	\N	\N
5811	253	2024	2012-11-26 16:00:00	\N	\N	8.8000000000000007	\N
5814	253	2025	2012-11-26 16:30:00	\N	\N	8.8000000000000007	\N
5817	253	2026	2012-11-26 17:00:00	\N	\N	9	\N
5818	259	2026	2012-11-26 17:00:00	0	\N	\N	\N
5819	250	2027	2012-11-26 17:30:00	\N	\N	9.5	\N
5827	259	2029	2012-11-26 18:30:00	0	\N	\N	\N
5830	259	2030	2012-11-26 19:00:00	0	\N	\N	\N
5864	250	2042	2012-11-27 01:00:00	\N	\N	8.0999999999999996	\N
5874	253	2045	2012-11-27 02:30:00	\N	\N	7.9000000000000004	\N
5875	259	2045	2012-11-27 02:30:00	0	\N	\N	\N
5888	250	2050	2012-11-27 05:00:00	\N	\N	7.9000000000000004	\N
5891	250	2051	2012-11-27 05:30:00	\N	\N	7.5999999999999996	\N
5936	250	2066	2012-11-27 13:00:00	\N	\N	9.0999999999999996	\N
5942	250	2068	2012-11-27 14:00:00	\N	\N	8.4000000000000004	\N
5943	253	2068	2012-11-27 14:00:00	\N	\N	7.5999999999999996	\N
5944	259	2068	2012-11-27 14:00:00	0	\N	\N	\N
5945	250	2069	2012-11-27 14:30:00	\N	\N	8.0999999999999996	\N
5946	253	2069	2012-11-27 14:30:00	\N	\N	7.5999999999999996	\N
5947	259	2069	2012-11-27 14:30:00	0	\N	\N	\N
5948	250	2070	2012-11-27 15:00:00	\N	\N	8	\N
5949	253	2070	2012-11-27 15:00:00	\N	\N	7.5	\N
5950	259	2070	2012-11-27 15:00:00	0	\N	\N	\N
5951	250	2071	2012-11-27 15:30:00	\N	\N	8.1999999999999993	\N
5952	253	2071	2012-11-27 15:30:00	\N	\N	7.5	\N
5953	259	2071	2012-11-27 15:30:00	0	\N	\N	\N
5954	250	2072	2012-11-27 16:00:00	\N	\N	8.1999999999999993	\N
5955	253	2072	2012-11-27 16:00:00	\N	\N	7.5	\N
5956	259	2072	2012-11-27 16:00:00	0	\N	\N	\N
5957	250	2073	2012-11-27 16:30:00	\N	\N	8	\N
5958	253	2073	2012-11-27 16:30:00	\N	\N	7.2000000000000002	\N
5959	259	2073	2012-11-27 16:30:00	0	\N	\N	\N
5960	250	2074	2012-11-27 17:00:00	\N	\N	7.7999999999999998	\N
5961	253	2074	2012-11-27 17:00:00	\N	\N	7.0999999999999996	\N
5962	259	2074	2012-11-27 17:00:00	0	\N	\N	\N
5963	250	2075	2012-11-27 17:30:00	\N	\N	7.7999999999999998	\N
5964	253	2075	2012-11-27 17:30:00	\N	\N	7.0999999999999996	\N
5965	259	2075	2012-11-27 17:30:00	0	\N	\N	\N
5966	250	2076	2012-11-27 18:00:00	\N	\N	7.2000000000000002	\N
5967	253	2076	2012-11-27 18:00:00	\N	\N	7.0999999999999996	\N
5968	259	2076	2012-11-27 18:00:00	0	\N	\N	\N
5969	250	2077	2012-11-27 18:30:00	\N	\N	7	\N
5970	253	2077	2012-11-27 18:30:00	\N	\N	6.7999999999999998	\N
5971	259	2077	2012-11-27 18:30:00	0	\N	\N	\N
5972	250	2078	2012-11-27 19:00:00	\N	\N	7.2999999999999998	\N
5973	253	2078	2012-11-27 19:00:00	\N	\N	7.0999999999999996	\N
5974	259	2078	2012-11-27 19:00:00	0	\N	\N	\N
5975	250	2079	2012-11-27 19:30:00	\N	\N	7.2999999999999998	\N
5976	253	2079	2012-11-27 19:30:00	\N	\N	7.0999999999999996	\N
5977	259	2079	2012-11-27 19:30:00	0	\N	\N	\N
5978	250	2080	2012-11-27 20:00:00	\N	\N	7.2999999999999998	\N
5979	253	2080	2012-11-27 20:00:00	\N	\N	7.4000000000000004	\N
5980	259	2080	2012-11-27 20:00:00	0	\N	\N	\N
5981	250	2081	2012-11-27 20:30:00	\N	\N	7.5	\N
5982	253	2081	2012-11-27 20:30:00	\N	\N	7.4000000000000004	\N
5983	259	2081	2012-11-27 20:30:00	0	\N	\N	\N
5984	250	2082	2012-11-27 21:00:00	\N	\N	7.5999999999999996	\N
5985	253	2082	2012-11-27 21:00:00	\N	\N	7.4000000000000004	\N
5986	259	2082	2012-11-27 21:00:00	0	\N	\N	\N
5987	250	2083	2012-11-27 21:30:00	\N	\N	7.5	\N
5988	253	2083	2012-11-27 21:30:00	\N	\N	7.4000000000000004	\N
5989	259	2083	2012-11-27 21:30:00	0	\N	\N	\N
5990	250	2084	2012-11-27 22:00:00	\N	\N	7.4000000000000004	\N
5991	253	2084	2012-11-27 22:00:00	\N	\N	7.4000000000000004	\N
5992	259	2084	2012-11-27 22:00:00	0	\N	\N	\N
5993	250	2085	2012-11-27 22:30:00	\N	\N	7.5	\N
5994	253	2085	2012-11-27 22:30:00	\N	\N	7.4000000000000004	\N
5995	259	2085	2012-11-27 22:30:00	0	\N	\N	\N
5996	250	2086	2012-11-27 23:00:00	\N	\N	7.5999999999999996	\N
5997	253	2086	2012-11-27 23:00:00	\N	\N	7.4000000000000004	\N
5998	259	2086	2012-11-27 23:00:00	0	\N	\N	\N
5999	250	2087	2012-11-27 23:30:00	\N	\N	7.5999999999999996	\N
6000	253	2087	2012-11-27 23:30:00	\N	\N	7.4000000000000004	\N
6001	259	2087	2012-11-27 23:30:00	0	\N	\N	\N
6002	250	2088	2012-11-28 00:00:00	\N	\N	7.5999999999999996	\N
6003	253	2088	2012-11-28 00:00:00	\N	\N	7.4000000000000004	\N
6004	259	2088	2012-11-28 00:00:00	0	\N	\N	\N
6005	250	2089	2012-11-28 00:30:00	\N	\N	7.2999999999999998	\N
6006	253	2089	2012-11-28 00:30:00	\N	\N	7.7000000000000002	\N
6007	259	2089	2012-11-28 00:30:00	0	\N	\N	\N
6008	250	2090	2012-11-28 01:00:00	\N	\N	7.0999999999999996	\N
6009	253	2090	2012-11-28 01:00:00	\N	\N	7.7000000000000002	\N
6010	259	2090	2012-11-28 01:00:00	1	\N	\N	\N
6011	250	2091	2012-11-28 01:30:00	\N	\N	7.0999999999999996	\N
6012	253	2091	2012-11-28 01:30:00	\N	\N	7.5999999999999996	\N
6013	259	2091	2012-11-28 01:30:00	1	\N	\N	\N
6014	250	2092	2012-11-28 02:00:00	\N	\N	7.4000000000000004	\N
6047	250	2103	2012-11-28 07:30:00	\N	\N	6.5999999999999996	\N
6061	259	2107	2012-11-28 09:30:00	0	\N	\N	\N
6064	259	2108	2012-11-28 10:00:00	0	\N	\N	\N
6065	250	2109	2012-11-28 10:30:00	\N	\N	9.5	\N
6098	250	2120	2012-11-28 16:00:00	\N	\N	9.8000000000000007	\N
6104	250	2122	2012-11-28 17:00:00	\N	\N	10	\N
6117	253	2126	2012-11-28 19:00:00	\N	\N	9.9000000000000004	\N
6152	250	2138	2012-11-29 01:00:00	\N	\N	10.1	\N
6166	259	2142	2012-11-29 03:00:00	11	\N	\N	\N
6169	259	2143	2012-11-29 03:30:00	13	\N	\N	\N
6170	250	2144	2012-11-29 04:00:00	\N	\N	6.4000000000000004	\N
6181	259	2147	2012-11-29 05:30:00	14	\N	\N	\N
6184	259	2148	2012-11-29 06:00:00	14	\N	\N	\N
6185	250	2149	2012-11-29 06:30:00	\N	\N	4.9000000000000004	\N
6212	250	2158	2012-11-29 11:00:00	\N	\N	9.1999999999999993	\N
6230	250	2164	2012-11-29 14:00:00	\N	\N	8.8000000000000007	\N
6242	250	2168	2012-11-29 16:00:00	\N	\N	8.9000000000000004	\N
6255	253	2172	2012-11-29 18:00:00	\N	\N	9.0999999999999996	\N
6256	259	2172	2012-11-29 18:00:00	14	\N	\N	\N
6257	250	2173	2012-11-29 18:30:00	\N	\N	8.1999999999999993	\N
6264	253	2175	2012-11-29 19:30:00	\N	\N	9	\N
6015	253	2092	2012-11-28 02:00:00	\N	\N	7.5999999999999996	\N
6020	250	2094	2012-11-28 03:00:00	\N	\N	7.2999999999999998	\N
6049	259	2103	2012-11-28 07:30:00	1	\N	\N	\N
6052	259	2104	2012-11-28 08:00:00	0	\N	\N	\N
6093	253	2118	2012-11-28 15:00:00	\N	\N	9.0999999999999996	\N
6096	253	2119	2012-11-28 15:30:00	\N	\N	9.3000000000000007	\N
6110	250	2124	2012-11-28 18:00:00	\N	\N	9.9000000000000004	\N
6113	250	2125	2012-11-28 18:30:00	\N	\N	9.8000000000000007	\N
6129	253	2130	2012-11-28 21:00:00	\N	\N	9.6999999999999993	\N
6134	250	2132	2012-11-28 22:00:00	\N	\N	9.5999999999999996	\N
6138	253	2133	2012-11-28 22:30:00	\N	\N	9.5	\N
6143	250	2135	2012-11-28 23:30:00	\N	\N	10.4	\N
6153	253	2138	2012-11-29 01:00:00	\N	\N	9.6999999999999993	\N
6174	253	2145	2012-11-29 04:30:00	\N	\N	9.0999999999999996	\N
6175	259	2145	2012-11-29 04:30:00	14	\N	\N	\N
6179	250	2147	2012-11-29 05:30:00	\N	\N	5.2000000000000002	\N
6187	259	2149	2012-11-29 06:30:00	14	\N	\N	\N
6190	259	2150	2012-11-29 07:00:00	14	\N	\N	\N
6191	250	2151	2012-11-29 07:30:00	\N	\N	5.5999999999999996	\N
6195	253	2152	2012-11-29 08:00:00	\N	\N	8.0999999999999996	\N
6196	259	2152	2012-11-29 08:00:00	13	\N	\N	\N
6197	250	2153	2012-11-29 08:30:00	\N	\N	8.4000000000000004	\N
6201	253	2154	2012-11-29 09:00:00	\N	\N	8.1999999999999993	\N
6202	259	2154	2012-11-29 09:00:00	0	\N	\N	\N
6210	253	2157	2012-11-29 10:30:00	\N	\N	7.7000000000000002	\N
6214	259	2158	2012-11-29 11:00:00	0	\N	\N	\N
6221	250	2161	2012-11-29 12:30:00	\N	\N	8.5999999999999996	\N
6237	253	2166	2012-11-29 15:00:00	\N	\N	8.3000000000000007	\N
6238	259	2166	2012-11-29 15:00:00	1	\N	\N	\N
6253	259	2171	2012-11-29 17:30:00	14	\N	\N	\N
6266	250	2176	2012-11-29 20:00:00	\N	\N	7.5999999999999996	\N
6016	259	2092	2012-11-28 02:00:00	1	\N	\N	\N
6029	250	2097	2012-11-28 04:30:00	\N	\N	7.4000000000000004	\N
6032	250	2098	2012-11-28 05:00:00	\N	\N	7.2999999999999998	\N
6056	250	2106	2012-11-28 09:00:00	\N	\N	8	\N
6063	253	2108	2012-11-28 10:00:00	\N	\N	7.4000000000000004	\N
6066	253	2109	2012-11-28 10:30:00	\N	\N	7.4000000000000004	\N
6077	250	2113	2012-11-28 12:30:00	\N	\N	10.6	\N
6097	259	2119	2012-11-28 15:30:00	15	\N	\N	\N
6099	253	2120	2012-11-28 16:00:00	\N	\N	9.5	\N
6100	259	2120	2012-11-28 16:00:00	13	\N	\N	\N
6118	259	2126	2012-11-28 19:00:00	3	\N	\N	\N
6139	259	2133	2012-11-28 22:30:00	7	\N	\N	\N
6150	253	2137	2012-11-29 00:30:00	\N	\N	9.6999999999999993	\N
6151	259	2137	2012-11-29 00:30:00	8	\N	\N	\N
6154	259	2138	2012-11-29 01:00:00	3	\N	\N	\N
6161	250	2141	2012-11-29 02:30:00	\N	\N	8.6999999999999993	\N
6177	253	2146	2012-11-29 05:00:00	\N	\N	8.6999999999999993	\N
6178	259	2146	2012-11-29 05:00:00	14	\N	\N	\N
6182	250	2148	2012-11-29 06:00:00	\N	\N	4.7000000000000002	\N
6192	253	2151	2012-11-29 07:30:00	\N	\N	8.3000000000000007	\N
6216	253	2159	2012-11-29 11:30:00	\N	\N	8	\N
6217	259	2159	2012-11-29 11:30:00	0	\N	\N	\N
6227	250	2163	2012-11-29 13:30:00	\N	\N	8.6999999999999993	\N
6248	250	2170	2012-11-29 17:00:00	\N	\N	8.8000000000000007	\N
6265	259	2175	2012-11-29 19:30:00	13	\N	\N	\N
6017	250	2093	2012-11-28 02:30:00	\N	\N	7.2999999999999998	\N
6027	253	2096	2012-11-28 04:00:00	\N	\N	7.5999999999999996	\N
6028	259	2096	2012-11-28 04:00:00	0	\N	\N	\N
6031	259	2097	2012-11-28 04:30:00	0	\N	\N	\N
6035	250	2099	2012-11-28 05:30:00	\N	\N	7.2000000000000002	\N
6045	253	2102	2012-11-28 07:00:00	\N	\N	7.5	\N
6046	259	2102	2012-11-28 07:00:00	2	\N	\N	\N
6050	250	2104	2012-11-28 08:00:00	\N	\N	7.0999999999999996	\N
6071	250	2111	2012-11-28 11:30:00	\N	\N	10.800000000000001	\N
6083	250	2115	2012-11-28 13:30:00	\N	\N	9.6999999999999993	\N
6105	253	2122	2012-11-28 17:00:00	\N	\N	9.8000000000000007	\N
6106	259	2122	2012-11-28 17:00:00	9	\N	\N	\N
6107	250	2123	2012-11-28 17:30:00	\N	\N	9.9000000000000004	\N
6112	259	2124	2012-11-28 18:00:00	7	\N	\N	\N
6120	253	2127	2012-11-28 19:30:00	\N	\N	9.9000000000000004	\N
6121	259	2127	2012-11-28 19:30:00	3	\N	\N	\N
6122	250	2128	2012-11-28 20:00:00	\N	\N	9.4000000000000004	\N
6126	253	2129	2012-11-28 20:30:00	\N	\N	9.8000000000000007	\N
6127	259	2129	2012-11-28 20:30:00	3	\N	\N	\N
6130	259	2130	2012-11-28 21:00:00	12	\N	\N	\N
6132	253	2131	2012-11-28 21:30:00	\N	\N	9.5999999999999996	\N
6133	259	2131	2012-11-28 21:30:00	11	\N	\N	\N
6147	253	2136	2012-11-29 00:00:00	\N	\N	9.8000000000000007	\N
6148	259	2136	2012-11-29 00:00:00	11	\N	\N	\N
6149	250	2137	2012-11-29 00:30:00	\N	\N	10.300000000000001	\N
6162	253	2141	2012-11-29 02:30:00	\N	\N	9.3000000000000007	\N
6163	259	2141	2012-11-29 02:30:00	7	\N	\N	\N
6164	250	2142	2012-11-29 03:00:00	\N	\N	8.3000000000000007	\N
6168	253	2143	2012-11-29 03:30:00	\N	\N	9.1999999999999993	\N
6171	253	2144	2012-11-29 04:00:00	\N	\N	9.1999999999999993	\N
6189	253	2150	2012-11-29 07:00:00	\N	\N	8.4000000000000004	\N
6194	250	2152	2012-11-29 08:00:00	\N	\N	6.9000000000000004	\N
6204	253	2155	2012-11-29 09:30:00	\N	\N	8.1999999999999993	\N
6205	259	2155	2012-11-29 09:30:00	0	\N	\N	\N
6211	259	2157	2012-11-29 10:30:00	0	\N	\N	\N
6215	250	2159	2012-11-29 11:30:00	\N	\N	9.8000000000000007	\N
6233	250	2165	2012-11-29 14:30:00	\N	\N	8.6999999999999993	\N
6244	259	2168	2012-11-29 16:00:00	15	\N	\N	\N
6251	250	2171	2012-11-29 17:30:00	\N	\N	8.5	\N
6018	253	2093	2012-11-28 02:30:00	\N	\N	7.5999999999999996	\N
6024	253	2095	2012-11-28 03:30:00	\N	\N	7.5999999999999996	\N
6025	259	2095	2012-11-28 03:30:00	1	\N	\N	\N
6044	250	2102	2012-11-28 07:00:00	\N	\N	6.9000000000000004	\N
6060	253	2107	2012-11-28 09:30:00	\N	\N	7.4000000000000004	\N
6068	250	2110	2012-11-28 11:00:00	\N	\N	9.6999999999999993	\N
6072	253	2111	2012-11-28 11:30:00	\N	\N	7.7999999999999998	\N
6073	259	2111	2012-11-28 11:30:00	0	\N	\N	\N
6074	250	2112	2012-11-28 12:00:00	\N	\N	10.6	\N
6082	259	2114	2012-11-28 13:00:00	0	\N	\N	\N
6086	250	2116	2012-11-28 14:00:00	\N	\N	9.6999999999999993	\N
6101	250	2121	2012-11-28 16:30:00	\N	\N	9.6999999999999993	\N
6108	253	2123	2012-11-28 17:30:00	\N	\N	10	\N
6109	259	2123	2012-11-28 17:30:00	10	\N	\N	\N
6114	253	2125	2012-11-28 18:30:00	\N	\N	9.9000000000000004	\N
6115	259	2125	2012-11-28 18:30:00	4	\N	\N	\N
6116	250	2126	2012-11-28 19:00:00	\N	\N	9.6999999999999993	\N
6123	253	2128	2012-11-28 20:00:00	\N	\N	9.8000000000000007	\N
6124	259	2128	2012-11-28 20:00:00	3	\N	\N	\N
6131	250	2131	2012-11-28 21:30:00	\N	\N	9.5	\N
6141	253	2134	2012-11-28 23:00:00	\N	\N	9.8000000000000007	\N
6142	259	2134	2012-11-28 23:00:00	8	\N	\N	\N
6146	250	2136	2012-11-29 00:00:00	\N	\N	10.199999999999999	\N
6173	250	2145	2012-11-29 04:30:00	\N	\N	6	\N
6199	259	2153	2012-11-29 08:30:00	6	\N	\N	\N
6206	250	2156	2012-11-29 10:00:00	\N	\N	9.3000000000000007	\N
6234	253	2165	2012-11-29 14:30:00	\N	\N	8.1999999999999993	\N
6235	259	2165	2012-11-29 14:30:00	0	\N	\N	\N
6252	253	2171	2012-11-29 17:30:00	\N	\N	9	\N
6267	253	2176	2012-11-29 20:00:00	\N	\N	9	\N
6268	259	2176	2012-11-29 20:00:00	13	\N	\N	\N
6019	259	2093	2012-11-28 02:30:00	2	\N	\N	\N
6021	253	2094	2012-11-28 03:00:00	\N	\N	7.5999999999999996	\N
6022	259	2094	2012-11-28 03:00:00	2	\N	\N	\N
6030	253	2097	2012-11-28 04:30:00	\N	\N	7.5999999999999996	\N
6033	253	2098	2012-11-28 05:00:00	\N	\N	7.5999999999999996	\N
6034	259	2098	2012-11-28 05:00:00	4	\N	\N	\N
6038	250	2100	2012-11-28 06:00:00	\N	\N	7	\N
6042	253	2101	2012-11-28 06:30:00	\N	\N	7.5999999999999996	\N
6043	259	2101	2012-11-28 06:30:00	0	\N	\N	\N
6057	253	2106	2012-11-28 09:00:00	\N	\N	7.4000000000000004	\N
6058	259	2106	2012-11-28 09:00:00	0	\N	\N	\N
6076	259	2112	2012-11-28 12:00:00	0	\N	\N	\N
6079	259	2113	2012-11-28 12:30:00	0	\N	\N	\N
6080	250	2114	2012-11-28 13:00:00	\N	\N	10.699999999999999	\N
6084	253	2115	2012-11-28 13:30:00	\N	\N	8.5999999999999996	\N
6087	253	2116	2012-11-28 14:00:00	\N	\N	8.8000000000000007	\N
6088	259	2116	2012-11-28 14:00:00	0	\N	\N	\N
6089	250	2117	2012-11-28 14:30:00	\N	\N	9.6999999999999993	\N
6102	253	2121	2012-11-28 16:30:00	\N	\N	9.6999999999999993	\N
6156	253	2139	2012-11-29 01:30:00	\N	\N	9.6999999999999993	\N
6157	259	2139	2012-11-29 01:30:00	3	\N	\N	\N
6160	259	2140	2012-11-29 02:00:00	3	\N	\N	\N
6225	253	2162	2012-11-29 13:00:00	\N	\N	8.3000000000000007	\N
6226	259	2162	2012-11-29 13:00:00	0	\N	\N	\N
6236	250	2166	2012-11-29 15:00:00	\N	\N	9.4000000000000004	\N
6243	253	2168	2012-11-29 16:00:00	\N	\N	8.3000000000000007	\N
6246	253	2169	2012-11-29 16:30:00	\N	\N	8.6999999999999993	\N
6247	259	2169	2012-11-29 16:30:00	14	\N	\N	\N
6254	250	2172	2012-11-29 18:00:00	\N	\N	8.5999999999999996	\N
6260	250	2174	2012-11-29 19:00:00	\N	\N	7.9000000000000004	\N
6023	250	2095	2012-11-28 03:30:00	\N	\N	7.5999999999999996	\N
6026	250	2096	2012-11-28 04:00:00	\N	\N	7.4000000000000004	\N
6041	250	2101	2012-11-28 06:30:00	\N	\N	7.0999999999999996	\N
6069	253	2110	2012-11-28 11:00:00	\N	\N	7.7000000000000002	\N
6092	250	2118	2012-11-28 15:00:00	\N	\N	9.6999999999999993	\N
6137	250	2133	2012-11-28 22:30:00	\N	\N	10.9	\N
6144	253	2135	2012-11-28 23:30:00	\N	\N	9.8000000000000007	\N
6145	259	2135	2012-11-28 23:30:00	9	\N	\N	\N
6155	250	2139	2012-11-29 01:30:00	\N	\N	9.5999999999999996	\N
6158	250	2140	2012-11-29 02:00:00	\N	\N	9.0999999999999996	\N
6165	253	2142	2012-11-29 03:00:00	\N	\N	9.4000000000000004	\N
6176	250	2146	2012-11-29 05:00:00	\N	\N	5	\N
6183	253	2148	2012-11-29 06:00:00	\N	\N	8.5	\N
6186	253	2149	2012-11-29 06:30:00	\N	\N	8.5	\N
6193	259	2151	2012-11-29 07:30:00	14	\N	\N	\N
6200	250	2154	2012-11-29 09:00:00	\N	\N	9	\N
6219	253	2160	2012-11-29 12:00:00	\N	\N	8	\N
6220	259	2160	2012-11-29 12:00:00	0	\N	\N	\N
6229	259	2163	2012-11-29 13:30:00	0	\N	\N	\N
6232	259	2164	2012-11-29 14:00:00	0	\N	\N	\N
6249	253	2170	2012-11-29 17:00:00	\N	\N	8.9000000000000004	\N
6036	253	2099	2012-11-28 05:30:00	\N	\N	7.5999999999999996	\N
6039	253	2100	2012-11-28 06:00:00	\N	\N	7.5999999999999996	\N
6040	259	2100	2012-11-28 06:00:00	0	\N	\N	\N
6048	253	2103	2012-11-28 07:30:00	\N	\N	7.5	\N
6051	253	2104	2012-11-28 08:00:00	\N	\N	7.5	\N
6054	253	2105	2012-11-28 08:30:00	\N	\N	7.4000000000000004	\N
6055	259	2105	2012-11-28 08:30:00	0	\N	\N	\N
6059	250	2107	2012-11-28 09:30:00	\N	\N	8.3000000000000007	\N
6067	259	2109	2012-11-28 10:30:00	0	\N	\N	\N
6070	259	2110	2012-11-28 11:00:00	0	\N	\N	\N
6078	253	2113	2012-11-28 12:30:00	\N	\N	8.0999999999999996	\N
6081	253	2114	2012-11-28 13:00:00	\N	\N	8.5999999999999996	\N
6085	259	2115	2012-11-28 13:30:00	0	\N	\N	\N
6111	253	2124	2012-11-28 18:00:00	\N	\N	10.1	\N
6119	250	2127	2012-11-28 19:30:00	\N	\N	9.4000000000000004	\N
6125	250	2129	2012-11-28 20:30:00	\N	\N	9.4000000000000004	\N
6128	250	2130	2012-11-28 21:00:00	\N	\N	9.4000000000000004	\N
6135	253	2132	2012-11-28 22:00:00	\N	\N	9.5999999999999996	\N
6136	259	2132	2012-11-28 22:00:00	9	\N	\N	\N
6140	250	2134	2012-11-28 23:00:00	\N	\N	10.800000000000001	\N
6159	253	2140	2012-11-29 02:00:00	\N	\N	9.3000000000000007	\N
6167	250	2143	2012-11-29 03:30:00	\N	\N	8.0999999999999996	\N
6180	253	2147	2012-11-29 05:30:00	\N	\N	8.5999999999999996	\N
6188	250	2150	2012-11-29 07:00:00	\N	\N	4.7000000000000002	\N
6198	253	2153	2012-11-29 08:30:00	\N	\N	8	\N
6203	250	2155	2012-11-29 09:30:00	\N	\N	9.0999999999999996	\N
6213	253	2158	2012-11-29 11:00:00	\N	\N	7.7000000000000002	\N
6218	250	2160	2012-11-29 12:00:00	\N	\N	9.1999999999999993	\N
6222	253	2161	2012-11-29 12:30:00	\N	\N	8.3000000000000007	\N
6223	259	2161	2012-11-29 12:30:00	0	\N	\N	\N
6224	250	2162	2012-11-29 13:00:00	\N	\N	9.0999999999999996	\N
6228	253	2163	2012-11-29 13:30:00	\N	\N	8.3000000000000007	\N
6231	253	2164	2012-11-29 14:00:00	\N	\N	8.3000000000000007	\N
6240	253	2167	2012-11-29 15:30:00	\N	\N	8.1999999999999993	\N
6241	259	2167	2012-11-29 15:30:00	15	\N	\N	\N
6245	250	2169	2012-11-29 16:30:00	\N	\N	8.9000000000000004	\N
6258	253	2173	2012-11-29 18:30:00	\N	\N	9.0999999999999996	\N
6259	259	2173	2012-11-29 18:30:00	11	\N	\N	\N
6037	259	2099	2012-11-28 05:30:00	0	\N	\N	\N
6053	250	2105	2012-11-28 08:30:00	\N	\N	7.7999999999999998	\N
6062	250	2108	2012-11-28 10:00:00	\N	\N	8.9000000000000004	\N
6075	253	2112	2012-11-28 12:00:00	\N	\N	7.9000000000000004	\N
6090	253	2117	2012-11-28 14:30:00	\N	\N	9	\N
6091	259	2117	2012-11-28 14:30:00	0	\N	\N	\N
6094	259	2118	2012-11-28 15:00:00	0	\N	\N	\N
6095	250	2119	2012-11-28 15:30:00	\N	\N	9.9000000000000004	\N
6103	259	2121	2012-11-28 16:30:00	15	\N	\N	\N
6172	259	2144	2012-11-29 04:00:00	14	\N	\N	\N
6207	253	2156	2012-11-29 10:00:00	\N	\N	7.7999999999999998	\N
6208	259	2156	2012-11-29 10:00:00	0	\N	\N	\N
6209	250	2157	2012-11-29 10:30:00	\N	\N	8.9000000000000004	\N
6239	250	2167	2012-11-29 15:30:00	\N	\N	8.9000000000000004	\N
6250	259	2170	2012-11-29 17:00:00	15	\N	\N	\N
6261	253	2174	2012-11-29 19:00:00	\N	\N	9.1999999999999993	\N
6262	259	2174	2012-11-29 19:00:00	13	\N	\N	\N
6263	250	2175	2012-11-29 19:30:00	\N	\N	7.7000000000000002	\N
6269	250	2177	2012-11-29 20:30:00	\N	\N	7.9000000000000004	\N
6270	253	2177	2012-11-29 20:30:00	\N	\N	9.0999999999999996	\N
6271	259	2177	2012-11-29 20:30:00	13	\N	\N	\N
6272	250	2178	2012-11-29 21:00:00	\N	\N	8	\N
6273	253	2178	2012-11-29 21:00:00	\N	\N	9.0999999999999996	\N
6274	259	2178	2012-11-29 21:00:00	14	\N	\N	\N
6275	250	2179	2012-11-29 21:30:00	\N	\N	8	\N
6276	253	2179	2012-11-29 21:30:00	\N	\N	9.3000000000000007	\N
6277	259	2179	2012-11-29 21:30:00	14	\N	\N	\N
6278	250	2180	2012-11-29 22:00:00	\N	\N	7.9000000000000004	\N
6279	253	2180	2012-11-29 22:00:00	\N	\N	9.3000000000000007	\N
6280	259	2180	2012-11-29 22:00:00	14	\N	\N	\N
6281	250	2181	2012-11-29 22:30:00	\N	\N	7.9000000000000004	\N
6282	253	2181	2012-11-29 22:30:00	\N	\N	9.4000000000000004	\N
6283	259	2181	2012-11-29 22:30:00	12	\N	\N	\N
6284	250	2182	2012-11-29 23:00:00	\N	\N	8.0999999999999996	\N
6285	253	2182	2012-11-29 23:00:00	\N	\N	9.4000000000000004	\N
6286	259	2182	2012-11-29 23:00:00	6	\N	\N	\N
6287	250	2183	2012-11-29 23:30:00	\N	\N	6.2999999999999998	\N
6288	253	2183	2012-11-29 23:30:00	\N	\N	9.4000000000000004	\N
6289	259	2183	2012-11-29 23:30:00	9	\N	\N	\N
6290	250	2184	2012-11-30 00:00:00	\N	\N	5.2000000000000002	\N
6291	253	2184	2012-11-30 00:00:00	\N	\N	9	\N
6292	259	2184	2012-11-30 00:00:00	6	\N	\N	\N
6293	250	2185	2012-11-30 00:30:00	\N	\N	4.7000000000000002	\N
6294	253	2185	2012-11-30 00:30:00	\N	\N	8.9000000000000004	\N
6295	259	2185	2012-11-30 00:30:00	4	\N	\N	\N
6296	250	2186	2012-11-30 01:00:00	\N	\N	4.2999999999999998	\N
6297	253	2186	2012-11-30 01:00:00	\N	\N	8.4000000000000004	\N
6298	259	2186	2012-11-30 01:00:00	4	\N	\N	\N
6299	250	2187	2012-11-30 01:30:00	\N	\N	4.2000000000000002	\N
6300	253	2187	2012-11-30 01:30:00	\N	\N	8	\N
6301	259	2187	2012-11-30 01:30:00	4	\N	\N	\N
6302	250	2188	2012-11-30 02:00:00	\N	\N	3	\N
6303	253	2188	2012-11-30 02:00:00	\N	\N	7.9000000000000004	\N
6304	259	2188	2012-11-30 02:00:00	3	\N	\N	\N
6305	250	2189	2012-11-30 02:30:00	\N	\N	2.8999999999999999	\N
6306	253	2189	2012-11-30 02:30:00	\N	\N	7.5	\N
6307	259	2189	2012-11-30 02:30:00	3	\N	\N	\N
6308	250	2190	2012-11-30 03:00:00	\N	\N	2.7000000000000002	\N
6309	253	2190	2012-11-30 03:00:00	\N	\N	7.0999999999999996	\N
6310	259	2190	2012-11-30 03:00:00	4	\N	\N	\N
6311	250	2191	2012-11-30 03:30:00	\N	\N	3	\N
6312	253	2191	2012-11-30 03:30:00	\N	\N	7	\N
6313	259	2191	2012-11-30 03:30:00	4	\N	\N	\N
6314	250	2192	2012-11-30 04:00:00	\N	\N	2.6000000000000001	\N
6315	253	2192	2012-11-30 04:00:00	\N	\N	7	\N
6316	259	2192	2012-11-30 04:00:00	3	\N	\N	\N
6317	250	2193	2012-11-30 04:30:00	\N	\N	2.2999999999999998	\N
6318	253	2193	2012-11-30 04:30:00	\N	\N	6.5999999999999996	\N
6319	259	2193	2012-11-30 04:30:00	3	\N	\N	\N
6320	250	2194	2012-11-30 05:00:00	\N	\N	2.3999999999999999	\N
6321	253	2194	2012-11-30 05:00:00	\N	\N	6.5	\N
6322	259	2194	2012-11-30 05:00:00	3	\N	\N	\N
6323	250	2195	2012-11-30 05:30:00	\N	\N	2.2000000000000002	\N
6324	253	2195	2012-11-30 05:30:00	\N	\N	6.4000000000000004	\N
6325	259	2195	2012-11-30 05:30:00	3	\N	\N	\N
6326	250	2196	2012-11-30 06:00:00	\N	\N	2.2000000000000002	\N
6327	253	2196	2012-11-30 06:00:00	\N	\N	6.2999999999999998	\N
6328	259	2196	2012-11-30 06:00:00	4	\N	\N	\N
6341	250	2221	2012-11-30 06:30:00	\N	\N	2	\N
6342	253	2221	2012-11-30 06:30:00	\N	\N	5.9000000000000004	\N
6343	259	2221	2012-11-30 06:30:00	4	\N	\N	\N
6344	250	2222	2012-11-30 07:00:00	\N	\N	1.8999999999999999	\N
6345	253	2222	2012-11-30 07:00:00	\N	\N	5.7999999999999998	\N
6346	259	2222	2012-11-30 07:00:00	3	\N	\N	\N
6361	250	2241	2012-11-30 07:30:00	\N	\N	2.1000000000000001	\N
6362	253	2241	2012-11-30 07:30:00	\N	\N	6.0999999999999996	\N
6363	259	2241	2012-11-30 07:30:00	7	\N	\N	\N
6364	250	2242	2012-11-30 08:00:00	\N	\N	2.2000000000000002	\N
6365	253	2242	2012-11-30 08:00:00	\N	\N	6.0999999999999996	\N
6366	259	2242	2012-11-30 08:00:00	9	\N	\N	\N
6367	250	2243	2012-11-30 08:30:00	\N	\N	2.3999999999999999	\N
6368	253	2243	2012-11-30 08:30:00	\N	\N	6.5	\N
6369	259	2243	2012-11-30 08:30:00	10	\N	\N	\N
6370	250	2244	2012-11-30 09:00:00	\N	\N	2.8999999999999999	\N
6371	253	2244	2012-11-30 09:00:00	\N	\N	6.5999999999999996	\N
6372	259	2244	2012-11-30 09:00:00	9	\N	\N	\N
6373	250	2245	2012-11-30 09:30:00	\N	\N	3.3999999999999999	\N
6374	253	2245	2012-11-30 09:30:00	\N	\N	6.7999999999999998	\N
6375	259	2245	2012-11-30 09:30:00	7	\N	\N	\N
6376	250	2246	2012-11-30 10:00:00	\N	\N	3.1000000000000001	\N
6377	253	2246	2012-11-30 10:00:00	\N	\N	7.2000000000000002	\N
6378	259	2246	2012-11-30 10:00:00	8	\N	\N	\N
6379	250	2247	2012-11-30 10:30:00	\N	\N	3.3999999999999999	\N
6380	253	2247	2012-11-30 10:30:00	\N	\N	7.2000000000000002	\N
6381	259	2247	2012-11-30 10:30:00	8	\N	\N	\N
6382	250	2248	2012-11-30 11:00:00	\N	\N	3.6000000000000001	\N
6383	253	2248	2012-11-30 11:00:00	\N	\N	7.2999999999999998	\N
6384	259	2248	2012-11-30 11:00:00	1	\N	\N	\N
6385	250	2249	2012-11-30 11:30:00	\N	\N	3.6000000000000001	\N
6386	253	2249	2012-11-30 11:30:00	\N	\N	7	\N
6387	259	2249	2012-11-30 11:30:00	1	\N	\N	\N
6388	250	2250	2012-11-30 12:00:00	\N	\N	3.7000000000000002	\N
6389	253	2250	2012-11-30 12:00:00	\N	\N	6.9000000000000004	\N
6390	259	2250	2012-11-30 12:00:00	1	\N	\N	\N
6391	250	2251	2012-11-30 12:30:00	\N	\N	3.7999999999999998	\N
6392	253	2251	2012-11-30 12:30:00	\N	\N	7	\N
6393	259	2251	2012-11-30 12:30:00	1	\N	\N	\N
6394	250	2252	2012-11-30 13:00:00	\N	\N	3.5	\N
6395	253	2252	2012-11-30 13:00:00	\N	\N	7	\N
6396	259	2252	2012-11-30 13:00:00	0	\N	\N	\N
6397	250	2253	2012-11-30 13:30:00	\N	\N	2.8999999999999999	\N
6398	253	2253	2012-11-30 13:30:00	\N	\N	6.9000000000000004	\N
6399	259	2253	2012-11-30 13:30:00	0	\N	\N	\N
6400	250	2254	2012-11-30 14:00:00	\N	\N	3	\N
6401	253	2254	2012-11-30 14:00:00	\N	\N	6.7999999999999998	\N
6402	259	2254	2012-11-30 14:00:00	0	\N	\N	\N
6403	250	2255	2012-11-30 14:30:00	\N	\N	2.7000000000000002	\N
6404	253	2255	2012-11-30 14:30:00	\N	\N	6.7000000000000002	\N
6405	259	2255	2012-11-30 14:30:00	0	\N	\N	\N
6406	250	2256	2012-11-30 15:00:00	\N	\N	2.7999999999999998	\N
6407	253	2256	2012-11-30 15:00:00	\N	\N	6.7000000000000002	\N
6408	259	2256	2012-11-30 15:00:00	10	\N	\N	\N
6409	250	2257	2012-11-30 15:30:00	\N	\N	2.7999999999999998	\N
6410	253	2257	2012-11-30 15:30:00	\N	\N	6.7999999999999998	\N
6411	259	2257	2012-11-30 15:30:00	14	\N	\N	\N
6412	250	2258	2012-11-30 16:00:00	\N	\N	2.6000000000000001	\N
6413	253	2258	2012-11-30 16:00:00	\N	\N	6.7999999999999998	\N
6414	259	2258	2012-11-30 16:00:00	15	\N	\N	\N
6415	250	2259	2012-11-30 16:30:00	\N	\N	2.7999999999999998	\N
6416	253	2259	2012-11-30 16:30:00	\N	\N	6.9000000000000004	\N
6417	259	2259	2012-11-30 16:30:00	10	\N	\N	\N
6418	250	2260	2012-11-30 17:00:00	\N	\N	2.6000000000000001	\N
6419	253	2260	2012-11-30 17:00:00	\N	\N	7	\N
6420	259	2260	2012-11-30 17:00:00	6	\N	\N	\N
6421	250	2261	2012-11-30 17:30:00	\N	\N	2.7999999999999998	\N
6422	253	2261	2012-11-30 17:30:00	\N	\N	7	\N
6423	259	2261	2012-11-30 17:30:00	5	\N	\N	\N
6424	250	2262	2012-11-30 18:00:00	\N	\N	2.7000000000000002	\N
6425	253	2262	2012-11-30 18:00:00	\N	\N	7	\N
6426	259	2262	2012-11-30 18:00:00	4	\N	\N	\N
6427	250	2263	2012-11-30 18:30:00	\N	\N	2.6000000000000001	\N
6428	253	2263	2012-11-30 18:30:00	\N	\N	7.0999999999999996	\N
6429	259	2263	2012-11-30 18:30:00	4	\N	\N	\N
6430	250	2264	2012-11-30 19:00:00	\N	\N	2.7999999999999998	\N
6431	253	2264	2012-11-30 19:00:00	\N	\N	7.0999999999999996	\N
6432	259	2264	2012-11-30 19:00:00	4	\N	\N	\N
6461	250	2281	2012-11-30 19:30:00	\N	\N	2.7999999999999998	\N
6462	253	2281	2012-11-30 19:30:00	\N	\N	7.0999999999999996	\N
6463	259	2281	2012-11-30 19:30:00	4	\N	\N	\N
6464	250	2282	2012-11-30 20:00:00	\N	\N	2.6000000000000001	\N
6465	253	2282	2012-11-30 20:00:00	\N	\N	7.0999999999999996	\N
6466	259	2282	2012-11-30 20:00:00	3	\N	\N	\N
6481	250	2301	2012-11-30 20:30:00	\N	\N	2.5	\N
6482	253	2301	2012-11-30 20:30:00	\N	\N	7	\N
6483	259	2301	2012-11-30 20:30:00	1	\N	\N	\N
6484	250	2302	2012-11-30 21:00:00	\N	\N	2.3999999999999999	\N
6485	253	2302	2012-11-30 21:00:00	\N	\N	7	\N
6486	259	2302	2012-11-30 21:00:00	1	\N	\N	\N
6487	250	2303	2012-11-30 21:30:00	\N	\N	2.8999999999999999	\N
6488	253	2303	2012-11-30 21:30:00	\N	\N	7	\N
6489	259	2303	2012-11-30 21:30:00	1	\N	\N	\N
6490	250	2304	2012-11-30 22:00:00	\N	\N	2.7000000000000002	\N
6491	253	2304	2012-11-30 22:00:00	\N	\N	6.9000000000000004	\N
6492	259	2304	2012-11-30 22:00:00	1	\N	\N	\N
6521	250	2321	2012-11-30 22:30:00	\N	\N	2.5	\N
6522	253	2321	2012-11-30 22:30:00	\N	\N	6.7999999999999998	\N
6523	259	2321	2012-11-30 22:30:00	0	\N	\N	\N
6524	250	2322	2012-11-30 23:00:00	\N	\N	2.2000000000000002	\N
6525	253	2322	2012-11-30 23:00:00	\N	\N	6.2999999999999998	\N
6526	259	2322	2012-11-30 23:00:00	0	\N	\N	\N
\.


--
-- Data for Name: s_data_winds; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_winds (id, sensor_id, sensor_data_id, date_time, wind_speed, wind_run, direction, direction_degree, wind_chill, wind_sample, wind_tx) FROM stdin;
1801	248	1801	2012-11-22 00:30:00	0	\N	---	\N	8.5999999999999996	690	1
1802	248	1802	2012-11-22 01:00:00	0	\N	---	\N	8.5999999999999996	698	1
1803	248	1803	2012-11-22 01:30:00	0	\N	---	\N	8.5999999999999996	684	1
1804	248	1804	2012-11-22 02:00:00	0	\N	---	\N	8.4000000000000004	698	1
1805	248	1805	2012-11-22 02:30:00	0	\N	---	\N	8.4000000000000004	689	1
1806	248	1806	2012-11-22 03:00:00	0	\N	SSW	\N	8.4000000000000004	693	1
1807	248	1807	2012-11-22 03:30:00	0	\N	SSW	\N	8.4000000000000004	690	1
1808	248	1808	2012-11-22 04:00:00	0	\N	SSW	\N	8.3000000000000007	691	1
1809	248	1809	2012-11-22 04:30:00	0	\N	---	\N	8.3000000000000007	691	1
1810	248	1810	2012-11-22 05:00:00	0	\N	---	\N	8.3000000000000007	698	1
1811	248	1811	2012-11-22 05:30:00	0	\N	---	\N	8.3000000000000007	682	1
1812	248	1812	2012-11-22 06:00:00	0	\N	---	\N	8.3000000000000007	701	1
1813	248	1813	2012-11-22 06:30:00	0	\N	---	\N	8.3000000000000007	681	1
1814	248	1814	2012-11-22 07:00:00	0	\N	---	\N	8.3000000000000007	699	1
1815	248	1815	2012-11-22 07:30:00	0	\N	---	\N	8.4000000000000004	694	1
1816	248	1816	2012-11-22 08:00:00	0	\N	---	\N	8.5999999999999996	687	1
1817	248	1817	2012-11-22 08:30:00	0	\N	---	\N	8.9000000000000004	693	1
1818	248	1818	2012-11-22 09:00:00	0	\N	SSW	\N	9.1999999999999993	695	1
1819	248	1819	2012-11-22 09:30:00	1.6000000000000001	\N	NNW	\N	9.3000000000000007	690	1
1820	248	1820	2012-11-22 10:00:00	1.6000000000000001	\N	N	\N	9.5999999999999996	702	1
1821	248	1821	2012-11-22 10:30:00	0	\N	NE	\N	9.6999999999999993	682	1
1822	248	1822	2012-11-22 11:00:00	1.6000000000000001	\N	E	\N	9.6999999999999993	701	1
1823	248	1823	2012-11-22 11:30:00	0	\N	ENE	\N	10	687	1
1824	248	1824	2012-11-22 12:00:00	0	\N	E	\N	10.1	692	1
1825	248	1825	2012-11-22 12:30:00	1.6000000000000001	\N	ENE	\N	10.199999999999999	690	1
1826	248	1826	2012-11-22 13:00:00	1.6000000000000001	\N	ENE	\N	10.300000000000001	693	1
1827	248	1827	2012-11-22 13:30:00	1.6000000000000001	\N	NE	\N	10.199999999999999	691	1
1828	248	1828	2012-11-22 14:00:00	1.6000000000000001	\N	ENE	\N	10.199999999999999	699	1
1829	248	1829	2012-11-22 14:30:00	1.6000000000000001	\N	ENE	\N	10.199999999999999	681	1
1830	248	1830	2012-11-22 15:00:00	0	\N	E	\N	10.199999999999999	699	1
1831	248	1831	2012-11-22 15:30:00	0	\N	NE	\N	10.1	691	1
1832	248	1832	2012-11-22 16:00:00	0	\N	---	\N	9.9000000000000004	692	1
1833	248	1833	2012-11-22 16:30:00	0	\N	---	\N	9.8000000000000007	696	1
1834	248	1834	2012-11-22 17:00:00	0	\N	ENE	\N	9.6999999999999993	683	1
1835	248	1835	2012-11-22 17:30:00	0	\N	---	\N	9.5999999999999996	696	1
1836	248	1836	2012-11-22 18:00:00	0	\N	ENE	\N	9.4000000000000004	696	1
1837	248	1837	2012-11-22 18:30:00	0	\N	E	\N	9.3000000000000007	685	1
1838	248	1838	2012-11-22 19:00:00	0	\N	E	\N	9.3000000000000007	700	1
1839	248	1839	2012-11-22 19:30:00	0	\N	---	\N	9.1999999999999993	686	1
1840	248	1840	2012-11-22 20:00:00	0	\N	---	\N	9.0999999999999996	692	1
1841	248	1841	2012-11-22 20:30:00	0	\N	E	\N	9	688	1
1842	248	1842	2012-11-22 21:00:00	0	\N	---	\N	8.9000000000000004	688	1
1843	248	1843	2012-11-22 21:30:00	0	\N	---	\N	8.9000000000000004	690	1
1844	248	1844	2012-11-22 22:00:00	0	\N	E	\N	8.8000000000000007	693	1
1845	248	1845	2012-11-22 22:30:00	0	\N	E	\N	8.8000000000000007	689	1
1846	248	1846	2012-11-22 23:00:00	0	\N	E	\N	8.8000000000000007	701	1
1847	248	1847	2012-11-22 23:30:00	0	\N	E	\N	8.6999999999999993	681	1
1848	248	1848	2012-11-23 00:00:00	0	\N	E	\N	8.5999999999999996	696	1
1849	248	1849	2012-11-23 00:30:00	0	\N	E	\N	8.5999999999999996	692	1
1850	248	1850	2012-11-23 01:00:00	0	\N	E	\N	8.4000000000000004	683	1
1851	248	1851	2012-11-23 01:30:00	0	\N	E	\N	8.3000000000000007	701	1
1852	248	1852	2012-11-23 02:00:00	0	\N	E	\N	8.3000000000000007	683	1
1853	248	1853	2012-11-23 02:30:00	0	\N	E	\N	8.1999999999999993	699	1
1854	248	1854	2012-11-23 03:00:00	0	\N	---	\N	8.1999999999999993	692	1
1855	248	1855	2012-11-23 03:30:00	0	\N	---	\N	8.1999999999999993	690	1
1856	248	1856	2012-11-23 04:00:00	0	\N	---	\N	8.1999999999999993	694	1
1857	248	1857	2012-11-23 04:30:00	0	\N	---	\N	8.0999999999999996	690	1
1858	248	1858	2012-11-23 05:00:00	0	\N	E	\N	8.0999999999999996	692	1
1859	248	1859	2012-11-23 05:30:00	0	\N	E	\N	8.0999999999999996	692	1
1860	248	1860	2012-11-23 06:00:00	0	\N	---	\N	8.0999999999999996	693	1
1861	248	1861	2012-11-23 06:30:00	0	\N	---	\N	8	691	1
1862	248	1862	2012-11-23 07:00:00	0	\N	---	\N	8	698	1
1863	248	1863	2012-11-23 07:30:00	0	\N	---	\N	8	684	1
1864	248	1864	2012-11-23 08:00:00	0	\N	---	\N	8.0999999999999996	698	1
1865	248	1865	2012-11-23 08:30:00	0	\N	---	\N	8.1999999999999993	686	1
1866	248	1866	2012-11-23 09:00:00	0	\N	---	\N	8.3000000000000007	692	1
1867	248	1867	2012-11-23 09:30:00	0	\N	S	\N	8.5	698	1
1868	248	1868	2012-11-23 10:00:00	1.6000000000000001	\N	S	\N	8.6999999999999993	681	1
1869	248	1869	2012-11-23 10:30:00	1.6000000000000001	\N	SW	\N	8.5999999999999996	702	1
1870	248	1870	2012-11-23 11:00:00	0	\N	SSW	\N	8.6999999999999993	684	1
1871	248	1871	2012-11-23 11:30:00	0	\N	SSW	\N	8.8000000000000007	696	1
1872	248	1872	2012-11-23 12:00:00	0	\N	SSW	\N	9.0999999999999996	692	1
1873	248	1873	2012-11-23 12:30:00	1.6000000000000001	\N	S	\N	9.4000000000000004	692	1
1874	248	1874	2012-11-23 13:00:00	0	\N	SSW	\N	9.8000000000000007	691	1
1875	248	1875	2012-11-23 13:30:00	0	\N	SSW	\N	10.1	699	1
1876	248	1876	2012-11-23 14:00:00	0	\N	SSW	\N	10.199999999999999	681	1
1877	248	1877	2012-11-23 14:30:00	0	\N	SSW	\N	10.1	703	1
1878	248	1878	2012-11-23 15:00:00	0	\N	SSW	\N	10	680	1
1879	248	1879	2012-11-23 15:30:00	0	\N	SSW	\N	9.8000000000000007	699	1
1880	248	1880	2012-11-23 16:00:00	0	\N	S	\N	9.5999999999999996	692	1
1881	248	1881	2012-11-23 16:30:00	0	\N	SSW	\N	9.4000000000000004	691	1
1882	248	1882	2012-11-23 17:00:00	0	\N	SSW	\N	9.3000000000000007	692	1
1883	248	1883	2012-11-23 17:30:00	0	\N	SSW	\N	9.1999999999999993	694	1
1884	248	1884	2012-11-23 18:00:00	0	\N	SSW	\N	9.0999999999999996	691	1
1885	248	1885	2012-11-23 18:30:00	0	\N	SSW	\N	9.0999999999999996	698	1
1886	248	1886	2012-11-23 19:00:00	0	\N	S	\N	9.0999999999999996	686	1
1887	248	1887	2012-11-23 19:30:00	0	\N	SSW	\N	9	695	1
1888	248	1888	2012-11-23 20:00:00	0	\N	SSW	\N	9	695	1
1889	248	1889	2012-11-23 20:30:00	0	\N	SSW	\N	8.9000000000000004	684	1
1890	248	1890	2012-11-23 21:00:00	0	\N	SSW	\N	8.8000000000000007	699	1
1891	248	1891	2012-11-23 21:30:00	0	\N	SSW	\N	8.8000000000000007	680	1
1892	248	1892	2012-11-23 22:00:00	0	\N	SSW	\N	8.8000000000000007	697	1
1893	248	1893	2012-11-23 22:30:00	0	\N	---	\N	8.8000000000000007	694	1
1894	248	1894	2012-11-23 23:00:00	0	\N	---	\N	8.5999999999999996	682	1
1895	248	1895	2012-11-23 23:30:00	0	\N	---	\N	8.3000000000000007	699	1
1896	248	1896	2012-11-24 00:00:00	0	\N	---	\N	8.0999999999999996	684	1
1897	248	1897	2012-11-24 00:30:00	0	\N	SSW	\N	7.7999999999999998	695	1
1898	248	1898	2012-11-24 01:00:00	0	\N	---	\N	7.9000000000000004	691	1
1899	248	1899	2012-11-24 01:30:00	0	\N	---	\N	7.9000000000000004	682	1
1900	248	1900	2012-11-24 02:00:00	0	\N	---	\N	7.7000000000000002	699	1
1901	248	1901	2012-11-24 02:30:00	0	\N	---	\N	7.4000000000000004	687	1
1902	248	1902	2012-11-24 03:00:00	0	\N	---	\N	7.0999999999999996	692	1
1903	248	1903	2012-11-24 03:30:00	0	\N	---	\N	6.7000000000000002	695	1
1904	248	1904	2012-11-24 04:00:00	0	\N	SSW	\N	6.0999999999999996	682	1
1905	248	1905	2012-11-24 04:30:00	0	\N	---	\N	5.9000000000000004	701	1
1906	248	1906	2012-11-24 05:00:00	0	\N	SSW	\N	6.0999999999999996	691	1
1907	248	1907	2012-11-24 05:30:00	0	\N	SSW	\N	6.2000000000000002	685	1
1908	248	1908	2012-11-24 06:00:00	0	\N	---	\N	6.2000000000000002	697	1
1909	248	1909	2012-11-24 06:30:00	0	\N	---	\N	6.2000000000000002	684	1
1910	248	1910	2012-11-24 07:00:00	0	\N	---	\N	6.0999999999999996	692	1
1911	248	1911	2012-11-24 07:30:00	0	\N	---	\N	6.4000000000000004	697	1
1912	248	1912	2012-11-24 08:00:00	0	\N	SSW	\N	6.9000000000000004	684	1
1913	248	1913	2012-11-24 08:30:00	0	\N	---	\N	7.5999999999999996	697	1
1914	248	1914	2012-11-24 09:00:00	0	\N	SSW	\N	7.9000000000000004	693	1
1915	248	1915	2012-11-24 09:30:00	0	\N	SSW	\N	9.1999999999999993	687	1
1916	248	1916	2012-11-24 10:00:00	0	\N	SSW	\N	9.9000000000000004	702	1
1917	248	1917	2012-11-24 10:30:00	1.6000000000000001	\N	NW	\N	10.5	678	1
1918	248	1918	2012-11-24 11:00:00	4.7999999999999998	\N	NW	\N	11.6	698	1
1919	248	1919	2012-11-24 11:30:00	4.7999999999999998	\N	WNW	\N	11.5	688	1
1920	248	1920	2012-11-24 12:00:00	4.7999999999999998	\N	WNW	\N	11.800000000000001	690	1
1921	248	1921	2012-11-24 12:30:00	1.6000000000000001	\N	WNW	\N	12.199999999999999	697	1
1922	248	1922	2012-11-24 13:00:00	3.2000000000000002	\N	WNW	\N	12.199999999999999	684	1
1923	248	1923	2012-11-24 13:30:00	3.2000000000000002	\N	WNW	\N	12.300000000000001	699	1
1924	248	1924	2012-11-24 14:00:00	3.2000000000000002	\N	WNW	\N	12.300000000000001	686	1
1925	248	1925	2012-11-24 14:30:00	0	\N	WNW	\N	12.4	689	1
1926	248	1926	2012-11-24 15:00:00	3.2000000000000002	\N	WNW	\N	12.800000000000001	693	1
1927	248	1927	2012-11-24 15:30:00	1.6000000000000001	\N	S	\N	11.699999999999999	692	1
1928	248	1928	2012-11-24 16:00:00	1.6000000000000001	\N	S	\N	10.800000000000001	689	1
1929	248	1929	2012-11-24 16:30:00	0	\N	S	\N	9.6999999999999993	692	1
1930	248	1930	2012-11-24 17:00:00	0	\N	SW	\N	8.9000000000000004	683	1
1931	248	1931	2012-11-24 17:30:00	0	\N	SW	\N	8.3000000000000007	697	1
1932	248	1932	2012-11-24 18:00:00	0	\N	---	\N	7.2000000000000002	686	1
1933	248	1933	2012-11-24 18:30:00	0	\N	---	\N	6.4000000000000004	691	1
1934	248	1934	2012-11-24 19:00:00	0	\N	---	\N	5.7000000000000002	698	1
1935	248	1935	2012-11-24 19:30:00	0	\N	SW	\N	4.7000000000000002	683	1
1936	248	1936	2012-11-24 20:00:00	0	\N	SW	\N	4.4000000000000004	695	1
1937	248	1937	2012-11-24 20:30:00	0	\N	SW	\N	4.2000000000000002	693	1
1938	248	1938	2012-11-24 21:00:00	0	\N	SW	\N	4.0999999999999996	691	1
1939	248	1939	2012-11-24 21:30:00	0	\N	SW	\N	3.7000000000000002	695	1
1940	248	1940	2012-11-24 22:00:00	0	\N	WSW	\N	3.7000000000000002	682	1
1941	248	1941	2012-11-24 22:30:00	0	\N	WSW	\N	3.3999999999999999	698	1
1942	248	1942	2012-11-24 23:00:00	0	\N	---	\N	2.7999999999999998	689	1
1943	248	1943	2012-11-24 23:30:00	0	\N	---	\N	2.2999999999999998	691	1
1944	248	1944	2012-11-25 00:00:00	0	\N	---	\N	2.2999999999999998	695	1
1945	248	1945	2012-11-25 00:30:00	0	\N	---	\N	1.8999999999999999	683	1
1946	248	1946	2012-11-25 01:00:00	0	\N	---	\N	1.8	695	1
1947	248	1947	2012-11-25 01:30:00	0	\N	WSW	\N	1.8999999999999999	693	1
1948	248	1948	2012-11-25 02:00:00	0	\N	WSW	\N	2.3999999999999999	691	1
1949	248	1949	2012-11-25 02:30:00	0	\N	WSW	\N	2.7999999999999998	694	1
1950	248	1950	2012-11-25 03:00:00	0	\N	WSW	\N	3	682	1
1951	248	1951	2012-11-25 03:30:00	0	\N	SW	\N	3	693	1
1953	248	1953	2012-11-25 04:30:00	0	\N	SW	\N	3.3999999999999999	692	1
1955	248	1955	2012-11-25 05:30:00	0	\N	S	\N	3.6000000000000001	684	1
1961	248	1961	2012-11-25 08:30:00	1.6000000000000001	\N	SSW	\N	3.2999999999999998	694	1
1963	248	1963	2012-11-25 09:30:00	1.6000000000000001	\N	SW	\N	4.4000000000000004	694	1
1998	248	1998	2012-11-26 03:00:00	0	\N	SSW	\N	6.4000000000000004	686	1
2039	248	2039	2012-11-26 23:30:00	8	\N	W	\N	11.6	698	1
2050	248	2050	2012-11-27 05:00:00	12.9	\N	W	\N	10.300000000000001	689	1
2055	248	2055	2012-11-27 07:30:00	11.300000000000001	\N	W	\N	10.199999999999999	680	1
1952	248	1952	2012-11-25 04:00:00	0	\N	SW	\N	3.2000000000000002	695	1
1954	248	1954	2012-11-25 05:00:00	0	\N	SSW	\N	3.3999999999999999	694	1
1956	248	1956	2012-11-25 06:00:00	0	\N	S	\N	3.5	700	1
1962	248	1962	2012-11-25 09:00:00	1.6000000000000001	\N	SSW	\N	4	690	1
1987	248	1987	2012-11-25 21:30:00	0	\N	SSW	\N	7.5999999999999996	698	1
1989	248	1989	2012-11-25 22:30:00	0	\N	---	\N	7.2999999999999998	694	1
2010	248	2010	2012-11-26 09:00:00	0	\N	---	\N	8.3000000000000007	702	1
2012	248	2012	2012-11-26 10:00:00	9.6999999999999993	\N	W	\N	10.9	702	1
2014	248	2014	2012-11-26 11:00:00	11.300000000000001	\N	W	\N	11.699999999999999	687	1
2017	248	2017	2012-11-26 12:30:00	11.300000000000001	\N	WNW	\N	12.699999999999999	697	1
2018	248	2018	2012-11-26 13:00:00	9.6999999999999993	\N	WNW	\N	13.199999999999999	691	1
2034	248	2034	2012-11-26 21:00:00	6.4000000000000004	\N	W	\N	11.1	687	1
2038	248	2038	2012-11-26 23:00:00	9.6999999999999993	\N	W	\N	11.800000000000001	691	1
2040	248	2040	2012-11-27 00:00:00	4.7999999999999998	\N	W	\N	11.699999999999999	682	1
2044	248	2044	2012-11-27 02:00:00	14.5	\N	WNW	\N	10.800000000000001	693	1
2047	248	2047	2012-11-27 03:30:00	17.699999999999999	\N	WNW	\N	9.9000000000000004	688	1
2048	248	2048	2012-11-27 04:00:00	16.100000000000001	\N	W	\N	10.199999999999999	694	1
2052	248	2052	2012-11-27 06:00:00	6.4000000000000004	\N	WNW	\N	10.1	698	1
2053	248	2053	2012-11-27 06:30:00	4.7999999999999998	\N	WNW	\N	10.199999999999999	685	1
1957	248	1957	2012-11-25 06:30:00	0	\N	SW	\N	3.3999999999999999	691	1
1959	248	1959	2012-11-25 07:30:00	0	\N	SSW	\N	3.2000000000000002	698	1
1965	248	1965	2012-11-25 10:30:00	1.6000000000000001	\N	SW	\N	5.9000000000000004	683	1
1971	248	1971	2012-11-25 13:30:00	0	\N	S	\N	10.4	688	1
1973	248	1973	2012-11-25 14:30:00	1.6000000000000001	\N	S	\N	9.8000000000000007	683	1
1975	248	1975	2012-11-25 15:30:00	1.6000000000000001	\N	S	\N	8.3000000000000007	681	1
1981	248	1981	2012-11-25 18:30:00	0	\N	SSW	\N	7.9000000000000004	694	1
1983	248	1983	2012-11-25 19:30:00	0	\N	SSW	\N	7.7999999999999998	690	1
2020	248	2020	2012-11-26 14:00:00	9.6999999999999993	\N	WNW	\N	15.6	701	1
2024	248	2024	2012-11-26 16:00:00	4.7999999999999998	\N	W	\N	14.5	676	1
2029	248	2029	2012-11-26 18:30:00	9.6999999999999993	\N	W	\N	13.1	684	1
2037	248	2037	2012-11-26 22:30:00	9.6999999999999993	\N	W	\N	11.9	687	1
2051	248	2051	2012-11-27 05:30:00	9.6999999999999993	\N	W	\N	9.9000000000000004	692	1
2054	248	2054	2012-11-27 07:00:00	9.6999999999999993	\N	WNW	\N	10.300000000000001	701	1
2056	248	2056	2012-11-27 08:00:00	11.300000000000001	\N	WNW	\N	10.699999999999999	699	1
2064	248	2064	2012-11-27 12:00:00	8	\N	W	\N	16.399999999999999	702	1
2065	248	2065	2012-11-27 12:30:00	9.6999999999999993	\N	W	\N	16.800000000000001	698	1
1958	248	1958	2012-11-25 07:00:00	0	\N	SSW	\N	3.2000000000000002	689	1
1980	248	1980	2012-11-25 18:00:00	0	\N	SW	\N	8.0999999999999996	689	1
1984	248	1984	2012-11-25 20:00:00	0	\N	---	\N	7.7999999999999998	695	1
1986	248	1986	2012-11-25 21:00:00	0	\N	---	\N	7.7000000000000002	688	1
1988	248	1988	2012-11-25 22:00:00	0	\N	SSW	\N	7.4000000000000004	685	1
2031	248	2031	2012-11-26 19:30:00	9.6999999999999993	\N	W	\N	12.1	697	1
2032	248	2032	2012-11-26 20:00:00	8	\N	W	\N	12.1	685	1
2033	248	2033	2012-11-26 20:30:00	6.4000000000000004	\N	W	\N	11.300000000000001	699	1
2036	248	2036	2012-11-26 22:00:00	8	\N	WNW	\N	11.300000000000001	691	1
2045	248	2045	2012-11-27 02:30:00	17.699999999999999	\N	WNW	\N	10	687	1
2049	248	2049	2012-11-27 04:30:00	12.9	\N	WNW	\N	10.699999999999999	692	1
2057	248	2057	2012-11-27 08:30:00	12.9	\N	WNW	\N	11.4	689	1
2062	248	2062	2012-11-27 11:00:00	14.5	\N	W	\N	14.300000000000001	697	1
2063	248	2063	2012-11-27 11:30:00	9.6999999999999993	\N	W	\N	15.9	680	1
1960	248	1960	2012-11-25 08:00:00	1.6000000000000001	\N	SSW	\N	3.2999999999999998	689	1
1964	248	1964	2012-11-25 10:00:00	1.6000000000000001	\N	SSW	\N	5.0999999999999996	695	1
1966	248	1966	2012-11-25 11:00:00	3.2000000000000002	\N	SSW	\N	6.7999999999999998	699	1
1968	248	1968	2012-11-25 12:00:00	1.6000000000000001	\N	S	\N	8.1999999999999993	690	1
1997	248	1997	2012-11-26 02:30:00	0	\N	---	\N	6.5	699	1
1999	248	1999	2012-11-26 03:30:00	0	\N	SW	\N	6.2999999999999998	690	1
2005	248	2005	2012-11-26 06:30:00	0	\N	SW	\N	6.5999999999999996	699	1
2011	248	2011	2012-11-26 09:30:00	3.2000000000000002	\N	W	\N	10.1	677	1
2013	248	2013	2012-11-26 10:30:00	11.300000000000001	\N	W	\N	11.199999999999999	686	1
2015	248	2015	2012-11-26 11:30:00	12.9	\N	W	\N	11.699999999999999	698	1
2042	248	2042	2012-11-27 01:00:00	6.4000000000000004	\N	W	\N	11.5	684	1
1967	248	1967	2012-11-25 11:30:00	1.6000000000000001	\N	S	\N	7.7000000000000002	688	1
1969	248	1969	2012-11-25 12:30:00	3.2000000000000002	\N	S	\N	9.4000000000000004	689	1
1990	248	1990	2012-11-25 23:00:00	0	\N	SSW	\N	7.0999999999999996	698	1
1992	248	1992	2012-11-26 00:00:00	0	\N	---	\N	6.9000000000000004	700	1
1994	248	1994	2012-11-26 01:00:00	0	\N	---	\N	6.5999999999999996	694	1
1996	248	1996	2012-11-26 02:00:00	0	\N	---	\N	6.5999999999999996	683	1
2002	248	2002	2012-11-26 05:00:00	0	\N	SW	\N	6.2999999999999998	696	1
2027	248	2027	2012-11-26 17:30:00	8	\N	W	\N	14.5	685	1
2028	248	2028	2012-11-26 18:00:00	9.6999999999999993	\N	W	\N	13.800000000000001	702	1
2041	248	2041	2012-11-27 00:30:00	6.4000000000000004	\N	W	\N	11.699999999999999	698	1
2059	248	2059	2012-11-27 09:30:00	16.100000000000001	\N	WNW	\N	11.199999999999999	699	1
2061	248	2061	2012-11-27 10:30:00	14.5	\N	W	\N	14.300000000000001	697	1
2066	248	2066	2012-11-27 13:00:00	11.300000000000001	\N	W	\N	16.399999999999999	678	1
1970	248	1970	2012-11-25 13:00:00	1.6000000000000001	\N	S	\N	10.1	690	1
1972	248	1972	2012-11-25 14:00:00	1.6000000000000001	\N	S	\N	10.199999999999999	700	1
1974	248	1974	2012-11-25 15:00:00	1.6000000000000001	\N	S	\N	8.9000000000000004	699	1
1976	248	1976	2012-11-25 16:00:00	1.6000000000000001	\N	SSW	\N	8.1999999999999993	702	1
1982	248	1982	2012-11-25 19:00:00	0	\N	SSW	\N	7.7999999999999998	694	1
2007	248	2007	2012-11-26 07:30:00	0	\N	---	\N	6.7999999999999998	695	1
2009	248	2009	2012-11-26 08:30:00	0	\N	SSE	\N	7.5	686	1
2016	248	2016	2012-11-26 12:00:00	11.300000000000001	\N	W	\N	12.199999999999999	682	1
2021	248	2021	2012-11-26 14:30:00	8	\N	WNW	\N	16.300000000000001	686	1
2043	248	2043	2012-11-27 01:30:00	8	\N	W	\N	11.300000000000001	699	1
2046	248	2046	2012-11-27 03:00:00	17.699999999999999	\N	WNW	\N	10.199999999999999	700	1
1977	248	1977	2012-11-25 16:30:00	1.6000000000000001	\N	S	\N	8	686	1
1979	248	1979	2012-11-25 17:30:00	1.6000000000000001	\N	S	\N	8	692	1
1985	248	1985	2012-11-25 20:30:00	0	\N	SSW	\N	7.7999999999999998	695	1
1991	248	1991	2012-11-25 23:30:00	0	\N	---	\N	7.0999999999999996	686	1
1993	248	1993	2012-11-26 00:30:00	0	\N	SSW	\N	6.5999999999999996	684	1
1995	248	1995	2012-11-26 01:30:00	0	\N	---	\N	6.5999999999999996	697	1
2001	248	2001	2012-11-26 04:30:00	0	\N	SW	\N	6.2999999999999998	679	1
2003	248	2003	2012-11-26 05:30:00	0	\N	---	\N	6.4000000000000004	690	1
2019	248	2019	2012-11-26 13:30:00	9.6999999999999993	\N	WNW	\N	14.300000000000001	688	1
2023	248	2023	2012-11-26 15:30:00	6.4000000000000004	\N	W	\N	15.6	703	1
2026	248	2026	2012-11-26 17:00:00	3.2000000000000002	\N	WSW	\N	14.699999999999999	696	1
2030	248	2030	2012-11-26 19:00:00	8	\N	W	\N	12.9	696	1
2058	248	2058	2012-11-27 09:00:00	16.100000000000001	\N	WNW	\N	11.6	691	1
2060	248	2060	2012-11-27 10:00:00	12.9	\N	W	\N	13.6	686	1
1978	248	1978	2012-11-25 17:00:00	0	\N	S	\N	8	694	1
2000	248	2000	2012-11-26 04:00:00	0	\N	SW	\N	6.2000000000000002	700	1
2004	248	2004	2012-11-26 06:00:00	0	\N	---	\N	6.4000000000000004	687	1
2006	248	2006	2012-11-26 07:00:00	0	\N	SSW	\N	6.7000000000000002	683	1
2008	248	2008	2012-11-26 08:00:00	0	\N	S	\N	7.0999999999999996	693	1
2022	248	2022	2012-11-26 15:00:00	6.4000000000000004	\N	W	\N	16.199999999999999	694	1
2025	248	2025	2012-11-26 16:30:00	4.7999999999999998	\N	WSW	\N	14.6	702	1
2035	248	2035	2012-11-26 21:30:00	8	\N	W	\N	10.9	692	1
2067	248	2067	2012-11-27 13:30:00	9.6999999999999993	\N	W	\N	16.800000000000001	700	1
2068	248	2068	2012-11-27 14:00:00	8	\N	W	\N	16.699999999999999	697	1
2069	248	2069	2012-11-27 14:30:00	9.6999999999999993	\N	W	\N	16.699999999999999	679	1
2070	248	2070	2012-11-27 15:00:00	11.300000000000001	\N	W	\N	15.699999999999999	702	1
2071	248	2071	2012-11-27 15:30:00	11.300000000000001	\N	W	\N	15.199999999999999	691	1
2072	248	2072	2012-11-27 16:00:00	9.6999999999999993	\N	W	\N	14.9	685	1
2073	248	2073	2012-11-27 16:30:00	6.4000000000000004	\N	W	\N	14.300000000000001	702	1
2074	248	2074	2012-11-27 17:00:00	3.2000000000000002	\N	WSW	\N	14.300000000000001	688	1
2075	248	2075	2012-11-27 17:30:00	0	\N	SW	\N	13.300000000000001	693	1
2076	248	2076	2012-11-27 18:00:00	1.6000000000000001	\N	SSW	\N	13.699999999999999	696	1
2077	248	2077	2012-11-27 18:30:00	1.6000000000000001	\N	SW	\N	13.699999999999999	685	1
2078	248	2078	2012-11-27 19:00:00	0	\N	S	\N	12.4	702	1
2079	248	2079	2012-11-27 19:30:00	0	\N	S	\N	12	685	1
2080	248	2080	2012-11-27 20:00:00	1.6000000000000001	\N	S	\N	11.6	698	1
2081	248	2081	2012-11-27 20:30:00	0	\N	SW	\N	10.800000000000001	697	1
2082	248	2082	2012-11-27 21:00:00	0	\N	S	\N	11.300000000000001	686	1
2083	248	2083	2012-11-27 21:30:00	0	\N	SW	\N	10.800000000000001	699	1
2084	248	2084	2012-11-27 22:00:00	0	\N	WSW	\N	10.300000000000001	687	1
2085	248	2085	2012-11-27 22:30:00	0	\N	SW	\N	10.4	696	1
2086	248	2086	2012-11-27 23:00:00	0	\N	SW	\N	10.9	693	1
2087	248	2087	2012-11-27 23:30:00	0	\N	SW	\N	10.9	689	1
2088	248	2088	2012-11-28 00:00:00	0	\N	S	\N	10.6	690	1
2089	248	2089	2012-11-28 00:30:00	0	\N	SW	\N	9.5	695	1
2090	248	2090	2012-11-28 01:00:00	0	\N	---	\N	8.9000000000000004	687	1
2091	248	2091	2012-11-28 01:30:00	0	\N	---	\N	8.8000000000000007	699	1
2092	248	2092	2012-11-28 02:00:00	0	\N	SW	\N	8.8000000000000007	685	1
2093	248	2093	2012-11-28 02:30:00	0	\N	SW	\N	8.9000000000000004	692	1
2094	248	2094	2012-11-28 03:00:00	0	\N	SSW	\N	8.9000000000000004	699	1
2095	248	2095	2012-11-28 03:30:00	0	\N	SSW	\N	9.0999999999999996	681	1
2096	248	2096	2012-11-28 04:00:00	0	\N	SSW	\N	9.1999999999999993	702	1
2097	248	2097	2012-11-28 04:30:00	0	\N	SSW	\N	9.1999999999999993	685	1
2098	248	2098	2012-11-28 05:00:00	1.6000000000000001	\N	S	\N	9.4000000000000004	697	1
2099	248	2099	2012-11-28 05:30:00	0	\N	S	\N	9.0999999999999996	692	1
2100	248	2100	2012-11-28 06:00:00	0	\N	S	\N	8.5	691	1
2101	248	2101	2012-11-28 06:30:00	0	\N	S	\N	8.4000000000000004	694	1
2102	248	2102	2012-11-28 07:00:00	0	\N	S	\N	8.3000000000000007	694	1
2103	248	2103	2012-11-28 07:30:00	0	\N	S	\N	7.7000000000000002	691	1
2104	248	2104	2012-11-28 08:00:00	0	\N	S	\N	8.0999999999999996	693	1
2105	248	2105	2012-11-28 08:30:00	0	\N	S	\N	9.1999999999999993	694	1
2106	248	2106	2012-11-28 09:00:00	0	\N	S	\N	10.1	690	1
2107	248	2107	2012-11-28 09:30:00	0	\N	SW	\N	10.300000000000001	700	1
2108	248	2108	2012-11-28 10:00:00	1.6000000000000001	\N	SW	\N	12.300000000000001	683	1
2109	248	2109	2012-11-28 10:30:00	3.2000000000000002	\N	S	\N	13.699999999999999	698	1
2110	248	2110	2012-11-28 11:00:00	3.2000000000000002	\N	S	\N	14.300000000000001	693	1
2111	248	2111	2012-11-28 11:30:00	3.2000000000000002	\N	S	\N	15.800000000000001	686	1
2112	248	2112	2012-11-28 12:00:00	1.6000000000000001	\N	SSW	\N	15.699999999999999	703	1
2113	248	2113	2012-11-28 12:30:00	0	\N	SSW	\N	15.699999999999999	689	1
2114	248	2114	2012-11-28 13:00:00	3.2000000000000002	\N	S	\N	15.699999999999999	690	1
2115	248	2115	2012-11-28 13:30:00	4.7999999999999998	\N	S	\N	15.6	696	1
2116	248	2116	2012-11-28 14:00:00	3.2000000000000002	\N	S	\N	14.699999999999999	692	1
2117	248	2117	2012-11-28 14:30:00	3.2000000000000002	\N	S	\N	14.699999999999999	689	1
2118	248	2118	2012-11-28 15:00:00	1.6000000000000001	\N	S	\N	14.1	690	1
2119	248	2119	2012-11-28 15:30:00	3.2000000000000002	\N	S	\N	13.4	692	1
2120	248	2120	2012-11-28 16:00:00	3.2000000000000002	\N	S	\N	12.300000000000001	695	1
2121	248	2121	2012-11-28 16:30:00	3.2000000000000002	\N	S	\N	12	688	1
2122	248	2122	2012-11-28 17:00:00	1.6000000000000001	\N	S	\N	11.4	697	1
2123	248	2123	2012-11-28 17:30:00	0	\N	SSW	\N	11.199999999999999	686	1
2124	248	2124	2012-11-28 18:00:00	0	\N	S	\N	11.1	692	1
2125	248	2125	2012-11-28 18:30:00	0	\N	S	\N	11.199999999999999	695	1
2126	248	2126	2012-11-28 19:00:00	1.6000000000000001	\N	S	\N	11.300000000000001	683	1
2127	248	2127	2012-11-28 19:30:00	1.6000000000000001	\N	S	\N	11	696	1
2128	248	2128	2012-11-28 20:00:00	1.6000000000000001	\N	S	\N	10.9	692	1
2129	248	2129	2012-11-28 20:30:00	1.6000000000000001	\N	S	\N	10.9	690	1
2130	248	2130	2012-11-28 21:00:00	1.6000000000000001	\N	S	\N	11.199999999999999	696	1
2131	248	2131	2012-11-28 21:30:00	0	\N	SW	\N	10.9	683	1
2132	248	2132	2012-11-28 22:00:00	3.2000000000000002	\N	SW	\N	10.699999999999999	701	1
2133	248	2133	2012-11-28 22:30:00	8	\N	WNW	\N	11.6	686	1
2134	248	2134	2012-11-28 23:00:00	3.2000000000000002	\N	S	\N	11.699999999999999	691	1
2144	248	2144	2012-11-29 04:00:00	0	\N	S	\N	7.2999999999999998	694	1
2149	248	2149	2012-11-29 06:30:00	0	\N	---	\N	5.2999999999999998	686	1
2155	248	2155	2012-11-29 09:30:00	4.7999999999999998	\N	WNW	\N	11.9	691	1
2171	248	2171	2012-11-29 17:30:00	0	\N	---	\N	9.3000000000000007	690	1
2135	248	2135	2012-11-28 23:30:00	3.2000000000000002	\N	S	\N	11.300000000000001	692	1
2159	248	2159	2012-11-29 11:30:00	9.6999999999999993	\N	NW	\N	13.699999999999999	696	1
2174	248	2174	2012-11-29 19:00:00	0	\N	---	\N	8.5	696	1
2136	248	2136	2012-11-29 00:00:00	1.6000000000000001	\N	S	\N	10.9	691	1
2142	248	2142	2012-11-29 03:00:00	1.6000000000000001	\N	SW	\N	9.0999999999999996	699	1
2143	248	2143	2012-11-29 03:30:00	1.6000000000000001	\N	S	\N	8.6999999999999993	692	1
2151	248	2151	2012-11-29 07:30:00	3.2000000000000002	\N	NW	\N	6	697	1
2166	248	2166	2012-11-29 15:00:00	4.7999999999999998	\N	NW	\N	12.699999999999999	693	1
2172	248	2172	2012-11-29 18:00:00	0	\N	WNW	\N	9.1999999999999993	691	1
2137	248	2137	2012-11-29 00:30:00	4.7999999999999998	\N	S	\N	11.199999999999999	687	1
2138	248	2138	2012-11-29 01:00:00	4.7999999999999998	\N	SSW	\N	11	699	1
2141	248	2141	2012-11-29 02:30:00	1.6000000000000001	\N	S	\N	9.5	689	1
2150	248	2150	2012-11-29 07:00:00	0	\N	S	\N	5.2999999999999998	690	1
2157	248	2157	2012-11-29 10:30:00	9.6999999999999993	\N	WNW	\N	12.300000000000001	689	1
2158	248	2158	2012-11-29 11:00:00	11.300000000000001	\N	NW	\N	12.4	689	1
2162	248	2162	2012-11-29 13:00:00	6.4000000000000004	\N	WNW	\N	14.1	690	1
2163	248	2163	2012-11-29 13:30:00	3.2000000000000002	\N	WNW	\N	14.800000000000001	689	1
2167	248	2167	2012-11-29 15:30:00	11.300000000000001	\N	NNW	\N	8.8000000000000007	690	1
2168	248	2168	2012-11-29 16:00:00	3.2000000000000002	\N	NNW	\N	9.9000000000000004	691	1
2173	248	2173	2012-11-29 18:30:00	0	\N	W	\N	8.9000000000000004	689	1
2139	248	2139	2012-11-29 01:30:00	4.7999999999999998	\N	S	\N	10.4	682	1
2140	248	2140	2012-11-29 02:00:00	3.2000000000000002	\N	S	\N	10	700	1
2147	248	2147	2012-11-29 05:30:00	0	\N	W	\N	5.7999999999999998	689	1
2148	248	2148	2012-11-29 06:00:00	0	\N	W	\N	5.2999999999999998	696	1
2154	248	2154	2012-11-29 09:00:00	4.7999999999999998	\N	NW	\N	10.699999999999999	692	1
2145	248	2145	2012-11-29 04:30:00	0	\N	S	\N	6.7000000000000002	692	1
2152	248	2152	2012-11-29 08:00:00	6.4000000000000004	\N	NW	\N	6.5	694	1
2164	248	2164	2012-11-29 14:00:00	1.6000000000000001	\N	WNW	\N	14.199999999999999	697	1
2165	248	2165	2012-11-29 14:30:00	3.2000000000000002	\N	NW	\N	13.800000000000001	688	1
2146	248	2146	2012-11-29 05:00:00	1.6000000000000001	\N	W	\N	5.5999999999999996	694	1
2161	248	2161	2012-11-29 12:30:00	6.4000000000000004	\N	NW	\N	14.699999999999999	699	1
2170	248	2170	2012-11-29 17:00:00	0	\N	NNW	\N	9.5999999999999996	679	1
2153	248	2153	2012-11-29 08:30:00	6.4000000000000004	\N	NW	\N	9.1999999999999993	695	1
2160	248	2160	2012-11-29 12:00:00	6.4000000000000004	\N	NW	\N	14	683	1
2175	248	2175	2012-11-29 19:30:00	0	\N	WSW	\N	8.3000000000000007	680	1
2176	248	2176	2012-11-29 20:00:00	0	\N	---	\N	8.1999999999999993	700	1
2156	248	2156	2012-11-29 10:00:00	8	\N	WNW	\N	11.9	696	1
2169	248	2169	2012-11-29 16:30:00	0	\N	NNW	\N	9.8000000000000007	697	1
2177	248	2177	2012-11-29 20:30:00	0	\N	SSW	\N	8.4000000000000004	690	1
2178	248	2178	2012-11-29 21:00:00	0	\N	SSW	\N	8.5999999999999996	689	1
2179	248	2179	2012-11-29 21:30:00	0	\N	S	\N	8.5999999999999996	697	1
2180	248	2180	2012-11-29 22:00:00	0	\N	---	\N	8.5	683	1
2181	248	2181	2012-11-29 22:30:00	0	\N	---	\N	8.5	699	1
2182	248	2182	2012-11-29 23:00:00	1.6000000000000001	\N	E	\N	8.6999999999999993	689	1
2183	248	2183	2012-11-29 23:30:00	8	\N	E	\N	5.5999999999999996	687	1
2184	248	2184	2012-11-30 00:00:00	8	\N	E	\N	4.4000000000000004	696	1
2185	248	2185	2012-11-30 00:30:00	8	\N	E	\N	3.7999999999999998	684	1
2186	248	2186	2012-11-30 01:00:00	8	\N	E	\N	3.2999999999999998	697	1
2187	248	2187	2012-11-30 01:30:00	3.2000000000000002	\N	E	\N	4.7999999999999998	697	1
2188	248	2188	2012-11-30 02:00:00	4.7999999999999998	\N	E	\N	3.2999999999999998	684	1
2189	248	2189	2012-11-30 02:30:00	6.4000000000000004	\N	E	\N	2.3999999999999999	692	1
2190	248	2190	2012-11-30 03:00:00	6.4000000000000004	\N	E	\N	2.2000000000000002	694	1
2191	248	2191	2012-11-30 03:30:00	3.2000000000000002	\N	ESE	\N	3.5	688	1
2192	248	2192	2012-11-30 04:00:00	1.6000000000000001	\N	E	\N	3.5	691	1
2193	248	2193	2012-11-30 04:30:00	3.2000000000000002	\N	ESE	\N	3.1000000000000001	686	1
2194	248	2194	2012-11-30 05:00:00	3.2000000000000002	\N	ESE	\N	3.1000000000000001	701	1
2195	248	2195	2012-11-30 05:30:00	4.7999999999999998	\N	ESE	\N	2.2000000000000002	690	1
2196	248	2196	2012-11-30 06:00:00	4.7999999999999998	\N	ESE	\N	1.8999999999999999	692	1
2221	248	2221	2012-11-30 06:30:00	3.2000000000000002	\N	ESE	\N	2.6000000000000001	694	1
2222	248	2222	2012-11-30 07:00:00	3.2000000000000002	\N	E	\N	2.5	689	1
2241	248	2241	2012-11-30 07:30:00	0	\N	E	\N	2.7999999999999998	698	1
2242	248	2242	2012-11-30 08:00:00	0	\N	E	\N	2.8999999999999999	687	1
2243	248	2243	2012-11-30 08:30:00	0	\N	E	\N	3.1000000000000001	687	1
2244	248	2244	2012-11-30 09:00:00	0	\N	ESE	\N	3.3999999999999999	694	1
2245	248	2245	2012-11-30 09:30:00	0	\N	E	\N	4	688	1
2246	248	2246	2012-11-30 10:00:00	1.6000000000000001	\N	E	\N	4.0999999999999996	694	1
2247	248	2247	2012-11-30 10:30:00	3.2000000000000002	\N	E	\N	4.4000000000000004	688	1
2248	248	2248	2012-11-30 11:00:00	1.6000000000000001	\N	E	\N	4.7999999999999998	692	1
2249	248	2249	2012-11-30 11:30:00	1.6000000000000001	\N	E	\N	5.0999999999999996	696	1
2250	248	2250	2012-11-30 12:00:00	0	\N	ESE	\N	5.2000000000000002	680	1
2251	248	2251	2012-11-30 12:30:00	0	\N	ESE	\N	5.4000000000000004	696	1
2252	248	2252	2012-11-30 13:00:00	0	\N	ESE	\N	5.5999999999999996	690	1
2253	248	2253	2012-11-30 13:30:00	1.6000000000000001	\N	E	\N	5.7000000000000002	684	1
2254	248	2254	2012-11-30 14:00:00	0	\N	ESE	\N	5.7999999999999998	700	1
2255	248	2255	2012-11-30 14:30:00	1.6000000000000001	\N	ESE	\N	5.7000000000000002	685	1
2256	248	2256	2012-11-30 15:00:00	0	\N	E	\N	5.7000000000000002	695	1
2257	248	2257	2012-11-30 15:30:00	0	\N	E	\N	5.4000000000000004	694	1
2258	248	2258	2012-11-30 16:00:00	1.6000000000000001	\N	E	\N	5.2999999999999998	691	1
2259	248	2259	2012-11-30 16:30:00	0	\N	E	\N	4.9000000000000004	694	1
2260	248	2260	2012-11-30 17:00:00	0	\N	SSE	\N	4.5999999999999996	680	1
2261	248	2261	2012-11-30 17:30:00	0	\N	E	\N	4.4000000000000004	702	1
2262	248	2262	2012-11-30 18:00:00	0	\N	SSE	\N	4.2000000000000002	688	1
2263	248	2263	2012-11-30 18:30:00	0	\N	---	\N	4.0999999999999996	690	1
2264	248	2264	2012-11-30 19:00:00	0	\N	---	\N	4	696	1
2281	248	2281	2012-11-30 19:30:00	0	\N	---	\N	3.7999999999999998	691	1
2282	248	2282	2012-11-30 20:00:00	0	\N	E	\N	4.0999999999999996	695	1
2301	248	2301	2012-11-30 20:30:00	3.2000000000000002	\N	E	\N	4.5	689	1
2302	248	2302	2012-11-30 21:00:00	1.6000000000000001	\N	E	\N	4.5	691	1
2303	248	2303	2012-11-30 21:30:00	0	\N	E	\N	4.4000000000000004	699	1
2304	248	2304	2012-11-30 22:00:00	0	\N	E	\N	4.2999999999999998	684	1
2321	248	2321	2012-11-30 22:30:00	1.6000000000000001	\N	E	\N	4.2999999999999998	691	1
2322	248	2322	2012-11-30 23:00:00	1.6000000000000001	\N	E	\N	4.2999999999999998	693	1
\.


--
-- Data for Name: s_data_winds_high_low; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_data_winds_high_low (id, sensor_id, sensor_data_id, date_time, high_speed, high_speed_direction, high_speed_direction_degree, low_speed, low_speed_direction, low_speed_direction_degree) FROM stdin;
1801	248	1801	2012-11-22 00:30:00	0	---	\N	\N	\N	\N
1802	248	1802	2012-11-22 01:00:00	0	---	\N	\N	\N	\N
1803	248	1803	2012-11-22 01:30:00	0	---	\N	\N	\N	\N
1804	248	1804	2012-11-22 02:00:00	0	---	\N	\N	\N	\N
1805	248	1805	2012-11-22 02:30:00	0	---	\N	\N	\N	\N
1806	248	1806	2012-11-22 03:00:00	3.2000000000000002	SSW	\N	\N	\N	\N
1807	248	1807	2012-11-22 03:30:00	3.2000000000000002	SSW	\N	\N	\N	\N
1808	248	1808	2012-11-22 04:00:00	1.6000000000000001	SSW	\N	\N	\N	\N
1809	248	1809	2012-11-22 04:30:00	0	---	\N	\N	\N	\N
1810	248	1810	2012-11-22 05:00:00	0	---	\N	\N	\N	\N
1811	248	1811	2012-11-22 05:30:00	0	---	\N	\N	\N	\N
1812	248	1812	2012-11-22 06:00:00	0	---	\N	\N	\N	\N
1813	248	1813	2012-11-22 06:30:00	0	---	\N	\N	\N	\N
1814	248	1814	2012-11-22 07:00:00	0	---	\N	\N	\N	\N
1815	248	1815	2012-11-22 07:30:00	0	---	\N	\N	\N	\N
1816	248	1816	2012-11-22 08:00:00	0	---	\N	\N	\N	\N
1817	248	1817	2012-11-22 08:30:00	0	---	\N	\N	\N	\N
1818	248	1818	2012-11-22 09:00:00	1.6000000000000001	SSW	\N	\N	\N	\N
1819	248	1819	2012-11-22 09:30:00	4.7999999999999998	NNW	\N	\N	\N	\N
1820	248	1820	2012-11-22 10:00:00	4.7999999999999998	N	\N	\N	\N	\N
1821	248	1821	2012-11-22 10:30:00	4.7999999999999998	NE	\N	\N	\N	\N
1822	248	1822	2012-11-22 11:00:00	6.4000000000000004	NE	\N	\N	\N	\N
1823	248	1823	2012-11-22 11:30:00	3.2000000000000002	E	\N	\N	\N	\N
1824	248	1824	2012-11-22 12:00:00	4.7999999999999998	E	\N	\N	\N	\N
1825	248	1825	2012-11-22 12:30:00	4.7999999999999998	E	\N	\N	\N	\N
1826	248	1826	2012-11-22 13:00:00	4.7999999999999998	E	\N	\N	\N	\N
1827	248	1827	2012-11-22 13:30:00	4.7999999999999998	ENE	\N	\N	\N	\N
1828	248	1828	2012-11-22 14:00:00	4.7999999999999998	NE	\N	\N	\N	\N
1829	248	1829	2012-11-22 14:30:00	4.7999999999999998	ENE	\N	\N	\N	\N
1830	248	1830	2012-11-22 15:00:00	3.2000000000000002	ENE	\N	\N	\N	\N
1831	248	1831	2012-11-22 15:30:00	3.2000000000000002	NE	\N	\N	\N	\N
1832	248	1832	2012-11-22 16:00:00	0	---	\N	\N	\N	\N
1833	248	1833	2012-11-22 16:30:00	0	---	\N	\N	\N	\N
1834	248	1834	2012-11-22 17:00:00	1.6000000000000001	ENE	\N	\N	\N	\N
1835	248	1835	2012-11-22 17:30:00	0	---	\N	\N	\N	\N
1836	248	1836	2012-11-22 18:00:00	1.6000000000000001	ENE	\N	\N	\N	\N
1837	248	1837	2012-11-22 18:30:00	1.6000000000000001	E	\N	\N	\N	\N
1838	248	1838	2012-11-22 19:00:00	3.2000000000000002	E	\N	\N	\N	\N
1839	248	1839	2012-11-22 19:30:00	0	---	\N	\N	\N	\N
1840	248	1840	2012-11-22 20:00:00	0	---	\N	\N	\N	\N
1841	248	1841	2012-11-22 20:30:00	1.6000000000000001	E	\N	\N	\N	\N
1842	248	1842	2012-11-22 21:00:00	0	---	\N	\N	\N	\N
1843	248	1843	2012-11-22 21:30:00	0	---	\N	\N	\N	\N
1844	248	1844	2012-11-22 22:00:00	1.6000000000000001	E	\N	\N	\N	\N
1845	248	1845	2012-11-22 22:30:00	1.6000000000000001	E	\N	\N	\N	\N
1846	248	1846	2012-11-22 23:00:00	1.6000000000000001	E	\N	\N	\N	\N
1847	248	1847	2012-11-22 23:30:00	3.2000000000000002	E	\N	\N	\N	\N
1848	248	1848	2012-11-23 00:00:00	3.2000000000000002	E	\N	\N	\N	\N
1849	248	1849	2012-11-23 00:30:00	3.2000000000000002	E	\N	\N	\N	\N
1850	248	1850	2012-11-23 01:00:00	3.2000000000000002	E	\N	\N	\N	\N
1851	248	1851	2012-11-23 01:30:00	4.7999999999999998	E	\N	\N	\N	\N
1852	248	1852	2012-11-23 02:00:00	3.2000000000000002	E	\N	\N	\N	\N
1853	248	1853	2012-11-23 02:30:00	1.6000000000000001	E	\N	\N	\N	\N
1854	248	1854	2012-11-23 03:00:00	0	---	\N	\N	\N	\N
1855	248	1855	2012-11-23 03:30:00	0	---	\N	\N	\N	\N
1856	248	1856	2012-11-23 04:00:00	0	---	\N	\N	\N	\N
1857	248	1857	2012-11-23 04:30:00	0	---	\N	\N	\N	\N
1858	248	1858	2012-11-23 05:00:00	1.6000000000000001	E	\N	\N	\N	\N
1859	248	1859	2012-11-23 05:30:00	1.6000000000000001	E	\N	\N	\N	\N
1860	248	1860	2012-11-23 06:00:00	0	---	\N	\N	\N	\N
1861	248	1861	2012-11-23 06:30:00	0	---	\N	\N	\N	\N
1862	248	1862	2012-11-23 07:00:00	0	---	\N	\N	\N	\N
1863	248	1863	2012-11-23 07:30:00	0	---	\N	\N	\N	\N
1864	248	1864	2012-11-23 08:00:00	0	---	\N	\N	\N	\N
1865	248	1865	2012-11-23 08:30:00	0	---	\N	\N	\N	\N
1866	248	1866	2012-11-23 09:00:00	0	---	\N	\N	\N	\N
1867	248	1867	2012-11-23 09:30:00	4.7999999999999998	S	\N	\N	\N	\N
1868	248	1868	2012-11-23 10:00:00	6.4000000000000004	SW	\N	\N	\N	\N
1869	248	1869	2012-11-23 10:30:00	8	WSW	\N	\N	\N	\N
1870	248	1870	2012-11-23 11:00:00	3.2000000000000002	SSW	\N	\N	\N	\N
1871	248	1871	2012-11-23 11:30:00	4.7999999999999998	SSW	\N	\N	\N	\N
1872	248	1872	2012-11-23 12:00:00	4.7999999999999998	SSW	\N	\N	\N	\N
1873	248	1873	2012-11-23 12:30:00	4.7999999999999998	S	\N	\N	\N	\N
1874	248	1874	2012-11-23 13:00:00	3.2000000000000002	SSW	\N	\N	\N	\N
1875	248	1875	2012-11-23 13:30:00	1.6000000000000001	SSW	\N	\N	\N	\N
1876	248	1876	2012-11-23 14:00:00	1.6000000000000001	SSW	\N	\N	\N	\N
1877	248	1877	2012-11-23 14:30:00	3.2000000000000002	SSW	\N	\N	\N	\N
1878	248	1878	2012-11-23 15:00:00	3.2000000000000002	SSW	\N	\N	\N	\N
1879	248	1879	2012-11-23 15:30:00	4.7999999999999998	SSW	\N	\N	\N	\N
1880	248	1880	2012-11-23 16:00:00	6.4000000000000004	S	\N	\N	\N	\N
1881	248	1881	2012-11-23 16:30:00	6.4000000000000004	S	\N	\N	\N	\N
1882	248	1882	2012-11-23 17:00:00	4.7999999999999998	SSW	\N	\N	\N	\N
1883	248	1883	2012-11-23 17:30:00	3.2000000000000002	SSW	\N	\N	\N	\N
1884	248	1884	2012-11-23 18:00:00	4.7999999999999998	SSW	\N	\N	\N	\N
1885	248	1885	2012-11-23 18:30:00	4.7999999999999998	S	\N	\N	\N	\N
1886	248	1886	2012-11-23 19:00:00	4.7999999999999998	S	\N	\N	\N	\N
1887	248	1887	2012-11-23 19:30:00	3.2000000000000002	SSW	\N	\N	\N	\N
1888	248	1888	2012-11-23 20:00:00	1.6000000000000001	SSW	\N	\N	\N	\N
1889	248	1889	2012-11-23 20:30:00	1.6000000000000001	SSW	\N	\N	\N	\N
1890	248	1890	2012-11-23 21:00:00	1.6000000000000001	SSW	\N	\N	\N	\N
1891	248	1891	2012-11-23 21:30:00	1.6000000000000001	SSW	\N	\N	\N	\N
1892	248	1892	2012-11-23 22:00:00	3.2000000000000002	SSW	\N	\N	\N	\N
1893	248	1893	2012-11-23 22:30:00	0	---	\N	\N	\N	\N
1894	248	1894	2012-11-23 23:00:00	0	---	\N	\N	\N	\N
1895	248	1895	2012-11-23 23:30:00	0	---	\N	\N	\N	\N
1896	248	1896	2012-11-24 00:00:00	0	---	\N	\N	\N	\N
1897	248	1897	2012-11-24 00:30:00	1.6000000000000001	SSW	\N	\N	\N	\N
1898	248	1898	2012-11-24 01:00:00	0	---	\N	\N	\N	\N
1899	248	1899	2012-11-24 01:30:00	0	---	\N	\N	\N	\N
1900	248	1900	2012-11-24 02:00:00	0	---	\N	\N	\N	\N
1901	248	1901	2012-11-24 02:30:00	0	---	\N	\N	\N	\N
1902	248	1902	2012-11-24 03:00:00	0	---	\N	\N	\N	\N
1903	248	1903	2012-11-24 03:30:00	0	---	\N	\N	\N	\N
1904	248	1904	2012-11-24 04:00:00	1.6000000000000001	SSW	\N	\N	\N	\N
1905	248	1905	2012-11-24 04:30:00	0	---	\N	\N	\N	\N
1906	248	1906	2012-11-24 05:00:00	1.6000000000000001	SSW	\N	\N	\N	\N
1907	248	1907	2012-11-24 05:30:00	1.6000000000000001	SSW	\N	\N	\N	\N
1908	248	1908	2012-11-24 06:00:00	0	---	\N	\N	\N	\N
1909	248	1909	2012-11-24 06:30:00	0	---	\N	\N	\N	\N
1910	248	1910	2012-11-24 07:00:00	0	---	\N	\N	\N	\N
1911	248	1911	2012-11-24 07:30:00	0	---	\N	\N	\N	\N
1912	248	1912	2012-11-24 08:00:00	1.6000000000000001	SSW	\N	\N	\N	\N
1913	248	1913	2012-11-24 08:30:00	0	---	\N	\N	\N	\N
1914	248	1914	2012-11-24 09:00:00	4.7999999999999998	SSW	\N	\N	\N	\N
1915	248	1915	2012-11-24 09:30:00	3.2000000000000002	SSW	\N	\N	\N	\N
1916	248	1916	2012-11-24 10:00:00	4.7999999999999998	WSW	\N	\N	\N	\N
1917	248	1917	2012-11-24 10:30:00	6.4000000000000004	WSW	\N	\N	\N	\N
1918	248	1918	2012-11-24 11:00:00	9.6999999999999993	W	\N	\N	\N	\N
1919	248	1919	2012-11-24 11:30:00	9.6999999999999993	WNW	\N	\N	\N	\N
1920	248	1920	2012-11-24 12:00:00	9.6999999999999993	WNW	\N	\N	\N	\N
1921	248	1921	2012-11-24 12:30:00	8	W	\N	\N	\N	\N
1922	248	1922	2012-11-24 13:00:00	9.6999999999999993	NW	\N	\N	\N	\N
1923	248	1923	2012-11-24 13:30:00	11.300000000000001	W	\N	\N	\N	\N
1924	248	1924	2012-11-24 14:00:00	9.6999999999999993	WNW	\N	\N	\N	\N
1925	248	1925	2012-11-24 14:30:00	3.2000000000000002	WNW	\N	\N	\N	\N
1926	248	1926	2012-11-24 15:00:00	9.6999999999999993	W	\N	\N	\N	\N
1927	248	1927	2012-11-24 15:30:00	8	SSE	\N	\N	\N	\N
1928	248	1928	2012-11-24 16:00:00	8	SW	\N	\N	\N	\N
1929	248	1929	2012-11-24 16:30:00	4.7999999999999998	WSW	\N	\N	\N	\N
1930	248	1930	2012-11-24 17:00:00	6.4000000000000004	SW	\N	\N	\N	\N
1931	248	1931	2012-11-24 17:30:00	4.7999999999999998	SW	\N	\N	\N	\N
1932	248	1932	2012-11-24 18:00:00	0	---	\N	\N	\N	\N
1933	248	1933	2012-11-24 18:30:00	0	---	\N	\N	\N	\N
1934	248	1934	2012-11-24 19:00:00	0	---	\N	\N	\N	\N
1935	248	1935	2012-11-24 19:30:00	3.2000000000000002	SW	\N	\N	\N	\N
1936	248	1936	2012-11-24 20:00:00	1.6000000000000001	SW	\N	\N	\N	\N
1937	248	1937	2012-11-24 20:30:00	3.2000000000000002	SW	\N	\N	\N	\N
1938	248	1938	2012-11-24 21:00:00	1.6000000000000001	SW	\N	\N	\N	\N
1939	248	1939	2012-11-24 21:30:00	3.2000000000000002	SW	\N	\N	\N	\N
1940	248	1940	2012-11-24 22:00:00	4.7999999999999998	SW	\N	\N	\N	\N
1941	248	1941	2012-11-24 22:30:00	3.2000000000000002	WSW	\N	\N	\N	\N
1942	248	1942	2012-11-24 23:00:00	0	---	\N	\N	\N	\N
1943	248	1943	2012-11-24 23:30:00	0	---	\N	\N	\N	\N
1944	248	1944	2012-11-25 00:00:00	0	---	\N	\N	\N	\N
1945	248	1945	2012-11-25 00:30:00	0	---	\N	\N	\N	\N
1946	248	1946	2012-11-25 01:00:00	0	---	\N	\N	\N	\N
1947	248	1947	2012-11-25 01:30:00	1.6000000000000001	WSW	\N	\N	\N	\N
1948	248	1948	2012-11-25 02:00:00	1.6000000000000001	WSW	\N	\N	\N	\N
1949	248	1949	2012-11-25 02:30:00	1.6000000000000001	WSW	\N	\N	\N	\N
1950	248	1950	2012-11-25 03:00:00	1.6000000000000001	WSW	\N	\N	\N	\N
1951	248	1951	2012-11-25 03:30:00	1.6000000000000001	SW	\N	\N	\N	\N
1952	248	1952	2012-11-25 04:00:00	1.6000000000000001	SW	\N	\N	\N	\N
1953	248	1953	2012-11-25 04:30:00	1.6000000000000001	SW	\N	\N	\N	\N
1954	248	1954	2012-11-25 05:00:00	1.6000000000000001	SW	\N	\N	\N	\N
1955	248	1955	2012-11-25 05:30:00	3.2000000000000002	S	\N	\N	\N	\N
1956	248	1956	2012-11-25 06:00:00	3.2000000000000002	SSE	\N	\N	\N	\N
1957	248	1957	2012-11-25 06:30:00	3.2000000000000002	WSW	\N	\N	\N	\N
1958	248	1958	2012-11-25 07:00:00	4.7999999999999998	SSW	\N	\N	\N	\N
1959	248	1959	2012-11-25 07:30:00	4.7999999999999998	SW	\N	\N	\N	\N
1960	248	1960	2012-11-25 08:00:00	8	SW	\N	\N	\N	\N
1961	248	1961	2012-11-25 08:30:00	6.4000000000000004	SSW	\N	\N	\N	\N
1962	248	1962	2012-11-25 09:00:00	6.4000000000000004	SSW	\N	\N	\N	\N
1963	248	1963	2012-11-25 09:30:00	6.4000000000000004	SW	\N	\N	\N	\N
1964	248	1964	2012-11-25 10:00:00	4.7999999999999998	S	\N	\N	\N	\N
1965	248	1965	2012-11-25 10:30:00	6.4000000000000004	SW	\N	\N	\N	\N
1966	248	1966	2012-11-25 11:00:00	9.6999999999999993	SW	\N	\N	\N	\N
1967	248	1967	2012-11-25 11:30:00	8	WSW	\N	\N	\N	\N
1968	248	1968	2012-11-25 12:00:00	9.6999999999999993	S	\N	\N	\N	\N
1969	248	1969	2012-11-25 12:30:00	9.6999999999999993	S	\N	\N	\N	\N
1970	248	1970	2012-11-25 13:00:00	8	S	\N	\N	\N	\N
1971	248	1971	2012-11-25 13:30:00	6.4000000000000004	SW	\N	\N	\N	\N
1972	248	1972	2012-11-25 14:00:00	8	SW	\N	\N	\N	\N
1973	248	1973	2012-11-25 14:30:00	8	S	\N	\N	\N	\N
1974	248	1974	2012-11-25 15:00:00	4.7999999999999998	S	\N	\N	\N	\N
1975	248	1975	2012-11-25 15:30:00	8	S	\N	\N	\N	\N
1976	248	1976	2012-11-25 16:00:00	9.6999999999999993	S	\N	\N	\N	\N
1977	248	1977	2012-11-25 16:30:00	8	SW	\N	\N	\N	\N
1978	248	1978	2012-11-25 17:00:00	4.7999999999999998	SSE	\N	\N	\N	\N
1979	248	1979	2012-11-25 17:30:00	6.4000000000000004	WSW	\N	\N	\N	\N
1980	248	1980	2012-11-25 18:00:00	6.4000000000000004	SW	\N	\N	\N	\N
1981	248	1981	2012-11-25 18:30:00	8	SW	\N	\N	\N	\N
1982	248	1982	2012-11-25 19:00:00	8	SW	\N	\N	\N	\N
1983	248	1983	2012-11-25 19:30:00	3.2000000000000002	SSW	\N	\N	\N	\N
1984	248	1984	2012-11-25 20:00:00	0	---	\N	\N	\N	\N
1985	248	1985	2012-11-25 20:30:00	1.6000000000000001	SSW	\N	\N	\N	\N
1986	248	1986	2012-11-25 21:00:00	0	---	\N	\N	\N	\N
1987	248	1987	2012-11-25 21:30:00	1.6000000000000001	SSW	\N	\N	\N	\N
1988	248	1988	2012-11-25 22:00:00	3.2000000000000002	SSW	\N	\N	\N	\N
1989	248	1989	2012-11-25 22:30:00	0	---	\N	\N	\N	\N
1990	248	1990	2012-11-25 23:00:00	3.2000000000000002	SSW	\N	\N	\N	\N
1991	248	1991	2012-11-25 23:30:00	0	---	\N	\N	\N	\N
1992	248	1992	2012-11-26 00:00:00	0	---	\N	\N	\N	\N
1993	248	1993	2012-11-26 00:30:00	3.2000000000000002	SSW	\N	\N	\N	\N
1994	248	1994	2012-11-26 01:00:00	0	---	\N	\N	\N	\N
1995	248	1995	2012-11-26 01:30:00	0	---	\N	\N	\N	\N
2001	248	2001	2012-11-26 04:30:00	3.2000000000000002	SW	\N	\N	\N	\N
2003	248	2003	2012-11-26 05:30:00	0	---	\N	\N	\N	\N
2007	248	2007	2012-11-26 07:30:00	0	---	\N	\N	\N	\N
2009	248	2009	2012-11-26 08:30:00	1.6000000000000001	S	\N	\N	\N	\N
2021	248	2021	2012-11-26 14:30:00	17.699999999999999	WNW	\N	\N	\N	\N
2025	248	2025	2012-11-26 16:30:00	11.300000000000001	WSW	\N	\N	\N	\N
2029	248	2029	2012-11-26 18:30:00	19.300000000000001	W	\N	\N	\N	\N
2033	248	2033	2012-11-26 20:30:00	14.5	W	\N	\N	\N	\N
2047	248	2047	2012-11-27 03:30:00	35.399999999999999	WNW	\N	\N	\N	\N
2048	248	2048	2012-11-27 04:00:00	30.600000000000001	W	\N	\N	\N	\N
2055	248	2055	2012-11-27 07:30:00	24.100000000000001	W	\N	\N	\N	\N
2058	248	2058	2012-11-27 09:00:00	27.399999999999999	W	\N	\N	\N	\N
2064	248	2064	2012-11-27 12:00:00	22.5	WSW	\N	\N	\N	\N
1996	248	1996	2012-11-26 02:00:00	0	---	\N	\N	\N	\N
2002	248	2002	2012-11-26 05:00:00	1.6000000000000001	SW	\N	\N	\N	\N
2019	248	2019	2012-11-26 13:30:00	17.699999999999999	W	\N	\N	\N	\N
2026	248	2026	2012-11-26 17:00:00	11.300000000000001	WSW	\N	\N	\N	\N
2031	248	2031	2012-11-26 19:30:00	17.699999999999999	W	\N	\N	\N	\N
2053	248	2053	2012-11-27 06:30:00	12.9	WNW	\N	\N	\N	\N
1997	248	1997	2012-11-26 02:30:00	0	---	\N	\N	\N	\N
1999	248	1999	2012-11-26 03:30:00	1.6000000000000001	SW	\N	\N	\N	\N
2012	248	2012	2012-11-26 10:00:00	20.899999999999999	W	\N	\N	\N	\N
2014	248	2014	2012-11-26 11:00:00	22.5	WNW	\N	\N	\N	\N
2018	248	2018	2012-11-26 13:00:00	19.300000000000001	WNW	\N	\N	\N	\N
2027	248	2027	2012-11-26 17:30:00	20.899999999999999	WSW	\N	\N	\N	\N
2030	248	2030	2012-11-26 19:00:00	17.699999999999999	W	\N	\N	\N	\N
2035	248	2035	2012-11-26 21:30:00	14.5	W	\N	\N	\N	\N
2038	248	2038	2012-11-26 23:00:00	20.899999999999999	W	\N	\N	\N	\N
2051	248	2051	2012-11-27 05:30:00	17.699999999999999	WSW	\N	\N	\N	\N
1998	248	1998	2012-11-26 03:00:00	4.7999999999999998	SW	\N	\N	\N	\N
2022	248	2022	2012-11-26 15:00:00	16.100000000000001	W	\N	\N	\N	\N
2023	248	2023	2012-11-26 15:30:00	12.9	W	\N	\N	\N	\N
2037	248	2037	2012-11-26 22:30:00	20.899999999999999	WSW	\N	\N	\N	\N
2054	248	2054	2012-11-27 07:00:00	22.5	W	\N	\N	\N	\N
2060	248	2060	2012-11-27 10:00:00	25.699999999999999	W	\N	\N	\N	\N
2062	248	2062	2012-11-27 11:00:00	27.399999999999999	W	\N	\N	\N	\N
2000	248	2000	2012-11-26 04:00:00	1.6000000000000001	SW	\N	\N	\N	\N
2004	248	2004	2012-11-26 06:00:00	0	---	\N	\N	\N	\N
2040	248	2040	2012-11-27 00:00:00	14.5	W	\N	\N	\N	\N
2052	248	2052	2012-11-27 06:00:00	20.899999999999999	W	\N	\N	\N	\N
2056	248	2056	2012-11-27 08:00:00	22.5	WNW	\N	\N	\N	\N
2059	248	2059	2012-11-27 09:30:00	29	WNW	\N	\N	\N	\N
2063	248	2063	2012-11-27 11:30:00	24.100000000000001	W	\N	\N	\N	\N
2005	248	2005	2012-11-26 06:30:00	1.6000000000000001	SW	\N	\N	\N	\N
2011	248	2011	2012-11-26 09:30:00	16.100000000000001	WNW	\N	\N	\N	\N
2013	248	2013	2012-11-26 10:30:00	20.899999999999999	W	\N	\N	\N	\N
2015	248	2015	2012-11-26 11:30:00	22.5	W	\N	\N	\N	\N
2017	248	2017	2012-11-26 12:30:00	20.899999999999999	WNW	\N	\N	\N	\N
2028	248	2028	2012-11-26 18:00:00	17.699999999999999	W	\N	\N	\N	\N
2050	248	2050	2012-11-27 05:00:00	20.899999999999999	WNW	\N	\N	\N	\N
2065	248	2065	2012-11-27 12:30:00	20.899999999999999	SW	\N	\N	\N	\N
2006	248	2006	2012-11-26 07:00:00	3.2000000000000002	SW	\N	\N	\N	\N
2008	248	2008	2012-11-26 08:00:00	3.2000000000000002	S	\N	\N	\N	\N
2010	248	2010	2012-11-26 09:00:00	0	---	\N	\N	\N	\N
2034	248	2034	2012-11-26 21:00:00	14.5	W	\N	\N	\N	\N
2043	248	2043	2012-11-27 01:30:00	22.5	W	\N	\N	\N	\N
2057	248	2057	2012-11-27 08:30:00	29	W	\N	\N	\N	\N
2016	248	2016	2012-11-26 12:00:00	20.899999999999999	W	\N	\N	\N	\N
2024	248	2024	2012-11-26 16:00:00	12.9	W	\N	\N	\N	\N
2036	248	2036	2012-11-26 22:00:00	19.300000000000001	W	\N	\N	\N	\N
2041	248	2041	2012-11-27 00:30:00	14.5	WSW	\N	\N	\N	\N
2046	248	2046	2012-11-27 03:00:00	32.200000000000003	W	\N	\N	\N	\N
2061	248	2061	2012-11-27 10:30:00	29	W	\N	\N	\N	\N
2066	248	2066	2012-11-27 13:00:00	24.100000000000001	W	\N	\N	\N	\N
2020	248	2020	2012-11-26 14:00:00	17.699999999999999	W	\N	\N	\N	\N
2032	248	2032	2012-11-26 20:00:00	19.300000000000001	W	\N	\N	\N	\N
2039	248	2039	2012-11-26 23:30:00	19.300000000000001	WNW	\N	\N	\N	\N
2042	248	2042	2012-11-27 01:00:00	17.699999999999999	W	\N	\N	\N	\N
2044	248	2044	2012-11-27 02:00:00	30.600000000000001	WNW	\N	\N	\N	\N
2045	248	2045	2012-11-27 02:30:00	32.200000000000003	W	\N	\N	\N	\N
2049	248	2049	2012-11-27 04:30:00	24.100000000000001	WNW	\N	\N	\N	\N
2067	248	2067	2012-11-27 13:30:00	20.899999999999999	WNW	\N	\N	\N	\N
2068	248	2068	2012-11-27 14:00:00	19.300000000000001	W	\N	\N	\N	\N
2069	248	2069	2012-11-27 14:30:00	25.699999999999999	W	\N	\N	\N	\N
2070	248	2070	2012-11-27 15:00:00	22.5	W	\N	\N	\N	\N
2071	248	2071	2012-11-27 15:30:00	22.5	WNW	\N	\N	\N	\N
2072	248	2072	2012-11-27 16:00:00	17.699999999999999	WNW	\N	\N	\N	\N
2073	248	2073	2012-11-27 16:30:00	14.5	W	\N	\N	\N	\N
2074	248	2074	2012-11-27 17:00:00	11.300000000000001	W	\N	\N	\N	\N
2075	248	2075	2012-11-27 17:30:00	3.2000000000000002	SW	\N	\N	\N	\N
2076	248	2076	2012-11-27 18:00:00	8	W	\N	\N	\N	\N
2077	248	2077	2012-11-27 18:30:00	8	SSW	\N	\N	\N	\N
2078	248	2078	2012-11-27 19:00:00	4.7999999999999998	S	\N	\N	\N	\N
2079	248	2079	2012-11-27 19:30:00	3.2000000000000002	S	\N	\N	\N	\N
2080	248	2080	2012-11-27 20:00:00	6.4000000000000004	S	\N	\N	\N	\N
2081	248	2081	2012-11-27 20:30:00	4.7999999999999998	SW	\N	\N	\N	\N
2082	248	2082	2012-11-27 21:00:00	4.7999999999999998	S	\N	\N	\N	\N
2083	248	2083	2012-11-27 21:30:00	4.7999999999999998	SSW	\N	\N	\N	\N
2084	248	2084	2012-11-27 22:00:00	1.6000000000000001	WSW	\N	\N	\N	\N
2085	248	2085	2012-11-27 22:30:00	1.6000000000000001	WSW	\N	\N	\N	\N
2086	248	2086	2012-11-27 23:00:00	1.6000000000000001	SW	\N	\N	\N	\N
2087	248	2087	2012-11-27 23:30:00	1.6000000000000001	SW	\N	\N	\N	\N
2088	248	2088	2012-11-28 00:00:00	4.7999999999999998	S	\N	\N	\N	\N
2089	248	2089	2012-11-28 00:30:00	3.2000000000000002	SW	\N	\N	\N	\N
2090	248	2090	2012-11-28 01:00:00	0	---	\N	\N	\N	\N
2091	248	2091	2012-11-28 01:30:00	0	---	\N	\N	\N	\N
2092	248	2092	2012-11-28 02:00:00	1.6000000000000001	SW	\N	\N	\N	\N
2093	248	2093	2012-11-28 02:30:00	1.6000000000000001	SW	\N	\N	\N	\N
2094	248	2094	2012-11-28 03:00:00	4.7999999999999998	SW	\N	\N	\N	\N
2095	248	2095	2012-11-28 03:30:00	3.2000000000000002	SSW	\N	\N	\N	\N
2096	248	2096	2012-11-28 04:00:00	1.6000000000000001	SSW	\N	\N	\N	\N
2097	248	2097	2012-11-28 04:30:00	4.7999999999999998	SW	\N	\N	\N	\N
2098	248	2098	2012-11-28 05:00:00	6.4000000000000004	SW	\N	\N	\N	\N
2099	248	2099	2012-11-28 05:30:00	4.7999999999999998	SSE	\N	\N	\N	\N
2100	248	2100	2012-11-28 06:00:00	1.6000000000000001	S	\N	\N	\N	\N
2101	248	2101	2012-11-28 06:30:00	1.6000000000000001	S	\N	\N	\N	\N
2102	248	2102	2012-11-28 07:00:00	1.6000000000000001	S	\N	\N	\N	\N
2103	248	2103	2012-11-28 07:30:00	1.6000000000000001	S	\N	\N	\N	\N
2104	248	2104	2012-11-28 08:00:00	1.6000000000000001	S	\N	\N	\N	\N
2105	248	2105	2012-11-28 08:30:00	1.6000000000000001	S	\N	\N	\N	\N
2106	248	2106	2012-11-28 09:00:00	4.7999999999999998	S	\N	\N	\N	\N
2107	248	2107	2012-11-28 09:30:00	4.7999999999999998	SW	\N	\N	\N	\N
2108	248	2108	2012-11-28 10:00:00	4.7999999999999998	SW	\N	\N	\N	\N
2109	248	2109	2012-11-28 10:30:00	9.6999999999999993	S	\N	\N	\N	\N
2110	248	2110	2012-11-28 11:00:00	9.6999999999999993	S	\N	\N	\N	\N
2111	248	2111	2012-11-28 11:30:00	9.6999999999999993	SSE	\N	\N	\N	\N
2112	248	2112	2012-11-28 12:00:00	9.6999999999999993	S	\N	\N	\N	\N
2113	248	2113	2012-11-28 12:30:00	4.7999999999999998	S	\N	\N	\N	\N
2114	248	2114	2012-11-28 13:00:00	12.9	SW	\N	\N	\N	\N
2115	248	2115	2012-11-28 13:30:00	19.300000000000001	SW	\N	\N	\N	\N
2116	248	2116	2012-11-28 14:00:00	14.5	S	\N	\N	\N	\N
2117	248	2117	2012-11-28 14:30:00	11.300000000000001	SW	\N	\N	\N	\N
2118	248	2118	2012-11-28 15:00:00	9.6999999999999993	S	\N	\N	\N	\N
2119	248	2119	2012-11-28 15:30:00	9.6999999999999993	S	\N	\N	\N	\N
2120	248	2120	2012-11-28 16:00:00	12.9	SSW	\N	\N	\N	\N
2121	248	2121	2012-11-28 16:30:00	11.300000000000001	SSE	\N	\N	\N	\N
2122	248	2122	2012-11-28 17:00:00	8	SSW	\N	\N	\N	\N
2123	248	2123	2012-11-28 17:30:00	4.7999999999999998	SSW	\N	\N	\N	\N
2124	248	2124	2012-11-28 18:00:00	4.7999999999999998	SSE	\N	\N	\N	\N
2125	248	2125	2012-11-28 18:30:00	4.7999999999999998	S	\N	\N	\N	\N
2126	248	2126	2012-11-28 19:00:00	9.6999999999999993	SSE	\N	\N	\N	\N
2127	248	2127	2012-11-28 19:30:00	9.6999999999999993	S	\N	\N	\N	\N
2128	248	2128	2012-11-28 20:00:00	9.6999999999999993	S	\N	\N	\N	\N
2129	248	2129	2012-11-28 20:30:00	11.300000000000001	SSE	\N	\N	\N	\N
2130	248	2130	2012-11-28 21:00:00	11.300000000000001	SSE	\N	\N	\N	\N
2131	248	2131	2012-11-28 21:30:00	4.7999999999999998	SW	\N	\N	\N	\N
2132	248	2132	2012-11-28 22:00:00	20.899999999999999	WNW	\N	\N	\N	\N
2133	248	2133	2012-11-28 22:30:00	22.5	WNW	\N	\N	\N	\N
2134	248	2134	2012-11-28 23:00:00	12.9	WSW	\N	\N	\N	\N
2135	248	2135	2012-11-28 23:30:00	11.300000000000001	SW	\N	\N	\N	\N
2136	248	2136	2012-11-29 00:00:00	8	SW	\N	\N	\N	\N
2137	248	2137	2012-11-29 00:30:00	12.9	WSW	\N	\N	\N	\N
2138	248	2138	2012-11-29 01:00:00	14.5	WSW	\N	\N	\N	\N
2139	248	2139	2012-11-29 01:30:00	14.5	SSE	\N	\N	\N	\N
2140	248	2140	2012-11-29 02:00:00	9.6999999999999993	SSE	\N	\N	\N	\N
2141	248	2141	2012-11-29 02:30:00	8	SW	\N	\N	\N	\N
2142	248	2142	2012-11-29 03:00:00	9.6999999999999993	WSW	\N	\N	\N	\N
2143	248	2143	2012-11-29 03:30:00	8	S	\N	\N	\N	\N
2144	248	2144	2012-11-29 04:00:00	3.2000000000000002	S	\N	\N	\N	\N
2145	248	2145	2012-11-29 04:30:00	1.6000000000000001	S	\N	\N	\N	\N
2146	248	2146	2012-11-29 05:00:00	3.2000000000000002	WSW	\N	\N	\N	\N
2147	248	2147	2012-11-29 05:30:00	3.2000000000000002	W	\N	\N	\N	\N
2148	248	2148	2012-11-29 06:00:00	6.4000000000000004	WSW	\N	\N	\N	\N
2149	248	2149	2012-11-29 06:30:00	0	---	\N	\N	\N	\N
2150	248	2150	2012-11-29 07:00:00	1.6000000000000001	S	\N	\N	\N	\N
2151	248	2151	2012-11-29 07:30:00	9.6999999999999993	NW	\N	\N	\N	\N
2152	248	2152	2012-11-29 08:00:00	11.300000000000001	NW	\N	\N	\N	\N
2153	248	2153	2012-11-29 08:30:00	14.5	NW	\N	\N	\N	\N
2154	248	2154	2012-11-29 09:00:00	11.300000000000001	NW	\N	\N	\N	\N
2155	248	2155	2012-11-29 09:30:00	11.300000000000001	W	\N	\N	\N	\N
2156	248	2156	2012-11-29 10:00:00	12.9	NW	\N	\N	\N	\N
2157	248	2157	2012-11-29 10:30:00	17.699999999999999	WNW	\N	\N	\N	\N
2160	248	2160	2012-11-29 12:00:00	14.5	NW	\N	\N	\N	\N
2162	248	2162	2012-11-29 13:00:00	12.9	WNW	\N	\N	\N	\N
2166	248	2166	2012-11-29 15:00:00	24.100000000000001	NNW	\N	\N	\N	\N
2158	248	2158	2012-11-29 11:00:00	19.300000000000001	WNW	\N	\N	\N	\N
2163	248	2163	2012-11-29 13:30:00	9.6999999999999993	WNW	\N	\N	\N	\N
2170	248	2170	2012-11-29 17:00:00	1.6000000000000001	NNW	\N	\N	\N	\N
2175	248	2175	2012-11-29 19:30:00	3.2000000000000002	WNW	\N	\N	\N	\N
2176	248	2176	2012-11-29 20:00:00	0	---	\N	\N	\N	\N
2159	248	2159	2012-11-29 11:30:00	22.5	NW	\N	\N	\N	\N
2167	248	2167	2012-11-29 15:30:00	27.399999999999999	NW	\N	\N	\N	\N
2171	248	2171	2012-11-29 17:30:00	0	---	\N	\N	\N	\N
2161	248	2161	2012-11-29 12:30:00	12.9	WNW	\N	\N	\N	\N
2164	248	2164	2012-11-29 14:00:00	6.4000000000000004	NW	\N	\N	\N	\N
2165	248	2165	2012-11-29 14:30:00	8	NW	\N	\N	\N	\N
2172	248	2172	2012-11-29 18:00:00	3.2000000000000002	NNW	\N	\N	\N	\N
2173	248	2173	2012-11-29 18:30:00	1.6000000000000001	WNW	\N	\N	\N	\N
2168	248	2168	2012-11-29 16:00:00	9.6999999999999993	N	\N	\N	\N	\N
2169	248	2169	2012-11-29 16:30:00	3.2000000000000002	NNW	\N	\N	\N	\N
2174	248	2174	2012-11-29 19:00:00	0	---	\N	\N	\N	\N
2177	248	2177	2012-11-29 20:30:00	3.2000000000000002	S	\N	\N	\N	\N
2178	248	2178	2012-11-29 21:00:00	3.2000000000000002	SSW	\N	\N	\N	\N
2179	248	2179	2012-11-29 21:30:00	3.2000000000000002	S	\N	\N	\N	\N
2180	248	2180	2012-11-29 22:00:00	0	---	\N	\N	\N	\N
2181	248	2181	2012-11-29 22:30:00	0	---	\N	\N	\N	\N
2182	248	2182	2012-11-29 23:00:00	11.300000000000001	E	\N	\N	\N	\N
2183	248	2183	2012-11-29 23:30:00	25.699999999999999	E	\N	\N	\N	\N
2184	248	2184	2012-11-30 00:00:00	24.100000000000001	E	\N	\N	\N	\N
2185	248	2185	2012-11-30 00:30:00	24.100000000000001	E	\N	\N	\N	\N
2186	248	2186	2012-11-30 01:00:00	22.5	SE	\N	\N	\N	\N
2187	248	2187	2012-11-30 01:30:00	12.9	ESE	\N	\N	\N	\N
2188	248	2188	2012-11-30 02:00:00	22.5	E	\N	\N	\N	\N
2189	248	2189	2012-11-30 02:30:00	27.399999999999999	ESE	\N	\N	\N	\N
2190	248	2190	2012-11-30 03:00:00	22.5	ESE	\N	\N	\N	\N
2191	248	2191	2012-11-30 03:30:00	12.9	E	\N	\N	\N	\N
2192	248	2192	2012-11-30 04:00:00	12.9	SE	\N	\N	\N	\N
2193	248	2193	2012-11-30 04:30:00	12.9	E	\N	\N	\N	\N
2194	248	2194	2012-11-30 05:00:00	12.9	ESE	\N	\N	\N	\N
2195	248	2195	2012-11-30 05:30:00	17.699999999999999	E	\N	\N	\N	\N
2196	248	2196	2012-11-30 06:00:00	16.100000000000001	ESE	\N	\N	\N	\N
2221	248	2221	2012-11-30 06:30:00	16.100000000000001	ESE	\N	\N	\N	\N
2222	248	2222	2012-11-30 07:00:00	12.9	ESE	\N	\N	\N	\N
2241	248	2241	2012-11-30 07:30:00	6.4000000000000004	ESE	\N	\N	\N	\N
2242	248	2242	2012-11-30 08:00:00	8	E	\N	\N	\N	\N
2243	248	2243	2012-11-30 08:30:00	4.7999999999999998	E	\N	\N	\N	\N
2244	248	2244	2012-11-30 09:00:00	3.2000000000000002	ESE	\N	\N	\N	\N
2245	248	2245	2012-11-30 09:30:00	4.7999999999999998	E	\N	\N	\N	\N
2246	248	2246	2012-11-30 10:00:00	8	E	\N	\N	\N	\N
2247	248	2247	2012-11-30 10:30:00	12.9	SE	\N	\N	\N	\N
2248	248	2248	2012-11-30 11:00:00	9.6999999999999993	E	\N	\N	\N	\N
2249	248	2249	2012-11-30 11:30:00	9.6999999999999993	E	\N	\N	\N	\N
2250	248	2250	2012-11-30 12:00:00	6.4000000000000004	ESE	\N	\N	\N	\N
2251	248	2251	2012-11-30 12:30:00	3.2000000000000002	E	\N	\N	\N	\N
2252	248	2252	2012-11-30 13:00:00	4.7999999999999998	E	\N	\N	\N	\N
2253	248	2253	2012-11-30 13:30:00	9.6999999999999993	E	\N	\N	\N	\N
2254	248	2254	2012-11-30 14:00:00	6.4000000000000004	ESE	\N	\N	\N	\N
2255	248	2255	2012-11-30 14:30:00	8	E	\N	\N	\N	\N
2256	248	2256	2012-11-30 15:00:00	4.7999999999999998	ENE	\N	\N	\N	\N
2257	248	2257	2012-11-30 15:30:00	8	ENE	\N	\N	\N	\N
2258	248	2258	2012-11-30 16:00:00	12.9	ENE	\N	\N	\N	\N
2259	248	2259	2012-11-30 16:30:00	4.7999999999999998	ESE	\N	\N	\N	\N
2260	248	2260	2012-11-30 17:00:00	4.7999999999999998	ENE	\N	\N	\N	\N
2261	248	2261	2012-11-30 17:30:00	1.6000000000000001	SE	\N	\N	\N	\N
2262	248	2262	2012-11-30 18:00:00	3.2000000000000002	SSE	\N	\N	\N	\N
2263	248	2263	2012-11-30 18:30:00	0	---	\N	\N	\N	\N
2264	248	2264	2012-11-30 19:00:00	0	---	\N	\N	\N	\N
2281	248	2281	2012-11-30 19:30:00	0	---	\N	\N	\N	\N
2282	248	2282	2012-11-30 20:00:00	11.300000000000001	E	\N	\N	\N	\N
2301	248	2301	2012-11-30 20:30:00	9.6999999999999993	E	\N	\N	\N	\N
2302	248	2302	2012-11-30 21:00:00	8	E	\N	\N	\N	\N
2303	248	2303	2012-11-30 21:30:00	3.2000000000000002	E	\N	\N	\N	\N
2304	248	2304	2012-11-30 22:00:00	3.2000000000000002	E	\N	\N	\N	\N
2321	248	2321	2012-11-30 22:30:00	8	E	\N	\N	\N	\N
2322	248	2322	2012-11-30 23:00:00	9.6999999999999993	E	\N	\N	\N	\N
\.


--
-- Data for Name: s_sensor_group_properties; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_sensor_group_properties (id, group_id, property, value, user_label, user_description, db_table, db_column, updated) FROM stdin;
1	181	ftp	svego.biz	\N	\N	\N	\N	2012-11-29 17:54:55.547
2	181	userName	svegobiz	\N	\N	\N	\N	2012-11-29 17:54:55.59
3	181	userPass	62Yc9h5guJ	\N	\N	\N	\N	2012-11-29 17:54:55.614
5	181	ftp_file2	\N	\N	\N	\N	\N	2012-11-29 17:54:55.658
6	181	localFile1	\N	\N	\N	\N	\N	2012-11-29 17:54:55.681
7	181	localFile2	\N	\N	\N	\N	\N	2012-11-29 17:54:55.702
8	181	pfDateFormat	MM/dd/yy	\N	\N	\N	\N	2012-11-29 17:54:55.713
10	181	threadSleep	120	\N	\N	\N	\N	2012-11-29 17:54:55.735
4	181	ftp_file1	public_ftp/incoming/meteoSipek/downld08.txt	\N	\N	\N	\N	2012-11-29 18:00:48.692
9	181	pfTimeFormat	K:mm a	\N	\N	\N	\N	2012-11-29 17:54:55.724
\.


--
-- Data for Name: s_sensor_groups; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_sensor_groups (id, user_id, name, description, active, visible, sensor_group_class) FROM stdin;
181	1	MeteoHub		t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub
\.


--
-- Data for Name: s_sensor_properties; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_sensor_properties (id, sensor_id, property, value, user_label, user_description, db_table, db_column, updated) FROM stdin;
141	241	col_temp	2	\N	\N	\N	\N	2012-11-29 17:27:07.282
142	241	col_temp_older_of	\N	\N	\N	\N	\N	2012-11-29 17:27:07.355
143	241	col_heat	\N	\N	\N	\N	\N	2012-11-29 17:27:07.366
144	241	col_heat_older_of	\N	\N	\N	\N	\N	2012-11-29 17:27:07.377
145	241	col_heat_index	13	\N	\N	\N	\N	2012-11-29 17:27:07.387
146	241	col_heat_index_older_of	\N	\N	\N	\N	\N	2012-11-29 17:27:07.399
147	241	col_thw_index	14	\N	\N	\N	\N	2012-11-29 17:27:07.41
148	241	col_thw_index_older_of	\N	\N	\N	\N	\N	2012-11-29 17:27:07.42
149	241	col_temp_high	3	\N	\N	\N	\N	2012-11-29 17:27:07.432
150	241	col_temp_low	4	\N	\N	\N	\N	2012-11-29 17:27:07.444
151	241	col_temp_high_low_older_of	\N	\N	\N	\N	\N	2012-11-29 17:27:07.454
152	241	col_heat_high	\N	\N	\N	\N	\N	2012-11-29 17:27:07.465
153	241	col_heat_low	\N	\N	\N	\N	\N	2012-11-29 17:27:07.475
154	241	col_heat_high_low_older_of	\N	\N	\N	\N	\N	2012-11-29 17:27:07.487
155	242	col_humidity	5	\N	\N	\N	\N	2012-11-29 17:27:52.158
156	242	col_humidity_older_of	\N	\N	\N	\N	\N	2012-11-29 17:27:52.18
157	244	col_moist	28	\N	\N	\N	\N	2012-11-29 17:29:36.306
158	244	col_moist_older_of	\N	\N	\N	\N	\N	2012-11-29 17:29:36.318
159	245	col_moist	29	\N	\N	\N	\N	2012-11-29 17:29:53.115
160	245	col_moist_older_of	\N	\N	\N	\N	\N	2012-11-29 17:29:53.145
161	246	col_rain	16	\N	\N	\N	\N	2012-11-29 17:30:30.323
162	246	col_rain_older_of	\N	\N	\N	\N	\N	2012-11-29 17:30:30.341
163	246	col_rain_rate	17	\N	\N	\N	\N	2012-11-29 17:30:30.35
164	246	col_rain_rate_older_of	\N	\N	\N	\N	\N	2012-11-29 17:30:30.361
165	247	col_bar	15	\N	\N	\N	\N	2012-11-29 17:30:51.906
166	247	col_bar_older_of	\N	\N	\N	\N	\N	2012-11-29 17:30:51.921
167	248	col_wind_speed	7	\N	\N	\N	\N	2012-11-29 17:33:01.019
168	248	col_wind_run	\N	\N	\N	\N	\N	2012-11-29 17:33:01.04
169	248	col_wind_dir	8	\N	\N	\N	\N	2012-11-29 17:33:01.05
170	248	col_wind_dir_degree	\N	\N	\N	\N	\N	2012-11-29 17:33:01.062
171	248	col_wind_chill	12	\N	\N	\N	\N	2012-11-29 17:33:01.073
172	248	col_wind_sample	32	\N	\N	\N	\N	2012-11-29 17:33:01.083
173	248	col_wind_tx	33	\N	\N	\N	\N	2012-11-29 17:33:01.094
174	248	col_wind_older_of	\N	\N	\N	\N	\N	2012-11-29 17:33:01.105
175	248	col_wind_hi_speed	10	\N	\N	\N	\N	2012-11-29 17:33:01.116
176	248	col_wind_hi_speed_dir	11	\N	\N	\N	\N	2012-11-29 17:33:01.127
177	248	col_wind_hi_speed_dir_degree	\N	\N	\N	\N	\N	2012-11-29 17:33:01.138
178	248	col_wind_low_speed	\N	\N	\N	\N	\N	2012-11-29 17:33:01.149
179	248	col_wind_low_speed_dir	\N	\N	\N	\N	\N	2012-11-29 17:33:01.16
180	248	col_wind_low_dir_degree	\N	\N	\N	\N	\N	2012-11-29 17:33:01.171
181	248	col_wind_high_low_older_of	\N	\N	\N	\N	\N	2012-11-29 17:33:01.182
182	249	col_heat	18	\N	\N	\N	\N	2012-11-29 17:33:55.397
183	249	col_heat_older_of	\N	\N	\N	\N	\N	2012-11-29 17:33:55.414
184	249	col_cool	19	\N	\N	\N	\N	2012-11-29 17:33:55.426
185	249	col_cool_older_of	\N	\N	\N	\N	\N	2012-11-29 17:33:55.437
186	250	col_wet	\N	\N	\N	\N	\N	2012-11-29 17:35:44.875
187	250	col_wet_older_of	\N	\N	\N	\N	\N	2012-11-29 17:35:44.978
188	250	col_dry	\N	\N	\N	\N	\N	2012-11-29 17:35:45.022
189	250	col_dry_older_of	\N	\N	\N	\N	\N	2012-11-29 17:35:45.069
190	250	col_dew_point	6	\N	\N	\N	\N	2012-11-29 17:35:45.113
191	250	col_dew_point_older_of	\N	\N	\N	\N	\N	2012-11-29 17:35:45.133
192	250	col_precipitation	\N	\N	\N	\N	\N	2012-11-29 17:35:45.144
193	250	col_precipitation_older_of	\N	\N	\N	\N	\N	2012-11-29 17:35:45.155
194	251	col_emc	24	\N	\N	\N	\N	2012-11-29 17:37:07.558
195	251	col_emc_older_of	\N	\N	\N	\N	\N	2012-11-29 17:37:07.57
196	252	col_temp	20	\N	\N	\N	\N	2012-11-29 17:39:19.744
197	252	col_temp_older_of	\N	\N	\N	\N	\N	2012-11-29 17:39:19.762
198	252	col_heat	23	\N	\N	\N	\N	2012-11-29 17:39:19.771
199	252	col_heat_older_of	\N	\N	\N	\N	\N	2012-11-29 17:39:19.782
200	252	col_heat_index	\N	\N	\N	\N	\N	2012-11-29 17:39:19.794
201	252	col_heat_index_older_of	\N	\N	\N	\N	\N	2012-11-29 17:39:19.826
202	252	col_thw_index	\N	\N	\N	\N	\N	2012-11-29 17:39:19.838
203	252	col_thw_index_older_of	\N	\N	\N	\N	\N	2012-11-29 17:39:19.849
204	252	col_temp_high	\N	\N	\N	\N	\N	2012-11-29 17:39:19.859
205	252	col_temp_low	\N	\N	\N	\N	\N	2012-11-29 17:39:19.87
206	252	col_temp_high_low_older_of	\N	\N	\N	\N	\N	2012-11-29 17:39:19.881
207	252	col_heat_high	\N	\N	\N	\N	\N	2012-11-29 17:39:19.892
208	252	col_heat_low	\N	\N	\N	\N	\N	2012-11-29 17:39:19.919
209	252	col_heat_high_low_older_of	\N	\N	\N	\N	\N	2012-11-29 17:39:19.947
210	253	col_wet	\N	\N	\N	\N	\N	2012-11-29 17:48:05.448
211	253	col_wet_older_of	\N	\N	\N	\N	\N	2012-11-29 17:48:05.465
212	253	col_dry	\N	\N	\N	\N	\N	2012-11-29 17:48:05.473
213	253	col_dry_older_of	\N	\N	\N	\N	\N	2012-11-29 17:48:05.484
214	253	col_dew_point	22	\N	\N	\N	\N	2012-11-29 17:48:05.495
215	253	col_dew_point_older_of	\N	\N	\N	\N	\N	2012-11-29 17:48:05.506
216	253	col_precipitation	\N	\N	\N	\N	\N	2012-11-29 17:48:05.517
217	253	col_precipitation_older_of	\N	\N	\N	\N	\N	2012-11-29 17:48:05.528
218	254	col_humidity	21	\N	\N	\N	\N	2012-11-29 17:48:36.953
219	254	col_humidity_older_of	\N	\N	\N	\N	\N	2012-11-29 17:48:36.97
220	255	col_humidity	27	\N	\N	\N	\N	2012-11-29 17:49:01.112
221	255	col_humidity_older_of	\N	\N	\N	\N	\N	2012-11-29 17:49:01.126
222	256	col_temp	26	\N	\N	\N	\N	2012-11-29 17:49:41.654
223	256	col_temp_older_of	\N	\N	\N	\N	\N	2012-11-29 17:49:41.669
224	256	col_heat	\N	\N	\N	\N	\N	2012-11-29 17:49:41.677
225	256	col_heat_older_of	\N	\N	\N	\N	\N	2012-11-29 17:49:41.688
226	256	col_heat_index	\N	\N	\N	\N	\N	2012-11-29 17:49:41.699
227	256	col_heat_index_older_of	\N	\N	\N	\N	\N	2012-11-29 17:49:41.71
228	256	col_thw_index	\N	\N	\N	\N	\N	2012-11-29 17:49:41.721
229	256	col_thw_index_older_of	\N	\N	\N	\N	\N	2012-11-29 17:49:41.732
230	256	col_temp_high	\N	\N	\N	\N	\N	2012-11-29 17:49:41.743
231	256	col_temp_low	\N	\N	\N	\N	\N	2012-11-29 17:49:41.754
232	256	col_temp_high_low_older_of	\N	\N	\N	\N	\N	2012-11-29 17:49:41.765
233	256	col_heat_high	\N	\N	\N	\N	\N	2012-11-29 17:49:41.779
234	256	col_heat_low	\N	\N	\N	\N	\N	2012-11-29 17:49:41.787
235	256	col_heat_high_low_older_of	\N	\N	\N	\N	\N	2012-11-29 17:49:41.798
236	257	col_temp	30	\N	\N	\N	\N	2012-11-29 17:50:29.868
237	257	col_temp_older_of	\N	\N	\N	\N	\N	2012-11-29 17:50:29.972
238	257	col_heat	\N	\N	\N	\N	\N	2012-11-29 17:50:29.988
239	257	col_heat_older_of	\N	\N	\N	\N	\N	2012-11-29 17:50:29.999
240	257	col_heat_index	\N	\N	\N	\N	\N	2012-11-29 17:50:30.011
241	257	col_heat_index_older_of	\N	\N	\N	\N	\N	2012-11-29 17:50:30.021
242	257	col_thw_index	\N	\N	\N	\N	\N	2012-11-29 17:50:30.032
243	257	col_thw_index_older_of	\N	\N	\N	\N	\N	2012-11-29 17:50:30.044
244	257	col_temp_high	\N	\N	\N	\N	\N	2012-11-29 17:50:30.055
245	257	col_temp_low	\N	\N	\N	\N	\N	2012-11-29 17:50:30.066
246	257	col_temp_high_low_older_of	\N	\N	\N	\N	\N	2012-11-29 17:50:30.077
247	257	col_heat_high	\N	\N	\N	\N	\N	2012-11-29 17:50:30.088
248	257	col_heat_low	\N	\N	\N	\N	\N	2012-11-29 17:50:30.099
249	257	col_heat_high_low_older_of	\N	\N	\N	\N	\N	2012-11-29 17:50:30.109
250	258	col_density	25	\N	\N	\N	\N	2012-11-29 17:51:02.381
251	258	col_density_older_of	\N	\N	\N	\N	\N	2012-11-29 17:51:02.4
252	259	col_wet	31	\N	\N	\N	\N	2012-11-29 17:51:51.081
253	259	col_wet_older_of	\N	\N	\N	\N	\N	2012-11-29 17:51:51.108
254	259	col_dry	\N	\N	\N	\N	\N	2012-11-29 17:51:51.129
255	259	col_dry_older_of	\N	\N	\N	\N	\N	2012-11-29 17:51:51.151
256	259	col_dew_point	\N	\N	\N	\N	\N	2012-11-29 17:51:51.173
257	259	col_dew_point_older_of	\N	\N	\N	\N	\N	2012-11-29 17:51:51.195
258	259	col_precipitation	\N	\N	\N	\N	\N	2012-11-29 17:51:51.217
259	259	col_precipitation_older_of	\N	\N	\N	\N	\N	2012-11-29 17:51:51.239
\.


--
-- Data for Name: s_sensor_raw_data; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_sensor_raw_data (id, group_id, when_created, date_time, data) FROM stdin;
1801	181	2012-11-29 20:29:11.332	2012-11-22 00:30:00	11/22/12 12:30a    8.6    8.6    8.6    96    8.0   0.0   ---   0.00   0.0   ---    8.6    8.8    8.8  1023.5  0.00   0.0   0.204   0.000   18.7    50    8.0   17.8   9.34 1.2096    12.2     80     11       8     8.9      0    690    1    100.0   30 
1802	181	2012-11-29 20:29:11.713	2012-11-22 01:00:00	11/22/12  1:00a    8.6    8.6    8.6    96    8.0   0.0   ---   0.00   0.0   ---    8.6    8.8    8.8  1023.5  0.00   0.0   0.204   0.000   18.6    50    7.9   17.6   9.34 1.2102    12.2     80     11       8     8.9      0    698    1    100.0   30 
1803	181	2012-11-29 20:29:11.944	2012-11-22 01:30:00	11/22/12  1:30a    8.6    8.6    8.6    96    8.0   0.0   ---   0.00   0.0   ---    8.6    8.8    8.8  1023.7  0.00   0.0   0.204   0.000   18.6    50    7.9   17.6   9.34 1.2105    12.2     80     11       8     8.9      0    684    1    100.0   30 
1804	181	2012-11-29 20:29:12.175	2012-11-22 02:00:00	11/22/12  2:00a    8.4    8.6    8.4    96    7.8   0.0   ---   0.00   0.0   ---    8.4    8.7    8.7  1024.0  0.00   0.0   0.206   0.000   18.5    50    7.9   17.6   9.34 1.2110    12.2     80     11       8     8.9      0    698    1    100.0   30 
1805	181	2012-11-29 20:29:12.406	2012-11-22 02:30:00	11/22/12  2:30a    8.4    8.5    8.4    96    7.8   0.0   ---   0.00   0.0   ---    8.4    8.7    8.7  1024.0  0.00   0.0   0.206   0.000   18.5    50    7.9   17.6   9.34 1.2111    12.2     80     11       8     8.9      0    689    1    100.0   30 
1806	181	2012-11-29 20:29:12.64	2012-11-22 03:00:00	11/22/12  3:00a    8.4    8.4    8.4    96    7.8   0.0   SSW   0.00   3.2   SSW    8.4    8.6    8.6  1023.9  0.00   0.0   0.207   0.000   18.4    50    7.8   17.4   9.35 1.2116    12.2     80     11       8     8.9      0    693    1    100.0   30 
1807	181	2012-11-29 20:29:12.872	2012-11-22 03:30:00	11/22/12  3:30a    8.4    8.4    8.4    96    7.8   0.0   SSW   0.00   3.2   SSW    8.4    8.7    8.7  1023.9  0.00   0.0   0.206   0.000   18.4    50    7.8   17.4   9.35 1.2116    12.2     80     11       8     8.9      0    690    1    100.0   30 
1808	181	2012-11-29 20:29:13.103	2012-11-22 04:00:00	11/22/12  4:00a    8.3    8.4    8.3    96    7.7   0.0   SSW   0.00   1.6   SSW    8.3    8.5    8.5  1023.9  0.00   0.0   0.208   0.000   18.3    50    7.7   17.3   9.35 1.2120    12.2     80     11       8     8.9      0    691    1    100.0   30 
1809	181	2012-11-29 20:29:13.331	2012-11-22 04:30:00	11/22/12  4:30a    8.3    8.3    8.3    97    7.9   0.0   ---   0.00   0.0   ---    8.3    8.6    8.6  1024.0  0.00   0.0   0.208   0.000   18.3    50    7.7   17.3   9.35 1.2122    12.2     80     12       8     8.9      0    691    1    100.0   30 
1810	181	2012-11-29 20:29:13.562	2012-11-22 05:00:00	11/22/12  5:00a    8.3    8.3    8.3    97    7.8   0.0   ---   0.00   0.0   ---    8.3    8.5    8.5  1024.1  0.00   0.0   0.209   0.000   18.2    50    7.6   17.3   9.35 1.2126    12.2     80     12       8     8.9      0    698    1    100.0   30 
1811	181	2012-11-29 20:29:13.796	2012-11-22 05:30:00	11/22/12  5:30a    8.3    8.3    8.3    97    7.9   0.0   ---   0.00   0.0   ---    8.3    8.6    8.6  1024.5  0.00   0.0   0.208   0.000   18.2    50    7.6   17.3   9.35 1.2130    12.2     80     12       8     8.9      0    682    1     99.7   30 
1812	181	2012-11-29 20:29:14.026	2012-11-22 06:00:00	11/22/12  6:00a    8.3    8.3    8.3    97    7.8   0.0   ---   0.00   0.0   ---    8.3    8.5    8.5  1024.7  0.00   0.0   0.209   0.000   18.1    50    7.5   17.2   9.36 1.2139    12.2     80     12       8     8.9      0    701    1    100.0   30 
1813	181	2012-11-29 20:29:14.256	2012-11-22 06:30:00	11/22/12  6:30a    8.3    8.3    8.3    97    7.9   0.0   ---   0.00   0.0   ---    8.3    8.6    8.6  1024.8  0.00   0.0   0.208   0.000   18.1    50    7.5   17.2   9.36 1.2139    12.2     80     12       8     8.9      0    681    1     99.6   30 
1814	181	2012-11-29 20:29:14.488	2012-11-22 07:00:00	11/22/12  7:00a    8.3    8.3    8.3    97    7.9   0.0   ---   0.00   0.0   ---    8.3    8.6    8.6  1025.2  0.00   0.0   0.208   0.000   18.1    50    7.5   17.2   9.36 1.2144    12.2     80     12       8     8.9      0    699    1    100.0   30 
1815	181	2012-11-29 20:29:14.72	2012-11-22 07:30:00	11/22/12  7:30a    8.4    8.4    8.3    97    8.0   0.0   ---   0.00   0.0   ---    8.4    8.7    8.7  1025.5  0.00   0.0   0.206   0.000   18.1    50    7.5   17.1   9.36 1.2151    12.2     80     12       8     8.9      0    694    1    100.0   30 
1816	181	2012-11-29 20:29:14.971	2012-11-22 08:00:00	11/22/12  8:00a    8.6    8.7    8.4    97    8.2   0.0   ---   0.00   0.0   ---    8.6    8.8    8.8  1025.8  0.00   0.0   0.203   0.000   18.1    50    7.5   17.1   9.36 1.2154    12.2     80     12       8     8.9      0    687    1    100.0   30 
1817	181	2012-11-29 20:29:15.281	2012-11-22 08:30:00	11/22/12  8:30a    8.9    8.9    8.6    96    8.3   0.0   ---   0.00   0.0   ---    8.9    9.1    9.1  1026.0  0.00   0.0   0.197   0.000   18.1    50    7.5   17.1   9.36 1.2157    12.2     80     12       8     8.9      0    693    1    100.0   30 
1818	181	2012-11-29 20:29:15.512	2012-11-22 09:00:00	11/22/12  9:00a    9.2    9.2    8.9    95    8.4   0.0   SSW   0.00   1.6   SSW    9.2    9.4    9.4  1026.2  0.00   0.0   0.191   0.000   17.9    50    7.4   16.9   9.36 1.2165    12.2     80     12       8     8.9      0    695    1    100.0   30 
1819	181	2012-11-29 20:29:15.743	2012-11-22 09:30:00	11/22/12  9:30a    9.3    9.3    9.2    93    8.3   1.6   NNW   0.80   4.8   NNW    9.3    9.6    9.6  1026.5  0.00   0.0   0.188   0.000   17.9    50    7.4   16.9   9.36 1.2168    12.2     80     12       8     8.9      0    690    1    100.0   30 
1820	181	2012-11-29 20:29:15.998	2012-11-22 10:00:00	11/22/12 10:00a    9.6    9.6    9.3    93    8.5   1.6     N   0.80   4.8     N    9.6    9.8    9.8  1026.7  0.00   0.0   0.183   0.000   17.8    50    7.3   16.8   9.37 1.2176    12.2     80     12       8     8.9      0    702    1    100.0   30 
1821	181	2012-11-29 20:29:16.374	2012-11-22 10:30:00	11/22/12 10:30a    9.7    9.7    9.6    93    8.6   0.0    NE   0.00   4.8    NE    9.7    9.9    9.9  1026.8  0.00   0.0   0.181   0.000   17.8    50    7.3   16.8   9.37 1.2177    12.2     80     12       8     8.9      0    682    1     99.7   30 
1822	181	2012-11-29 20:29:16.648	2012-11-22 11:00:00	11/22/12 11:00a    9.7    9.7    9.7    92    8.5   1.6     E   0.80   6.4    NE    9.7    9.9    9.9  1026.6  0.00   0.0   0.179   0.000   17.8    50    7.2   16.8   9.37 1.2177    12.2     81     12       8     8.9      0    701    1    100.0   30 
1823	181	2012-11-29 20:29:16.891	2012-11-22 11:30:00	11/22/12 11:30a   10.0   10.0    9.7    91    8.6   0.0   ENE   0.00   3.2     E   10.0   10.2   10.2  1026.3  0.00   0.0   0.174   0.000   17.8    52    7.8   16.9   9.75 1.2166    12.2     81     12       8     9.4      0    687    1    100.0   30 
1824	181	2012-11-29 20:29:17.121	2012-11-22 12:00:00	11/22/12 12:00p   10.1   10.1   10.0    91    8.7   0.0     E   0.00   4.8     E   10.1   10.2   10.2  1026.2  0.00   0.0   0.172   0.000   18.4    56    9.4   17.8  10.45 1.2127    12.8     81     12       8     9.4      0    692    1    100.0   30 
1825	181	2012-11-29 20:29:17.353	2012-11-22 12:30:00	11/22/12 12:30p   10.2   10.2   10.1    90    8.7   1.6   ENE   0.80   4.8     E   10.2   10.4   10.4  1026.1  0.00   0.0   0.169   0.000   18.8    58   10.4   18.3  10.75 1.2099    12.8     80     12       8     9.4      0    690    1    100.0   30 
1826	181	2012-11-29 20:29:17.583	2012-11-22 13:00:00	11/22/12  1:00p   10.3   10.3   10.2    90    8.8   1.6   ENE   0.80   4.8     E   10.3   10.4   10.4  1026.0  0.00   0.0   0.167   0.000   19.3    60   11.3   18.9  11.05 1.2069    13.3     80     11       8     9.4      0    693    1    100.0   30 
1827	181	2012-11-29 20:29:17.813	2012-11-22 13:30:00	11/22/12  1:30p   10.2   10.3   10.2    91    8.8   1.6    NE   0.80   4.8   ENE   10.2   10.4   10.4  1025.8  0.00   0.0   0.169   0.000   19.6    60   11.6   19.3  11.05 1.2053    13.3     79     11       8     9.4      0    691    1    100.0   30 
1828	181	2012-11-29 20:29:18.046	2012-11-22 14:00:00	11/22/12  2:00p   10.2   10.3   10.2    91    8.8   1.6   ENE   0.80   4.8    NE   10.2   10.3   10.3  1025.7  0.00   0.0   0.170   0.000   19.6    57   10.8   19.2  10.61 1.2059    13.3     79     11       8     9.4      0    699    1    100.0   30 
1829	181	2012-11-29 20:29:18.278	2012-11-22 14:30:00	11/22/12  2:30p   10.2   10.2   10.1    91    8.8   1.6   ENE   0.80   4.8   ENE   10.2   10.3   10.3  1025.6  0.00   0.0   0.170   0.000   19.7    57   10.9   19.3  10.60 1.2053    13.3     79     11       8     9.4      0    681    1     99.6   30 
1830	181	2012-11-29 20:29:18.508	2012-11-22 15:00:00	11/22/12  3:00p   10.2   10.2   10.2    91    8.8   0.0     E   0.00   3.2   ENE   10.2   10.3   10.3  1025.7  0.00   0.0   0.170   0.000   19.7    56   10.7   19.3  10.40 1.2054    13.3     80     11       8     9.4      0    699    1    100.0   30 
1831	181	2012-11-29 20:29:18.739	2012-11-22 15:30:00	11/22/12  3:30p   10.1   10.2   10.1    91    8.7   0.0    NE   0.00   3.2    NE   10.1   10.2   10.2  1025.8  0.00   0.0   0.172   0.000   19.8    55   10.5   19.4  10.20 1.2052    13.3     80     11       8     9.4      0    691    1    100.0   30 
1832	181	2012-11-29 20:29:18.97	2012-11-22 16:00:00	11/22/12  4:00p    9.9   10.1    9.9    92    8.7   0.0   ---   0.00   0.0   ---    9.9   10.2   10.2  1026.0  0.00   0.0   0.175   0.000   19.9    55   10.6   19.5  10.19 1.2049    13.3     80     11       8     9.4      0    692    1    100.0   30 
1833	181	2012-11-29 20:29:19.202	2012-11-22 16:30:00	11/22/12  4:30p    9.8   10.0    9.8    92    8.6   0.0   ---   0.00   0.0   ---    9.8   10.1   10.1  1026.1  0.00   0.0   0.177   0.000   20.0    54   10.4   19.5  10.03 1.2050    13.3     80     11       8     9.4      0    696    1    100.0   30 
1834	181	2012-11-29 20:29:19.434	2012-11-22 17:00:00	11/22/12  5:00p    9.7    9.8    9.7    93    8.6   0.0   ENE   0.00   1.6   ENE    9.7    9.9    9.9  1026.2  0.00   0.0   0.179   0.000   20.1    54   10.5   19.6  10.02 1.2046    13.3     80     11       8     9.4      0    683    1     99.9   30 
1835	181	2012-11-29 20:29:19.664	2012-11-22 17:30:00	11/22/12  5:30p    9.6    9.7    9.6    93    8.5   0.0   ---   0.00   0.0   ---    9.6    9.8    9.8  1026.1  0.00   0.0   0.183   0.000   20.3    55   10.9   19.8  10.18 1.2034    13.9     80     11       8     9.4      0    696    1    100.0   30 
1836	181	2012-11-29 20:29:19.896	2012-11-22 18:00:00	11/22/12  6:00p    9.4    9.6    9.4    94    8.5   0.0   ENE   0.00   1.6   ENE    9.4    9.7    9.7  1026.1  0.00   0.0   0.186   0.000   20.5    55   11.1   19.9  10.17 1.2022    13.9     79     11       8     9.4      0    696    1    100.0   30 
1837	181	2012-11-29 20:29:20.126	2012-11-22 18:30:00	11/22/12  6:30p    9.3    9.4    9.3    94    8.4   0.0     E   0.00   1.6     E    9.3    9.6    9.6  1026.0  0.00   0.0   0.188   0.000   20.7    55   11.3   20.1  10.17 1.2012    13.9     79     11       8     9.4      0    685    1    100.0   30 
1838	181	2012-11-29 20:29:20.369	2012-11-22 19:00:00	11/22/12  7:00p    9.3    9.3    9.3    94    8.4   0.0     E   0.00   3.2     E    9.3    9.5    9.5  1026.1  0.00   0.0   0.189   0.000   20.8    54   11.1   20.1   9.97 1.2011    13.9     79     12       8     9.4      0    700    1    100.0   30 
1839	181	2012-11-29 20:29:20.601	2012-11-22 19:30:00	11/22/12  7:30p    9.2    9.3    9.2    94    8.3   0.0   ---   0.00   0.0   ---    9.2    9.4    9.4  1025.9  0.00   0.0   0.190   0.000   20.7    54   11.0   20.1   9.98 1.2015    13.9     79     12       8     9.4      0    686    1    100.0   30 
1840	181	2012-11-29 20:29:20.876	2012-11-22 20:00:00	11/22/12  8:00p    9.1    9.2    9.1    95    8.4   0.0   ---   0.00   0.0   ---    9.1    9.3    9.3  1026.0  0.00   0.0   0.192   0.000   20.7    54   11.0   20.1   9.98 1.2016    13.9     79     12       8     9.4      0    692    1    100.0   30 
1841	181	2012-11-29 20:29:21.14	2012-11-22 20:30:00	11/22/12  8:30p    9.0    9.1    8.9    95    8.2   0.0     E   0.00   1.6     E    9.0    9.2    9.2  1026.1  0.00   0.0   0.194   0.000   20.8    53   10.8   20.1   9.86 1.2014    13.9     79     12       8     9.4      0    688    1    100.0   30 
1842	181	2012-11-29 20:29:21.37	2012-11-22 21:00:00	11/22/12  9:00p    8.9    9.0    8.9    95    8.2   0.0   ---   0.00   0.0   ---    8.9    9.2    9.2  1026.1  0.00   0.0   0.196   0.000   20.9    53   10.9   20.2   9.86 1.2008    13.9     79     12       8     9.4      0    688    1    100.0   30 
1843	181	2012-11-29 20:29:21.602	2012-11-22 21:30:00	11/22/12  9:30p    8.9    8.9    8.9    95    8.1   0.0   ---   0.00   0.0   ---    8.9    9.1    9.1  1025.9  0.00   0.0   0.197   0.000   20.9    53   10.9   20.2   9.86 1.2006    13.9     79     12       8     9.4      0    690    1    100.0   30 
1844	181	2012-11-29 20:29:22.053	2012-11-22 22:00:00	11/22/12 10:00p    8.8    8.9    8.8    96    8.2   0.0     E   0.00   1.6     E    8.8    9.1    9.1  1025.8  0.00   0.0   0.198   0.000   20.9    53   11.0   20.2   9.86 1.2002    13.9     79     12       8     9.4      0    693    1    100.0   30 
1845	181	2012-11-29 20:29:22.284	2012-11-22 22:30:00	11/22/12 10:30p    8.8    8.8    8.8    96    8.2   0.0     E   0.00   1.6     E    8.8    9.1    9.1  1025.8  0.00   0.0   0.198   0.000   20.9    52   10.7   20.2   9.66 1.2005    13.9     78     12       8     9.4      0    689    1    100.0   30 
1846	181	2012-11-29 20:29:22.517	2012-11-22 23:00:00	11/22/12 11:00p    8.8    8.8    8.8    96    8.2   0.0     E   0.00   1.6     E    8.8    9.0    9.0  1025.6  0.00   0.0   0.199   0.000   20.9    52   10.7   20.1   9.66 1.2005    13.9     79     12       8     9.4      0    701    1    100.0   30 
1847	181	2012-11-29 20:29:22.747	2012-11-22 23:30:00	11/22/12 11:30p    8.7    8.8    8.7    95    7.9   0.0     E   0.00   3.2     E    8.7    8.9    8.9  1025.5  0.00   0.0   0.201   0.000   20.8    52   10.6   20.0   9.66 1.2009    13.9     79     12       8     9.4      0    681    1     99.6   30 
1848	181	2012-11-29 20:29:22.977	2012-11-23 00:00:00	11/23/12 12:00a    8.6    8.7    8.6    95    7.9   0.0     E   0.00   3.2     E    8.6    8.8    8.8  1025.4  0.00   0.0   0.203   0.000   20.7    52   10.5   19.9   9.67 1.2014    13.9     78     12       8     9.4      0    696    1    100.0   30 
1849	181	2012-11-29 20:29:23.208	2012-11-23 00:30:00	11/23/12 12:30a    8.6    8.6    8.5    95    7.8   0.0     E   0.00   3.2     E    8.6    8.7    8.7  1025.2  0.00   0.0   0.204   0.000   20.6    52   10.4   19.9   9.67 1.2017    13.9     78     12       8     9.4      0    692    1    100.0   30 
1850	181	2012-11-29 20:29:23.44	2012-11-23 01:00:00	11/23/12  1:00a    8.4    8.6    8.4    95    7.7   0.0     E   0.00   3.2     E    8.4    8.6    8.6  1025.0  0.00   0.0   0.206   0.000   20.5    51   10.0   19.8   9.47 1.2021    13.9     78     12       8     9.4      0    683    1     99.9   30 
1851	181	2012-11-29 20:29:23.673	2012-11-23 01:30:00	11/23/12  1:30a    8.3    8.4    8.3    95    7.6   0.0     E   0.00   4.8     E    8.3    8.5    8.5  1025.0  0.00   0.0   0.208   0.000   20.4    51    9.9   19.7   9.48 1.2026    13.3     78     12       8     9.4      0    701    1    100.0   30 
1861	181	2012-11-29 20:29:26.029	2012-11-23 06:30:00	11/23/12  6:30a    8.0    8.1    8.0    96    7.4   0.0   ---   0.00   0.0   ---    8.0    8.2    8.2  1024.1  0.00   0.0   0.215   0.000   19.7    50    9.0   18.9   9.30 1.2051    13.3     79     12       8     9.4      1    691    1    100.0   30 
1875	181	2012-11-29 20:29:29.287	2012-11-23 13:30:00	11/23/12  1:30p   10.1   10.2    9.8    94    9.1   0.0   SSW   0.00   1.6   SSW   10.1   10.3   10.3  1023.4  0.00   0.0   0.172   0.000   20.8    54   11.1   20.1   9.97 1.1979    13.9     79     12       8     9.4      0    699    1    100.0   30 
1877	181	2012-11-29 20:29:29.751	2012-11-23 14:30:00	11/23/12  2:30p   10.1   10.2   10.1    94    9.2   0.0   SSW   0.00   3.2   SSW   10.1   10.3   10.3  1023.3  0.00   0.0   0.171   0.000   20.9    53   11.0   20.2   9.86 1.1973    14.4     79     12       8     9.4      0    703    1    100.0   30 
1893	181	2012-11-29 20:29:33.514	2012-11-23 22:30:00	11/23/12 10:30p    8.8    8.8    8.8    97    8.3   0.0   ---   0.00   0.0   ---    8.8    9.1    9.1  1025.3  0.00   0.0   0.199   0.000   21.7    54   12.0   21.2   9.93 1.1954    14.4     78     12       8     9.4     15    694    1    100.0   30 
1912	181	2012-11-29 20:29:37.952	2012-11-24 08:00:00	11/24/12  8:00a    6.9    6.9    6.4    98    6.7   0.0   SSW   0.00   1.6   SSW    6.9    7.1    7.1  1025.3  0.00   0.0   0.237   0.000   20.5    50    9.7   19.7   9.27 1.2027    13.9     75     12       8     8.9     10    684    1    100.0   30 
1914	181	2012-11-29 20:29:38.425	2012-11-24 09:00:00	11/24/12  9:00a    7.9    7.9    7.6    98    7.6   0.0   SSW   0.00   4.8   SSW    7.9    8.2    8.2  1025.4  0.00   0.0   0.216   0.000   20.4    50    9.6   19.6   9.28 1.2033    13.3     75     12       8     8.9      1    693    1    100.0   30 
1916	181	2012-11-29 20:29:39.076	2012-11-24 10:00:00	11/24/12 10:00a    9.9    9.9    9.2    98    9.6   0.0   SSW   0.00   4.8   WSW    9.9   10.3   10.3  1025.5  0.00   0.0   0.175   0.000   20.2    51    9.8   19.6   9.48 1.2040    13.3     77     12       8     8.9      0    702    1    100.0   30 
1918	181	2012-11-29 20:29:39.539	2012-11-24 11:00:00	11/24/12 11:00a   11.6   11.6   10.6    89    9.8   4.8    NW   2.41   9.7     W   11.6   11.6   11.6  1025.2  0.00   0.0   0.141   0.000   20.2    51    9.8   19.6   9.48 1.2037    13.9     78     12       8     8.9      0    698    1    100.0   30 
1922	181	2012-11-29 20:29:40.464	2012-11-24 13:00:00	11/24/12  1:00p   12.2   12.3   12.2    77    8.3   3.2   WNW   1.61   9.7    NW   12.2   12.0   12.0  1024.4  0.00   0.0   0.127   0.000   20.6    51   10.1   19.8   9.47 1.2010    14.4     77     12       8     9.4      0    684    1    100.0   30 
1924	181	2012-11-29 20:29:40.927	2012-11-24 14:00:00	11/24/12  2:00p   12.3   12.5   12.3    76    8.2   3.2   WNW   1.61   9.7   WNW   12.3   12.1   12.1  1024.3  0.00   0.0   0.125   0.000   20.7    51   10.2   19.9   9.47 1.2003    14.4     76     12       8     9.4      0    686    1    100.0   30 
1930	181	2012-11-29 20:29:42.522	2012-11-24 17:00:00	11/24/12  5:00p    8.9    9.7    8.9    93    7.9   0.0    SW   0.00   6.4    SW    8.9    9.1    9.1  1024.0  0.00   0.0   0.196   0.000   20.7    50    9.9   19.8   9.27 1.2003    14.4     76     12       8    10.0      0    683    1     99.9   30 
1959	181	2012-11-29 20:29:49.363	2012-11-25 07:30:00	11/25/12  7:30a    3.2    3.2    3.2    98    2.9   0.0   SSW   0.00   4.8    SW    3.2    3.3    3.3  1021.9  0.00   0.0   0.315   0.000   18.4    47    6.9   17.3   8.85 1.2098    12.2     68     13       8     8.3     15    698    1    100.0   30 
1965	181	2012-11-29 20:29:50.747	2012-11-25 10:30:00	11/25/12 10:30a    5.9    6.0    5.1    98    5.7   1.6    SW   0.80   6.4    SW    5.9    6.1    6.1  1022.3  0.00   0.0   0.258   0.000   18.4    48    7.2   17.3   8.95 1.2100    12.2     71     13       9     8.3      0    683    1     99.9   30 
1967	181	2012-11-29 20:29:51.231	2012-11-25 11:30:00	11/25/12 11:30a    7.7    7.7    6.8    98    7.4   1.6     S   0.80   8.0   WSW    7.7    7.9    7.9  1021.5  0.00   0.0   0.222   0.000   18.8    48    7.6   17.8   8.93 1.2069    12.8     73     13       9     8.3      0    688    1    100.0   30 
1969	181	2012-11-29 20:29:51.705	2012-11-25 12:30:00	11/25/12 12:30p    9.4    9.4    8.2    96    8.8   3.2     S   1.61   9.7     S    9.4    9.7    9.7  1021.1  0.00   0.0   0.186   0.000   19.1    48    7.8   18.2   8.92 1.2051    12.8     74     13       9     8.3      0    689    1    100.0   30 
1971	181	2012-11-29 20:29:52.212	2012-11-25 13:30:00	11/25/12  1:30p   10.4   10.4   10.1    91    9.0   0.0     S   0.00   6.4    SW   10.4   10.6   10.6  1020.7  0.00   0.0   0.164   0.000   19.1    49    8.1   18.2   9.12 1.2044    12.8     75     13       9     8.3      0    688    1    100.0   30 
1981	181	2012-11-29 20:29:54.671	2012-11-25 18:30:00	11/25/12  6:30p    7.9    8.1    7.9    98    7.6   0.0   SSW   0.00   8.0    SW    7.9    8.2    8.2  1020.9  0.00   0.0   0.216   0.000   19.9    49    8.9   19.2   9.09 1.2005    13.3     76     13       9     8.9      1    694    1    100.0   30 
1995	181	2012-11-29 20:29:58.119	2012-11-26 01:30:00	11/26/12  1:30a    6.6    6.7    6.6    98    6.3   0.0   ---   0.00   0.0   ---    6.6    6.8    6.8  1020.7  0.00   0.0   0.244   0.000   19.6    49    8.5   18.7   9.11 1.2021    12.8     75     13       9     8.9     13    697    1    100.0   30 
1997	181	2012-11-29 20:29:58.613	2012-11-26 02:30:00	11/26/12  2:30a    6.5    6.6    6.5    98    6.2   0.0   ---   0.00   0.0   ---    6.5    6.7    6.7  1020.4  0.00   0.0   0.247   0.000   19.4    48    8.1   18.6   8.91 1.2027    12.8     75     13       9     8.9     11    699    1    100.0   30 
2013	181	2012-11-29 20:30:02.324	2012-11-26 10:30:00	11/26/12 10:30a   12.3   12.3   11.8    82    9.3  11.3     W   5.63  20.9     W   11.2   12.2   11.1  1018.6  0.00   0.0   0.125   0.000   18.7    49    7.7   17.7   9.14 1.2040    12.8     77     13       9     8.9      0    686    1    100.0   30 
2030	181	2012-11-29 20:30:06.299	2012-11-26 19:00:00	11/26/12  7:00p   13.3   13.7   13.3    74    8.7   8.0     W   4.02  17.7     W   12.9   12.9   12.6  1015.0  0.00   0.0   0.105   0.000   19.8    50    9.1   19.1   9.30 1.1938    13.9     77     13       9    10.0      0    696    1    100.0   30 
2036	181	2012-11-29 20:30:07.721	2012-11-26 22:00:00	11/26/12 10:00p   11.9   11.9   11.7    78    8.2   8.0   WNW   4.02  19.3     W   11.3   11.7   11.1  1014.1  0.00   0.0   0.133   0.000   19.6    49    8.5   18.7   9.11 1.1943    13.3     77     13       9     9.4      0    691    1    100.0   30 
2067	181	2012-11-29 20:30:15.008	2012-11-27 13:30:00	11/27/12  1:30p   16.8   17.1   16.6    59    8.8   9.7     W   4.83  20.9   WNW   16.8   16.2   16.2  1010.5  0.00   0.0   0.031   0.000   18.8    48    7.5   17.8   8.93 1.1941    13.3     76     13       8     9.4      0    700    1    100.0   30 
1852	181	2012-11-29 20:29:23.903	2012-11-23 02:00:00	11/23/12  2:00a    8.3    8.3    8.3    96    7.7   0.0     E   0.00   3.2     E    8.3    8.4    8.4  1025.1  0.00   0.0   0.209   0.000   20.4    51    9.9   19.7   9.48 1.2027    13.3     79     12       8     9.4      0    683    1     99.9   30 
1854	181	2012-11-29 20:29:24.365	2012-11-23 03:00:00	11/23/12  3:00a    8.2    8.2    8.2    96    7.6   0.0   ---   0.00   0.0   ---    8.2    8.4    8.4  1024.7  0.00   0.0   0.211   0.000   20.2    51    9.8   19.6   9.48 1.2030    13.3     79     12       8     9.4      9    692    1    100.0   30 
1856	181	2012-11-29 20:29:24.827	2012-11-23 04:00:00	11/23/12  4:00a    8.2    8.2    8.1    96    7.6   0.0   ---   0.00   0.0   ---    8.2    8.3    8.3  1024.3  0.00   0.0   0.212   0.000   20.0    51    9.6   19.3   9.49 1.2037    13.3     78     12       8     9.4      4    694    1    100.0   30 
1858	181	2012-11-29 20:29:25.291	2012-11-23 05:00:00	11/23/12  5:00a    8.1    8.2    8.1    96    7.5   0.0     E   0.00   1.6     E    8.1    8.2    8.2  1024.0  0.00   0.0   0.214   0.000   19.9    50    9.2   19.2   9.29 1.2039    13.3     78     12       8     9.4      0    692    1    100.0   30 
1862	181	2012-11-29 20:29:26.258	2012-11-23 07:00:00	11/23/12  7:00a    8.0    8.0    8.0    97    7.6   0.0   ---   0.00   0.0   ---    8.0    8.2    8.2  1024.1  0.00   0.0   0.215   0.000   19.7    50    8.9   18.9   9.30 1.2055    13.3     79     12       8     9.4      1    698    1    100.0   30 
1864	181	2012-11-29 20:29:26.723	2012-11-23 08:00:00	11/23/12  8:00a    8.1    8.1    8.0    97    7.6   0.0   ---   0.00   0.0   ---    8.1    8.3    8.3  1024.3  0.00   0.0   0.214   0.000   19.4    50    8.7   18.7   9.31 1.2068    12.8     79     12       8     9.4      4    698    1    100.0   30 
1870	181	2012-11-29 20:29:28.131	2012-11-23 11:00:00	11/23/12 11:00a    8.7    8.7    8.6    98    8.4   0.0   SSW   0.00   3.2   SSW    8.7    9.0    9.0  1024.4  0.00   0.0   0.200   0.000   19.4    54    9.9   18.9  10.07 1.2058    13.3     80     12       8     9.4     15    684    1    100.0   30 
1899	181	2012-11-29 20:29:34.903	2012-11-24 01:30:00	11/24/12  1:30a    7.9    7.9    7.9    98    7.6   0.0   ---   0.00   0.0   ---    7.9    8.2    8.2  1025.3  0.00   0.0   0.216   0.000   21.3    53   11.4   20.6   9.83 1.1977    13.9     78     12       8     9.4     15    682    1     99.7   30 
1905	181	2012-11-29 20:29:36.323	2012-11-24 04:30:00	11/24/12  4:30a    5.9    6.1    5.9    97    5.5   0.0   ---   0.00   0.0   ---    5.9    6.1    6.1  1024.9  0.00   0.0   0.258   0.000   21.1    51   10.5   20.2   9.45 1.1992    13.9     75     12       8     9.4     15    701    1    100.0   30 
1907	181	2012-11-29 20:29:36.785	2012-11-24 05:30:00	11/24/12  5:30a    6.2    6.2    6.1    98    5.9   0.0   SSW   0.00   1.6   SSW    6.2    6.3    6.3  1024.9  0.00   0.0   0.252   0.000   20.9    51   10.4   20.1   9.46 1.1999    13.9     76     12       8     9.4     14    685    1    100.0   30 
1909	181	2012-11-29 20:29:37.248	2012-11-24 06:30:00	11/24/12  6:30a    6.2    6.2    6.2    98    5.9   0.0   ---   0.00   0.0   ---    6.2    6.3    6.3  1024.9  0.00   0.0   0.253   0.000   20.8    51   10.3   20.0   9.46 1.2006    13.9     75     12       8     8.9     13    684    1    100.0   30 
1911	181	2012-11-29 20:29:37.72	2012-11-24 07:30:00	11/24/12  7:30a    6.4    6.4    6.2    98    6.1   0.0   ---   0.00   0.0   ---    6.4    6.6    6.6  1025.2  0.00   0.0   0.249   0.000   20.6    50    9.8   19.8   9.27 1.2023    13.9     75     12       8     8.9     12    697    1    100.0   30 
1921	181	2012-11-29 20:29:40.233	2012-11-24 12:30:00	11/24/12 12:30p   12.2   12.2   11.7    83    9.4   1.6   WNW   0.80   8.0     W   12.2   12.1   12.1  1024.8  0.00   0.0   0.128   0.000   20.6    51   10.1   19.8   9.47 1.2015    13.9     78     12       8     9.4      0    697    1    100.0   30 
1935	181	2012-11-29 20:29:43.679	2012-11-24 19:30:00	11/24/12  7:30p    4.7    5.7    4.7    95    4.0   0.0    SW   0.00   3.2    SW    4.7    4.8    4.8  1024.1  0.00   0.0   0.284   0.000   20.3    50    9.5   19.5   9.28 1.2024    13.9     73     12       8     9.4      1    683    1     99.9   30 
1937	181	2012-11-29 20:29:44.142	2012-11-24 20:30:00	11/24/12  8:30p    4.2    4.4    4.2    96    3.6   0.0    SW   0.00   3.2    SW    4.2    4.2    4.2  1024.0  0.00   0.0   0.295   0.000   20.2    49    9.2   19.4   9.08 1.2028    13.9     71     12       8     9.4      2    693    1    100.0   30 
1953	181	2012-11-29 20:29:47.973	2012-11-25 04:30:00	11/25/12  4:30a    3.4    3.4    3.2    98    3.2   0.0    SW   0.00   1.6    SW    3.4    3.5    3.5  1021.6  0.00   0.0   0.310   0.000   18.8    47    7.3   17.8   8.83 1.2074    12.2     67     13       8     8.3     15    692    1    100.0   30 
1972	181	2012-11-29 20:29:52.444	2012-11-25 14:00:00	11/25/12  2:00p   10.2   10.4   10.2    92    9.0   1.6     S   0.80   8.0    SW   10.2   10.4   10.4  1020.7  0.00   0.0   0.169   0.000   19.1    49    8.1   18.2   9.12 1.2044    12.8     76     13       9     8.3      0    700    1    100.0   30 
1974	181	2012-11-29 20:29:52.906	2012-11-25 15:00:00	11/25/12  3:00p    8.9    9.8    8.9    94    8.0   1.6     S   0.80   4.8     S    8.9    9.2    9.2  1020.7  0.00   0.0   0.196   0.000   19.3    49    8.3   18.4   9.12 1.2035    13.3     76     13       9     8.9      0    699    1    100.0   30 
1976	181	2012-11-29 20:29:53.402	2012-11-25 16:00:00	11/25/12  4:00p    8.2    8.3    8.1    97    7.7   1.6   SSW   0.80   9.7     S    8.2    8.4    8.4  1020.8  0.00   0.0   0.212   0.000   19.6    49    8.5   18.7   9.11 1.2023    13.3     75     13       9     8.9      0    702    1    100.0   30 
1978	181	2012-11-29 20:29:53.876	2012-11-25 17:00:00	11/25/12  5:00p    8.0    8.1    8.0    97    7.6   0.0     S   0.00   4.8   SSE    8.0    8.2    8.2  1021.0  0.00   0.0   0.215   0.000   19.7    49    8.7   18.9   9.10 1.2017    13.3     75     13       9     8.9      0    694    1    100.0   30 
1982	181	2012-11-29 20:29:54.904	2012-11-25 19:00:00	11/25/12  7:00p    7.8    7.9    7.8    98    7.5   0.0   SSW   0.00   8.0    SW    7.8    8.0    8.0  1021.1  0.00   0.0   0.220   0.000   20.0    49    9.0   19.2   9.09 1.2005    13.3     76     13       9     8.9      2    694    1    100.0   30 
1984	181	2012-11-29 20:29:55.365	2012-11-25 20:00:00	11/25/12  8:00p    7.8    7.8    7.8    98    7.5   0.0   ---   0.00   0.0   ---    7.8    8.1    8.1  1021.3  0.00   0.0   0.219   0.000   20.2    49    9.2   19.4   9.08 1.1996    13.3     75     13       9     8.9      8    695    1    100.0   30 
1990	181	2012-11-29 20:29:56.785	2012-11-25 23:00:00	11/25/12 11:00p    7.1    7.3    7.1    98    6.8   0.0   SSW   0.00   3.2   SSW    7.1    7.3    7.3  1021.0  0.00   0.0   0.234   0.000   20.0    49    9.0   19.2   9.09 1.2004    13.3     75     13       9     8.9     15    698    1    100.0   30 
2041	181	2012-11-29 20:30:08.909	2012-11-27 00:30:00	11/27/12 12:30a   12.0   12.0   11.7    77    8.1   6.4     W   3.22  14.5   WSW   11.7   11.8   11.4  1013.4  0.00   0.0   0.132   0.000   19.4    49    8.4   18.6   9.11 1.1944    13.3     77     13       9     9.4      0    698    1    100.0   30 
2050	181	2012-11-29 20:30:10.99	2012-11-27 05:00:00	11/27/12  5:00a   11.8   12.3   11.8    77    7.9  12.9     W   6.44  20.9   WNW   10.3   11.6   10.1  1011.5  0.00   0.0   0.135   0.000   19.0    48    7.7   18.0   8.93 1.1942    13.3     77     13       8     9.4      0    689    1    100.0   30 
1853	181	2012-11-29 20:29:24.135	2012-11-23 02:30:00	11/23/12  2:30a    8.2    8.3    8.2    96    7.6   0.0     E   0.00   1.6     E    8.2    8.4    8.4  1024.9  0.00   0.0   0.211   0.000   20.3    51    9.8   19.6   9.48 1.2030    13.3     79     12       8     9.4      0    699    1    100.0   30 
1872	181	2012-11-29 20:29:28.593	2012-11-23 12:00:00	11/23/12 12:00p    9.1    9.1    8.8    98    8.8   0.0   SSW   0.00   4.8   SSW    9.1    9.4    9.4  1023.9  0.00   0.0   0.192   0.000   20.3    58   11.7   19.9  10.75 1.1999    13.9     79     12       8     9.4      1    692    1    100.0   30 
1874	181	2012-11-29 20:29:29.057	2012-11-23 13:00:00	11/23/12  1:00p    9.8    9.8    9.4    96    9.2   0.0   SSW   0.00   3.2   SSW    9.8   10.1   10.1  1023.3  0.00   0.0   0.177   0.000   20.7    55   11.3   20.1  10.17 1.1981    13.9     79     12       8     9.4      1    691    1    100.0   30 
1876	181	2012-11-29 20:29:29.518	2012-11-23 14:00:00	11/23/12  2:00p   10.2   10.2   10.1    94    9.2   0.0   SSW   0.00   1.6   SSW   10.2   10.4   10.4  1023.3  0.00   0.0   0.170   0.000   20.9    53   10.9   20.2   9.86 1.1975    13.9     79     12       8     9.4      0    681    1     99.6   30 
1878	181	2012-11-29 20:29:29.981	2012-11-23 15:00:00	11/23/12  3:00p   10.0   10.1   10.0    93    8.9   0.0   SSW   0.00   3.2   SSW   10.0   10.2   10.2  1023.6  0.00   0.0   0.174   0.000   20.9    54   11.2   20.2   9.97 1.1976    14.4     79     12       8     9.4      0    680    1     99.4   30 
1882	181	2012-11-29 20:29:30.923	2012-11-23 17:00:00	11/23/12  5:00p    9.3    9.4    9.3    95    8.6   0.0   SSW   0.00   4.8   SSW    9.3    9.6    9.6  1023.9  0.00   0.0   0.188   0.000   21.2    54   11.5   20.4   9.95 1.1965    15.0     78     12       8     9.4      1    692    1    100.0   30 
1884	181	2012-11-29 20:29:31.402	2012-11-23 18:00:00	11/23/12  6:00p    9.1    9.2    9.1    96    8.5   0.0   SSW   0.00   4.8   SSW    9.1    9.4    9.4  1024.3  0.00   0.0   0.192   0.000   21.4    54   11.7   20.8   9.94 1.1956    15.0     78     12       8     9.4     10    691    1    100.0   30 
1890	181	2012-11-29 20:29:32.821	2012-11-23 21:00:00	11/23/12  9:00p    8.8    8.9    8.8    97    8.4   0.0   SSW   0.00   1.6   SSW    8.8    9.1    9.1  1025.3  0.20   0.0   0.198   0.000   22.0    54   12.3   21.6   9.92 1.1940    15.0     77     12       8     9.4     15    699    1    100.0   30 
1919	181	2012-11-29 20:29:39.771	2012-11-24 11:30:00	11/24/12 11:30a   11.5   11.6   11.4    87    9.4   4.8   WNW   2.41   9.7   WNW   11.5   11.5   11.5  1025.0  0.00   0.0   0.142   0.000   20.4    51    9.9   19.7   9.48 1.2026    13.9     78     12       8     9.4      0    688    1    100.0   30 
1925	181	2012-11-29 20:29:41.18	2012-11-24 14:30:00	11/24/12  2:30p   12.4   12.4   12.3    74    7.9   0.0   WNW   0.00   3.2   WNW   12.4   12.2   12.2  1024.3  0.00   0.0   0.123   0.000   20.8    51   10.3   20.0   9.46 1.1998    14.4     76     12       8     9.4      0    689    1    100.0   30 
1927	181	2012-11-29 20:29:41.642	2012-11-24 15:30:00	11/24/12  3:30p   11.7   12.8   11.7    86    9.4   1.6     S   0.80   8.0   SSE   11.7   11.6   11.6  1024.0  0.00   0.0   0.139   0.000   20.8    49    9.7   19.9   9.06 1.2001    14.4     76     12       8    10.0      0    692    1    100.0   30 
1929	181	2012-11-29 20:29:42.291	2012-11-24 16:30:00	11/24/12  4:30p    9.7   10.8    9.7    91    8.3   0.0     S   0.00   4.8   WSW    9.7    9.9    9.9  1024.1  0.00   0.0   0.179   0.000   20.8    50   10.0   19.9   9.26 1.1999    14.4     76     12       8    10.0      0    692    1    100.0   30 
1931	181	2012-11-29 20:29:42.753	2012-11-24 17:30:00	11/24/12  5:30p    8.3    8.9    8.3    94    7.4   0.0    SW   0.00   4.8    SW    8.3    8.5    8.5  1024.1  0.00   0.0   0.208   0.000   20.6    50    9.8   19.8   9.27 1.2011    14.4     76     12       8    10.0      0    697    1    100.0   30 
1941	181	2012-11-29 20:29:45.145	2012-11-24 22:30:00	11/24/12 10:30p    3.4    3.7    3.4    97    3.0   0.0   WSW   0.00   3.2   WSW    3.4    3.4    3.4  1023.5  0.00   0.0   0.310   0.000   19.9    49    8.9   19.2   9.09 1.2036    13.3     69     12       8     9.4     13    698    1    100.0   30 
1955	181	2012-11-29 20:29:48.436	2012-11-25 05:30:00	11/25/12  5:30a    3.6    3.6    3.4    98    3.3   0.0     S   0.00   3.2     S    3.6    3.6    3.6  1021.3  0.00   0.0   0.308   0.000   18.7    47    7.1   17.6   8.84 1.2078    12.2     68     13       8     8.3     15    684    1    100.0   30 
1957	181	2012-11-29 20:29:48.899	2012-11-25 06:30:00	11/25/12  6:30a    3.4    3.5    3.4    98    3.2   0.0    SW   0.00   3.2   WSW    3.4    3.5    3.5  1021.6  0.00   0.0   0.310   0.000   18.6    47    7.0   17.4   8.84 1.2087    12.2     68     13       8     8.3     15    691    1    100.0   30 
1973	181	2012-11-29 20:29:52.675	2012-11-25 14:30:00	11/25/12  2:30p    9.8   10.3    9.8    92    8.6   1.6     S   0.80   8.0     S    9.8   10.1   10.1  1020.7  0.00   0.0   0.177   0.000   19.1    49    8.1   18.2   9.12 1.2043    12.8     76     13       9     8.9      0    683    1     99.9   30 
1992	181	2012-11-29 20:29:57.414	2012-11-26 00:00:00	11/26/12 12:00a    6.9    7.1    6.9    98    6.7   0.0   ---   0.00   0.0   ---    6.9    7.1    7.1  1021.1  0.00   0.0   0.237   0.000   19.8    49    8.8   19.1   9.10 1.2013    12.8     76     13       9     8.9     15    700    1    100.0   30 
1994	181	2012-11-29 20:29:57.889	2012-11-26 01:00:00	11/26/12  1:00a    6.6    6.7    6.6    98    6.3   0.0   ---   0.00   0.0   ---    6.6    6.8    6.8  1020.7  0.00   0.0   0.244   0.000   19.7    49    8.6   18.8   9.10 1.2017    12.8     75     13       9     8.9     14    694    1    100.0   30 
1996	181	2012-11-29 20:29:58.382	2012-11-26 02:00:00	11/26/12  2:00a    6.6    6.6    6.6    98    6.3   0.0   ---   0.00   0.0   ---    6.6    6.7    6.7  1020.5  0.00   0.0   0.245   0.000   19.4    48    8.1   18.6   8.91 1.2028    12.8     75     13       9     8.9     12    683    1     99.9   30 
1998	181	2012-11-29 20:29:58.845	2012-11-26 03:00:00	11/26/12  3:00a    6.4    6.5    6.4    98    6.1   0.0   SSW   0.00   4.8    SW    6.4    6.6    6.6  1020.1  0.20   0.0   0.249   0.000   19.4    48    8.1   18.5   8.91 1.2025    12.8     75     13       9     8.9     10    686    1    100.0   30 
2002	181	2012-11-29 20:29:59.769	2012-11-26 05:00:00	11/26/12  5:00a    6.3    6.4    6.3    98    6.0   0.0    SW   0.00   1.6    SW    6.3    6.5    6.5  1019.8  0.00   0.0   0.250   0.000   19.1    48    7.8   18.2   8.92 1.2036    12.8     74     13       9     8.9     10    696    1    100.0   30 
2004	181	2012-11-29 20:30:00.233	2012-11-26 06:00:00	11/26/12  6:00a    6.4    6.4    6.3    98    6.2   0.0   ---   0.00   0.0   ---    6.4    6.6    6.6  1019.4  0.00   0.0   0.248   0.000   19.0    48    7.7   18.0   8.93 1.2037    12.8     74     13       9     8.9      8    687    1    100.0   30 
2010	181	2012-11-29 20:30:01.62	2012-11-26 09:00:00	11/26/12  9:00a    8.3    8.3    7.5    98    8.0   0.0   ---   0.00   0.0   ---    8.3    8.6    8.6  1019.0  0.00   0.0   0.208   0.000   18.7    48    7.4   17.7   8.94 1.2048    12.2     76     13       9     8.9      1    702    1    100.0   30 
2020	181	2012-11-29 20:30:03.986	2012-11-26 14:00:00	11/26/12  2:00p   15.7   15.7   14.7    71   10.5   9.7   WNW   4.83  17.7     W   15.6   15.4   15.2  1016.0  0.00   0.0   0.054   0.000   19.4    49    8.4   18.6   9.11 1.1974    13.9     77     13       9     9.4      0    701    1    100.0   30 
1855	181	2012-11-29 20:29:24.598	2012-11-23 03:30:00	11/23/12  3:30a    8.2    8.2    8.2    96    7.6   0.0   ---   0.00   0.0   ---    8.2    8.3    8.3  1024.4  0.00   0.0   0.212   0.000   20.1    51    9.7   19.4   9.49 1.2033    13.3     78     12       8     9.4      8    690    1    100.0   30 
1857	181	2012-11-29 20:29:25.058	2012-11-23 04:30:00	11/23/12  4:30a    8.1    8.2    8.1    96    7.5   0.0   ---   0.00   0.0   ---    8.1    8.3    8.3  1024.1  0.00   0.0   0.213   0.000   19.9    51    9.5   19.3   9.49 1.2038    13.3     78     12       8     9.4      2    690    1    100.0   30 
1873	181	2012-11-29 20:29:28.825	2012-11-23 12:30:00	11/23/12 12:30p    9.4    9.4    9.1    97    9.0   1.6     S   0.80   4.8     S    9.4    9.7    9.7  1023.6  0.00   0.0   0.185   0.000   20.6    56   11.5   20.1  10.37 1.1987    13.9     79     12       8     9.4      1    692    1    100.0   30 
1892	181	2012-11-29 20:29:33.284	2012-11-23 22:00:00	11/23/12 10:00p    8.8    8.8    8.8    97    8.3   0.0   SSW   0.00   3.2   SSW    8.8    9.1    9.1  1025.2  0.00   0.0   0.199   0.000   21.8    54   12.1   21.2   9.93 1.1950    14.4     78     12       8     9.4     15    697    1    100.0   30 
1894	181	2012-11-29 20:29:33.747	2012-11-23 23:00:00	11/23/12 11:00p    8.6    8.8    8.5    97    8.1   0.0   ---   0.00   0.0   ---    8.6    8.8    8.8  1025.5  0.00   0.0   0.204   0.000   21.6    54   11.9   21.0   9.93 1.1961    14.4     78     12       8     9.4     15    682    1     99.7   30 
1896	181	2012-11-29 20:29:34.209	2012-11-24 00:00:00	11/24/12 12:00a    8.1    8.3    8.1    97    7.6   0.0   ---   0.00   0.0   ---    8.1    8.3    8.3  1025.1  0.00   0.0   0.214   0.000   21.5    54   11.8   20.8   9.94 1.1963    14.4     78     12       8     9.4     15    684    1    100.0   30 
1898	181	2012-11-29 20:29:34.672	2012-11-24 01:00:00	11/24/12  1:00a    7.9    7.9    7.7    98    7.6   0.0   ---   0.00   0.0   ---    7.9    8.1    8.1  1025.3  0.00   0.0   0.218   0.000   21.4    54   11.7   20.8   9.94 1.1967    14.4     78     12       8     9.4     15    691    1    100.0   30 
1902	181	2012-11-29 20:29:35.595	2012-11-24 03:00:00	11/24/12  3:00a    7.1    7.4    7.1    97    6.6   0.0   ---   0.00   0.0   ---    7.1    7.2    7.2  1025.0  0.00   0.0   0.235   0.000   21.2    52   11.0   20.4   9.65 1.1981    14.4     77     12       8     9.4     15    692    1    100.0   30 
1904	181	2012-11-29 20:29:36.092	2012-11-24 04:00:00	11/24/12  4:00a    6.1    6.7    6.1    97    5.6   0.0   SSW   0.00   1.6   SSW    6.1    6.2    6.2  1024.8  0.00   0.0   0.256   0.000   21.1    52   10.8   20.2   9.65 1.1987    13.9     76     12       8     9.4     15    682    1     99.7   30 
1910	181	2012-11-29 20:29:37.49	2012-11-24 07:00:00	11/24/12  7:00a    6.1    6.2    6.1    98    5.8   0.0   ---   0.00   0.0   ---    6.1    6.2    6.2  1025.0  0.00   0.0   0.255   0.000   20.7    50    9.9   19.8   9.27 1.2015    13.9     75     12       8     8.9     13    692    1    100.0   30 
1939	181	2012-11-29 20:29:44.66	2012-11-24 21:30:00	11/24/12  9:30p    3.7    4.1    3.7    96    3.1   0.0    SW   0.00   3.2    SW    3.7    3.7    3.7  1023.9  0.00   0.0   0.306   0.000   20.0    49    9.0   19.2   9.09 1.2038    13.3     70     12       8     9.4      2    695    1    100.0   30 
1945	181	2012-11-29 20:29:46.102	2012-11-25 00:30:00	11/25/12 12:30a    1.9    2.3    1.9    97    1.5   0.0   ---   0.00   0.0   ---    1.9    1.9    1.9  1023.1  0.00   0.0   0.343   0.000   19.6    48    8.2   18.7   8.91 1.2053    12.8     66     13       8     8.9     15    683    1     99.9   30 
1947	181	2012-11-29 20:29:46.563	2012-11-25 01:30:00	11/25/12  1:30a    1.9    1.9    1.8    97    1.5   0.0   WSW   0.00   1.6   WSW    1.9    1.9    1.9  1022.7  0.00   0.0   0.343   0.000   19.4    48    8.1   18.5   8.91 1.2056    12.8     65     13       8     8.9     15    693    1    100.0   30 
1949	181	2012-11-29 20:29:47.049	2012-11-25 02:30:00	11/25/12  2:30a    2.8    2.8    2.4    98    2.5   0.0   WSW   0.00   1.6   WSW    2.8    2.9    2.9  1022.6  0.00   0.0   0.323   0.000   19.2    47    7.6   18.2   8.82 1.2066    12.8     66     13       8     8.9     15    694    1    100.0   30 
1951	181	2012-11-29 20:29:47.51	2012-11-25 03:30:00	11/25/12  3:30a    3.0    3.1    2.9    97    2.6   0.0    SW   0.00   1.6    SW    3.0    3.0    3.0  1021.8  0.00   0.0   0.319   0.000   19.0    47    7.4   17.9   8.83 1.2068    12.8     66     13       8     8.3     15    693    1    100.0   30 
1961	181	2012-11-29 20:29:49.824	2012-11-25 08:30:00	11/25/12  8:30a    3.3    3.4    3.3    98    3.0   1.6   SSW   0.80   6.4   SSW    3.3    3.4    3.4  1022.0  0.00   0.0   0.313   0.000   18.2    47    6.7   17.1   8.85 1.2108    11.7     68     13       9     8.3     13    694    1    100.0   30 
1975	181	2012-11-29 20:29:53.137	2012-11-25 15:30:00	11/25/12  3:30p    8.3    9.0    8.3    95    7.6   1.6     S   0.80   8.0     S    8.3    8.5    8.5  1020.9  0.00   0.0   0.208   0.000   19.4    49    8.4   18.6   9.11 1.2032    13.3     76     13       9     8.9      0    681    1     99.6   30 
1977	181	2012-11-29 20:29:53.647	2012-11-25 16:30:00	11/25/12  4:30p    8.0    8.2    8.0    97    7.6   1.6     S   0.80   8.0    SW    8.0    8.2    8.2  1020.9  0.00   0.0   0.215   0.000   19.7    49    8.6   18.8   9.10 1.2019    13.3     75     13       9     8.9      0    686    1    100.0   30 
1993	181	2012-11-29 20:29:57.656	2012-11-26 00:30:00	11/26/12 12:30a    6.6    6.9    6.6    98    6.3   0.0   SSW   0.00   3.2   SSW    6.6    6.8    6.8  1020.8  0.00   0.0   0.244   0.000   19.7    49    8.7   18.9   9.10 1.2015    12.8     75     13       9     8.9     14    684    1    100.0   30 
2012	181	2012-11-29 20:30:02.093	2012-11-26 10:00:00	11/26/12 10:00a   11.8   11.8   10.1    84    9.2   9.7     W   4.83  20.9     W   10.9   11.8   10.8  1018.9  0.00   0.0   0.135   0.000   18.6    49    7.6   17.6   9.14 1.2049    12.2     77     13       9     8.9      0    702    1    100.0   30 
2014	181	2012-11-29 20:30:02.557	2012-11-26 11:00:00	11/26/12 11:00a   12.7   12.7   12.3    79    9.1  11.3     W   5.63  22.5   WNW   11.7   12.5   11.5  1018.0  0.00   0.0   0.118   0.000   18.8    49    7.8   17.8   9.13 1.2028    12.8     77     13       9     8.9      0    687    1    100.0   30 
2016	181	2012-11-29 20:30:03.017	2012-11-26 12:00:00	11/26/12 12:00p   13.2   13.2   12.9    78    9.4  11.3     W   5.63  20.9     W   12.2   12.9   12.0  1017.1  0.00   0.0   0.108   0.000   18.9    49    8.0   18.0   9.13 1.2009    13.3     77     13       9     8.9      0    682    1     99.7   30 
2021	181	2012-11-29 20:30:04.219	2012-11-26 14:30:00	11/26/12  2:30p   16.3   16.3   15.7    70   10.8   8.0   WNW   4.02  17.7   WNW   16.3   15.9   15.9  1015.8  0.00   0.0   0.043   0.000   19.4    49    8.4   18.6   9.11 1.1969    13.9     77     13       9     9.4      0    686    1    100.0   30 
2029	181	2012-11-29 20:30:06.068	2012-11-26 18:30:00	11/26/12  6:30p   13.7   14.3   13.7    73    9.0   9.7     W   4.83  19.3     W   13.1   13.4   12.8  1015.0  0.00   0.0   0.096   0.000   19.9    50    9.2   19.2   9.29 1.1932    13.9     77     13       9    10.0      0    684    1    100.0   30 
2037	181	2012-11-29 20:30:07.952	2012-11-26 22:30:00	11/26/12 10:30p   12.7   12.7   11.9    75    8.3   9.7     W   4.83  20.9   WSW   11.9   12.4   11.6  1014.0  0.00   0.0   0.118   0.000   19.6    49    8.5   18.7   9.11 1.1942    13.3     77     13       9     9.4      0    687    1    100.0   30 
1859	181	2012-11-29 20:29:25.521	2012-11-23 05:30:00	11/23/12  5:30a    8.1    8.1    8.1    96    7.5   0.0     E   0.00   1.6     E    8.1    8.2    8.2  1023.9  0.00   0.0   0.214   0.000   19.8    50    9.1   19.1   9.30 1.2044    13.3     79     12       8     9.4      0    692    1    100.0   30 
1865	181	2012-11-29 20:29:26.975	2012-11-23 08:30:00	11/23/12  8:30a    8.2    8.2    8.1    97    7.8   0.0   ---   0.00   0.0   ---    8.2    8.4    8.4  1024.4  0.00   0.0   0.211   0.000   19.4    50    8.7   18.7   9.31 1.2068    12.8     79     12       8     9.4     15    686    1    100.0   30 
1867	181	2012-11-29 20:29:27.436	2012-11-23 09:30:00	11/23/12  9:30a    8.5    8.6    8.3    98    8.2   0.0     S   0.00   4.8     S    8.5    8.7    8.7  1024.5  0.00   0.0   0.205   0.000   19.4    50    8.7   18.6   9.31 1.2073    12.8     79     12       8     9.4     15    698    1    100.0   30 
1869	181	2012-11-29 20:29:27.9	2012-11-23 10:30:00	11/23/12 10:30a    8.6    8.7    8.6    98    8.3   1.6    SW   0.80   8.0   WSW    8.6    8.9    8.9  1024.7  0.00   0.0   0.203   0.000   19.3    50    8.6   18.4   9.32 1.2081    12.8     80     12       8     9.4     15    702    1    100.0   30 
1871	181	2012-11-29 20:29:28.362	2012-11-23 11:30:00	11/23/12 11:30a    8.8    8.8    8.7    98    8.5   0.0   SSW   0.00   4.8   SSW    8.8    9.1    9.1  1024.2  0.00   0.0   0.198   0.000   19.9    57   11.2   19.6  10.59 1.2022    13.9     79     12       8     9.4     15    696    1    100.0   30 
1881	181	2012-11-29 20:29:30.673	2012-11-23 16:30:00	11/23/12  4:30p    9.4    9.6    9.4    95    8.6   0.0   SSW   0.00   6.4     S    9.4    9.7    9.7  1023.7  0.00   0.0   0.186   0.000   20.9    54   11.3   20.2   9.96 1.1974    14.4     78     12       8     9.4      0    691    1    100.0   30 
1895	181	2012-11-29 20:29:33.978	2012-11-23 23:30:00	11/23/12 11:30p    8.3    8.6    8.3    97    7.9   0.0   ---   0.00   0.0   ---    8.3    8.6    8.6  1025.4  0.00   0.0   0.208   0.000   21.5    54   11.8   20.8   9.94 1.1967    14.4     78     12       8     9.4     15    699    1    100.0   30 
1897	181	2012-11-29 20:29:34.439	2012-11-24 00:30:00	11/24/12 12:30a    7.8    8.1    7.8    97    7.4   0.0   SSW   0.00   1.6   SSW    7.8    8.0    8.0  1025.2  0.00   0.0   0.219   0.000   21.4    54   11.7   20.8   9.94 1.1966    14.4     78     12       8     9.4     15    695    1    100.0   30 
1913	181	2012-11-29 20:29:38.184	2012-11-24 08:30:00	11/24/12  8:30a    7.6    7.6    6.9    98    7.3   0.0   ---   0.00   0.0   ---    7.6    7.7    7.7  1025.5  0.00   0.0   0.225   0.000   20.4    50    9.6   19.6   9.28 1.2035    13.9     75     12       8     8.9      3    697    1    100.0   30 
1932	181	2012-11-29 20:29:42.985	2012-11-24 18:00:00	11/24/12  6:00p    7.2    8.3    7.2    94    6.3   0.0   ---   0.00   0.0   ---    7.2    7.3    7.3  1024.1  0.00   0.0   0.231   0.000   20.6    50    9.8   19.8   9.27 1.2010    13.9     76     12       8    10.0      1    686    1    100.0   30 
1934	181	2012-11-29 20:29:43.447	2012-11-24 19:00:00	11/24/12  7:00p    5.7    6.4    5.7    95    5.0   0.0   ---   0.00   0.0   ---    5.7    5.8    5.8  1024.3  0.00   0.0   0.263   0.000   20.4    50    9.6   19.6   9.28 1.2020    13.9     75     12       8     9.4      1    698    1    100.0   30 
1936	181	2012-11-29 20:29:43.911	2012-11-24 20:00:00	11/24/12  8:00p    4.4    4.7    4.4    95    3.7   0.0    SW   0.00   1.6    SW    4.4    4.4    4.4  1023.9  0.00   0.0   0.291   0.000   20.3    50    9.5   19.5   9.28 1.2022    13.9     72     12       8     9.4      1    695    1    100.0   30 
1938	181	2012-11-29 20:29:44.373	2012-11-24 21:00:00	11/24/12  9:00p    4.1    4.2    4.1    96    3.5   0.0    SW   0.00   1.6    SW    4.1    4.1    4.1  1023.9  0.00   0.0   0.297   0.000   20.1    49    9.1   19.3   9.09 1.2033    13.9     70     12       8     9.4      2    691    1    100.0   30 
1942	181	2012-11-29 20:29:45.374	2012-11-24 23:00:00	11/24/12 11:00p    2.8    3.4    2.8    97    2.3   0.0   ---   0.00   0.0   ---    2.8    2.8    2.8  1023.4  0.20   0.0   0.324   0.000   19.7    49    8.7   18.9   9.10 1.2046    13.3     67     12       8     8.9     15    689    1    100.0   30 
1944	181	2012-11-29 20:29:45.847	2012-11-25 00:00:00	11/25/12 12:00a    2.3    2.3    2.3    97    1.9   0.0   ---   0.00   0.0   ---    2.3    2.3    2.3  1023.2  0.00   0.0   0.334   0.000   19.7    48    8.3   18.8   8.90 1.2049    13.3     67     12       8     8.9     15    695    1    100.0   30 
1950	181	2012-11-29 20:29:47.279	2012-11-25 03:00:00	11/25/12  3:00a    3.0    3.0    2.8    98    2.7   0.0   WSW   0.00   1.6   WSW    3.0    3.1    3.1  1022.4  0.00   0.0   0.319   0.000   19.1    47    7.5   18.1   8.82 1.2069    12.8     67     13       8     8.9     15    682    1     99.7   30 
1979	181	2012-11-29 20:29:54.11	2012-11-25 17:30:00	11/25/12  5:30p    8.0    8.1    7.9    97    7.6   1.6     S   0.80   6.4   WSW    8.0    8.2    8.2  1020.9  0.00   0.0   0.215   0.000   19.7    49    8.7   18.9   9.10 1.2016    13.3     76     13       9     8.9      0    692    1    100.0   30 
1985	181	2012-11-29 20:29:55.597	2012-11-25 20:30:00	11/25/12  8:30p    7.8    7.8    7.8    98    7.5   0.0   SSW   0.00   1.6   SSW    7.8    8.0    8.0  1021.3  0.00   0.0   0.220   0.000   20.2    49    9.2   19.4   9.08 1.1996    13.3     75     13       9     8.9     14    695    1    100.0   30 
1987	181	2012-11-29 20:29:56.093	2012-11-25 21:30:00	11/25/12  9:30p    7.6    7.7    7.6    98    7.3   0.0   SSW   0.00   1.6   SSW    7.6    7.8    7.8  1021.0  0.00   0.0   0.223   0.000   20.2    49    9.2   19.4   9.08 1.1993    13.3     76     13       8     8.9     15    698    1    100.0   30 
1989	181	2012-11-29 20:29:56.554	2012-11-25 22:30:00	11/25/12 10:30p    7.3    7.4    7.3    98    7.0   0.0   ---   0.00   0.0   ---    7.3    7.4    7.4  1021.0  0.00   0.0   0.230   0.000   20.0    49    9.0   19.2   9.09 1.2004    13.3     75     13       9     8.9     15    694    1    100.0   30 
1991	181	2012-11-29 20:29:57.183	2012-11-25 23:30:00	11/25/12 11:30p    7.1    7.2    7.1    98    6.8   0.0   ---   0.00   0.0   ---    7.1    7.3    7.3  1021.1  0.00   0.0   0.234   0.000   19.9    49    8.9   19.2   9.09 1.2008    13.3     75     13       9     8.9     15    686    1    100.0   30 
2001	181	2012-11-29 20:29:59.538	2012-11-26 04:30:00	11/26/12  4:30a    6.3    6.3    6.2    98    6.0   0.0    SW   0.00   3.2    SW    6.3    6.4    6.4  1019.8  0.00   0.0   0.251   0.000   19.2    48    7.9   18.3   8.92 1.2030    12.8     74     13       9     8.9     10    679    1     99.3   30 
2015	181	2012-11-29 20:30:02.787	2012-11-26 11:30:00	11/26/12 11:30a   13.1   13.1   12.7    78    9.3  12.9     W   6.44  22.5     W   11.7   12.8   11.5  1017.4  0.00   0.0   0.110   0.000   18.8    49    7.9   17.9   9.13 1.2018    12.8     77     13       9     8.9      0    698    1    100.0   30 
2019	181	2012-11-29 20:30:03.756	2012-11-26 13:30:00	11/26/12  1:30p   14.7   14.7   13.8    75   10.3   9.7   WNW   4.83  17.7     W   14.3   14.4   14.1  1016.3  0.00   0.0   0.075   0.000   19.3    49    8.3   18.4   9.12 1.1983    13.3     77     13       9     9.4      0    688    1    100.0   30 
2028	181	2012-11-29 20:30:05.836	2012-11-26 18:00:00	11/26/12  6:00p   14.3   14.7   14.3    72    9.3   9.7     W   4.83  17.7     W   13.8   13.9   13.4  1015.1  0.00   0.0   0.084   0.000   19.8    50    9.1   19.1   9.30 1.1938    13.9     77     12       9    10.0      0    702    1    100.0   30 
1860	181	2012-11-29 20:29:25.754	2012-11-23 06:00:00	11/23/12  6:00a    8.1    8.1    8.0    96    7.5   0.0   ---   0.00   0.0   ---    8.1    8.2    8.2  1023.9  0.00   0.0   0.214   0.000   19.7    50    9.0   18.9   9.30 1.2049    13.3     78     12       8     9.4      0    693    1    100.0   30 
1868	181	2012-11-29 20:29:27.669	2012-11-23 10:00:00	11/23/12 10:00a    8.7    8.7    8.5    98    8.4   1.6     S   0.80   6.4    SW    8.7    8.9    8.9  1024.5  0.00   0.0   0.201   0.000   19.3    50    8.6   18.4   9.32 1.2078    12.8     79     12       8     9.4     15    681    1     99.6   30 
1903	181	2012-11-29 20:29:35.828	2012-11-24 03:30:00	11/24/12  3:30a    6.7    7.1    6.7    97    6.2   0.0   ---   0.00   0.0   ---    6.7    6.8    6.8  1024.8  0.00   0.0   0.243   0.000   21.2    52   10.9   20.3   9.65 1.1982    13.9     76     12       8     9.4     15    695    1    100.0   30 
1906	181	2012-11-29 20:29:36.554	2012-11-24 05:00:00	11/24/12  5:00a    6.1    6.1    5.8    98    5.8   0.0   SSW   0.00   1.6   SSW    6.1    6.2    6.2  1024.9  0.00   0.0   0.255   0.000   20.9    51   10.4   20.1   9.46 1.1997    13.9     75     12       8     9.4     15    691    1    100.0   30 
1920	181	2012-11-29 20:29:40.002	2012-11-24 12:00:00	11/24/12 12:00p   11.8   11.8   11.5    84    9.2   4.8   WNW   2.41   9.7   WNW   11.8   11.7   11.7  1025.0  0.00   0.0   0.137   0.000   20.5    51   10.0   19.8   9.47 1.2020    13.9     77     12       8     9.4      0    690    1    100.0   30 
1928	181	2012-11-29 20:29:42.06	2012-11-24 16:00:00	11/24/12  4:00p   10.8   11.6   10.8    89    9.0   1.6     S   0.80   8.0    SW   10.8   10.9   10.9  1024.1  0.00   0.0   0.157   0.000   20.7    50    9.9   19.8   9.27 1.2005    14.4     76     12       8    10.0      0    689    1    100.0   30 
1963	181	2012-11-29 20:29:50.284	2012-11-25 09:30:00	11/25/12  9:30a    4.4    4.4    4.0    98    4.1   1.6    SW   0.80   6.4    SW    4.4    4.5    4.5  1022.3  0.00   0.0   0.291   0.000   18.1    47    6.6   16.9   8.86 1.2120    11.7     70     13       9     8.3      8    694    1    100.0   30 
1966	181	2012-11-29 20:29:51.001	2012-11-25 11:00:00	11/25/12 11:00a    6.8    6.8    5.9    98    6.5   3.2   SSW   1.61   9.7    SW    6.8    6.9    6.9  1021.7  0.00   0.0   0.241   0.000   18.7    48    7.4   17.7   8.94 1.2080    12.8     72     13       9     8.3      0    699    1    100.0   30 
1980	181	2012-11-29 20:29:54.44	2012-11-25 18:00:00	11/25/12  6:00p    8.1    8.1    7.9    98    7.8   0.0    SW   0.00   6.4    SW    8.1    8.3    8.3  1021.0  0.00   0.0   0.214   0.000   19.8    49    8.8   19.1   9.10 1.2012    13.3     76     13       9     8.9      1    689    1    100.0   30 
1988	181	2012-11-29 20:29:56.324	2012-11-25 22:00:00	11/25/12 10:00p    7.4    7.6    7.4    98    7.1   0.0   SSW   0.00   3.2   SSW    7.4    7.6    7.6  1021.0  0.00   0.0   0.227   0.000   20.1    49    9.1   19.3   9.09 1.1998    13.3     76     13       9     8.9     15    685    1    100.0   30 
2023	181	2012-11-29 20:30:04.68	2012-11-26 15:30:00	11/26/12  3:30p   15.6   16.2   15.6    69    9.9   6.4     W   3.22  12.9     W   15.6   15.2   15.2  1015.3  0.00   0.0   0.057   0.000   19.6    49    8.5   18.7   9.11 1.1958    13.9     77     13       9     9.4      0    703    1    100.0   30 
2024	181	2012-11-29 20:30:04.912	2012-11-26 16:00:00	11/26/12  4:00p   14.5   15.7   14.5    72    9.5   4.8     W   2.41  12.9     W   14.5   14.1   14.1  1015.2  0.00   0.0   0.080   0.000   19.6    50    8.8   18.8   9.31 1.1954    13.9     77     13       9     9.4      0    676    1     98.8   30 
2034	181	2012-11-29 20:30:07.257	2012-11-26 21:00:00	11/26/12  9:00p   11.5   11.7   11.5    80    8.2   6.4     W   3.22  14.5     W   11.1   11.3   10.9  1014.5  0.00   0.0   0.142   0.000   19.7    50    8.9   18.9   9.30 1.1939    13.9     77     13       9    10.0      0    687    1    100.0   30 
2055	181	2012-11-29 20:30:12.157	2012-11-27 07:30:00	11/27/12  7:30a   11.5   11.5   11.2    76    7.4  11.3     W   5.63  24.1     W   10.2   11.3   10.0  1011.4  0.00   0.0   0.142   0.000   18.8    48    7.6   17.8   8.93 1.1949    13.3     76     13       8     9.4      0    680    1     99.4   30 
2062	181	2012-11-29 20:30:13.809	2012-11-27 11:00:00	11/27/12 11:00a   15.6   15.6   15.5    65    9.0  14.5     W   7.24  27.4     W   14.3   15.1   13.8  1011.9  0.00   0.0   0.058   0.000   18.7    48    7.4   17.7   8.94 1.1963    13.3     75     13       8     9.4      0    697    1    100.0   30 
1863	181	2012-11-29 20:29:26.49	2012-11-23 07:30:00	11/23/12  7:30a    8.0    8.0    7.9    97    7.6   0.0   ---   0.00   0.0   ---    8.0    8.2    8.2  1024.4  0.00   0.0   0.215   0.000   19.6    50    8.8   18.8   9.31 1.2063    13.3     79     12       8     9.4      2    684    1    100.0   30 
1866	181	2012-11-29 20:29:27.207	2012-11-23 09:00:00	11/23/12  9:00a    8.3    8.4    8.2    97    7.9   0.0   ---   0.00   0.0   ---    8.3    8.6    8.6  1024.4  0.00   0.0   0.208   0.000   19.4    50    8.7   18.6   9.31 1.2072    12.8     79     12       8     9.4     15    692    1    100.0   30 
1880	181	2012-11-29 20:29:30.444	2012-11-23 16:00:00	11/23/12  4:00p    9.6    9.8    9.6    94    8.6   0.0     S   0.00   6.4     S    9.6    9.8    9.8  1023.8  0.00   0.0   0.183   0.000   20.9    54   11.2   20.2   9.97 1.1978    14.4     78     12       8     9.4      0    692    1    100.0   30 
1888	181	2012-11-29 20:29:32.347	2012-11-23 20:00:00	11/23/12  8:00p    9.0    9.1    9.0    97    8.5   0.0   SSW   0.00   1.6   SSW    9.0    9.3    9.3  1024.9  0.00   0.0   0.194   0.000   21.9    54   12.2   21.4   9.92 1.1941    15.0     77     12       8     9.4     15    695    1    100.0   30 
1923	181	2012-11-29 20:29:40.696	2012-11-24 13:30:00	11/24/12  1:30p   12.3   12.3   12.2    76    8.2   3.2   WNW   1.61  11.3     W   12.3   12.1   12.1  1024.4  0.00   0.0   0.125   0.000   20.7    51   10.2   19.9   9.47 1.2005    14.4     77     12       8     9.4      0    699    1    100.0   30 
1926	181	2012-11-29 20:29:41.41	2012-11-24 15:00:00	11/24/12  3:00p   12.8   12.8   12.4    73    8.1   3.2   WNW   1.61   9.7     W   12.8   12.4   12.4  1024.0  0.00   0.0   0.116   0.000   20.8    50   10.0   19.9   9.26 1.1998    14.4     76     12       8     9.4      0    693    1    100.0   30 
1940	181	2012-11-29 20:29:44.889	2012-11-24 22:00:00	11/24/12 10:00p    3.7    3.8    3.7    97    3.2   0.0   WSW   0.00   4.8    SW    3.7    3.7    3.7  1023.6  0.00   0.0   0.306   0.000   19.9    49    8.9   19.2   9.09 1.2037    13.3     69     12       8     9.4      4    682    1     99.7   30 
1948	181	2012-11-29 20:29:46.817	2012-11-25 02:00:00	11/25/12  2:00a    2.4    2.4    1.9    97    2.0   0.0   WSW   0.00   1.6   WSW    2.4    2.4    2.4  1022.8  0.00   0.0   0.332   0.000   19.3    48    8.0   18.3   8.92 1.2063    12.8     66     13       8     8.9     15    691    1    100.0   30 
1983	181	2012-11-29 20:29:55.135	2012-11-25 19:30:00	11/25/12  7:30p    7.8    7.8    7.8    98    7.5   0.0   SSW   0.00   3.2   SSW    7.8    8.0    8.0  1021.3  0.00   0.0   0.220   0.000   20.1    49    9.1   19.3   9.09 1.2002    13.3     76     13       9     8.9      3    690    1    100.0   30 
1986	181	2012-11-29 20:29:55.828	2012-11-25 21:00:00	11/25/12  9:00p    7.7    7.8    7.7    98    7.4   0.0   ---   0.00   0.0   ---    7.7    7.9    7.9  1021.2  0.00   0.0   0.221   0.000   20.2    49    9.2   19.4   9.08 1.1995    13.3     76     13       9     8.9     15    688    1    100.0   30 
2000	181	2012-11-29 20:29:59.307	2012-11-26 04:00:00	11/26/12  4:00a    6.2    6.3    6.2    98    5.9   0.0    SW   0.00   1.6    SW    6.2    6.3    6.3  1019.7  0.00   0.0   0.253   0.000   19.3    48    8.0   18.3   8.92 1.2027    12.8     74     13       9     8.9     10    700    1    100.0   30 
2008	181	2012-11-29 20:30:01.158	2012-11-26 08:00:00	11/26/12  8:00a    7.1    7.1    6.7    98    6.8   0.0     S   0.00   3.2     S    7.1    7.2    7.2  1019.3  0.00   0.0   0.235   0.000   18.8    48    7.5   17.8   8.93 1.2046    12.2     75     13       9     8.9      4    693    1    100.0   30 
2017	181	2012-11-29 20:30:03.294	2012-11-26 12:30:00	11/26/12 12:30p   13.6   13.6   13.2    77    9.6  11.3   WNW   5.63  20.9   WNW   12.7   13.3   12.4  1016.9  0.00   0.0   0.100   0.000   19.1    49    8.1   18.2   9.12 1.1998    13.3     77     13       9     8.9      0    697    1    100.0   30 
2018	181	2012-11-29 20:30:03.525	2012-11-26 13:00:00	11/26/12  1:00p   13.8   13.8   13.6    78   10.0   9.7   WNW   4.83  19.3   WNW   13.2   13.6   13.0  1016.5  0.00   0.0   0.095   0.000   19.2    49    8.2   18.3   9.12 1.1989    13.3     77     13       9     8.9      0    691    1    100.0   30 
2025	181	2012-11-29 20:30:05.143	2012-11-26 16:30:00	11/26/12  4:30p   14.6   14.7   14.4    72    9.6   4.8   WSW   2.41  11.3   WSW   14.6   14.2   14.2  1015.0  0.00   0.0   0.078   0.000   19.6    50    8.8   18.8   9.31 1.1952    13.9     78     13       9     9.4      0    702    1    100.0   30 
2047	181	2012-11-29 20:30:10.296	2012-11-27 03:30:00	11/27/12  3:30a   12.4   12.7   12.4    76    8.3  17.7   WNW   8.85  35.4   WNW    9.9   12.1    9.6  1011.8  0.00   0.0   0.124   0.000   19.1    48    7.8   18.2   8.92 1.1940    13.3     77     13       8     9.4      0    688    1    100.0   30 
2053	181	2012-11-29 20:30:11.683	2012-11-27 06:30:00	11/27/12  6:30a   10.3   10.6   10.3    80    7.0   4.8   WNW   2.41  12.9   WNW   10.2   10.3   10.2  1011.4  0.00   0.0   0.168   0.000   18.9    48    7.7   17.9   8.93 1.1943    13.3     76     13       8     9.4      0    685    1    100.0   30 
2054	181	2012-11-29 20:30:11.924	2012-11-27 07:00:00	11/27/12  7:00a   11.3   11.3    9.9    77    7.4   9.7   WNW   4.83  22.5     W   10.3   11.1   10.1  1011.5  0.00   0.0   0.146   0.000   18.8    48    7.6   17.8   8.93 1.1950    13.3     76     13       8     9.4      0    701    1    100.0   30 
2057	181	2012-11-29 20:30:12.62	2012-11-27 08:30:00	11/27/12  8:30a   12.8   12.8   11.9    70    7.5  12.9   WNW   6.44  29.0     W   11.4   12.4   11.0  1011.7  0.00   0.0   0.115   0.000   18.8    48    7.5   17.8   8.93 1.1955    13.3     77     13       8     9.4      0    689    1    100.0   30 
2063	181	2012-11-29 20:30:14.04	2012-11-27 11:30:00	11/27/12 11:30a   16.1   16.1   15.6    61    8.5   9.7     W   4.83  24.1     W   15.9   15.4   15.3  1011.5  0.00   0.0   0.047   0.000   18.7    48    7.4   17.7   8.94 1.1958    13.3     75     13       8     9.4      0    680    1     99.4   30 
1879	181	2012-11-29 20:29:30.211	2012-11-23 15:30:00	11/23/12  3:30p    9.8   10.0    9.8    94    8.9   0.0   SSW   0.00   4.8   SSW    9.8   10.1   10.1  1023.8  0.00   0.0   0.178   0.000   20.9    54   11.2   20.2   9.97 1.1978    14.4     79     12       8     9.4      0    699    1    100.0   30 
1885	181	2012-11-29 20:29:31.632	2012-11-23 18:30:00	11/23/12  6:30p    9.1    9.1    9.1    96    8.5   0.0   SSW   0.00   4.8     S    9.1    9.3    9.3  1024.5  0.00   0.0   0.193   0.000   21.6    54   11.9   21.0   9.93 1.1950    15.0     78     12       8     9.4     10    698    1    100.0   30 
1887	181	2012-11-29 20:29:32.117	2012-11-23 19:30:00	11/23/12  7:30p    9.0    9.1    9.0    97    8.5   0.0   SSW   0.00   3.2   SSW    9.0    9.3    9.3  1024.8  0.00   0.0   0.194   0.000   21.8    54   12.1   21.2   9.93 1.1945    15.0     77     12       8     9.4     15    695    1    100.0   30 
1889	181	2012-11-29 20:29:32.579	2012-11-23 20:30:00	11/23/12  8:30p    8.9    9.0    8.9    97    8.5   0.0   SSW   0.00   1.6   SSW    8.9    9.2    9.2  1025.2  0.00   0.0   0.196   0.000   22.0    54   12.3   21.6   9.92 1.1938    15.0     77     12       8     9.4     15    684    1    100.0   30 
1891	181	2012-11-29 20:29:33.053	2012-11-23 21:30:00	11/23/12  9:30p    8.8    8.8    8.8    97    8.4   0.0   SSW   0.00   1.6   SSW    8.8    9.1    9.1  1025.3  0.00   0.0   0.198   0.000   21.9    54   12.2   21.4   9.92 1.1945    15.0     77     12       8     9.4     15    680    1     99.4   30 
1901	181	2012-11-29 20:29:35.365	2012-11-24 02:30:00	11/24/12  2:30a    7.4    7.7    7.4    97    7.0   0.0   ---   0.00   0.0   ---    7.4    7.6    7.6  1025.1  0.00   0.0   0.227   0.000   21.2    53   11.3   20.4   9.84 1.1980    14.4     77     12       8     9.4     15    687    1    100.0   30 
1915	181	2012-11-29 20:29:38.846	2012-11-24 09:30:00	11/24/12  9:30a    9.2    9.2    7.9    98    8.9   0.0   SSW   0.00   3.2   SSW    9.2    9.4    9.4  1025.6  0.00   0.0   0.191   0.000   20.3    50    9.5   19.5   9.28 1.2041    13.3     76     12       8     8.9      1    687    1    100.0   30 
1917	181	2012-11-29 20:29:39.307	2012-11-24 10:30:00	11/24/12 10:30a   10.5   10.5    9.9    93    9.4   1.6    NW   0.80   6.4   WSW   10.5   10.7   10.7  1025.5  0.00   0.0   0.163   0.000   20.2    50    9.5   19.5   9.28 1.2043    13.3     77     12       8     8.9      0    678    1     99.1   30 
1933	181	2012-11-29 20:29:43.217	2012-11-24 18:30:00	11/24/12  6:30p    6.4    7.2    6.4    95    5.7   0.0   ---   0.00   0.0   ---    6.4    6.6    6.6  1024.2  0.00   0.0   0.248   0.000   20.5    50    9.7   19.7   9.27 1.2014    13.9     75     12       8    10.0      1    691    1    100.0   30 
1952	181	2012-11-29 20:29:47.743	2012-11-25 04:00:00	11/25/12  4:00a    3.2    3.2    3.0    98    2.9   0.0    SW   0.00   1.6    SW    3.2    3.3    3.3  1021.7  0.00   0.0   0.315   0.000   18.9    47    7.4   17.9   8.83 1.2069    12.2     67     13       8     8.3     15    695    1    100.0   30 
1954	181	2012-11-29 20:29:48.203	2012-11-25 05:00:00	11/25/12  5:00a    3.4    3.4    3.4    98    3.1   0.0   SSW   0.00   1.6    SW    3.4    3.4    3.4  1021.5  0.00   0.0   0.311   0.000   18.8    47    7.2   17.7   8.83 1.2075    12.2     68     13       8     8.3     15    694    1    100.0   30 
1956	181	2012-11-29 20:29:48.667	2012-11-25 06:00:00	11/25/12  6:00a    3.5    3.6    3.5    98    3.2   0.0     S   0.00   3.2   SSE    3.5    3.6    3.6  1021.7  0.00   0.0   0.309   0.000   18.7    47    7.1   17.6   8.84 1.2082    12.2     68     13       8     8.3     15    700    1    100.0   30 
1958	181	2012-11-29 20:29:49.129	2012-11-25 07:00:00	11/25/12  7:00a    3.2    3.4    3.2    98    2.9   0.0   SSW   0.00   4.8   SSW    3.2    3.3    3.3  1021.6  0.00   0.0   0.315   0.000   18.5    47    7.0   17.4   8.84 1.2090    12.2     68     13       8     8.3     15    689    1    100.0   30 
1962	181	2012-11-29 20:29:50.055	2012-11-25 09:00:00	11/25/12  9:00a    4.0    4.0    3.3    98    3.7   1.6   SSW   0.80   6.4   SSW    4.0    4.1    4.1  1022.1  0.00   0.0   0.299   0.000   18.1    47    6.6   17.0   8.86 1.2114    11.7     69     13       9     8.3     12    690    1    100.0   30 
1964	181	2012-11-29 20:29:50.517	2012-11-25 10:00:00	11/25/12 10:00a    5.1    5.1    4.4    98    4.8   1.6   SSW   0.80   4.8     S    5.1    5.2    5.2  1022.4  0.00   0.0   0.275   0.000   18.1    47    6.6   17.0   8.86 1.2118    11.7     71     13       9     8.3      0    695    1    100.0   30 
1970	181	2012-11-29 20:29:51.98	2012-11-25 13:00:00	11/25/12  1:00p   10.1   10.1    9.4    93    9.0   1.6     S   0.80   8.0     S   10.1   10.3   10.3  1020.9  0.00   0.0   0.172   0.000   19.2    49    8.2   18.3   9.12 1.2041    12.8     75     13       9     8.3      0    690    1    100.0   30 
1999	181	2012-11-29 20:29:59.077	2012-11-26 03:30:00	11/26/12  3:30a    6.3    6.4    6.3    98    6.0   0.0    SW   0.00   1.6    SW    6.3    6.5    6.5  1020.0  0.00   0.0   0.250   0.000   19.3    48    8.0   18.3   8.92 1.2030    12.8     75     13       9     8.9     10    690    1    100.0   30 
2005	181	2012-11-29 20:30:00.464	2012-11-26 06:30:00	11/26/12  6:30a    6.6    6.6    6.4    98    6.3   0.0    SW   0.00   1.6    SW    6.6    6.7    6.7  1019.4  0.00   0.0   0.245   0.000   18.9    48    7.7   17.9   8.93 1.2040    12.2     74     13       9     8.9      7    699    1    100.0   30 
2007	181	2012-11-29 20:30:00.925	2012-11-26 07:30:00	11/26/12  7:30a    6.8    6.8    6.7    98    6.5   0.0   ---   0.00   0.0   ---    6.8    6.9    6.9  1019.4  0.00   0.0   0.241   0.000   18.8    48    7.6   17.8   8.93 1.2045    12.2     75     13       9     8.9      6    695    1    100.0   30 
2009	181	2012-11-29 20:30:01.388	2012-11-26 08:30:00	11/26/12  8:30a    7.5    7.5    7.1    98    7.2   0.0   SSE   0.00   1.6     S    7.5    7.7    7.7  1019.3  0.00   0.0   0.226   0.000   18.8    48    7.5   17.8   8.93 1.2046    12.2     75     13       9     8.9      2    686    1    100.0   30 
2011	181	2012-11-29 20:30:01.861	2012-11-26 09:30:00	11/26/12  9:30a   10.1   10.1    8.3    98    9.8   3.2     W   1.61  16.1   WNW   10.1   10.4   10.4  1019.0  0.00   0.0   0.172   0.000   18.6    48    7.3   17.5   8.94 1.2053    12.2     77     13       9     8.9      0    677    1     99.0   30 
2022	181	2012-11-29 20:30:04.449	2012-11-26 15:00:00	11/26/12  3:00p   16.2   16.4   16.2    68   10.3   6.4     W   3.22  16.1     W   16.2   15.8   15.8  1015.5  0.00   0.0   0.045   0.000   19.6    49    8.5   18.7   9.11 1.1960    13.9     77     13       9     9.4      0    694    1    100.0   30 
2035	181	2012-11-29 20:30:07.489	2012-11-26 21:30:00	11/26/12  9:30p   11.7   11.7   11.3    79    8.1   8.0     W   4.02  14.5     W   10.9   11.5   10.8  1014.5  0.00   0.0   0.139   0.000   19.7    50    8.9   18.9   9.30 1.1939    13.9     77     13       9     9.4      0    692    1    100.0   30 
2040	181	2012-11-29 20:30:08.677	2012-11-27 00:00:00	11/27/12 12:00a   11.7   12.2   11.7    79    8.2   4.8     W   2.41  14.5     W   11.7   11.6   11.6  1013.8  0.00   0.0   0.138   0.000   19.4    49    8.4   18.6   9.11 1.1948    13.3     77     13       9     9.4      0    682    1     99.7   30 
2048	181	2012-11-29 20:30:10.528	2012-11-27 04:00:00	11/27/12  4:00a   12.4   12.4   12.3    77    8.5  16.1     W   8.05  30.6     W   10.2   12.2    9.9  1011.7  0.00   0.0   0.124   0.000   19.1    48    7.8   18.2   8.92 1.1938    13.3     77     13       8     9.4      0    694    1    100.0   30 
1883	181	2012-11-29 20:29:31.169	2012-11-23 17:30:00	11/23/12  5:30p    9.2    9.3    9.2    96    8.6   0.0   SSW   0.00   3.2   SSW    9.2    9.5    9.5  1024.2  0.00   0.0   0.190   0.000   21.3    54   11.6   20.6   9.94 1.1961    15.0     78     12       8     9.4      3    694    1    100.0   30 
1886	181	2012-11-29 20:29:31.885	2012-11-23 19:00:00	11/23/12  7:00p    9.1    9.1    9.0    97    8.6   0.0     S   0.00   4.8     S    9.1    9.3    9.3  1024.6  0.00   0.0   0.193   0.000   21.7    54   12.0   21.2   9.93 1.1945    15.0     77     12       8     9.4     12    686    1    100.0   30 
1900	181	2012-11-29 20:29:35.134	2012-11-24 02:00:00	11/24/12  2:00a    7.7    7.9    7.7    98    7.4   0.0   ---   0.00   0.0   ---    7.7    7.9    7.9  1025.3  0.00   0.0   0.221   0.000   21.2    53   11.3   20.4   9.84 1.1982    13.9     78     12       8     9.4     15    699    1    100.0   30 
1908	181	2012-11-29 20:29:37.016	2012-11-24 06:00:00	11/24/12  6:00a    6.2    6.2    6.2    98    5.9   0.0   ---   0.00   0.0   ---    6.2    6.3    6.3  1025.0  0.00   0.0   0.253   0.000   20.9    51   10.4   20.1   9.46 1.2001    13.9     75     12       8     9.4     13    697    1    100.0   30 
1943	181	2012-11-29 20:29:45.61	2012-11-24 23:30:00	11/24/12 11:30p    2.3    2.8    2.3    97    1.9   0.0   ---   0.00   0.0   ---    2.3    2.3    2.3  1023.4  0.00   0.0   0.334   0.000   19.7    48    8.4   18.8   8.90 1.2049    13.3     67     12       8     8.9     15    691    1    100.0   30 
1946	181	2012-11-29 20:29:46.333	2012-11-25 01:00:00	11/25/12  1:00a    1.8    1.9    1.8    97    1.4   0.0   ---   0.00   0.0   ---    1.8    1.8    1.8  1022.9  0.00   0.0   0.345   0.000   19.4    48    8.1   18.6   8.91 1.2057    12.8     66     13       8     8.9     15    695    1    100.0   30 
1960	181	2012-11-29 20:29:49.593	2012-11-25 08:00:00	11/25/12  8:00a    3.3    3.3    3.2    98    3.0   1.6   SSW   0.80   8.0    SW    3.3    3.3    3.3  1021.9  0.00   0.0   0.314   0.000   18.3    47    6.8   17.2   8.85 1.2104    12.2     68     13       9     8.3     14    689    1    100.0   30 
1968	181	2012-11-29 20:29:51.464	2012-11-25 12:00:00	11/25/12 12:00p    8.2    8.2    7.6    98    7.9   1.6     S   0.80   9.7     S    8.2    8.4    8.4  1021.2  0.00   0.0   0.211   0.000   19.0    48    7.7   18.0   8.93 1.2057    12.8     73     13       9     8.3      0    690    1    100.0   30 
2003	181	2012-11-29 20:30:00	2012-11-26 05:30:00	11/26/12  5:30a    6.4    6.4    6.3    98    6.1   0.0   ---   0.00   0.0   ---    6.4    6.6    6.6  1019.7  0.00   0.0   0.249   0.000   19.0    48    7.7   18.0   8.93 1.2040    12.8     74     13       9     8.9      9    690    1    100.0   30 
2006	181	2012-11-29 20:30:00.695	2012-11-26 07:00:00	11/26/12  7:00a    6.7    6.7    6.6    98    6.4   0.0   SSW   0.00   3.2    SW    6.7    6.8    6.8  1019.4  0.00   0.0   0.243   0.000   18.9    48    7.7   17.9   8.93 1.2039    12.2     74     13       9     8.9      6    683    1     99.9   30 
2026	181	2012-11-29 20:30:05.374	2012-11-26 17:00:00	11/26/12  5:00p   14.7   14.7   14.6    72    9.7   3.2   WSW   1.61  11.3   WSW   14.7   14.3   14.3  1015.0  0.00   0.0   0.076   0.000   19.7    50    9.0   18.9   9.30 1.1944    13.9     78     13       9     9.4      0    696    1    100.0   30 
2032	181	2012-11-29 20:30:06.762	2012-11-26 20:00:00	11/26/12  8:00p   12.6   12.9   12.6    76    8.5   8.0     W   4.02  19.3     W   12.1   12.3   11.8  1014.7  0.00   0.0   0.119   0.000   19.7    50    9.0   18.9   9.30 1.1939    13.9     77     13       9    10.0      0    685    1    100.0   30 
2033	181	2012-11-29 20:30:07.025	2012-11-26 20:30:00	11/26/12  8:30p   11.7   12.6   11.7    79    8.2   6.4     W   3.22  14.5     W   11.3   11.6   11.2  1014.6  0.00   0.0   0.138   0.000   19.7    50    9.0   18.9   9.30 1.1938    13.9     77     13       9    10.0      0    699    1    100.0   30 
2042	181	2012-11-29 20:30:09.139	2012-11-27 01:00:00	11/27/12  1:00a   11.8   12.1   11.8    78    8.1   6.4     W   3.22  17.7     W   11.5   11.6   11.3  1013.1  0.00   0.0   0.135   0.000   19.4    49    8.4   18.6   9.11 1.1940    13.3     77     13       9     9.4      0    684    1    100.0   30 
2046	181	2012-11-29 20:30:10.064	2012-11-27 03:00:00	11/27/12  3:00a   12.7   12.7   12.4    72    7.7  17.7   WNW   8.85  32.2     W   10.2   12.3    9.8  1011.7  0.00   0.0   0.118   0.000   19.2    48    7.9   18.3   8.92 1.1933    13.3     77     13       8     9.4      0    700    1    100.0   30 
2058	181	2012-11-29 20:30:12.861	2012-11-27 09:00:00	11/27/12  9:00a   13.6   13.6   12.8    68    7.8  16.1   WNW   8.05  27.4     W   11.6   13.1   11.1  1011.9  0.00   0.0   0.100   0.000   18.8    48    7.5   17.8   8.93 1.1958    13.3     77     13       8     8.9      0    691    1    100.0   30 
2065	181	2012-11-29 20:30:14.502	2012-11-27 12:30:00	11/27/12 12:30p   16.8   16.8   16.3    61    9.3   9.7     W   4.83  20.9    SW   16.8   16.2   16.2  1011.0  0.00   0.0   0.031   0.000   18.7    49    7.7   17.7   9.14 1.1949    13.3     76     13       8     9.4      0    698    1    100.0   30 
2027	181	2012-11-29 20:30:05.604	2012-11-26 17:30:00	11/26/12  5:30p   14.7   14.9   14.7    71    9.5   8.0     W   4.02  20.9   WSW   14.5   14.3   14.1  1015.0  0.00   0.0   0.076   0.000   19.8    50    9.1   19.1   9.30 1.1938    13.9     77     12       9     9.4      0    685    1    100.0   30 
2043	181	2012-11-29 20:30:09.37	2012-11-27 01:30:00	11/27/12  1:30a   12.0   12.0   11.8    77    8.1   8.0     W   4.02  22.5     W   11.3   11.8   11.1  1012.7  0.20   0.0   0.132   0.000   19.4    49    8.4   18.6   9.11 1.1934    13.3     77     13       9     9.4      0    699    1    100.0   30 
2031	181	2012-11-29 20:30:06.53	2012-11-26 19:30:00	11/26/12  7:30p   12.9   13.3   12.9    75    8.6   9.7     W   4.83  17.7     W   12.1   12.6   11.8  1014.9  0.00   0.0   0.113   0.000   19.8    50    9.1   19.1   9.30 1.1936    13.9     77     13       9    10.0      0    697    1    100.0   30 
2039	181	2012-11-29 20:30:08.446	2012-11-26 23:30:00	11/26/12 11:30p   12.2   12.6   12.2    77    8.3   8.0     W   4.02  19.3   WNW   11.6   11.9   11.3  1014.0  0.00   0.0   0.128   0.000   19.4    49    8.4   18.6   9.11 1.1948    13.3     77     13       9     9.4      0    698    1    100.0   30 
2061	181	2012-11-29 20:30:13.577	2012-11-27 10:30:00	11/27/12 10:30a   15.6   15.6   14.7    63    8.6  14.5     W   7.24  29.0     W   14.3   15.0   13.7  1012.2  0.00   0.0   0.057   0.000   18.7    48    7.4   17.7   8.94 1.1967    13.3     76     13       8     9.4      0    697    1    100.0   30 
2038	181	2012-11-29 20:30:08.182	2012-11-26 23:00:00	11/26/12 11:00p   12.6   12.8   12.6    75    8.3   9.7     W   4.83  20.9     W   11.8   12.3   11.5  1013.9  0.00   0.0   0.119   0.000   19.4    49    8.4   18.6   9.11 1.1947    13.3     77     13       9     9.4      0    691    1    100.0   30 
2044	181	2012-11-29 20:30:09.602	2012-11-27 02:00:00	11/27/12  2:00a   12.6   12.7   12.0    73    7.9  14.5   WNW   7.24  30.6   WNW   10.8   12.3   10.4  1012.5  0.00   0.0   0.119   0.000   19.3    49    8.3   18.4   9.12 1.1937    13.3     77     13       8     9.4      0    693    1    100.0   30 
2045	181	2012-11-29 20:30:09.833	2012-11-27 02:30:00	11/27/12  2:30a   12.5   12.7   12.4    73    7.8  17.7   WNW   8.85  32.2     W   10.0   12.2    9.7  1012.2  0.00   0.0   0.122   0.000   19.2    48    7.9   18.3   8.92 1.1940    13.3     77     13       8     9.4      0    687    1    100.0   30 
2056	181	2012-11-29 20:30:12.388	2012-11-27 08:00:00	11/27/12  8:00a   11.8   11.8   11.4    75    7.5  11.3   WNW   5.63  22.5   WNW   10.7   11.6   10.4  1011.6  0.00   0.0   0.135   0.000   18.8    48    7.6   17.8   8.93 1.1951    13.3     76     13       8     9.4      0    699    1    100.0   30 
2059	181	2012-11-29 20:30:13.093	2012-11-27 09:30:00	11/27/12  9:30a   13.3   13.6   13.3    68    7.5  16.1   WNW   8.05  29.0   WNW   11.2   12.8   10.7  1012.1  0.00   0.0   0.105   0.000   18.8    48    7.5   17.8   8.93 1.1960    13.3     77     13       8     9.4      0    699    1    100.0   30 
2049	181	2012-11-29 20:30:10.758	2012-11-27 04:30:00	11/27/12  4:30a   12.2   12.4   11.9    77    8.3  12.9   WNW   6.44  24.1   WNW   10.7   12.0   10.5  1011.7  0.00   0.0   0.127   0.000   19.1    48    7.8   18.2   8.92 1.1939    13.3     77     13       8     9.4      0    692    1    100.0   30 
2051	181	2012-11-29 20:30:11.221	2012-11-27 05:30:00	11/27/12  5:30a   11.1   11.8   11.1    79    7.6   9.7     W   4.83  17.7   WSW    9.9   10.9    9.8  1011.4  0.00   0.0   0.152   0.000   19.0    48    7.7   18.0   8.93 1.1941    13.3     77     13       8     9.4      0    692    1    100.0   30 
2064	181	2012-11-29 20:30:14.271	2012-11-27 12:00:00	11/27/12 12:00p   16.4   16.6   16.1    60    8.7   8.0     W   4.02  22.5   WSW   16.4   15.8   15.8  1011.1  0.00   0.0   0.039   0.000   18.6    49    7.6   17.6   9.14 1.1957    13.3     76     13       8     9.4      0    702    1    100.0   30 
2052	181	2012-11-29 20:30:11.451	2012-11-27 06:00:00	11/27/12  6:00a   10.6   11.1   10.6    80    7.3   6.4   WNW   3.22  20.9     W   10.1   10.6   10.0  1011.5  0.00   0.0   0.161   0.000   18.9    48    7.7   17.9   8.93 1.1945    13.3     77     13       8     9.4      0    698    1    100.0   30 
2060	181	2012-11-29 20:30:13.346	2012-11-27 10:00:00	11/27/12 10:00a   14.6   14.6   13.2    67    8.5  12.9     W   6.44  25.7     W   13.6   14.1   13.1  1012.1  0.00   0.0   0.078   0.000   18.7    48    7.4   17.7   8.94 1.1965    13.3     76     13       8     9.4      0    686    1    100.0   30 
2066	181	2012-11-29 20:30:14.734	2012-11-27 13:00:00	11/27/12  1:00p   16.6   16.8   16.6    61    9.1  11.3     W   5.63  24.1     W   16.4   16.0   15.8  1010.6  0.00   0.0   0.036   0.000   18.8    49    7.8   17.8   9.13 1.1940    13.3     76     13       8     9.4      0    678    1     99.1   30 
2068	181	2012-11-29 20:30:15.543	2012-11-27 14:00:00	11/27/12  2:00p   16.7   16.8   16.6    58    8.4   8.0     W   4.02  19.3     W   16.7   15.9   15.9  1010.4  0.00   0.0   0.035   0.000   18.8    48    7.6   17.8   8.93 1.1937    13.3     76     13       8    10.0      0    697    1    100.0   30 
2069	181	2012-11-29 20:30:15.783	2012-11-27 14:30:00	11/27/12  2:30p   16.7   16.8   16.7    57    8.1   9.7     W   4.83  25.7     W   16.7   15.9   15.9  1010.1  0.00   0.0   0.035   0.000   18.8    48    7.6   17.8   8.93 1.1934    13.3     76     13       8    10.0      0    679    1     99.3   30 
2070	181	2012-11-29 20:30:16.014	2012-11-27 15:00:00	11/27/12  3:00p   16.0   16.7   16.0    59    8.0  11.3     W   5.63  22.5     W   15.7   15.3   14.9  1010.0  0.00   0.0   0.049   0.000   18.8    48    7.5   17.8   8.93 1.1935    13.3     76     13       8    10.0      0    702    1    100.0   30 
2071	181	2012-11-29 20:30:16.245	2012-11-27 15:30:00	11/27/12  3:30p   15.7   16.0   15.7    61    8.2  11.3     W   5.63  22.5   WNW   15.2   15.0   14.6  1009.9  0.00   0.0   0.056   0.000   18.8    48    7.5   17.8   8.93 1.1933    13.3     76     13       8    10.0      0    691    1    100.0   30 
2072	181	2012-11-29 20:30:16.476	2012-11-27 16:00:00	11/27/12  4:00p   15.2   15.7   15.2    63    8.2   9.7     W   4.83  17.7   WNW   14.9   14.6   14.3  1009.9  0.00   0.0   0.065   0.000   18.8    48    7.5   17.8   8.93 1.1933    13.3     76     13       8    10.0      0    685    1    100.0   30 
2073	181	2012-11-29 20:30:16.707	2012-11-27 16:30:00	11/27/12  4:30p   14.3   15.2   14.3    66    8.0   6.4     W   3.22  14.5     W   14.3   13.7   13.7  1009.8  0.00   0.0   0.084   0.000   18.8    47    7.2   17.7   8.83 1.1935    13.3     76     13       8    10.0      0    702    1    100.0   30 
2074	181	2012-11-29 20:30:16.993	2012-11-27 17:00:00	11/27/12  5:00p   14.3   14.3   14.2    65    7.8   3.2   WSW   1.61  11.3     W   14.3   13.7   13.7  1009.9  0.00   0.0   0.084   0.000   18.7    47    7.1   17.6   8.84 1.1941    13.3     76     13       8    10.0      0    688    1    100.0   30 
2075	181	2012-11-29 20:30:17.224	2012-11-27 17:30:00	11/27/12  5:30p   13.3   14.3   13.3    69    7.8   0.0    SW   0.00   3.2    SW   13.3   12.9   12.9  1009.8  0.00   0.0   0.104   0.000   18.7    47    7.1   17.6   8.84 1.1940    13.3     76     13       8    10.0      0    693    1    100.0   30 
2076	181	2012-11-29 20:30:17.456	2012-11-27 18:00:00	11/27/12  6:00p   13.7   13.7   13.1    65    7.2   1.6   SSW   0.80   8.0     W   13.7   13.1   13.1  1009.4  0.00   0.0   0.097   0.000   18.7    47    7.1   17.6   8.84 1.1935    13.3     75     13       8    10.0      0    696    1    100.0   30 
2077	181	2012-11-29 20:30:17.687	2012-11-27 18:30:00	11/27/12  6:30p   13.7   13.7   13.6    64    7.0   1.6    SW   0.80   8.0   SSW   13.7   13.1   13.1  1009.0  0.00   0.0   0.097   0.000   18.7    46    6.8   17.6   8.65 1.1934    13.3     73     13       8    10.0      0    685    1    100.0   30 
2078	181	2012-11-29 20:30:17.918	2012-11-27 19:00:00	11/27/12  7:00p   12.4   13.7   12.4    71    7.3   0.0     S   0.00   4.8     S   12.4   12.1   12.1  1009.2  0.00   0.0   0.123   0.000   18.7    47    7.1   17.6   8.84 1.1934    13.3     74     13       8    10.0      0    702    1    100.0   30 
2079	181	2012-11-29 20:30:18.149	2012-11-27 19:30:00	11/27/12  7:30p   12.0   12.4   12.0    73    7.3   0.0     S   0.00   3.2     S   12.0   11.7   11.7  1009.0  0.00   0.0   0.132   0.000   18.7    47    7.1   17.6   8.84 1.1932    13.3     75     13       8    10.0      0    685    1    100.0   30 
2080	181	2012-11-29 20:30:18.414	2012-11-27 20:00:00	11/27/12  8:00p   11.6   12.0   11.6    75    7.3   1.6     S   0.80   6.4     S   11.6   11.3   11.3  1008.9  0.00   0.0   0.140   0.000   18.7    48    7.4   17.7   8.94 1.1927    13.3     75     13       8    10.0      0    698    1    100.0   30 
2081	181	2012-11-29 20:30:18.644	2012-11-27 20:30:00	11/27/12  8:30p   10.8   11.6   10.8    80    7.5   0.0    SW   0.00   4.8    SW   10.8   10.7   10.7  1008.9  0.00   0.0   0.156   0.000   18.7    48    7.4   17.7   8.94 1.1927    13.3     75     13       8    10.0      0    697    1    100.0   30 
2082	181	2012-11-29 20:30:18.875	2012-11-27 21:00:00	11/27/12  9:00p   11.3   11.4   10.8    78    7.6   0.0     S   0.00   4.8     S   11.3   11.2   11.2  1008.6  0.00   0.0   0.146   0.000   18.7    48    7.4   17.7   8.94 1.1924    13.3     76     13       8    10.0      0    686    1    100.0   30 
2083	181	2012-11-29 20:30:19.108	2012-11-27 21:30:00	11/27/12  9:30p   10.8   11.3   10.8    80    7.5   0.0    SW   0.00   4.8   SSW   10.8   10.7   10.7  1008.4  0.00   0.0   0.156   0.000   18.7    48    7.4   17.7   8.94 1.1922    13.3     75     13       8    10.0      0    699    1    100.0   30 
2084	181	2012-11-29 20:30:19.337	2012-11-27 22:00:00	11/27/12 10:00p   10.3   10.8   10.3    82    7.4   0.0   WSW   0.00   1.6   WSW   10.3   10.3   10.3  1008.4  0.00   0.0   0.167   0.000   18.7    48    7.4   17.7   8.94 1.1921    13.3     75     13       8    10.0      0    687    1    100.0   30 
2085	181	2012-11-29 20:30:19.569	2012-11-27 22:30:00	11/27/12 10:30p   10.4   10.4   10.3    82    7.5   0.0    SW   0.00   1.6   WSW   10.4   10.4   10.4  1008.2  0.00   0.0   0.164   0.000   18.7    48    7.4   17.7   8.94 1.1919    13.3     75     13       8    10.0      0    696    1    100.0   30 
2086	181	2012-11-29 20:30:19.801	2012-11-27 23:00:00	11/27/12 11:00p   10.9   10.9   10.4    80    7.6   0.0    SW   0.00   1.6    SW   10.9   10.8   10.8  1008.2  0.00   0.0   0.155   0.000   18.7    48    7.4   17.7   8.94 1.1918    13.3     76     13       8    10.0      0    693    1    100.0   30 
2087	181	2012-11-29 20:30:20.032	2012-11-27 23:30:00	11/27/12 11:30p   10.9   11.0   10.9    80    7.6   0.0    SW   0.00   1.6    SW   10.9   10.8   10.8  1008.1  0.00   0.0   0.154   0.000   18.7    48    7.4   17.7   8.94 1.1918    13.3     76     13       8    10.0      0    689    1    100.0   30 
2088	181	2012-11-29 20:30:20.263	2012-11-28 00:00:00	11/28/12 12:00a   10.6   10.9   10.6    82    7.6   0.0     S   0.00   4.8     S   10.6   10.5   10.5  1008.0  0.00   0.0   0.162   0.000   18.7    48    7.4   17.7   8.94 1.1916    13.3     76     13       8    10.0      0    690    1    100.0   30 
2089	181	2012-11-29 20:30:20.494	2012-11-28 00:30:00	11/28/12 12:30a    9.5   10.6    9.5    86    7.3   0.0    SW   0.00   3.2    SW    9.5    9.6    9.6  1007.8  0.00   0.0   0.184   0.000   18.7    49    7.7   17.7   9.14 1.1911    13.3     76     13       8    10.0      0    695    1    100.0   30 
2090	181	2012-11-29 20:30:20.726	2012-11-28 01:00:00	11/28/12  1:00a    8.9    9.5    8.9    88    7.1   0.0   ---   0.00   0.0   ---    8.9    9.0    9.0  1007.5  0.00   0.0   0.196   0.000   18.7    49    7.7   17.7   9.14 1.1908    13.3     76     13       8    10.0      1    687    1    100.0   30 
2095	181	2012-11-29 20:30:22.169	2012-11-28 03:30:00	11/28/12  3:30a    9.1    9.2    8.9    90    7.6   0.0   SSW   0.00   3.2   SSW    9.1    9.2    9.2  1006.6  0.00   0.0   0.192   0.000   18.6    49    7.6   17.6   9.14 1.1903    13.3     76     13       8    10.0      1    681    1     99.6   30 
2098	181	2012-11-29 20:30:22.863	2012-11-28 05:00:00	11/28/12  5:00a    9.4    9.4    9.2    87    7.3   1.6     S   0.80   6.4    SW    9.4    9.5    9.5  1005.9  0.00   0.0   0.186   0.000   18.5    49    7.6   17.5   9.14 1.1897    13.3     75     13       8     9.4      4    697    1    100.0   30 
2104	181	2012-11-29 20:30:24.304	2012-11-28 08:00:00	11/28/12  8:00a    8.1    8.1    7.7    94    7.1   0.0     S   0.00   1.6     S    8.1    8.2    8.2  1004.9  0.00   0.0   0.214   0.000   18.4    49    7.5   17.4   9.15 1.1891    13.3     75     13       8     9.4      0    693    1    100.0   30 
2107	181	2012-11-29 20:30:24.999	2012-11-28 09:30:00	11/28/12  9:30a   10.3   10.3   10.1    87    8.3   0.0    SW   0.00   4.8    SW   10.3   10.4   10.4  1004.6  0.00   0.0   0.167   0.000   18.3    49    7.4   17.3   9.15 1.1892    13.3     76     13       8     9.4      0    700    1    100.0   30 
2113	181	2012-11-29 20:30:26.397	2012-11-28 12:30:00	11/28/12 12:30p   15.7   15.7   15.6    72   10.6   0.0   SSW   0.00   4.8     S   15.7   15.4   15.4  1001.7  0.00   0.0   0.056   0.000   18.8    50    8.1   17.9   9.33 1.1830    13.9     78     13       8    10.0      0    689    1    100.0   30 
2125	181	2012-11-29 20:30:29.448	2012-11-28 18:30:00	11/28/12  6:30p   11.2   11.2   11.1    91    9.8   0.0     S   0.00   4.8     S   11.2   11.3   11.3   996.7  0.00   0.0   0.148   0.000   20.7    50    9.9   19.8   9.27 1.1679    15.0     78     13       8    10.6      4    695    1    100.0   30 
2126	181	2012-11-29 20:30:29.677	2012-11-28 19:00:00	11/28/12  7:00p   11.3   11.3   11.2    90    9.7   1.6     S   0.80   9.7   SSE   11.3   11.4   11.4   995.9  0.00   0.0   0.147   0.000   20.7    50    9.9   19.8   9.27 1.1670    15.0     77     13       8    10.6      3    683    1     99.9   30 
2128	181	2012-11-29 20:30:30.141	2012-11-28 20:00:00	11/28/12  8:00p   10.9   11.0   10.9    90    9.4   1.6     S   0.80   9.7     S   10.9   11.1   11.1   995.0  0.00   0.0   0.154   0.000   20.6    50    9.8   19.8   9.27 1.1664    15.0     77     13       8    10.6      3    692    1    100.0   30 
2129	181	2012-11-29 20:30:30.373	2012-11-28 20:30:00	11/28/12  8:30p   10.9   10.9   10.8    90    9.4   1.6     S   0.80  11.3   SSE   10.9   11.1   11.1   994.5  0.00   0.0   0.154   0.000   20.6    50    9.8   19.8   9.27 1.1659    14.4     77     13       8    10.6      3    690    1    100.0   30 
2134	181	2012-11-29 20:30:31.529	2012-11-28 23:00:00	11/28/12 11:00p   11.7   12.2   11.7    94   10.8   3.2     S   1.61  12.9   WSW   11.7   11.9   11.9   994.3  2.00   8.6   0.138   0.000   20.3    51    9.8   19.6   9.48 1.1667    14.4     79     13       8    10.6      8    691    1    100.0   30 
2137	181	2012-11-29 20:30:32.541	2012-11-29 00:30:00	11/29/12 12:30a   11.2   11.3   10.9    94   10.3   4.8     S   2.41  12.9   WSW   11.2   11.4   11.3   994.2  0.00   0.0   0.148   0.000   20.1    51    9.7   19.4   9.49 1.1674    14.4     79     11       8    10.0      8    687    1    100.0   30 
2144	181	2012-11-29 20:30:34.214	2012-11-29 04:00:00	11/29/12  4:00a    7.3    8.7    7.3    94    6.4   0.0     S   0.00   3.2     S    7.3    7.4    7.4   993.0  0.00   0.0   0.230   0.000   19.9    50    9.2   19.2   9.29 1.1671    13.9     77     10       8    10.0     14    694    1    100.0   30 
2169	181	2012-11-29 20:30:40.194	2012-11-29 16:30:00	11/29/12  4:30p    9.8    9.9    9.8    94    8.9   0.0   NNW   0.00   3.2   NNW    9.8   10.1   10.1   994.5  0.00   0.0   0.178   0.000   19.1    51    8.7   18.3   9.52 1.1725    13.9     77      9       8    10.0     14    697    1    100.0   30 
2091	181	2012-11-29 20:30:20.957	2012-11-28 01:30:00	11/28/12  1:30a    8.8    8.9    8.8    89    7.1   0.0   ---   0.00   0.0   ---    8.8    8.9    8.9  1007.3  0.00   0.0   0.199   0.000   18.6    49    7.6   17.6   9.14 1.1911    13.3     76     13       8    10.0      1    699    1    100.0   30 
2109	181	2012-11-29 20:30:25.461	2012-11-28 10:30:00	11/28/12 10:30a   13.7   13.7   12.3    76    9.5   3.2     S   1.61   9.7     S   13.7   13.4   13.4  1004.0  0.00   0.0   0.097   0.000   18.3    49    7.4   17.3   9.15 1.1885    13.3     77     13       8     9.4      0    698    1    100.0   30 
2119	181	2012-11-29 20:30:27.96	2012-11-28 15:30:00	11/28/12  3:30p   13.4   14.1   13.4    79    9.9   3.2     S   1.61   9.7     S   13.4   13.2   13.2   999.9  0.00   0.0   0.102   0.000   19.7    51    9.3   19.1   9.50 1.1760    14.4     76     13       8    10.6     15    692    1    100.0   30 
2135	181	2012-11-29 20:30:31.759	2012-11-28 23:30:00	11/28/12 11:30p   11.3   11.7   11.3    94   10.4   3.2     S   1.61  11.3    SW   11.3   11.5   11.5   994.4  0.00   0.0   0.146   0.000   20.2    51    9.8   19.6   9.48 1.1671    14.4     79     12       8    10.6      9    692    1    100.0   30 
2145	181	2012-11-29 20:30:34.447	2012-11-29 04:30:00	11/29/12  4:30a    6.7    7.3    6.7    95    6.0   0.0     S   0.00   1.6     S    6.7    6.8    6.8   992.9  0.00   0.0   0.242   0.000   19.8    50    9.1   19.1   9.30 1.1675    13.9     76     10       8    10.0     14    692    1    100.0   30 
2156	181	2012-11-29 20:30:37.155	2012-11-29 10:00:00	11/29/12 10:00a   12.5   12.5   11.9    81    9.3   8.0   WNW   4.02  12.9    NW   11.9   12.3   11.8   993.7  0.00   0.0   0.122   0.000   19.1    48    7.8   18.2   8.92 1.1724    13.9     76     10       8     9.4      0    696    1    100.0   30 
2164	181	2012-11-29 20:30:39.039	2012-11-29 14:00:00	11/29/12  2:00p   14.2   14.8   14.2    70    8.8   1.6   WNW   0.80   6.4    NW   14.2   13.7   13.7   992.9  0.00   0.0   0.087   0.000   18.9    50    8.3   18.1   9.33 1.1718    13.9     77     10       8    10.0      0    697    1    100.0   30 
2168	181	2012-11-29 20:30:39.961	2012-11-29 16:00:00	11/29/12  4:00p    9.9   10.3    9.9    93    8.9   3.2   NNW   1.61   9.7     N    9.9   10.2   10.2   994.3  0.20   2.6   0.175   0.000   18.9    50    8.3   18.1   9.33 1.1734    13.9     78      9       8    10.0     15    691    1    100.0   30 
2092	181	2012-11-29 20:30:21.211	2012-11-28 02:00:00	11/28/12  2:00a    8.8    8.9    8.8    91    7.4   0.0    SW   0.00   1.6    SW    8.8    8.9    8.9  1007.5  0.00   0.0   0.198   0.000   18.6    49    7.6   17.6   9.14 1.1913    13.3     76     13       8    10.0      1    685    1    100.0   30 
2093	181	2012-11-29 20:30:21.608	2012-11-28 02:30:00	11/28/12  2:30a    8.9    8.9    8.8    90    7.3   0.0    SW   0.00   1.6    SW    8.9    9.0    9.0  1007.3  0.00   0.0   0.197   0.000   18.6    49    7.6   17.6   9.14 1.1911    13.3     76     13       8    10.0      2    692    1    100.0   30 
2122	181	2012-11-29 20:30:28.699	2012-11-28 17:00:00	11/28/12  5:00p   11.4   12.0   11.4    91   10.0   1.6     S   0.80   8.0   SSW   11.4   11.5   11.5   998.6  1.20   7.8   0.145   0.000   20.3    51    9.8   19.6   9.48 1.1718    15.0     77     13       8    10.6      9    697    1    100.0   30 
2131	181	2012-11-29 20:30:30.835	2012-11-28 21:30:00	11/28/12  9:30p   10.9   11.2   10.9    91    9.5   0.0    SW   0.00   4.8    SW   10.9   11.0   11.0   994.9  0.20   0.0   0.155   0.000   20.4    50    9.6   19.6   9.28 1.1671    14.4     78     13       8    10.6     11    683    1     99.9   30 
2149	181	2012-11-29 20:30:35.371	2012-11-29 06:30:00	11/29/12  6:30a    5.3    5.4    5.3    97    4.9   0.0   ---   0.00   0.0   ---    5.3    5.4    5.4   993.0  0.00   0.0   0.271   0.000   19.6    49    8.5   18.7   9.11 1.1692    13.9     72     10       8     9.4     14    686    1    100.0   30 
2155	181	2012-11-29 20:30:36.759	2012-11-29 09:30:00	11/29/12  9:30a   11.9   11.9   10.8    83    9.1   4.8   WNW   2.41  11.3     W   11.9   11.8   11.8   993.7  0.00   0.0   0.133   0.000   19.2    49    8.2   18.3   9.12 1.1716    13.9     75     10       8     9.4      0    691    1    100.0   30 
2159	181	2012-11-29 20:30:37.849	2012-11-29 11:30:00	11/29/12 11:30a   14.2   14.2   13.3    75    9.8   9.7    NW   4.83  22.5    NW   13.7   13.9   13.4   993.3  0.00   0.0   0.087   0.000   18.9    49    8.0   18.0   9.13 1.1725    13.9     76     10       8     9.4      0    696    1    100.0   30 
2171	181	2012-11-29 20:30:40.657	2012-11-29 17:30:00	11/29/12  5:30p    9.3    9.6    9.3    95    8.5   0.0   ---   0.00   0.0   ---    9.3    9.6    9.6   994.7  0.00   0.0   0.189   0.000   19.4    51    9.0   18.7   9.51 1.1712    14.4     77      8       8    10.0     14    690    1    100.0   30 
2094	181	2012-11-29 20:30:21.937	2012-11-28 03:00:00	11/28/12  3:00a    8.9    8.9    8.8    90    7.3   0.0   SSW   0.00   4.8    SW    8.9    9.0    9.0  1006.8  0.00   0.0   0.197   0.000   18.6    49    7.6   17.6   9.14 1.1905    13.3     76     13       8    10.0      2    699    1    100.0   30 
2099	181	2012-11-29 20:30:23.106	2012-11-28 05:30:00	11/28/12  5:30a    9.1    9.4    9.1    88    7.2   0.0     S   0.00   4.8   SSE    9.1    9.2    9.2  1005.6  0.00   0.0   0.192   0.000   18.5    49    7.6   17.5   9.14 1.1893    13.3     75     13       8     9.4      0    692    1    100.0   30 
2105	181	2012-11-29 20:30:24.537	2012-11-28 08:30:00	11/28/12  8:30a    9.2    9.2    8.1    91    7.8   0.0     S   0.00   1.6     S    9.2    9.4    9.4  1004.7  0.00   0.0   0.190   0.000   18.3    49    7.4   17.3   9.15 1.1893    13.3     76     13       8     9.4      0    694    1    100.0   30 
2114	181	2012-11-29 20:30:26.628	2012-11-28 13:00:00	11/28/12  1:00p   15.7   15.7   15.3    72   10.7   3.2     S   1.61  12.9    SW   15.7   15.4   15.4  1001.5  0.00   0.0   0.054   0.000   18.9    51    8.6   18.1   9.53 1.1818    13.9     78     13       8    10.0      0    690    1    100.0   30 
2136	181	2012-11-29 20:30:32.311	2012-11-29 00:00:00	11/29/12 12:00a   10.9   11.3   10.9    95   10.2   1.6     S   0.80   8.0    SW   10.9   11.1   11.1   994.3  0.00   0.0   0.154   0.000   20.2    51    9.8   19.6   9.48 1.1670    14.4     79     12       8    10.6     11    691    1    100.0   30 
2138	181	2012-11-29 20:30:32.773	2012-11-29 01:00:00	11/29/12  1:00a   11.1   11.2   11.1    94   10.1   4.8   SSW   2.41  14.5   WSW   11.0   11.2   11.2   994.0  0.00   0.0   0.152   0.000   20.1    51    9.7   19.4   9.49 1.1671    14.4     79     11       8    10.0      3    699    1    100.0   30 
2143	181	2012-11-29 20:30:33.983	2012-11-29 03:30:00	11/29/12  3:30a    8.7    9.1    8.7    96    8.1   1.6     S   0.80   8.0     S    8.7    8.9    8.9   993.4  0.00   0.0   0.201   0.000   19.9    50    9.2   19.2   9.29 1.1675    13.9     77     10       8    10.0     13    692    1    100.0   30 
2150	181	2012-11-29 20:30:35.602	2012-11-29 07:00:00	11/29/12  7:00a    5.3    5.8    5.3    96    4.7   0.0     S   0.00   1.6     S    5.3    5.4    5.4   992.9  0.00   0.0   0.271   0.000   19.4    49    8.4   18.6   9.11 1.1696    13.9     72     10       8     9.4     14    690    1    100.0   30 
2157	181	2012-11-29 20:30:37.386	2012-11-29 10:30:00	11/29/12 10:30a   13.1   13.1   12.5    76    8.9   9.7   WNW   4.83  17.7   WNW   12.3   12.8   12.1   993.7  0.00   0.0   0.110   0.000   19.0    48    7.7   18.0   8.93 1.1730    13.9     76     10       8     9.4      0    689    1    100.0   30 
2163	181	2012-11-29 20:30:38.807	2012-11-29 13:30:00	11/29/12  1:30p   14.8   14.8   14.1    67    8.7   3.2   WNW   1.61   9.7   WNW   14.8   14.3   14.3   993.0  0.00   0.0   0.074   0.000   18.9    50    8.3   18.1   9.33 1.1719    13.9     77     10       8     9.4      0    689    1    100.0   30 
2170	181	2012-11-29 20:30:40.425	2012-11-29 17:00:00	11/29/12  5:00p    9.6    9.8    9.6    95    8.8   0.0   NNW   0.00   1.6   NNW    9.6    9.8    9.8   994.6  0.20   0.0   0.183   0.000   19.3    51    8.9   18.5   9.52 1.1719    14.4     77      8       8    10.0     15    679    1     99.3   30 
2173	181	2012-11-29 20:30:41.119	2012-11-29 18:30:00	11/29/12  6:30p    8.9    9.2    8.9    95    8.2   0.0     W   0.00   1.6   WNW    8.9    9.2    9.2   994.8  0.00   0.0   0.196   0.000   19.6    51    9.1   18.8   9.51 1.1707    14.4     77      8       8    10.0     11    689    1    100.0   30 
2174	181	2012-11-29 20:30:41.349	2012-11-29 19:00:00	11/29/12  7:00p    8.5    8.9    8.5    96    7.9   0.0   ---   0.00   0.0   ---    8.5    8.7    8.7   995.0  0.00   0.0   0.205   0.000   19.7    51    9.2   18.9   9.50 1.1704    14.4     77      8       8    10.0     13    696    1    100.0   30 
2096	181	2012-11-29 20:30:22.4	2012-11-28 04:00:00	11/28/12  4:00a    9.2    9.2    9.1    89    7.4   0.0   SSW   0.00   1.6   SSW    9.2    9.3    9.3  1006.3  0.00   0.0   0.191   0.000   18.6    49    7.6   17.6   9.14 1.1899    13.3     76     13       8    10.0      0    702    1    100.0   30 
2097	181	2012-11-29 20:30:22.632	2012-11-28 04:30:00	11/28/12  4:30a    9.2    9.2    9.2    89    7.4   0.0   SSW   0.00   4.8    SW    9.2    9.3    9.3  1006.1  0.00   0.0   0.191   0.000   18.5    49    7.6   17.5   9.14 1.1899    13.3     75     13       8     9.4      0    685    1    100.0   30 
2100	181	2012-11-29 20:30:23.381	2012-11-28 06:00:00	11/28/12  6:00a    8.5    9.1    8.5    90    7.0   0.0     S   0.00   1.6     S    8.5    8.6    8.6  1005.3  0.00   0.0   0.205   0.000   18.5    49    7.6   17.5   9.14 1.1890    13.3     75     13       8     9.4      0    691    1    100.0   30 
2102	181	2012-11-29 20:30:23.842	2012-11-28 07:00:00	11/28/12  7:00a    8.3    8.5    8.3    91    6.9   0.0     S   0.00   1.6     S    8.3    8.4    8.4  1005.3  0.00   0.0   0.209   0.000   18.4    49    7.5   17.4   9.15 1.1895    13.3     76     13       8     9.4      2    694    1    100.0   30 
2103	181	2012-11-29 20:30:24.075	2012-11-28 07:30:00	11/28/12  7:30a    7.7    8.2    7.7    93    6.6   0.0     S   0.00   1.6     S    7.7    7.8    7.8  1005.3  0.00   0.0   0.222   0.000   18.4    49    7.5   17.4   9.15 1.1895    13.3     75     13       8     9.4      1    691    1    100.0   30 
2110	181	2012-11-29 20:30:25.693	2012-11-28 11:00:00	11/28/12 11:00a   14.3   14.3   13.7    74    9.7   3.2     S   1.61   9.7     S   14.3   13.9   13.9  1003.3  0.00   0.0   0.084   0.000   18.3    50    7.7   17.3   9.35 1.1874    13.3     77     13       8     9.4      0    693    1    100.0   30 
2111	181	2012-11-29 20:30:25.934	2012-11-28 11:30:00	11/28/12 11:30a   15.8   15.8   14.3    72   10.8   3.2     S   1.61   9.7   SSE   15.8   15.6   15.6  1002.7  0.00   0.0   0.052   0.000   18.4    50    7.8   17.4   9.35 1.1862    13.3     78     13       8     9.4      0    686    1    100.0   30 
2115	181	2012-11-29 20:30:27.036	2012-11-28 13:30:00	11/28/12  1:30p   15.6   16.1   15.6    68    9.7   4.8     S   2.41  19.3    SW   15.6   15.2   15.2  1000.6  0.00   0.0   0.057   0.000   19.0    51    8.6   18.2   9.53 1.1805    13.9     77     13       8    10.0      0    696    1    100.0   30 
2120	181	2012-11-29 20:30:28.193	2012-11-28 16:00:00	11/28/12  4:00p   12.3   13.4   12.3    85    9.8   3.2     S   1.61  12.9   SSW   12.3   12.2   12.2   999.0  0.40   0.0   0.126   0.000   19.9    51    9.5   19.3   9.49 1.1739    15.0     77     13       8    10.6     13    695    1    100.0   30 
2121	181	2012-11-29 20:30:28.468	2012-11-28 16:30:00	11/28/12  4:30p   12.0   12.3   12.0    86    9.7   3.2     S   1.61  11.3   SSE   12.0   11.9   11.9   998.9  0.00   0.0   0.132   0.000   20.1    51    9.7   19.4   9.49 1.1729    15.0     77     13       8    10.6     15    688    1    100.0   30 
2123	181	2012-11-29 20:30:28.93	2012-11-28 17:30:00	11/28/12  5:30p   11.2   11.4   11.2    92    9.9   0.0   SSW   0.00   4.8   SSW   11.2   11.3   11.3   998.0  0.00   0.0   0.149   0.000   20.5    51   10.0   19.8   9.47 1.1700    15.0     77     13       8    10.6     10    686    1    100.0   30 
2124	181	2012-11-29 20:30:29.161	2012-11-28 18:00:00	11/28/12  6:00p   11.1   11.2   11.1    92    9.9   0.0     S   0.00   4.8   SSE   11.1   11.2   11.2   997.4  0.00   0.0   0.150   0.000   20.6    51   10.1   19.8   9.47 1.1691    15.0     78     13       8    10.6      7    692    1    100.0   30 
2130	181	2012-11-29 20:30:30.604	2012-11-28 21:00:00	11/28/12  9:00p   11.2   11.2   10.9    89    9.4   1.6     S   0.80  11.3   SSE   11.2   11.3   11.3   994.5  0.00   0.0   0.149   0.000   20.5    50    9.7   19.7   9.27 1.1661    14.4     77     13       8    10.6     12    696    1    100.0   30 
2133	181	2012-11-29 20:30:31.297	2012-11-28 22:30:00	11/28/12 10:30p   12.2   12.2   10.7    92   10.9   8.0   WNW   4.02  22.5   WNW   11.6   12.2   11.6   996.3  1.80   9.4   0.128   0.000   20.3    50    9.5   19.5   9.28 1.1693    14.4     79     13       8    10.6      7    686    1    100.0   30 
2139	181	2012-11-29 20:30:33.008	2012-11-29 01:30:00	11/29/12  1:30a   10.6   11.1   10.6    94    9.6   4.8     S   2.41  14.5   SSE   10.4   10.8   10.7   993.8  0.00   0.0   0.162   0.000   20.1    51    9.7   19.4   9.49 1.1670    14.4     79     10       8    10.0      3    682    1     99.7   30 
2140	181	2012-11-29 20:30:33.279	2012-11-29 02:00:00	11/29/12  2:00a   10.0   10.6   10.0    94    9.1   3.2     S   1.61   9.7   SSE   10.0   10.3   10.3   993.5  0.00   0.0   0.174   0.000   20.0    50    9.3   19.3   9.29 1.1674    14.4     78     10       8    10.0      3    700    1    100.0   30 
2142	181	2012-11-29 20:30:33.752	2012-11-29 03:00:00	11/29/12  3:00a    9.1    9.4    9.1    95    8.3   1.6    SW   0.80   9.7   WSW    9.1    9.3    9.3   993.3  0.00   0.0   0.193   0.000   20.1    50    9.4   19.4   9.29 1.1666    13.9     78     10       8    10.0     11    699    1    100.0   30 
2146	181	2012-11-29 20:30:34.677	2012-11-29 05:00:00	11/29/12  5:00a    5.6    6.7    5.4    96    5.0   1.6     W   0.80   3.2   WSW    5.6    5.6    5.6   992.8  0.00   0.0   0.266   0.000   19.7    49    8.7   18.9   9.10 1.1682    13.9     75     10       8    10.0     14    694    1    100.0   30 
2152	181	2012-11-29 20:30:36.065	2012-11-29 08:00:00	11/29/12  8:00a    7.5    7.5    6.0    96    6.9   6.4    NW   3.22  11.3    NW    6.5    7.7    6.7   993.7  0.00   0.0   0.226   0.000   19.4    48    8.1   18.6   8.91 1.1708    13.9     73     10       8     9.4     13    694    1    100.0   30 
2158	181	2012-11-29 20:30:37.617	2012-11-29 11:00:00	11/29/12 11:00a   13.3   13.4   13.1    76    9.2  11.3    NW   5.63  19.3   WNW   12.4   13.1   12.2   993.5  0.00   0.0   0.104   0.000   18.9    48    7.7   17.9   8.93 1.1730    13.9     76     10       8     9.4      0    689    1    100.0   30 
2161	181	2012-11-29 20:30:38.344	2012-11-29 12:30:00	11/29/12 12:30p   14.7   14.7   14.0    67    8.6   6.4    NW   3.22  12.9   WNW   14.7   14.2   14.2   992.7  0.00   0.0   0.076   0.000   18.9    50    8.3   18.1   9.33 1.1715    13.9     76     10       8     9.4      0    699    1    100.0   30 
2176	181	2012-11-29 20:30:41.813	2012-11-29 20:00:00	11/29/12  8:00p    8.2    8.3    8.2    96    7.6   0.0   ---   0.00   0.0   ---    8.2    8.4    8.4   995.1  0.00   0.0   0.211   0.000   19.7    50    9.0   18.9   9.30 1.1706    14.4     76      8       8    10.0     13    700    1    100.0   30 
2101	181	2012-11-29 20:30:23.612	2012-11-28 06:30:00	11/28/12  6:30a    8.4    8.5    8.3    91    7.1   0.0     S   0.00   1.6     S    8.4    8.6    8.6  1005.5  0.00   0.0   0.206   0.000   18.5    49    7.6   17.5   9.14 1.1892    13.3     76     13       8     9.4      0    694    1    100.0   30 
2108	181	2012-11-29 20:30:25.231	2012-11-28 10:00:00	11/28/12 10:00a   12.3   12.3   10.3    80    8.9   1.6    SW   0.80   4.8    SW   12.3   12.1   12.1  1004.4  0.00   0.0   0.126   0.000   18.3    49    7.4   17.3   9.15 1.1889    13.3     77     13       8     9.4      0    683    1     99.9   30 
2147	181	2012-11-29 20:30:34.908	2012-11-29 05:30:00	11/29/12  5:30a    5.8    5.8    5.6    96    5.2   0.0     W   0.00   3.2     W    5.8    5.9    5.9   993.0  0.00   0.0   0.260   0.000   19.7    49    8.6   18.8   9.10 1.1687    13.9     74     10       8    10.0     14    689    1    100.0   30 
2153	181	2012-11-29 20:30:36.296	2012-11-29 08:30:00	11/29/12  8:30a    9.8    9.8    7.5    91    8.4   6.4    NW   3.22  14.5    NW    9.2   10.0    9.3   993.7  0.00   0.0   0.177   0.000   19.3    48    8.0   18.3   8.92 1.1716    13.9     74     10       8     9.4      6    695    1    100.0   30 
2160	181	2012-11-29 20:30:38.081	2012-11-29 12:00:00	11/29/12 12:00p   14.0   14.3   13.9    73    9.2   6.4    NW   3.22  14.5    NW   14.0   13.7   13.7   992.9  0.00   0.0   0.090   0.000   18.9    49    8.0   18.0   9.13 1.1720    13.9     76     10       8     9.4      0    683    1     99.9   30 
2166	181	2012-11-29 20:30:39.5	2012-11-29 15:00:00	11/29/12  3:00p   12.7   13.8   12.7    80    9.4   4.8    NW   2.41  24.1   NNW   12.7   12.6   12.6   994.0  0.00   0.0   0.117   0.000   18.9    50    8.3   18.1   9.33 1.1731    13.3     77     10       8    10.0      1    693    1    100.0   30 
2172	181	2012-11-29 20:30:40.888	2012-11-29 18:00:00	11/29/12  6:00p    9.2    9.3    9.2    96    8.6   0.0   WNW   0.00   3.2   NNW    9.2    9.4    9.4   995.0  0.00   0.0   0.191   0.000   19.6    51    9.1   18.8   9.51 1.1711    14.4     77      8       8    10.0     14    691    1    100.0   30 
2175	181	2012-11-29 20:30:41.582	2012-11-29 19:30:00	11/29/12  7:30p    8.3    8.5    8.3    96    7.7   0.0   WSW   0.00   3.2   WNW    8.3    8.5    8.5   994.9  0.00   0.0   0.208   0.000   19.7    50    9.0   18.9   9.30 1.1704    14.4     76      8       8    10.0     13    680    1     99.4   30 
2106	181	2012-11-29 20:30:24.768	2012-11-28 09:00:00	11/28/12  9:00a   10.1   10.1    9.3    87    8.0   0.0     S   0.00   4.8     S   10.1   10.2   10.2  1004.6  0.00   0.0   0.172   0.000   18.3    49    7.4   17.3   9.15 1.1892    13.3     76     13       8     9.4      0    690    1    100.0   30 
2116	181	2012-11-29 20:30:27.268	2012-11-28 14:00:00	11/28/12  2:00p   14.7   15.6   14.7    72    9.7   3.2     S   1.61  14.5     S   14.7   14.3   14.3  1000.5  0.00   0.0   0.075   0.000   19.2    51    8.8   18.4   9.52 1.1792    14.4     77     13       8    10.0      0    692    1    100.0   30 
2118	181	2012-11-29 20:30:27.729	2012-11-28 15:00:00	11/28/12  3:00p   14.1   14.7   14.1    75    9.7   1.6     S   0.80   9.7     S   14.1   13.8   13.8   999.8  0.00   0.0   0.088   0.000   19.6    51    9.1   18.8   9.51 1.1768    14.4     77     13       8    10.6      0    690    1    100.0   30 
2141	181	2012-11-29 20:30:33.521	2012-11-29 02:30:00	11/29/12  2:30a    9.5    9.9    9.4    95    8.7   1.6     S   0.80   8.0    SW    9.5    9.8    9.8   993.2  0.00   0.0   0.184   0.000   20.4    49    9.3   19.6   9.08 1.1654    13.9     78     10       8    10.0      7    689    1    100.0   30 
2148	181	2012-11-29 20:30:35.14	2012-11-29 06:00:00	11/29/12  6:00a    5.3    5.9    5.2    96    4.7   0.0     W   0.00   6.4   WSW    5.3    5.3    5.3   993.3  0.00   0.0   0.272   0.000   19.6    49    8.5   18.7   9.11 1.1695    13.9     73     10       8    10.0     14    696    1    100.0   30 
2151	181	2012-11-29 20:30:35.834	2012-11-29 07:30:00	11/29/12  7:30a    6.0    6.0    5.2    97    5.6   3.2    NW   1.61   9.7    NW    6.0    6.1    6.1   993.3  0.00   0.0   0.257   0.000   19.7    48    8.3   18.8   8.90 1.1692    13.9     72     10       8     9.4     14    697    1    100.0   30 
2154	181	2012-11-29 20:30:36.527	2012-11-29 09:00:00	11/29/12  9:00a   10.8   10.8    9.8    89    9.0   4.8    NW   2.41  11.3    NW   10.7   10.9   10.8   993.7  0.00   0.0   0.157   0.000   19.2    49    8.2   18.3   9.12 1.1717    13.9     75     10       8     9.4      0    692    1    100.0   30 
2165	181	2012-11-29 20:30:39.269	2012-11-29 14:30:00	11/29/12  2:30p   13.8   14.2   13.8    71    8.7   3.2    NW   1.61   8.0    NW   13.8   13.4   13.4   993.2  0.00   0.0   0.094   0.000   18.8    50    8.2   17.9   9.33 1.1726    13.9     77     10       8    10.0      0    688    1    100.0   30 
2112	181	2012-11-29 20:30:26.166	2012-11-28 12:00:00	11/28/12 12:00p   15.7   15.8   15.6    72   10.6   1.6   SSW   0.80   9.7     S   15.7   15.4   15.4  1002.0  0.00   0.0   0.056   0.000   18.6    50    7.9   17.6   9.34 1.1846    13.9     78     13       8     9.4      0    703    1    100.0   30 
2117	181	2012-11-29 20:30:27.498	2012-11-28 14:30:00	11/28/12  2:30p   14.7   14.9   14.7    72    9.7   3.2     S   1.61  11.3    SW   14.7   14.3   14.3  1000.2  0.00   0.0   0.075   0.000   19.4    51    9.0   18.7   9.51 1.1780    14.4     77     13       8    10.0      0    689    1    100.0   30 
2127	181	2012-11-29 20:30:29.91	2012-11-28 19:30:00	11/28/12  7:30p   11.0   11.3   11.0    90    9.4   1.6     S   0.80   9.7     S   11.0   11.1   11.1   995.1  0.00   0.0   0.153   0.000   20.7    50    9.9   19.8   9.27 1.1661    15.0     77     13       8    10.6      3    696    1    100.0   30 
2132	181	2012-11-29 20:30:31.065	2012-11-28 22:00:00	11/28/12 10:00p   10.7   10.9   10.7    93    9.6   3.2    SW   1.61  20.9   WNW   10.7   10.9   10.9   996.1  0.80   3.8   0.159   0.000   20.4    50    9.6   19.6   9.28 1.1686    14.4     78     13       8    10.6      9    701    1    100.0   30 
2162	181	2012-11-29 20:30:38.575	2012-11-29 13:00:00	11/29/12  1:00p   14.1   14.7   14.1    72    9.1   6.4   WNW   3.22  12.9   WNW   14.1   13.7   13.7   992.9  0.00   0.0   0.088   0.000   18.9    50    8.3   18.1   9.33 1.1718    13.9     77     10       8     9.4      0    690    1    100.0   30 
2167	181	2012-11-29 20:30:39.73	2012-11-29 15:30:00	11/29/12  3:30p   10.3   12.7   10.3    91    8.9  11.3   NNW   5.63  27.4    NW    8.8   10.4    8.9   994.3  2.40  75.2   0.168   0.000   18.8    50    8.2   17.9   9.33 1.1739    13.3     77     10       8    10.0     15    690    1    100.0   30 
2177	181	2012-11-29 21:09:55.736	2012-11-29 20:30:00	11/29/12  8:30p    8.4    8.4    8.0    97    7.9   0.0   SSW   0.00   3.2     S    8.4    8.6    8.6   995.5  0.00   0.0   0.207   0.000   19.8    50    9.1   19.1   9.30 1.1706    14.4     76      8       8    10.0     13    690    1    100.0   30 
2178	181	2012-11-29 21:09:55.998	2012-11-29 21:00:00	11/29/12  9:00p    8.6    8.6    8.4    96    8.0   0.0   SSW   0.00   3.2   SSW    8.6    8.8    8.8   995.5  0.00   0.0   0.204   0.000   19.8    50    9.1   19.1   9.30 1.1705    14.4     76      9       8    10.0     14    689    1    100.0   30 
2179	181	2012-11-29 22:04:18.867	2012-11-29 21:30:00	11/29/12  9:30p    8.6    8.7    8.6    96    8.0   0.0     S   0.00   3.2     S    8.6    8.8    8.8   995.6  0.00   0.0   0.203   0.000   20.0    50    9.3   19.3   9.29 1.1698    14.4     76      9       8    10.0     14    697    1    100.0   30 
2180	181	2012-11-29 22:04:19.126	2012-11-29 22:00:00	11/29/12 10:00p    8.5    8.6    8.5    96    7.9   0.0   ---   0.00   0.0   ---    8.5    8.7    8.7   995.6  0.00   0.0   0.205   0.000   20.0    50    9.3   19.3   9.29 1.1699    14.4     76      9       8    10.0     14    683    1     99.9   30 
2181	181	2012-11-29 23:04:41.752	2012-11-29 22:30:00	11/29/12 10:30p    8.5    8.5    8.4    96    7.9   0.0   ---   0.00   0.0   ---    8.5    8.7    8.7   996.0  0.40   1.6   0.205   0.000   20.1    50    9.4   19.4   9.29 1.1698    14.4     75      9       8    10.0     12    699    1    100.0   30 
2182	181	2012-11-29 23:04:42.003	2012-11-29 23:00:00	11/29/12 11:00p    8.7    8.7    8.5    96    8.1   1.6     E   0.80  11.3     E    8.7    8.9    8.9   996.2  1.20   9.2   0.201   0.000   20.1    50    9.4   19.4   9.29 1.1701    14.4     75      9       8    10.0      6    689    1    100.0   30 
2183	181	2012-11-30 00:05:03.179	2012-11-29 23:30:00	11/29/12 11:30p    7.1    8.7    7.1    95    6.3   8.0     E   4.02  25.7     E    5.6    7.2    5.7   996.6  1.60   5.4   0.235   0.000   20.1    50    9.4   19.4   9.29 1.1705    14.4     74      8       8    10.0      9    687    1    100.0   30 
2184	181	2012-11-30 00:05:03.419	2012-11-30 00:00:00	11/30/12 12:00a    6.1    7.1    6.1    94    5.2   8.0     E   4.02  24.1     E    4.4    6.2    4.5   997.7  0.80   4.4   0.255   0.000   20.0    49    9.0   19.2   9.09 1.1726    14.4     73      8       8    10.0      6    696    1    100.0   30 
2185	181	2012-11-30 01:05:22.442	2012-11-30 00:30:00	11/30/12 12:30a    5.6    6.1    5.6    94    4.7   8.0     E   4.02  24.1     E    3.8    5.6    3.8   998.6  1.60   7.4   0.266   0.000   19.9    49    8.9   19.2   9.09 1.1740    13.9     70      8       8    10.0      4    684    1    100.0   30 
2186	181	2012-11-30 01:05:22.698	2012-11-30 01:00:00	11/30/12  1:00a    5.2    5.6    5.2    94    4.3   8.0     E   4.02  22.5    SE    3.3    5.2    3.4   998.8  1.20   5.6   0.274   0.000   19.7    48    8.4   18.8   8.90 1.1755    13.9     68      8       8     9.4      4    697    1    100.0   30 
2187	181	2012-11-30 02:05:40.785	2012-11-30 01:30:00	11/30/12  1:30a    4.9    5.2    4.9    95    4.2   3.2     E   1.61  12.9   ESE    4.8    4.9    4.9   999.5  0.80   4.0   0.280   0.000   19.7    47    8.0   18.7   8.80 1.1769    13.9     68      8       8     9.4      4    697    1    100.0   30 
2188	181	2012-11-30 02:05:41.025	2012-11-30 02:00:00	11/30/12  2:00a    4.2    4.9    4.2    92    3.0   4.8     E   2.41  22.5     E    3.3    4.2    3.3   999.5  1.00   4.8   0.294   0.000   19.6    47    7.9   18.6   8.81 1.1775    13.9     66      8       8     9.4      3    684    1    100.0   30 
2189	181	2012-11-30 03:03:59.089	2012-11-30 02:30:00	11/30/12  2:30a    3.9    4.2    3.9    93    2.9   6.4     E   3.22  27.4   ESE    2.4    3.9    2.4   999.7  0.60   1.6   0.300   0.000   19.4    46    7.5   18.4   8.65 1.1785    13.3     64      8       8     9.4      3    692    1    100.0   30 
2190	181	2012-11-30 03:03:59.329	2012-11-30 03:00:00	11/30/12  3:00a    3.8    3.9    3.8    93    2.7   6.4     E   3.22  22.5   ESE    2.2    3.8    2.2   999.9  0.40   1.8   0.303   0.000   19.4    45    7.1   18.3   8.51 1.1793    13.3     64      8       8     8.9      4    694    1    100.0   30 
2191	181	2012-11-30 04:04:17.643	2012-11-30 03:30:00	11/30/12  3:30a    3.7    3.8    3.7    95    3.0   3.2   ESE   1.61  12.9     E    3.5    3.7    3.5  1000.0  0.80   3.0   0.304   0.000   19.3    45    7.0   18.2   8.52 1.1800    13.3     64      8       8     8.9      4    688    1    100.0   30 
2192	181	2012-11-30 04:04:17.919	2012-11-30 04:00:00	11/30/12  4:00a    3.5    3.7    3.5    94    2.6   1.6     E   0.80  12.9    SE    3.5    3.5    3.5  1000.6  0.60   2.8   0.309   0.000   19.2    45    7.0   18.1   8.52 1.1809    13.3     64      8       8     8.9      3    691    1    100.0   30 
2193	181	2012-11-30 05:04:36.272	2012-11-30 04:30:00	11/30/12  4:30a    3.3    3.5    3.3    93    2.3   3.2   ESE   1.61  12.9     E    3.1    3.3    3.1  1001.1  1.00   4.4   0.313   0.000   19.1    44    6.6   17.9   8.35 1.1823    13.3     63      8       8     8.9      3    686    1    100.0   30 
2194	181	2012-11-30 05:04:36.518	2012-11-30 05:00:00	11/30/12  5:00a    3.3    3.3    3.3    94    2.4   3.2   ESE   1.61  12.9   ESE    3.1    3.3    3.1  1001.6  0.60   2.0   0.314   0.000   19.0    44    6.5   17.8   8.35 1.1834    12.8     63      8       8     8.9      3    701    1    100.0   30 
2195	181	2012-11-30 06:04:54.515	2012-11-30 05:30:00	11/30/12  5:30a    3.2    3.3    3.2    93    2.2   4.8   ESE   2.41  17.7     E    2.2    3.2    2.2  1002.0  0.60   2.4   0.315   0.000   18.9    44    6.4   17.7   8.35 1.1842    12.8     63      8       8     8.3      3    690    1    100.0   30 
2196	181	2012-11-30 06:04:54.755	2012-11-30 06:00:00	11/30/12  6:00a    3.1    3.2    3.1    94    2.2   4.8   ESE   2.41  16.1   ESE    1.9    3.1    1.9  1002.3  0.60   2.0   0.318   0.000   18.8    44    6.3   17.6   8.35 1.1850    12.8     62      8       8     8.3      4    692    1    100.0   30 
2221	181	2012-11-30 07:37:17.159	2012-11-30 06:30:00	11/30/12  6:30a    2.8    3.1    2.8    94    2.0   3.2   ESE   1.61  16.1   ESE    2.6    2.8    2.6  1002.5  0.60   2.8   0.323   0.000   18.8    43    5.9   17.5   8.25 1.1859    12.8     62      8       8     8.3      4    694    1    100.0   30 
2222	181	2012-11-30 07:37:17.516	2012-11-30 07:00:00	11/30/12  7:00a    2.8    2.8    2.7    94    1.9   3.2     E   1.61  12.9   ESE    2.5    2.8    2.5  1002.8  0.40   1.4   0.324   0.000   18.7    43    5.8   17.4   8.25 1.1867    12.8     63      8       8     8.3      3    689    1    100.0   30 
2241	181	2012-11-30 08:04:37.99	2012-11-30 07:30:00	11/30/12  7:30a    2.8    2.8    2.7    95    2.1   0.0     E   0.00   6.4   ESE    2.8    2.8    2.8  1003.4  0.00   0.0   0.323   0.000   18.6    44    6.1   17.3   8.35 1.1877    12.8     64      8       8     8.3      7    698    1    100.0   30 
2242	181	2012-11-30 08:04:38.307	2012-11-30 08:00:00	11/30/12  8:00a    2.9    2.9    2.8    95    2.2   0.0     E   0.00   8.0     E    2.9    2.9    2.9  1003.6  0.40   1.2   0.321   0.000   18.6    44    6.1   17.3   8.35 1.1880    12.8     66      8       8     8.3      9    687    1    100.0   30 
2243	181	2012-11-30 09:04:59.498	2012-11-30 08:30:00	11/30/12  8:30a    3.1    3.1    2.9    95    2.4   0.0     E   0.00   4.8     E    3.1    3.1    3.1  1003.8  0.40   0.8   0.317   0.000   18.7    45    6.5   17.5   8.54 1.1874    12.8     65      8       8     8.3     10    687    1    100.0   30 
2244	181	2012-11-30 09:04:59.791	2012-11-30 09:00:00	11/30/12  9:00a    3.4    3.4    3.1    96    2.9   0.0   ESE   0.00   3.2   ESE    3.4    3.4    3.4  1004.5  0.00   0.0   0.310   0.000   18.8    45    6.6   17.7   8.53 1.1874    12.8     68      8       8     8.3      9    694    1    100.0   30 
2245	181	2012-11-30 10:05:19.339	2012-11-30 09:30:00	11/30/12  9:30a    4.0    4.0    3.4    96    3.4   0.0     E   0.00   4.8     E    4.0    4.1    4.1  1004.7  0.00   0.0   0.299   0.000   19.0    45    6.8   17.8   8.53 1.1869    13.3     69      8       8     8.3      7    688    1    100.0   30 
2246	181	2012-11-30 10:05:19.593	2012-11-30 10:00:00	11/30/12 10:00a    4.1    4.2    4.0    93    3.1   1.6     E   0.80   8.0     E    4.1    4.1    4.1  1005.4  0.20   0.0   0.296   0.000   19.1    46    7.2   18.1   8.65 1.1869    13.3     69      8       8     7.8      8    694    1    100.0   30 
2247	181	2012-11-30 11:05:40.494	2012-11-30 10:30:00	11/30/12 10:30a    4.6    4.6    4.1    92    3.4   3.2     E   1.61  12.9    SE    4.4    4.6    4.4  1005.5  0.00   0.0   0.287   0.000   19.1    46    7.2   18.1   8.65 1.1871    13.3     69      8       8     7.8      8    688    1    100.0   30 
2248	181	2012-11-30 11:05:40.76	2012-11-30 11:00:00	11/30/12 11:00a    4.8    4.8    4.6    92    3.6   1.6     E   0.80   9.7     E    4.8    4.8    4.8  1005.5  0.00   0.0   0.281   0.000   19.2    46    7.3   18.2   8.65 1.1865    13.3     69      8       8     7.8      1    692    1    100.0   30 
2249	181	2012-11-30 12:04:00.338	2012-11-30 11:30:00	11/30/12 11:30a    5.1    5.1    4.8    90    3.6   1.6     E   0.80   9.7     E    5.1    5.0    5.0  1005.6  0.20   0.0   0.277   0.000   19.2    45    7.0   18.1   8.52 1.1868    13.3     69      8       8     8.3      1    696    1    100.0   30 
2250	181	2012-11-30 12:04:00.576	2012-11-30 12:00:00	11/30/12 12:00p    5.2    5.2    5.1    90    3.7   0.0   ESE   0.00   6.4   ESE    5.2    5.2    5.2  1005.7  0.00   0.0   0.273   0.000   19.1    45    6.9   18.0   8.52 1.1876    13.3     69      8       8     8.3      1    680    1     99.4   30 
2251	181	2012-11-30 13:04:19.826	2012-11-30 12:30:00	11/30/12 12:30p    5.4    5.4    5.2    89    3.8   0.0   ESE   0.00   3.2     E    5.4    5.4    5.4  1005.8  0.00   0.0   0.269   0.000   19.2    45    7.0   18.1   8.52 1.1872    13.3     69      8       8     8.3      1    696    1    100.0   30 
2252	181	2012-11-30 13:04:20.069	2012-11-30 13:00:00	11/30/12  1:00p    5.6    5.7    5.4    86    3.5   0.0   ESE   0.00   4.8     E    5.6    5.5    5.5  1005.9  0.00   0.0   0.265   0.000   19.2    45    7.0   18.1   8.52 1.1872    13.3     69      8       8     8.3      0    690    1    100.0   30 
2253	181	2012-11-30 14:04:39.248	2012-11-30 13:30:00	11/30/12  1:30p    5.7    5.8    5.7    82    2.9   1.6     E   0.80   9.7     E    5.7    5.6    5.6  1005.9  0.00   0.0   0.263   0.000   19.1    45    6.9   18.0   8.52 1.1878    13.3     68      8       8     8.3      0    684    1    100.0   30 
2254	181	2012-11-30 14:04:39.53	2012-11-30 14:00:00	11/30/12  2:00p    5.8    5.8    5.7    82    3.0   0.0   ESE   0.00   6.4   ESE    5.8    5.7    5.7  1006.3  0.00   0.0   0.260   0.000   19.0    45    6.8   17.8   8.53 1.1888    13.3     68      8       8     8.3      0    700    1    100.0   30 
2255	181	2012-11-30 15:05:01.361	2012-11-30 14:30:00	11/30/12  2:30p    5.7    5.8    5.7    81    2.7   1.6   ESE   0.80   8.0     E    5.7    5.6    5.6  1006.4  0.00   0.0   0.263   0.000   18.9    45    6.7   17.8   8.53 1.1892    13.3     67      8       8     8.3      0    685    1    100.0   30 
2256	181	2012-11-30 15:05:01.62	2012-11-30 15:00:00	11/30/12  3:00p    5.7    5.8    5.7    82    2.8   0.0     E   0.00   4.8   ENE    5.7    5.5    5.5  1006.8  0.00   0.0   0.264   0.000   18.9    45    6.7   17.8   8.53 1.1896    13.3     67      8       8     8.3     10    695    1    100.0   30 
2257	181	2012-11-30 16:05:21.791	2012-11-30 15:30:00	11/30/12  3:30p    5.4    5.7    5.4    83    2.8   0.0     E   0.00   8.0   ENE    5.4    5.3    5.3  1007.3  0.00   0.0   0.269   0.000   19.0    45    6.8   17.8   8.53 1.1900    13.3     67      8       8     8.3     14    694    1    100.0   30 
2258	181	2012-11-30 16:05:22.034	2012-11-30 16:00:00	11/30/12  4:00p    5.3    5.5    5.3    83    2.6   1.6     E   0.80  12.9   ENE    5.3    5.2    5.2  1007.4  0.00   0.0   0.272   0.000   19.0    45    6.8   17.8   8.53 1.1901    13.3     66      8       8     8.3     15    691    1    100.0   30 
2259	181	2012-11-30 17:05:41.818	2012-11-30 16:30:00	11/30/12  4:30p    4.9    5.3    4.9    86    2.8   0.0     E   0.00   4.8   ESE    4.9    4.8    4.8  1007.9  0.20   0.0   0.279   0.000   19.1    45    6.9   18.0   8.52 1.1902    13.3     65      8       8     8.3     10    694    1    100.0   30 
2260	181	2012-11-30 17:05:42.068	2012-11-30 17:00:00	11/30/12  5:00p    4.6    4.9    4.6    87    2.6   0.0   SSE   0.00   4.8   ENE    4.6    4.5    4.5  1007.8  0.20   0.0   0.286   0.000   19.2    45    7.0   18.1   8.52 1.1895    13.3     65      8       8     8.3      6    680    1     99.4   30 
2261	181	2012-11-30 18:04:03.979	2012-11-30 17:30:00	11/30/12  5:30p    4.4    4.6    4.4    89    2.8   0.0     E   0.00   1.6    SE    4.4    4.4    4.4  1007.9  0.00   0.0   0.289   0.000   19.3    45    7.0   18.2   8.52 1.1894    13.3     65      8       8     8.3      5    702    1    100.0   30 
2262	181	2012-11-30 18:04:04.245	2012-11-30 18:00:00	11/30/12  6:00p    4.2    4.4    4.2    90    2.7   0.0   SSE   0.00   3.2   SSE    4.2    4.1    4.1  1008.3  0.00   0.0   0.295   0.000   19.3    45    7.0   18.2   8.52 1.1898    13.3     65      8       8     8.3      4    688    1    100.0   30 
2263	181	2012-11-30 19:04:26.376	2012-11-30 18:30:00	11/30/12  6:30p    4.1    4.2    4.0    90    2.6   0.0   ---   0.00   0.0   ---    4.1    4.0    4.0  1008.6  0.00   0.0   0.297   0.000   19.4    45    7.1   18.3   8.51 1.1897    13.3     66      8       8     8.3      4    690    1    100.0   30 
2264	181	2012-11-30 19:04:26.62	2012-11-30 19:00:00	11/30/12  7:00p    4.0    4.1    3.9    92    2.8   0.0   ---   0.00   0.0   ---    4.0    3.9    3.9  1009.0  0.00   0.0   0.299   0.000   19.4    45    7.1   18.3   8.51 1.1901    13.3     66      8       8     8.3      4    696    1    100.0   30 
2281	181	2012-11-30 20:04:20.037	2012-11-30 19:30:00	11/30/12  7:30p    3.8    4.0    3.8    93    2.8   0.0   ---   0.00   0.0   ---    3.8    3.8    3.8  1009.4  0.00   0.0   0.302   0.000   19.4    45    7.1   18.3   8.51 1.1906    13.3     66      8       8     8.3      4    691    1    100.0   30 
2282	181	2012-11-30 20:04:20.431	2012-11-30 20:00:00	11/30/12  8:00p    4.1    4.1    3.8    90    2.6   0.0     E   0.00  11.3     E    4.1    4.0    4.0  1009.7  0.00   0.0   0.297   0.000   19.4    45    7.1   18.3   8.51 1.1910    13.3     67      8       8     8.3      3    695    1    100.0   30 
2301	181	2012-11-30 21:04:03.756	2012-11-30 20:30:00	11/30/12  8:30p    4.6    4.6    4.1    86    2.5   3.2     E   1.61   9.7     E    4.5    4.5    4.4  1010.0  0.00   0.0   0.286   0.000   19.3    45    7.0   18.2   8.52 1.1919    13.3     67      8       7     8.3      1    689    1    100.0   30 
2302	181	2012-11-30 21:04:04.101	2012-11-30 21:00:00	11/30/12  9:00p    4.5    4.6    4.5    86    2.4   1.6     E   0.80   8.0     E    4.5    4.4    4.4  1010.3  0.00   0.0   0.288   0.000   19.3    45    7.0   18.2   8.52 1.1922    13.3     67      8       8     8.3      1    691    1    100.0   30 
2303	181	2012-11-30 22:04:30.976	2012-11-30 21:30:00	11/30/12  9:30p    4.4    4.6    4.4    90    2.9   0.0     E   0.00   3.2     E    4.4    4.4    4.4  1011.0  0.00   0.0   0.289   0.000   19.2    45    7.0   18.1   8.52 1.1933    13.3     67      8       8     8.3      1    699    1    100.0   30 
2304	181	2012-11-30 22:04:31.391	2012-11-30 22:00:00	11/30/12 10:00p    4.3    4.4    4.3    89    2.7   0.0     E   0.00   3.2     E    4.3    4.3    4.3  1011.0  0.00   0.0   0.292   0.000   19.1    45    6.9   18.0   8.52 1.1939    13.3     67      8       8     7.8      1    684    1    100.0   30 
2321	181	2012-11-30 23:04:21.116	2012-11-30 22:30:00	11/30/12 10:30p    4.3    4.3    4.3    88    2.5   1.6     E   0.80   8.0     E    4.3    4.3    4.3  1011.0  0.00   0.0   0.292   0.000   19.0    45    6.8   17.8   8.53 1.1944    13.3     67      8       8     7.8      0    691    1    100.0   30 
2322	181	2012-11-30 23:04:21.426	2012-11-30 23:00:00	11/30/12 11:00p    4.3    4.4    4.3    86    2.2   1.6     E   0.80   9.7     E    4.3    4.2    4.2  1011.2  0.00   0.0   0.292   0.000   18.8    44    6.3   17.6   8.35 1.1957    13.3     67      8       8     7.8      0    693    1    100.0   30 
\.


--
-- Data for Name: s_sensors; Type: TABLE DATA; Schema: public; Owner: dsauer
--

COPY s_sensors (id, group_id, user_id, name, description, last_update, active, visible, sensor_class) FROM stdin;
249	181	1	DegreeDay	Faktor zagrijavanja/hlađenja	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_DegreeDay
250	181	1	Dew pt.	Senzor vlage lista	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Wetness
251	181	1	EMC	Equilibrium moisture content	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_EMC
252	181	1	In Temp, In heat	Senzor temperature	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Temperature
253	181	1	In Dew	Senzor vlage lista	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Wetness
254	181	1	In Hum	Senzor vlage zraka	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Humidity
255	181	1	Hum 2nd	Senzor vlage zraka	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Humidity
256	181	1	Temp 2nd	Senzor temperature	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Temperature
257	181	1	Soil Temp 1	Senzor temperature	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Temperature
258	181	1	In Air Density	Prosjećna gustoća	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Density
259	181	1	Leaf Wet 1	Senzor vlage lista	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Wetness
241	181	1	Temp Out	Temp Out, Hi Temp, Low Temp	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Temperature
242	181	1	Out Hum	Senzor vlage zraka	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Humidity
244	181	1	Soil 3 Moist	Senzor vlage u nekom materijalu	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Moisture
245	181	1	Soil 4 Moist	Senzor vlage u nekom materijalu	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Moisture
246	181	1	Raint, Rain rate	Senzor količine padalina	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Rain
247	181	1	Bar	Senzor pritiska	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Pressure
248	181	1	Wind	Sensor za vjetar	\N	t	t	module.sensor.sensor.vendor.davis.meteohub.MeteoHub_Wind
\.


--
-- Name: pk_c_users; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY c_users
    ADD CONSTRAINT pk_c_users PRIMARY KEY (id);


--
-- Name: pk_s_data_customs; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_customs
    ADD CONSTRAINT pk_s_data_customs PRIMARY KEY (id);


--
-- Name: pk_s_data_degree_days; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_degree_days
    ADD CONSTRAINT pk_s_data_degree_days PRIMARY KEY (id);


--
-- Name: pk_s_data_densitys; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_densitys
    ADD CONSTRAINT pk_s_data_densitys PRIMARY KEY (id);


--
-- Name: pk_s_data_emc; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_emc
    ADD CONSTRAINT pk_s_data_emc PRIMARY KEY (id);


--
-- Name: pk_s_data_humiditys; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_humiditys
    ADD CONSTRAINT pk_s_data_humiditys PRIMARY KEY (id);


--
-- Name: pk_s_data_moistures; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_moistures
    ADD CONSTRAINT pk_s_data_moistures PRIMARY KEY (id);


--
-- Name: pk_s_data_pressures; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_pressures
    ADD CONSTRAINT pk_s_data_pressures PRIMARY KEY (id);


--
-- Name: pk_s_data_rains; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_rains
    ADD CONSTRAINT pk_s_data_rains PRIMARY KEY (id);


--
-- Name: pk_s_data_temperatures; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_temperatures
    ADD CONSTRAINT pk_s_data_temperatures PRIMARY KEY (id);


--
-- Name: pk_s_data_temperatures_high_low; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_temperatures_high_low
    ADD CONSTRAINT pk_s_data_temperatures_high_low PRIMARY KEY (id);


--
-- Name: pk_s_data_wetness; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_wetness
    ADD CONSTRAINT pk_s_data_wetness PRIMARY KEY (id);


--
-- Name: pk_s_data_winds; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_winds
    ADD CONSTRAINT pk_s_data_winds PRIMARY KEY (id);


--
-- Name: pk_s_data_winds_high_low; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_data_winds_high_low
    ADD CONSTRAINT pk_s_data_winds_high_low PRIMARY KEY (id);


--
-- Name: pk_s_sensor_group_properties; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_sensor_group_properties
    ADD CONSTRAINT pk_s_sensor_group_properties PRIMARY KEY (id);


--
-- Name: pk_s_sensor_groups; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_sensor_groups
    ADD CONSTRAINT pk_s_sensor_groups PRIMARY KEY (id);


--
-- Name: pk_s_sensor_properties; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_sensor_properties
    ADD CONSTRAINT pk_s_sensor_properties PRIMARY KEY (id);


--
-- Name: pk_s_sensor_raw_data; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_sensor_raw_data
    ADD CONSTRAINT pk_s_sensor_raw_data PRIMARY KEY (id);


--
-- Name: pk_s_sensors; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY s_sensors
    ADD CONSTRAINT pk_s_sensors PRIMARY KEY (id);


--
-- Name: play_evolutions_pkey; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY play_evolutions
    ADD CONSTRAINT play_evolutions_pkey PRIMARY KEY (id);


--
-- Name: uq_c_users_email; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY c_users
    ADD CONSTRAINT uq_c_users_email UNIQUE (email);


--
-- Name: uq_c_users_user_name; Type: CONSTRAINT; Schema: public; Owner: dsauer; Tablespace: 
--

ALTER TABLE ONLY c_users
    ADD CONSTRAINT uq_c_users_user_name UNIQUE (user_name);


--
-- Name: ix_s_data_customs_sensor_4; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_customs_sensor_4 ON s_data_customs USING btree (sensor_id);


--
-- Name: ix_s_data_customs_sensordata_5; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_customs_sensordata_5 ON s_data_customs USING btree (sensor_data_id);


--
-- Name: ix_s_data_degree_days_sensor_6; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_degree_days_sensor_6 ON s_data_degree_days USING btree (sensor_id);


--
-- Name: ix_s_data_degree_days_sensorda_7; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_degree_days_sensorda_7 ON s_data_degree_days USING btree (sensor_data_id);


--
-- Name: ix_s_data_densitys_sensor_8; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_densitys_sensor_8 ON s_data_densitys USING btree (sensor_id);


--
-- Name: ix_s_data_densitys_sensordata_9; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_densitys_sensordata_9 ON s_data_densitys USING btree (sensor_data_id);


--
-- Name: ix_s_data_emc_sensor_10; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_emc_sensor_10 ON s_data_emc USING btree (sensor_id);


--
-- Name: ix_s_data_emc_sensordata_11; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_emc_sensordata_11 ON s_data_emc USING btree (sensor_data_id);


--
-- Name: ix_s_data_humiditys_sensor_12; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_humiditys_sensor_12 ON s_data_humiditys USING btree (sensor_id);


--
-- Name: ix_s_data_humiditys_sensordat_13; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_humiditys_sensordat_13 ON s_data_humiditys USING btree (sensor_data_id);


--
-- Name: ix_s_data_moistures_sensor_14; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_moistures_sensor_14 ON s_data_moistures USING btree (sensor_id);


--
-- Name: ix_s_data_moistures_sensordat_15; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_moistures_sensordat_15 ON s_data_moistures USING btree (sensor_data_id);


--
-- Name: ix_s_data_pressures_sensor_16; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_pressures_sensor_16 ON s_data_pressures USING btree (sensor_id);


--
-- Name: ix_s_data_pressures_sensordat_17; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_pressures_sensordat_17 ON s_data_pressures USING btree (sensor_data_id);


--
-- Name: ix_s_data_rains_sensor_18; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_rains_sensor_18 ON s_data_rains USING btree (sensor_id);


--
-- Name: ix_s_data_rains_sensordata_19; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_rains_sensordata_19 ON s_data_rains USING btree (sensor_data_id);


--
-- Name: ix_s_data_temperatures_high_l_22; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_temperatures_high_l_22 ON s_data_temperatures_high_low USING btree (sensor_id);


--
-- Name: ix_s_data_temperatures_high_l_23; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_temperatures_high_l_23 ON s_data_temperatures_high_low USING btree (sensor_data_id);


--
-- Name: ix_s_data_temperatures_sensor_20; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_temperatures_sensor_20 ON s_data_temperatures USING btree (sensor_id);


--
-- Name: ix_s_data_temperatures_sensor_21; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_temperatures_sensor_21 ON s_data_temperatures USING btree (sensor_data_id);


--
-- Name: ix_s_data_wetness_sensor_24; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_wetness_sensor_24 ON s_data_wetness USING btree (sensor_id);


--
-- Name: ix_s_data_wetness_sensordata_25; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_wetness_sensordata_25 ON s_data_wetness USING btree (sensor_data_id);


--
-- Name: ix_s_data_winds_high_low_sens_28; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_winds_high_low_sens_28 ON s_data_winds_high_low USING btree (sensor_id);


--
-- Name: ix_s_data_winds_high_low_sens_29; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_winds_high_low_sens_29 ON s_data_winds_high_low USING btree (sensor_data_id);


--
-- Name: ix_s_data_winds_sensor_26; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_winds_sensor_26 ON s_data_winds USING btree (sensor_id);


--
-- Name: ix_s_data_winds_sensordata_27; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_data_winds_sensordata_27 ON s_data_winds USING btree (sensor_data_id);


--
-- Name: ix_s_sensor_group_properties__31; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_sensor_group_properties__31 ON s_sensor_group_properties USING btree (group_id);


--
-- Name: ix_s_sensor_groups_user_30; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_sensor_groups_user_30 ON s_sensor_groups USING btree (user_id);


--
-- Name: ix_s_sensor_properties_sensor_32; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_sensor_properties_sensor_32 ON s_sensor_properties USING btree (sensor_id);


--
-- Name: ix_s_sensor_raw_data_group_3; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_sensor_raw_data_group_3 ON s_sensor_raw_data USING btree (group_id);


--
-- Name: ix_s_sensors_group_1; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_sensors_group_1 ON s_sensors USING btree (group_id);


--
-- Name: ix_s_sensors_user_2; Type: INDEX; Schema: public; Owner: dsauer; Tablespace: 
--

CREATE INDEX ix_s_sensors_user_2 ON s_sensors USING btree (user_id);


--
-- Name: fk_s_data_customs_sensor_4; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_customs
    ADD CONSTRAINT fk_s_data_customs_sensor_4 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_customs_sensordata_5; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_customs
    ADD CONSTRAINT fk_s_data_customs_sensordata_5 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_degree_days_sensor_6; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_degree_days
    ADD CONSTRAINT fk_s_data_degree_days_sensor_6 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_degree_days_sensorda_7; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_degree_days
    ADD CONSTRAINT fk_s_data_degree_days_sensorda_7 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_densitys_sensor_8; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_densitys
    ADD CONSTRAINT fk_s_data_densitys_sensor_8 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_densitys_sensordata_9; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_densitys
    ADD CONSTRAINT fk_s_data_densitys_sensordata_9 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_emc_sensor_10; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_emc
    ADD CONSTRAINT fk_s_data_emc_sensor_10 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_emc_sensordata_11; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_emc
    ADD CONSTRAINT fk_s_data_emc_sensordata_11 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_humiditys_sensor_12; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_humiditys
    ADD CONSTRAINT fk_s_data_humiditys_sensor_12 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_humiditys_sensordat_13; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_humiditys
    ADD CONSTRAINT fk_s_data_humiditys_sensordat_13 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_moistures_sensor_14; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_moistures
    ADD CONSTRAINT fk_s_data_moistures_sensor_14 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_moistures_sensordat_15; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_moistures
    ADD CONSTRAINT fk_s_data_moistures_sensordat_15 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_pressures_sensor_16; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_pressures
    ADD CONSTRAINT fk_s_data_pressures_sensor_16 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_pressures_sensordat_17; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_pressures
    ADD CONSTRAINT fk_s_data_pressures_sensordat_17 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_rains_sensor_18; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_rains
    ADD CONSTRAINT fk_s_data_rains_sensor_18 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_rains_sensordata_19; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_rains
    ADD CONSTRAINT fk_s_data_rains_sensordata_19 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_temperatures_high_l_22; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_temperatures_high_low
    ADD CONSTRAINT fk_s_data_temperatures_high_l_22 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_temperatures_high_l_23; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_temperatures_high_low
    ADD CONSTRAINT fk_s_data_temperatures_high_l_23 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_temperatures_sensor_20; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_temperatures
    ADD CONSTRAINT fk_s_data_temperatures_sensor_20 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_temperatures_sensor_21; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_temperatures
    ADD CONSTRAINT fk_s_data_temperatures_sensor_21 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_wetness_sensor_24; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_wetness
    ADD CONSTRAINT fk_s_data_wetness_sensor_24 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_wetness_sensordata_25; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_wetness
    ADD CONSTRAINT fk_s_data_wetness_sensordata_25 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_winds_high_low_sens_28; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_winds_high_low
    ADD CONSTRAINT fk_s_data_winds_high_low_sens_28 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_winds_high_low_sens_29; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_winds_high_low
    ADD CONSTRAINT fk_s_data_winds_high_low_sens_29 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_data_winds_sensor_26; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_winds
    ADD CONSTRAINT fk_s_data_winds_sensor_26 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_data_winds_sensordata_27; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_data_winds
    ADD CONSTRAINT fk_s_data_winds_sensordata_27 FOREIGN KEY (sensor_data_id) REFERENCES s_sensor_raw_data(id);


--
-- Name: fk_s_sensor_group_properties__31; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_sensor_group_properties
    ADD CONSTRAINT fk_s_sensor_group_properties__31 FOREIGN KEY (group_id) REFERENCES s_sensor_groups(id);


--
-- Name: fk_s_sensor_groups_user_30; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_sensor_groups
    ADD CONSTRAINT fk_s_sensor_groups_user_30 FOREIGN KEY (user_id) REFERENCES c_users(id);


--
-- Name: fk_s_sensor_properties_sensor_32; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_sensor_properties
    ADD CONSTRAINT fk_s_sensor_properties_sensor_32 FOREIGN KEY (sensor_id) REFERENCES s_sensors(id);


--
-- Name: fk_s_sensor_raw_data_group_3; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_sensor_raw_data
    ADD CONSTRAINT fk_s_sensor_raw_data_group_3 FOREIGN KEY (group_id) REFERENCES s_sensor_groups(id);


--
-- Name: fk_s_sensors_group_1; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_sensors
    ADD CONSTRAINT fk_s_sensors_group_1 FOREIGN KEY (group_id) REFERENCES s_sensor_groups(id);


--
-- Name: fk_s_sensors_user_2; Type: FK CONSTRAINT; Schema: public; Owner: dsauer
--

ALTER TABLE ONLY s_sensors
    ADD CONSTRAINT fk_s_sensors_user_2 FOREIGN KEY (user_id) REFERENCES c_users(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

